export {};

declare global {
    interface Window {
        adobeDataLayer: Array<Record<string, any>>;
    }
}

/**
 * HTML Types
 */

declare module '*.html' {
	const value: string;
	export default value;
}

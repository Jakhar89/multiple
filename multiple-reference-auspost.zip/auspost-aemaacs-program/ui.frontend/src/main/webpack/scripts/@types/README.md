# Custom type definitions

Use this folder for defining modules for file types and languages, libraries and plugins that don't have any existing types.

Most type definitions should come from the source library/plugin or the [DefinitelyTypes](https://github.com/DefinitelyTyped) project.

Failing that, create the file you need to type and declare any relevant interfaces and modules in this folder.

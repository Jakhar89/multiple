import { liquidEngine } from '~/../../../jest.config';
import { optionFieldsData } from './analytics';
import { allFormFieldsWithErrors, formCheckboxField, formDropdown, formFields, formRadioButton, formWithMultipleOption } from '~/patterns/components/forms/_forms.mock';

describe('forms Component', () => {
  beforeEach(async () => {
    const html = await liquidEngine.renderFile(
      'src/main/webpack/patterns/components/forms/forms.liquid',
      {
        fields: formFields, dropdownFields: formDropdown, radioFields: formRadioButton, checkboxFields: {
          ...formWithMultipleOption,
          required: true
        }
      }
    );
    document.body.innerHTML = html;
  });

  it('collects select, radio, single checkbox and checkbox groups in optionFieldsData', () => {
    const form = document.querySelector('form') as HTMLFormElement;
    const select = form.querySelector('select#dropdown-id') as HTMLSelectElement;
    select.value = 'option2';
    form.querySelectorAll('input[type="checkbox"]')[1].setAttribute('checked', 'true');
    form.querySelectorAll('input[type="checkbox"]')[2].setAttribute('checked', 'true');
    form.querySelectorAll('input[type="radio"]')[0].setAttribute('checked', 'true');

    expect(optionFieldsData(form)).toEqual({
      "dropdown-name": "option2", "radio-name": "Option1", "servicesInterested": [
        "international_parcels",
        "lettetr_service",
      ],
    });
  });
});



describe('optionFieldsData checkbox', () => {
  beforeEach(async () => {
    const html = await liquidEngine.renderFile(
      'src/main/webpack/patterns/components/forms/forms.liquid',
      {
        checkboxFields: {
          ...{
            type: 'checkbox',
            id: 'checkbox-id',
            name: 'servicesInterested',
            title: 'What service(s) are you interested in? ',
            helpMessage: 'You may select more than one option',


            options: [
              {
                value: 'domestic_parcels',
                text: 'Domestic parcels',
                selected: false,
                disabled: false,
              },
            ],

          }
        }
      }
    );
    document.body.innerHTML = html;
  });
  it('sets single checkbox value when only one checkbox exists', async () => {
    const form = document.querySelector('form') as HTMLFormElement;
    const checkbox = form.querySelector('input[type="checkbox"]') as HTMLInputElement;
    checkbox.checked = true;
    const result = optionFieldsData(form);
    expect(result.servicesInterested).toBe('domestic_parcels');
  });

  it('sets single checkbox to "false" if not checked', () => {
    const form = document.querySelector('form') as HTMLFormElement;
    (form.querySelectorAll('input[type="checkbox"]')[0] as HTMLInputElement).checked = false;
    const result = optionFieldsData(form);
    expect(result.testCheckbox).toBe(undefined);
  });
});

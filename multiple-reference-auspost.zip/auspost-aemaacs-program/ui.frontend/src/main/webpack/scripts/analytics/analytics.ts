import { AnalticsFormData } from '~/patterns/components/forms/interfaces';

window.adobeDataLayer = window.adobeDataLayer || [];

// Generic function to push any component data Adobe Data Layer
export function pushToAdobeDataLayer(data: Record<string, any>) {
  window.adobeDataLayer.push(data);
}

// Check if Form submitted successfully after redirection
if (sessionStorage.getItem('formInteractionDataStored')) {
  handleFormAnalyticsOnSubmit();
}

export function handleFormAnalyticsOnSubmit() {
  const stateOfForm = sessionStorage.getItem('formSubmitted');
  if (!stateOfForm) {
    return;
  }

  const apiErrorMessage = document.querySelector('.cmp-form-error__item')?.textContent?.trim();
  if (apiErrorMessage) {
    pushFormDataToDataLayer('submit-error', 'single-page', [apiErrorMessage]);
    sessionStorage.removeItem('formSubmitted');
  } else {
    pushFormDataToDataLayer('submit', 'single-page', []);
    sessionStorage.removeItem('formSubmitted');
  }
}

export function optionFieldsData(form: HTMLFormElement): Record<string, string | string[]> {
  const options: Record<string, string | string[]> = {};

  // Selects
  const selects = Array.from(form.querySelectorAll('select')) as HTMLSelectElement[];
  selects.forEach(sel => {
    const name = sel.name || sel.id;
    if (!name) return;
    options[name] = sel.value;
  });

  // Radio groups - record the selected value for each named group
  const radios = Array.from(form.querySelectorAll('input[type="radio"]')) as HTMLInputElement[];
  const radioGroups: Record<string, string> = {};
  radios.forEach(r => {
    const name = r.name || r.id;
    if (!name) return;
    if (r.checked) radioGroups[name] = r.value;
  });
  Object.keys(radioGroups).forEach(k => options[k] = radioGroups[k]);

  // Checkboxes - collect values for each named checkbox group. If single checkbox, record its value or "true"/"false".
  const checkboxes = Array.from(form.querySelectorAll('input[type="checkbox"]')) as HTMLInputElement[];
  const checkboxGroups: Record<string, string[]> = {};
  checkboxes.forEach(cb => {
    const name = cb.name || cb.id;
    if (!name) return;
    if (!checkboxGroups[name]) checkboxGroups[name] = [];
    if (cb.checked) checkboxGroups[name].push(cb.value || 'true');
  });

  Object.keys(checkboxGroups).forEach(name => {
    // if only one checkbox element with that name exists, coerce to single value
    const elCount = form.querySelectorAll(`input[type="checkbox"][name="${name}"]`).length || form.querySelectorAll(`#${name}`).length;
    if (elCount === 1) {
      options[name] = checkboxGroups[name][0] ?? 'false';
    } else {
      options[name] = checkboxGroups[name];
    }
  });

  return options;
};

export function attachOptionsToDataObject(formId: string): Record<string, string | string[]> {
  // Try to attach option fields from the actual form element in the DOM
  let options;
  try {
    const formEl = document.getElementById(formId) as HTMLFormElement | null;
    if (formEl) {
      options = optionFieldsData(formEl);
      if (Object.keys(options).length > 0) {
        return options;
      }
    }
  } catch (e) {
    console.error('Error collecting form option fields for analytics', e);
  }
  return {};
}

// Create Form Data Object to pass to Adobe data Layer
export function pushFormDataToDataLayer(stage: string, step: string, errorList: string[]) {
  const formData = sessionStorage.getItem('formInteractionDataStored');
  if (formData) {
    const { formId, name, referenceId } = JSON.parse(formData) as {
      formId: string;
      referenceId: string;
      name: string;
    };

    const dataObject: AnalticsFormData = {
      'event': 'form-event',
      'eventCategory': `forms||${formId}`,
      'eventDescription': `${stage}||${step}`,
      formInfo: {
        'name': `${name}`,
        'details': `${name}`,
        'id': `${formId}`,
        'stage': `${stage}`,
        'step': `${step}`,
        'referenceId': `${referenceId}`
      }
    };

    if (stage === 'submit') {
      dataObject.formInfo.status = 'success';
      dataObject.formInfo.options = attachOptionsToDataObject(formId);
    } else if (stage === 'submit-error') {
      dataObject.formInfo.status = 'submit-error';
      if (errorList.length > 0) {
        dataObject.formInfo.error = errorList;
      }
      dataObject.formInfo.options = attachOptionsToDataObject(formId);
    } else if (stage === 'field-error') {
      dataObject.formInfo.status = 'field-error';
      if (errorList.length > 0) {
        dataObject.formInfo.error = errorList;
      }
    }

    pushToAdobeDataLayer(dataObject);
  }
}

// Helper function to create data layer object with element ID
function createDataLayerWithElement(elementId: string, data: Record<string, any>): string {
  return JSON.stringify({ [elementId]: data });
}

// Helper function to create search interaction data
function createSearchInteractionData(eventCategory: string, eventDescription: string, additionalData?: Record<string, any>) {
  return {
    event: 'search-interaction',
    eventCategory,
    eventDescription,
    ...additionalData
  };
}

// Create Search Results Data Layer
export function createSearchResultsDataLayer(
  searchResultsId: string,
  searchQuery: string,
  totalResults: number
): string {
  return createDataLayerWithElement(searchResultsId, {
    event: 'search-impression',
    eventCategory: 'int-search||search-results',
    eventDescription: searchQuery,
    searchResult: String(totalResults)
  });
}

// Push Search Results Data to Adobe Data Layer
export function pushSearchResultsToDataLayer(searchQuery: string, totalResults: number): void {
  pushToAdobeDataLayer({
    event: 'search-impression',
    eventCategory: 'int-search||search-results',
    eventDescription: searchQuery,
    searchResult: String(totalResults)
  });
}

// Create individual Search Result Link Data Layer
export function createSearchResultLinkDataLayer(elementId: string, searchQuery: string, linkUrl: string): string {
  return createDataLayerWithElement(elementId, createSearchInteractionData('int-search||search-result', searchQuery, { linkUrl }));
}

// Push Search Result Link Data to Adobe Data Layer
export function pushSearchResultLinkToDataLayer(searchQuery: string, linkUrl: string): void {
  pushToAdobeDataLayer(createSearchInteractionData('int-search||search-result', searchQuery, { linkUrl }));
}

// Create Popular Search Data Layer
export function createPopularSearchDataLayer(elementId: string, keyword: string): string {
  return createDataLayerWithElement(elementId, createSearchInteractionData('int-search||popular-search', keyword));
}

// Push Popular Search Data to Adobe Data Layer
export function pushPopularSearchToDataLayer(keyword: string): void {
  pushToAdobeDataLayer(createSearchInteractionData('int-search||popular-search', keyword));
}

// Create Suggested Search Data Layer
export function createSuggestedSearchDataLayer(elementId: string, keyword: string): string {
  return createDataLayerWithElement(elementId, createSearchInteractionData('int-search||suggested-search', keyword));
}

// Push Suggested Search Data to Adobe Data Layer
export function pushSuggestedSearchToDataLayer(keyword: string): void {
  pushToAdobeDataLayer(createSearchInteractionData('int-search||suggested-search', keyword));
}

export enum ResponseFormat {
    Json = 0,
    Html = 1,
    Blob = 2
}

export async function fetchApiGet<T>(url: string, responseFormat = ResponseFormat.Json): Promise<string | Blob | T> {
    try {
        const response = await fetch(url);
        switch (responseFormat) {
            case ResponseFormat.Json:
                return (await response.json()) as T;
            case ResponseFormat.Html:
                return (await response.text());
            case ResponseFormat.Blob:
                return (await response.blob());
            default:
                return (await response.json()) as T;
        }
    } catch (error) {
        console.error('Error fetching:', error);
        return '';
    }
}

export async function fetchApiPost(
    url: string,
    data: unknown,
    responseFormat = ResponseFormat.Json,
    headers: Record<string, string> = { 'Content-Type': 'application/json' },
    onError?: (error: unknown) => void
): Promise<string | Blob> {
    try {
        const body: BodyInit | null = headers['Content-Type']?.includes('application/json')
            ? JSON.stringify(data)
            : (data as BodyInit);

        const response = await fetch(url, {
            method: 'POST',
            headers,
            body
        });

        if (!response.ok) {
            const error = new Error(`HTTP ${response.status} ${response.statusText}`);
            if (onError) onError(error);
            throw error;
        }

        switch (responseFormat) {
            case ResponseFormat.Json:
                return await response.json();
            case ResponseFormat.Html:
                return await response.text();
            case ResponseFormat.Blob:
                return await response.blob();
            default:
                return await response.json();
        }
    } catch (error) {
        console.error('Error fetching:', error);
        if (onError) onError(error);
        throw error;
    }
}

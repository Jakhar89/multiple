export function isDevMode() {
    return window.location.host == 'localhost:6006';
}

export function getIconPath() {
    let path = '/etc.clientlibs/auspost-aemaacs-program/clientlibs/clientlib-site/resources/icons';
    if (isDevMode()) {
        path = '/src/main/webpack/resources/icons';
    }
    return path;
}

export function decodeHtmlEntities(encodedStr: string): string {
    const txt = document.createElement('textarea');
    txt.innerHTML = encodedStr;
    return txt.value;
}

// Restricts focus to a container
export function createFocusTrap(container: HTMLElement, excludeElements: HTMLElement[] = []) {
  const originalTabindexes = new Map<HTMLElement, string | null>();
  let isActive = false;

  const getFocusableElements = (): NodeListOf<HTMLElement> => {
    return document.querySelectorAll<HTMLElement>(
      'a, button, iframe, input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
  };
  
  const enable = () => {
    if (isActive) { return; }

    // For iOS/mobile
    document.querySelector('main')?.setAttribute('aria-hidden', 'true');
    document.querySelector('footer')?.setAttribute('aria-hidden', 'true');
    
    // For desktop
    const allFocusable = getFocusableElements();
    allFocusable.forEach(el => {
      if (container.contains(el) || excludeElements.includes(el)) { return; }
      
      if (!originalTabindexes.has(el)) {
        originalTabindexes.set(el, el.getAttribute('aria'));
        el.setAttribute('tabindex', '-1');
      }
    });
    isActive = true;
  };
  
  const disable = () => {
    if (!isActive) { return; }

    // Remove aria-hidden for iOS/mobile
    document.querySelector('main')?.removeAttribute('aria-hidden');
    document.querySelector('footer')?.removeAttribute('aria-hidden');
    
    // Restore tabindex for desktop
    originalTabindexes.forEach((originalValue, el) => {
      if (!document.body.contains(el)) { return; }
      
      if (originalValue === null) {
        el.removeAttribute('tabindex');
      } else {
        el.setAttribute('tabindex', originalValue);
      }
    });
    originalTabindexes.clear();
    
    isActive = false;
  };
  
  return { 
    enable,
    disable, 
    isActive: () => isActive 
  };
}

export const isTouchDevice = (): boolean => {
  if(typeof window === 'undefined' ||!window.matchMedia){
    return false;
  }
  return (
    window.matchMedia('(hover: none)').matches ||
    window.matchMedia('(pointer: coarse)').matches
  );
};

export function stripTags(html: string): string {
  if (!html) return '';
  if (typeof document !== 'undefined') {
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || '';
  }
  return html.replace(/<\/?[^>]+(>|$)/g, '');
}

export function handleCardClick(cards: NodeListOf<HTMLElement>) {

      Array.prototype.forEach.call(cards, card => { 
      
       card.style.cursor = 'pointer';

       const cardClickableItem = card.querySelector('.cmp-button');

          card.addEventListener('click', (event: any) => {
              const target = event.target as HTMLElement;

              if(target.closest('.cmp-button, a')){
                return;
              }

              const selection = window.getSelection();
              if(selection && selection.toString().length > 0 ){
                return;
              }

              if(cardClickableItem && cardClickableItem instanceof HTMLAnchorElement){
                cardClickableItem.click();
              }
          });
      });
    };

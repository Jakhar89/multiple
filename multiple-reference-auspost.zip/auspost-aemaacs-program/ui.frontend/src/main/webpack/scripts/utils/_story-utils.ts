const iconPaths = import.meta.glob<string[]>('/src/main/webpack/resources/icons/*.svg');

// Get a list of available SVG icons under `/resources/icons`
export function getIconList() {
  return Object.keys(iconPaths).map((path) => {
    const filename = path.split('/').pop() ?? '';
    return filename.split('.').slice(0, -1).join('.');
  })
}

// Wait for an UI to be available in DOM
export function waitForUIToRenderInDOM(selector: string, callback: (component: HTMLElement) => void, intervalMs: number = 100) {
  const interval = setInterval(() => {
    const component = document.querySelector(selector) as HTMLFormElement | null;
    if (component) {
      clearInterval(interval);
      callback(component);
    }
  }, intervalMs);
};


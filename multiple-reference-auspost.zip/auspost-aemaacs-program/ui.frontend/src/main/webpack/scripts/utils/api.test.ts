import { fetchApiPost, ResponseFormat } from './api';

describe('fetchApiPost', () => {
  const originalFetch = global.fetch;

  afterEach(() => {
    jest.resetAllMocks();
    global.fetch = originalFetch as unknown as typeof fetch;
  });

  test('posts JSON and returns parsed JSON on success', async () => {
    const mockJson = { ok: true, data: { id: 1 } };

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      status: 200,
      statusText: 'OK',
      json: jest.fn().mockResolvedValue(mockJson),
      text: jest.fn(),
      blob: jest.fn()
    } as unknown as Response);

    const url = '/api/test';
    const payload = { name: 'test' };

    const result = await fetchApiPost(url, payload, ResponseFormat.Json);

    expect(global.fetch).toHaveBeenCalledWith(url, expect.objectContaining({
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }));

    expect(result).toEqual(mockJson);
  });

  test('uses provided headers, sends raw body, and returns text', async () => {
    const mockText = 'ok';

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      status: 200,
      statusText: 'OK',
      text: jest.fn().mockResolvedValue(mockText),
      json: jest.fn(),
      blob: jest.fn()
    } as unknown as Response);

    const url = '/api/plain';
    const headers = { 'Content-Type': 'text/plain' };
    const body = 'a=1&b=2';

    const result = await fetchApiPost(url, body, ResponseFormat.Html, headers);

    expect(global.fetch).toHaveBeenCalledWith(url, expect.objectContaining({
      method: 'POST',
      headers,
      body
    }));

    expect(result).toBe(mockText);
  });

  test('calls onError and throws on non-ok response', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 500,
      statusText: 'Server Error',
      json: jest.fn(),
      text: jest.fn(),
      blob: jest.fn()
    } as unknown as Response);

    const url = '/api/fail';
    const onError = jest.fn();

    await expect(fetchApiPost(url, { a: 1 }, ResponseFormat.Json, undefined as any, onError)).rejects.toThrow('HTTP 500 Server Error');
    expect(onError).toHaveBeenCalled();
  });
});

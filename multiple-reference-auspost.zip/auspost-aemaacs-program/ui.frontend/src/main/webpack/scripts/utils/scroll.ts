
export function scrollTo(element: any) {
     window.scrollTo({top:element, behavior: 'smooth'});
}

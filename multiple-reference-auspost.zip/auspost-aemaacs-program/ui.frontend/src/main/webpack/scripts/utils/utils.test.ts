import { stripTags } from './utils';

describe('stripTags', () => {
  test('returns empty string for empty input', () => {
    expect(stripTags('')).toBe('');
  });

  test('removes HTML tags and keeps text', () => {
    const html = '<p>Hello <strong>World</strong></p>';
    expect(stripTags(html)).toBe('Hello World');
  });

  test('decodes HTML entities when DOM is available', () => {
    const html = 'Research &amp; Development';
    expect(stripTags(html)).toBe('Research & Development');
  });

  test('handles nested tags and attributes', () => {
    const html = '<div class="x">X<span>Y</span></div>';
    expect(stripTags(html)).toBe('XY');
  });

  test('fallback without document does not decode entities', () => {
    const originalDocument = (globalThis as any).document;
    try {
      (globalThis as any).document = undefined;
      expect(stripTags('<b>Hi</b>')).toBe('Hi');
      expect(stripTags('Research &amp; Development')).toBe('Research & Development');
    } finally {
      (globalThis as any).document = originalDocument;
    }
  });
});

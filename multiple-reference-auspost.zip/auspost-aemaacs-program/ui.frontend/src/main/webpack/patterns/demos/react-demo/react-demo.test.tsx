import { render, screen } from '@testing-library/react';
import ChildComponent from './ReactComponentChild';

describe('ChildComponent', () => {
    test('renders component', () => {
        render(<ChildComponent numbers={[1, 2, 3]} />);
        const heading = screen.getByText('Child Component');
        expect(heading).toBeDefined();
    });
});

import type { Meta, StoryObj } from '@storybook/html-vite';
import initReactTest from "./react-demo.js";
import component from './react-demo.liquid';

const meta = {
  title: 'Demo/React Demo',
  component: component,
  parameters: {},
  args: {},
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initReactTest();
  }
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const Default: Story = {};

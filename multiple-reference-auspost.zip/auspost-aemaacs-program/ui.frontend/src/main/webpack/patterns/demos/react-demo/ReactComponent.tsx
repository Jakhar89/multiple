import React from 'react';
import ChildComponent from './ReactComponentChild';

export default function ReactDemo() {
  return (<>
    <h3>rendered via React Component</h3>
    <ChildComponent numbers={[1, 2, 3, 4, 5]} />
  </>);
}

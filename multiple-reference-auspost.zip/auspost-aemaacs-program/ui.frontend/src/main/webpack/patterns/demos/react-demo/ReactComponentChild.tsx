import React, { FC } from 'react';

interface ChildComponentProps {
    numbers: number[];
}

const ChildComponent: FC<ChildComponentProps> = ({ numbers }) => {
    const sum = numbers.reduce((acc, num) => acc + num, 0);

    return (
        <div>
            <h4>Child Component</h4>
            <p>Numbers: {numbers.join(', ')}</p>
            <p>Sum: {sum}</p>
        </div>
    );
};

export default ChildComponent;

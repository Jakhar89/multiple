import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './api-demo.liquid';
import './api-demo';
import {
  healthSuccess,
  healthDegraded,
  healthError,
  healthMaintenance
} from '../../../../../../.storybook/mocks/handlers';

const meta = {
  title: 'Demo/API Demo',
  component: component,
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const Success: Story = {
  parameters: {
    msw: {
      handlers: healthSuccess
    }
  }
};

export const Degraded: Story = {
  parameters: {
    msw: {
      handlers: healthDegraded
    }
  }
};

export const Error: Story = {
  parameters: {
    msw: {
      handlers: healthError
    }
  }
};

export const Maintenance: Story = {
  parameters: {
    msw: {
      handlers: healthMaintenance
    }
  }
};

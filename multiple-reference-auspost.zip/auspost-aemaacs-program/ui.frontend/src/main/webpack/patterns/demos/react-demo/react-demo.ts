import { createRoot } from 'react-dom/client';
import React from 'react';
import ReactDemo from './ReactComponent';

let reactDemoLoaded = false;

export default function initReactDemo(): void {
    if (reactDemoLoaded)
        return;

    const componentRoot = document.getElementById('react-demo');

    if (!componentRoot)
        return;

    const root = createRoot(componentRoot);
    root.render(React.createElement(ReactDemo));
    reactDemoLoaded = true;
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initReactDemo);
} else {
    initReactDemo();
}

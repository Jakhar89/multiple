/**
 * Demo component for showcasing API integration patterns.
 * TODO: This is temporary demo code - remove from production builds.
 */

export class ApiDemoComponent {
  private element: HTMLElement;
  private statusEl: HTMLElement | null;

  constructor(element: HTMLElement) {
    this.element = element;
    this.statusEl = element.querySelector('#status');
    
    if (!this.statusEl) {
      console.error('API Demo: Status element not found');
      return;
    }
    
    this.callHealthApi();
  }

  async callHealthApi(): Promise<void> {
    if (!this.statusEl) { return; }
    this.statusEl.textContent = 'Loading...';
    
    try {
      const response = await fetch('/api/health');
      const data = await response.json();

      let timeString = '';
      if (data.timestamp) {
        const time = new Date(data.timestamp).toLocaleTimeString();
        timeString = `${time}`;
      }

      this.statusEl.textContent = `${response.status} ${response.statusText} (${data.status}) [${timeString}]`;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch';
      this.statusEl.textContent = `Error: ${errorMessage}`;
    }
  }
}

function initApiDemoComponents() {
  const elements = document.querySelectorAll('.api-demo:not([data-api-demo-initialized])');
  
  elements.forEach(element => {
    element.setAttribute('data-api-demo-initialized', 'true');
    new ApiDemoComponent(element as HTMLElement);
  });
}

// TODO: Replace global MutationObserver with proper component lifecycle management once TS component structure is finalized

// Run on DOM loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApiDemoComponents);
} else {
  initApiDemoComponents();
}

// Re-initialize when content changes (needed for Storybook)
const observer = new MutationObserver(() => {
  initApiDemoComponents();
});

observer.observe(document.body, { 
  childList: true, 
  subtree: true 
});

export interface inputFieldState {
  selectedAddress?: boolean;
}

export interface LocationLookup {
  lookupVariant: string;
  parentContainerSelector: string;
  lookupInputSelector: string;
  inputFieldState?: inputFieldState;
}
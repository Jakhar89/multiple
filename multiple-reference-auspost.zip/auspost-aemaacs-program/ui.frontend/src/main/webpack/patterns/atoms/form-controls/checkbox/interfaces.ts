export interface FormOptionItem {
  value: string;
  text: string;
  selected?: boolean;
  disabled?: boolean;
}

export interface FormOptionsGroup {
  id: string;
  title?: string;
  type: 'checkbox' | 'radio' | 'drop-down' | 'multi-drop-down';
  name: string;
  helpMessage?: string;
  required?: boolean;
  error?: string;
  options: FormOptionItem[];
}

export interface FormOptions {
  renderMode?: boolean,
  formOptions: FormOptionsGroup,
}

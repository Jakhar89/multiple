import { liquidEngine } from '~/../../../jest.config';
import initABNLookup from './abn-lookup';
import { abnLookupFieldMock, abnLookupApiResponseMock } from './_abn-lookup.mock';
import * as api from '../../../../scripts/utils/api';

jest.mock('../../../../scripts/utils/api');

describe('ABN Lookup Component', () => {
  let component: HTMLElement;
  let input: HTMLInputElement;
  let searchBtn: HTMLButtonElement;
  let clearBtn: HTMLElement;
  let errorContainer: HTMLElement;
  let errorMessage: HTMLElement;
  let resultsContainer: HTMLElement;
  
  beforeEach(async () => {
    const html = await liquidEngine.renderFile(
      'src/main/webpack/patterns/atoms/form-controls/abn-lookup/abn-lookup.liquid',
      { abnField: abnLookupFieldMock, renderMode: true }
    );
    document.body.innerHTML = html;
    initABNLookup();
    
    component = document.querySelector('.cmp-form-abn-lookup') as HTMLElement;
    input = document.querySelector('.abn-lookup-search__text') as HTMLInputElement;
    searchBtn = document.querySelector('.abn-search-wrapper .cmp-button') as HTMLButtonElement;
    clearBtn = document.querySelector('.abn-lookup-search__input-clear') as HTMLElement;
    resultsContainer = document.querySelector('.abn-lookup-info') as HTMLElement;
    errorContainer = document.querySelector('.error-message') as HTMLElement;
    errorMessage = document.querySelector('.error-label-item') as HTMLElement;
  });
  
  afterEach(() => {
    document.body.innerHTML = '';
    jest.clearAllMocks();
  });
  
  describe('ABN component rendering', () => {
    it('renders the component', () => {
      expect(component).not.toBeNull();
    });
    
    it('renders the input field', () => {
      expect(input).not.toBeNull();
    });
    
    it('renders the search button', () => {
      expect(searchBtn).not.toBeNull();
    });
  });
  
  describe('validation on ABN search', () => {

    it('show error for invalid entry on field blur',  () => {
      input.value = '  ';
      input.focus();
      input.blur();
      expect(errorContainer.classList.contains('d-flex')).toBe(true);
      expect(errorContainer.classList.contains('hide')).toBe(false);
    });

    it('shows error when input is empty', () => {
      input.value = '';
      searchBtn.click();
      
      expect(errorContainer.classList.contains('d-flex')).toBe(true);
      expect(errorContainer.classList.contains('hide')).toBe(false);
      expect(errorMessage.textContent).toBe(abnLookupFieldMock.errorEmpty);
    });
    
    it('shows error when ABN is less than 11 digits', () => {
      input.value = '12345';
      searchBtn.click();
      
      expect(errorContainer.classList.contains('d-flex')).toBe(true);
      expect(errorContainer.classList.contains('hide')).toBe(false);
      expect(errorMessage.textContent).toBe(abnLookupFieldMock.errorFormat);
    });
    
    it('shows error when ABN contains non-numeric characters', () => {
      input.value = '123456789ab';
      searchBtn.click();
      
      expect(errorContainer.classList.contains('d-flex')).toBe(true);
      expect(errorContainer.classList.contains('hide')).toBe(false);
      expect(errorMessage.textContent).toBe(abnLookupFieldMock.errorFormat);
    });
    
    it('does not show error for valid 11-digit ABN', async () => {
      (api.fetchApiGet as jest.Mock).mockResolvedValue(abnLookupApiResponseMock);
      input.value = '12345678901';
      searchBtn.click();
      await new Promise(resolve => setTimeout(resolve, 0));
      
      expect(errorContainer.classList.contains('hide')).toBe(true);
    });
  });
  
  describe('ABN field clear button', () => {
    it('clears input value and hides ABN results', async () => {
      (api.fetchApiGet as jest.Mock).mockResolvedValue(abnLookupApiResponseMock);
      input.value = '12345678901';
      searchBtn.click();
      await new Promise(resolve => setTimeout(resolve, 0));
      clearBtn.click();
      
      expect(input.value).toBe('');
      expect(resultsContainer.classList.contains('hide')).toBe(true);
      expect(clearBtn.classList.contains('hide')).toBe(true);
    });
  });
  
  describe('ABN field enter key', () => {
    it('triggers search on enter key press', () => {
      (api.fetchApiGet as jest.Mock).mockResolvedValue(abnLookupApiResponseMock);
      input.value = '12345678901';
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
      
      expect(api.fetchApiGet).toHaveBeenCalled();
    });
    
    it('does not trigger search on enter key press if already verified', async () => {
      (api.fetchApiGet as jest.Mock).mockResolvedValue(abnLookupApiResponseMock);
      input.value = '12345678901';
      searchBtn.click();
      await new Promise(resolve => setTimeout(resolve, 0));
      
      jest.clearAllMocks();
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
      expect(api.fetchApiGet).not.toHaveBeenCalled();
    });
  });
  
  describe('input change after ABN verification', () => {
    it('resets verified state when input changes', async () => {
      (api.fetchApiGet as jest.Mock).mockResolvedValue(abnLookupApiResponseMock);
      input.value = '12345678901';
      searchBtn.click();
      await new Promise(resolve => setTimeout(resolve, 0));
      input.value = '12345678902';
      input.dispatchEvent(new Event('input'));
      
      expect(resultsContainer.classList.contains('hide')).toBe(true);
      expect(clearBtn.classList.contains('hide')).toBe(true);
    });
  });
});

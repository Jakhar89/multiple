import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './checkbox.liquid';
import { SingleCheckboxOption, MultipleCheckboxOption, DisabledCheckboxOption, Dropdown, MultipleRadioOption, DisabledRadioOption } 
from './_checkbox.mock';


const meta: Meta = {
  title: 'Atoms/Form Controls/Form Options',
  component,
  args: {
    formOption : SingleCheckboxOption,
    renderMode: true
  }
};
export default meta;

type Story = StoryObj;

export const Checkbox: Story = {};

export const CheckboxGroup: Story = {
  args: {
    formOption: MultipleCheckboxOption
  },
};

export const CheckboxGroupDisabled: Story = {
  args: {
    formOption: DisabledCheckboxOption
  },
};

export const CheckboxGroupValidationError: Story = {
  args: {
    formOption: {
      ...MultipleCheckboxOption,
      required: true,
      error: 'This field is required',
    },

  }
};

export const RadioButtonGroup: Story = {
  args: {
    formOption: MultipleRadioOption
  },
};

export const RadioButtonGroupDisabled: Story = {
  args: {
    formOption: DisabledRadioOption
  },
};

export const RadioButtonGroupValidationError: Story = {
  args: {
    formOption: {
      ...MultipleRadioOption,
      required: true,
      error: 'This field is required',
    },

  }
};

export const DropdownDefault: Story = {
  args: {
    formOption: Dropdown
  },
};

export const DropdownValidationError: Story = {
  args: {
    formOption: { ...Dropdown,
    required: true,
    helpMessage: 'You may select more than one option',
    error: 'This field is required',
    }
  }
};



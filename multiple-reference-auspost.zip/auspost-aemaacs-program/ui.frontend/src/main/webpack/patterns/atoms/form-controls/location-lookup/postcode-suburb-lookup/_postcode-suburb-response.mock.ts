import { PostcodeSuburbLookupResponse } from './interfaces';

/* eslint-disable max-len */
export const Postcode_Suburb_Success_Response: PostcodeSuburbLookupResponse = {
  postCodeOrSuburbSuggestionList: {
    more_results_available: false,
    confidence: 'No matches',
    suggestions: [
      {
        locality: {
          region: {
            name: 'Victoria',
            code: 'VIC'
          },
          town: {
            name: 'Melbourne'
          }
        },
        postal_code: {
          full_name: '3000'
        },
        postal_code_key: 'aWQ9MzAwMCwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzAwMA',
        locality_key: 'aWQ9TWVsYm91cm5lLCBWaWN0b3JpYSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1sb2NhbGl0eX5sb2NhbGl0eT1NZWxib3VybmUsIFZpY3RvcmlhfnBvc3RhbF9jb2RlPQ'
      },
      {
        locality: {
          region: {
            name: 'Victoria',
            code: 'VIC'
          },
          town: {
            name: 'Melbourne'
          }
        },
        postal_code: {
          full_name: '3004'
        },
        postal_code_key: 'aWQ9MzAwNCwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9Mn5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzAwNA',
        locality_key: 'aWQ9TWVsYm91cm5lLCBWaWN0b3JpYSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9Mn5nYWtfdHlwZT1sb2NhbGl0eX5sb2NhbGl0eT1NZWxib3VybmUsIFZpY3RvcmlhfnBvc3RhbF9jb2RlPQ'
      },
      {
        locality: {
          region: {
            name: 'Victoria',
            code: 'VIC'
          },
          town: {
            name: 'Melbourne'
          }
        },
        postal_code: {
          full_name: '3001'
        },
        postal_code_key: 'aWQ9MzAwMSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9M35nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzAwMQ',
        locality_key: 'aWQ9TWVsYm91cm5lLCBWaWN0b3JpYSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9M35nYWtfdHlwZT1sb2NhbGl0eX5sb2NhbGl0eT1NZWxib3VybmUsIFZpY3RvcmlhfnBvc3RhbF9jb2RlPQ'
      },
      {
        locality: {
          region: {
            name: 'Victoria',
            code: 'VIC'
          },
          town: {
            name: 'Melbourne'
          }
        },
        postal_code: {
          full_name: '8001'
        },
        postal_code_key: 'aWQ9ODAwMSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9NH5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9ODAwMQ',
        locality_key: 'aWQ9TWVsYm91cm5lLCBWaWN0b3JpYSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9NH5nYWtfdHlwZT1sb2NhbGl0eX5sb2NhbGl0eT1NZWxib3VybmUsIFZpY3RvcmlhfnBvc3RhbF9jb2RlPQ'
      },
      {
        locality: {
          region: {
            name: 'Victoria',
            code: 'VIC'
          },
          town: {
            name: 'Melbourne University'
          }
        },
        postal_code: {
          full_name: '3052'
        },
        postal_code_key: 'aWQ9MzA1MiwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9NX5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzA1Mg',
        locality_key: 'aWQ9TWVsYm91cm5lIFVuaXZlcnNpdHksIFZpY3RvcmlhLCBBdXN0cmFsaWF-YWx0X2tleT1-ZGF0YXNldD1BVVNfUEFGfmZvcm1hdF9rZXk9QVVTJGF1LWFkZHJlc3MtYmV0YSQkJCQkfnBvcz01fmdha190eXBlPWxvY2FsaXR5fmxvY2FsaXR5PU1lbGJvdXJuZSBVbml2ZXJzaXR5LCBWaWN0b3JpYX5wb3N0YWxfY29kZT0'
      }
    ]
  }
};

export const Postcode_Suburb_Failure_Response = {
  postCodeOrSuburbSuggestionList: {
    error: 'No search parameters provided, provide suburb or postcode'
  }
};
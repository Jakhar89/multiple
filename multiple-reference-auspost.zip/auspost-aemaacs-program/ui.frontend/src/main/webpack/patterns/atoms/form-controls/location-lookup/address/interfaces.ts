import { FormOptionsGroup } from '../../checkbox/interfaces';
import { FormInputField } from '../../input/interfaces';
export interface FormAddressFieldItem {
  label: string;
  id?: string;
  name: string;
  type?: string;
  placeholder?: string;
  value?: string;
  helpMessage?: string;
  error?: string;
  disabled?: boolean;
  className?: string;
}

export interface FormAddressField {
  addressField: FormAddressFieldItem;
  manualAddressField: FormInputField | FormOptionsGroup;
  searchForAddress?: string;
  renderMode?: boolean;
}

export interface AddressItem {
  address?: string;
  moniker: string;
}

export interface AddressSuggestionItem {
  total?: number;
  entries?: AddressItem[];
  error?: string;
}

export interface AddressLookupResponse {
  addressSuggestionList?: AddressSuggestionItem;
}

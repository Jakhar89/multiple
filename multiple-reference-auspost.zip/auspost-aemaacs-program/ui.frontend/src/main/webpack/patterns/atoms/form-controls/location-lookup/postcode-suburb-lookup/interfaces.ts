import { FormOptionsGroup } from '../../checkbox/interfaces';
import { FormInputField } from '../../input/interfaces';
export interface FormPostcodeOrSuburbFieldItem {
  label: string;
  id?: string;
  name: string;
  type?: string;
  placeholder?: string;
  value?: string;
  optional?: boolean;
  helpMessage?: string;
  error?: string;
  disabled?: boolean;
  className?: string;
}

export interface FormPostcodeOrSuburbField {
  postcodeOrSuburbField: FormPostcodeOrSuburbFieldItem;
  manualPostcodeOrSuburbField: FormInputField | FormOptionsGroup;
  searchForAddress?: string;
  renderMode?: boolean;
}

export interface RegionItem {
  name: string;
  code: string;
}

export interface TownItem {
  name: string;
}

export interface LocalityItem {
  region: RegionItem;
  town?: TownItem;
}

export interface PostalcodeItem {
  full_name?: string;
}

export interface PostcodeSuburbItem {
  locality?: LocalityItem;
  postal_code?: PostalcodeItem;
  postal_code_key?: string;
  locality_key: string;
}

export interface PostcodeSuburbSuggestionItem {
  more_results_available?: boolean;
  confidence?: string;
  suggestions?: PostcodeSuburbItem[];
  error?: string;
}

export interface PostcodeSuburbLookupResponse {
  postCodeOrSuburbSuggestionList?: PostcodeSuburbSuggestionItem;
}

import { AddressLookupResponse } from './address/interfaces';
import { handleLocationLookupData, QueryParamObject, appendEnterManuallyButtonToList } from './location-lookup-service';
import { LocationLookup } from './interfaces';
import { PostcodeSuburbLookupResponse } from './postcode-suburb-lookup/interfaces';
import { toggleLocationSection } from './toggle-location-section';

export const addressState: Record<string, boolean> = {};

export const addressSection = {
  AddressLookupSection: 'search-address-container',
  ManualAddressSection: 'manual-address-container'
} as const;

export default function initLocationLookup(config: LocationLookup): void {

  const components = document.querySelectorAll<HTMLElement>(config.parentContainerSelector);
  if (!components)
    return;

  components.forEach(component => {
    const lookupInputField = component.querySelector(config.lookupInputSelector) as HTMLInputElement;
    const suggestedAddressContainer = component.querySelector('.suggested-address-container') as HTMLElement;
    const formSectionButton = component.querySelector('.form-section-button .cmp-button') as HTMLButtonElement;
    const searchAddressContainer = component.querySelector('.search-address-container') as HTMLElement;

    const lookupSection = sessionStorage.getItem('activeLookupSection');

    if (lookupSection === addressSection.ManualAddressSection) {
      toggleLocationSection(addressSection.AddressLookupSection, addressSection.ManualAddressSection,
        component, suggestedAddressContainer);
    }

    lookupInputField?.addEventListener('focusout', (e) => {
      const relatedItem = (e as FocusEvent).relatedTarget as HTMLElement;
      if (!suggestedAddressContainer.contains(relatedItem)) {
        setTimeout(() => {
          suggestedAddressContainer.classList.remove('active');
        }, 100);
      }
      if (!lookupInputField.value) {
        addressState[lookupInputField.id] = false;
      }
    });

    lookupInputField.addEventListener('keydown', (e) => {
      const { key } = e;
      if (key === 'ArrowDown') {

        setTimeout(() => {
          const focusButtonWithUpDownArrowKey = suggestedAddressContainer.querySelectorAll<HTMLButtonElement>('ul li button');
          if (focusButtonWithUpDownArrowKey.length > 0) {

            focusButtonWithUpDownArrowKey[0].focus();
          }
        }, 100);
      }
    });

    suggestedAddressContainer.addEventListener('mousedown', (e) => {
      e.preventDefault();
    });

    searchAddressContainer.addEventListener('focusout', (e) => {
      const target = e.relatedTarget as HTMLElement | null;

      if (!target || !searchAddressContainer.contains(target)) {

        setTimeout(() => {
          suggestedAddressContainer.classList.remove('active');
        }, 100);
      }
      if (!lookupInputField?.value) {
        addressState[lookupInputField.id] = false;
      }
    });

    lookupInputField?.addEventListener('input', async () => {
      suggestedAddressContainer.classList.add('active');

      setTimeout(() => {
        const suggestedAddressTopList = suggestedAddressContainer?.querySelector('.list-top-container') as HTMLElement;
        appendEnterManuallyButtonToList(suggestedAddressTopList, component, suggestedAddressContainer);
      }, 0);

      let queryParam: string;
      if (config.lookupVariant === 'address') {
        queryParam = QueryParamObject.address;
        handleLocationLookupData(lookupInputField, component, getAddressResponse, queryParam);
      } else {
        if (!isNaN(Number(lookupInputField.value.trim()))) {
          queryParam = QueryParamObject.postcode;
        } else {
          queryParam = QueryParamObject.suburb;
        }
        handleLocationLookupData(lookupInputField, component, getPostcodeSuburbResponse, queryParam);
      }
    });

    if (formSectionButton) {
      formSectionButton.addEventListener('mousedown', (e) => {
        e.preventDefault();
        toggleLocationSection(addressSection.ManualAddressSection, addressSection.AddressLookupSection,
          component, suggestedAddressContainer);
      });

      formSectionButton.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === '') {
          e.preventDefault();
          toggleLocationSection(addressSection.ManualAddressSection, addressSection.AddressLookupSection,
            component, suggestedAddressContainer);
        }
      });
    }

    function getAddressResponse(data: AddressLookupResponse) {
      return {
        locationSuggestionList: data?.addressSuggestionList?.entries,
        error: data?.addressSuggestionList?.error
      };
    }

    function getPostcodeSuburbResponse(data: PostcodeSuburbLookupResponse) {
      return {
        locationSuggestionList: data?.postCodeOrSuburbSuggestionList?.suggestions,
        error: data?.postCodeOrSuburbSuggestionList?.error
      };
    }
  });
}
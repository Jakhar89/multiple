import { fetchApiGet } from '../../../../scripts/utils/api';
import { pushFormDataToDataLayer } from '../../../../scripts/analytics/analytics';
import { addressState, addressSection } from '../location-lookup/location-lookup';
import { AddressLookupResponse, AddressItem } from '../location-lookup/address/interfaces';
import { PostcodeSuburbLookupResponse, PostcodeSuburbItem }
    from '../location-lookup/postcode-suburb-lookup/interfaces';
import { toggleLocationSection } from './toggle-location-section';

const minInputCharLength = 2;
const minPostcodeCharLength = 4;

export const QueryParamObject = {
    address: 'address',
    suburb: 'suburb',
    postcode: 'postcode'
} as const;

export async function handleLocationLookupData(input: HTMLInputElement | HTMLTextAreaElement,
    locationLookupComponent: HTMLElement, getLocationList: any, queryParam: string) {

    const suggestedAddressContainer = locationLookupComponent.querySelector('.suggested-address-container') as HTMLElement;
    const suggestedAddressTopList = locationLookupComponent.querySelector('.list-top-container') as HTMLElement;
    const locationValue = input.value.toLowerCase().trim();
    const loadingContext = loaderForInputContainer(locationLookupComponent);

    const minCharForLocationApiCall = queryParam === QueryParamObject.postcode ? minPostcodeCharLength : minInputCharLength;
    const conditionForLocationApiCall = queryParam === QueryParamObject.postcode ? locationValue.length === minCharForLocationApiCall
        : locationValue.length > minInputCharLength;

    if (conditionForLocationApiCall) {
        const apiUrl = buildApiUrl(locationLookupComponent, locationValue, queryParam);
        loadingContext.isLoading = true;
        const temporaryAddressData = await fetchApiGet<AddressLookupResponse | PostcodeSuburbLookupResponse>(apiUrl) as
            AddressLookupResponse | PostcodeSuburbLookupResponse;
        loadingContext.isLoading = false;
        const locationSuggestionList = getLocationList(temporaryAddressData);

        if (temporaryAddressData && locationSuggestionList.locationSuggestionList) {
            renderLocationSuggestionList(locationSuggestionList.locationSuggestionList);
        } else if (temporaryAddressData && locationSuggestionList.error) {
            pushFormDataToDataLayer('field-error', 'identifier', [`${input.name} || ${locationSuggestionList.error}`]);
        } else {
            pushFormDataToDataLayer('field-error', 'identifier', [input.name || 'Service error']);
        }

    } else {
        suggestedAddressTopList.querySelectorAll('li:not(.list-last-container)').forEach(li => li.remove());
    }

    // create api url for Address lookup and postcode and suburb lookup
    function buildApiUrl(component: HTMLElement, locationValue: string, queryParam: string) {
        let resourceUrl: string;
        if (queryParam === QueryParamObject.address) {
            resourceUrl = component?.dataset.addressUrl ?? '';
        } else {
            resourceUrl = component?.dataset.postcodeSuburbUrl ?? '';
        }

        return `${resourceUrl}?${queryParam}=${locationValue}`;
    }

    // Display Address or Suburb and Postcode lookup, with api response

    type updatedLocationList = (AddressItem | PostcodeSuburbItem)[];

    function renderLocationSuggestionList(locationList: updatedLocationList) {
        const locationSuggestionData = locationList?.slice(0, 5);
        suggestedAddressTopList.querySelectorAll('li:not(.list-last-container)').forEach(li => li.remove());

        locationSuggestionData?.forEach((item) => {

            if (queryParam === QueryParamObject.address && 'address' in item) {
                createLocationLookupList(item?.address);
            } else {
                if ('locality' in item || 'postal_code' in item) {

                    const locationDetails = `${item?.locality?.town?.name} ${item?.locality?.region.code} ${item?.postal_code?.full_name}`;
                    createLocationLookupList(locationDetails);
                }
            }
        });
    }

    // Select address from address lookup using mouse and keyboard with click and enter events

    function handleAddressInteraction(locationButton: HTMLButtonElement) {
        const handler = (e: Event | KeyboardEvent) => {
            if (e.type === 'mousedown') {
                e.preventDefault();
                selectLocationFromLookup(locationButton);
            }

            if (e.type === 'keydown') {
                const keyEvent = e as KeyboardEvent;
                if (keyEvent.key === 'Enter' || keyEvent.key === '') {
                    keyEvent.preventDefault();
                    selectLocationFromLookup(locationButton);
                }
            }
        };
        locationButton.addEventListener('mousedown', handler);
        locationButton.addEventListener('keydown', handler);
    }

    function selectLocationFromLookup(locationButton: HTMLButtonElement) {
        input.value = locationButton.textContent ?? '';
        addressState[input.id] = true;

        suggestedAddressContainer.classList.remove('active');

        setTimeout(() => input.focus(), 0);
    }

    function createLocationLookupList(item: string | undefined) {
        const listItem = document.createElement('li');
        const locationButton = document.createElement('button') as HTMLButtonElement;
        if (locationButton) {
            const itemText = item ? item.toLowerCase() : '';
            if (locationValue && itemText.includes(locationValue) && item) {
                const highlightedText = item.replace(
                    new RegExp(locationValue, 'gi'),
                    (match) => `<span class='highlight-text'>${match}</span>`
                );
                locationButton.innerHTML = highlightedText;
            } else {
                locationButton.textContent = item as string;
            }
            listItem.appendChild(locationButton);
        }

        setTimeout(() => {
            const getLastElement = locationLookupComponent.querySelector('.list-last-container') as HTMLElement;
            suggestedAddressTopList?.insertBefore(listItem, getLastElement);
            bindButtonNavigation();
        }, 100);


        handleAddressInteraction(locationButton);
    }

    function bindButtonNavigation() {
        const focusButtonWithUpDownArrowKey = locationLookupComponent.querySelectorAll<HTMLButtonElement>('ul li button');
        focusButtonWithUpDownArrowKey.forEach((buttonElement, index) => {

            buttonElement.addEventListener('focus', () => {
                buttonElement.classList.add('button-focus');
            });

            buttonElement.addEventListener('blur', () => {
                buttonElement.classList.remove('button-focus');
            });

            buttonElement.addEventListener('keydown', (e) => {
                let nextIndex;
                const keyEvent = e.key;
                if (keyEvent === 'ArrowDown') {
                    e.preventDefault();

                    nextIndex = (index + 1) % focusButtonWithUpDownArrowKey.length;
                    focusButtonWithUpDownArrowKey[nextIndex].focus();
                } else if (keyEvent === 'ArrowUp') {
                    e.preventDefault();
                    if (index === 0) {
                        input.focus();
                    } else {
                        nextIndex = (index - 1 + focusButtonWithUpDownArrowKey.length) % focusButtonWithUpDownArrowKey.length;
                        focusButtonWithUpDownArrowKey[nextIndex].focus();
                    }
                }
            });
        });
    }


}

export function appendEnterManuallyButtonToList(suggestedAddressTopList: HTMLElement,
    component: HTMLElement, suggestedAddressContainer: HTMLElement) {
    if (suggestedAddressTopList.querySelector('.list-last-container')) return;
    const parentContainer = document.createElement('li');
    parentContainer.classList.add('list-last-container');

    const childContainer = document.createElement('div');
    childContainer.classList.add('address-btn-container');

    const spanContainer = document.createElement('span');
    spanContainer.textContent = 'Can\'t find the address ?';

    const buttonWrapperDiv = document.createElement('div');
    buttonWrapperDiv.classList.add('button', 'tertiary-basic', 'default', 'address-lookup-button');

    const buttonContainer = document.createElement('button');
    buttonContainer.classList.add('cmp-button');
    buttonContainer.textContent = 'Enter it manually';

    buttonWrapperDiv.appendChild(buttonContainer);

    childContainer.appendChild(spanContainer);
    childContainer.appendChild(buttonWrapperDiv);

    parentContainer.appendChild(childContainer);

    suggestedAddressTopList.appendChild(parentContainer);
    buttonContainer.addEventListener('click', (e) => {
        e.preventDefault();
        toggleLocationSection(addressSection.AddressLookupSection, addressSection.ManualAddressSection,
            component, suggestedAddressContainer);
    });
}

export function loaderForInputContainer(locationContainer: HTMLElement) {
    //loading state for Address, postcode and suburb lookup input field
    const locationInputContainer = locationContainer.querySelector('.address-container') as HTMLElement;
    const loadingState = { isLoading: false };
    const loadingContext = new Proxy(loadingState, {
        set: function (target: any, key: any, value: string) {
            // All loading actions go here
            if (key === 'isLoading') {
                locationInputContainer?.classList.toggle('is-loading');
            }

            target[key] = value;
            return true;
        }
    });
    return loadingContext;
}

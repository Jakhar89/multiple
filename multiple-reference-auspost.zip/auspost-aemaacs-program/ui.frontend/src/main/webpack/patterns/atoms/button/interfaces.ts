import './button.scss';

export interface ButtonProps {
  type?: '' | 'primary' | 'secondary' | 'tertiary' | 'tertiary-basic' | 'inverted';
  size?: '' | 'default' | 'small' | 'medium' | 'large';
  label?: string;
  href?: string;
  target?: string;
  assetTypeAndSize?: string;
  loading?: boolean;
  disabled?: boolean;
  iconLeft?: string;
  iconRight?: string;
  onClick?: () => void;
  ariaDescribedBy?: string;
}

import { faker } from '@faker-js/faker';
import { ABNApiResponse, ABNLookupFieldItem } from './interfaces';

export const abnLookupApiResponseMock: ABNApiResponse = {
  abnDetails: {
    response: {
      businessEntity202001: {
        mainName: {
          organisationName: faker.company.name()
        },
        entityStatus: {
          entityStatusCode: 'Active'
        },
        entityType: {
          entityDescription: 'Australian Private Company'
        }
      }
    }
  }
};

export const abnLookupApiResponseErrorMock: ABNApiResponse = {
  abnDetails: {
    response: {
      exception: {
        exceptionDescription: 'Search text is not a valid ABN or ACN',
        exceptionCode: 'WEBSERVICES'
      }
    }
  }
};

export const abnLookupServiceDownApiResponse: ABNApiResponse = {
  abnDetails: {
    error: 'Service Error'
  }
};

export const abnLookupFieldMock: ABNLookupFieldItem = {
  id: 'abn-lookup-id',
  name: 'abn-field-name',
  type: 'text',
  label: 'Australian Business Number (ABN)',
  helpMessage: '11 digits, no spaces.',
  error: '',
  errorEmpty: 'ABN hasn\'t been entered',
  errorFormat: 'ABN should be an 11-digit number',
  errorInvalid: 'Enter a valid ABN'
};

export const abnLookupFieldWithErrorMock: ABNLookupFieldItem = {
  id: 'abn-lookup-id',
  name: 'abn-field-name',
  type: 'text',
  label: 'Australian Business Number (ABN)',
  helpMessage: '11 digits, no spaces.',
  error: 'Enter a valid ABN',
  errorEmpty: 'ABN hasn\'t been entered',
  errorFormat: 'ABN should be an 11-digit number',
  errorInvalid: 'Enter a valid ABN'
};

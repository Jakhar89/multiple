import type { Meta, StoryObj } from '@storybook/html-vite';
import { LightboxProps } from './interfaces';
import { initLightbox } from './lightbox';

import component from './lightbox.liquid';
import { caption, longCaption } from './_lightbox.mock';


const meta = {
  title: 'Atoms/Lightbox',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {
    imageHref: {
      control: { type: 'select' },
      options: ['', '/src/main/webpack/patterns/assets/images/stamp-portrait.png', '/src/main/webpack/patterns/assets/images/stamp-square.png']
    }
  },
  args: {
    caption: caption,
    imageHref: '/src/main/webpack/patterns/assets/images/stamp-portrait.png',
    renderMode: true
  }
} satisfies Meta<LightboxProps>;

export default meta;
type Story = StoryObj<LightboxProps>;

export const Default: Story = {
  args: {
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const SquareImage: Story = {
  args: {
    imageHref: '/src/main/webpack/patterns/assets/images/stamp-square.png'
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const LongCaption: Story = {
  args: {
    caption: longCaption
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

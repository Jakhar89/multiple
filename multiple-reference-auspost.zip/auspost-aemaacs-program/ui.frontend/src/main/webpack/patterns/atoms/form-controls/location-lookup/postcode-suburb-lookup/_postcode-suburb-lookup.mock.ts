import { FormOptionsGroup } from '../../checkbox/interfaces';
import { FormInputFieldItem } from '../../input/interfaces';
import { FormPostcodeOrSuburbFieldItem } from './interfaces';
import { faker } from '@faker-js/faker';

export const postcodeOrSuburbField: FormPostcodeOrSuburbFieldItem = {
    id: 'postcode-suburb-field-id',
    name: 'suburbandpostcode',
    type: 'text',
    label: 'Enter your current suburb or postcode',
    value: '',
    disabled: false,
    helpMessage: faker.lorem.sentences(1),
    placeholder: 'Search for a suburb or postcode'
};

export const postcodeOrSuburbFieldValidation: FormPostcodeOrSuburbFieldItem = {
    id: 'postcode-suburb-field-id',
    name: 'postcode-suburb-field-name',
    type: 'text',
    label: 'Enter your current suburb or postcode',
    value: '',
    disabled: false,
    helpMessage: faker.lorem.sentences(1),
    placeholder: 'Search for a suburb or postcode',
    error: 'Please select an option or enter an address manually'
};

export const manualPostcodeOrSuburbField: (FormInputFieldItem | FormOptionsGroup)[] = [
    {
        label: 'Suburb',
        type: 'text',
        id: 'suburb-id',
        name: 'suburb-name',
        placeholder: '',
        optional: false,
    },
    {
        id: 'cmp-dropdown-options-1',
        type: 'drop-down',
        title: 'State',
        name: 'form-options',
        helpMessage: '',
        required: true,
        options: [
            { value: 'nsw', text: 'NSW' },
            { value: 'vic', text: 'VIC' },
            { value: 'qld', text: 'QLD' }
        ]
    },
    {
        label: 'Postcode',
        type: 'text',
        id: 'postcode',
        name: 'postcode-name',
        placeholder: '',
        optional: false,
        charLimit: 4
    }
];

export const ValidationErrorManualSuburbPostcodeField: (FormInputFieldItem | FormOptionsGroup)[] = [
    {
        label: 'Suburb',
        type: 'text',
        id: 'suburb-id',
        name: 'suburb-name',
        placeholder: '',
        optional: false,
        error: 'Suburb is required'
    },
    {
        id: 'cmp-dropdown-options-1',
        type: 'drop-down',
        title: 'State',
        name: 'form-options',
        helpMessage: '',
        required: true,
        options: [
            { value: 'nsw', text: 'NSW' },
            { value: 'vic', text: 'VIC' },
            { value: 'qld', text: 'QLD' }
        ],
        error: 'State is required'
    },
    {
        label: 'Postcode',
        type: 'text',
        id: 'postcode',
        name: 'postcode-name',
        placeholder: '',
        optional: false,
        error: 'Postcode is required',
        charLimit: 4
    }
];



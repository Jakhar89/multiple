import { FormOptionsGroup } from '../../checkbox/interfaces';
import { FormInputFieldItem } from '../../input/interfaces';
import { FormAddressFieldItem } from './interfaces';
import { faker } from '@faker-js/faker';

export const searchAddressField: FormAddressFieldItem = {
    id: 'address-field-id',
    name: 'address-field-name',
    type: 'text',
    label: 'Address',
    value: '',
    disabled: false,
    helpMessage: faker.lorem.sentences(1),
    placeholder: 'Search for an address'
};


export const searchAddressFieldValidation: FormAddressFieldItem = {
    id: 'address-field-id',
    name: 'address-field-name',
    type: 'text',
    label: 'Address',
    value: 'abc',
    disabled: false,
    className: '',
    helpMessage: faker.lorem.sentences(1),
    placeholder: 'Search for an address',
    error: 'Enter your a valid address'
};

export const manualAddressField: (FormInputFieldItem | FormOptionsGroup)[] = [
    {
        label: 'Address 1',
        type: 'text',
        id: 'address-1',
        name: 'address-name-1',
        placeholder: '',
        optional: false,
    },
    {
        label: 'Address 2',
        type: 'text',
        id: 'address-2',
        name: 'address-name-2',
        placeholder: '',
        optional: true
    },
    {
        label: 'Address 3',
        type: 'text',
        id: 'address-3',
        name: 'address-name-3',
        placeholder: '',
        optional: true
    },
    {
        label: 'Suburb',
        type: 'text',
        id: 'suburb-id',
        name: 'suburb-name',
        placeholder: '',
        optional: false,
    },
    {
        id: 'cmp-dropdown-options-1',
        type: 'drop-down',
        title: 'State',
        name: 'form-options',
        helpMessage: '',
        required: true,
        options: [
            { value: 'nsw', text: 'NSW' },
            { value: 'vic', text: 'VIC' },
            { value: 'qld', text: 'QLD' }
        ]
    },
    {
        label: 'Postcode',
        type: 'text',
        id: 'postcode',
        name: 'postcode-name',
        placeholder: '',
        optional: false,
        charLimit: 4
    }
];

export const ValidationErrorManualAddressField: (FormInputFieldItem | FormOptionsGroup)[] = [
    {
        label: 'Address 1',
        type: 'text',
        id: 'address-1',
        name: 'address-name-1',
        placeholder: '',
        optional: false,
        error: 'Address 1 is required'
    },
    {
        label: 'Address 2',
        type: 'text',
        id: 'address-2',
        name: 'address-name-2',
        placeholder: '',
        optional: true
    },
    {
        label: 'Address 3',
        type: 'text',
        id: 'address-3',
        name: 'address-name-3',
        placeholder: '',
        optional: true
    },
    {
        label: 'Suburb',
        type: 'text',
        id: 'suburb-id',
        name: 'suburb-name',
        placeholder: '',
        optional: false,
        error: 'Suburb is required'
    },
    {
        id: 'cmp-dropdown-options-1',
        type: 'drop-down',
        title: 'State',
        name: 'form-options',
        helpMessage: '',
        required: true,
        options: [
            { value: 'nsw', text: 'NSW' },
            { value: 'vic', text: 'VIC' },
            { value: 'qld', text: 'QLD' }
        ],
        error: 'State is required'
    },
    {
        label: 'Postcode',
        type: 'text',
        id: 'postcode',
        name: 'postcode-name',
        placeholder: '',
        optional: false,
        error: 'Postcode is required',
        charLimit: 4
    }
];



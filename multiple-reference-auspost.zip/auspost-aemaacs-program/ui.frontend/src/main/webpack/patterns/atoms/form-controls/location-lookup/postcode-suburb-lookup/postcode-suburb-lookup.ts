import initLocationLookup from '../location-lookup';

export const postcodeSuburbSection = {
  PostcodeOrSuburbLookupSection: 'search-address-container',
  ManualPostcodeSuburbSection: 'manual-address-container'
} as const;

export default function initPostcodeOrSuburb(): void {

  initLocationLookup({
    lookupVariant: 'postcode-suburb',
    parentContainerSelector: '.postcode-suburb-lookup-container',
    lookupInputSelector: '.postcode-suburb-input'
  });

}

document.addEventListener('DOMContentLoaded', initPostcodeOrSuburb);

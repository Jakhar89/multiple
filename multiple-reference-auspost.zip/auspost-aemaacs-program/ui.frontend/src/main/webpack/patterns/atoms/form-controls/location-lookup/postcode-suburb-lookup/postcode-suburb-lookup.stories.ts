import type { Meta, StoryObj } from '@storybook/html-vite';
import { faker } from '@faker-js/faker';
import { waitForUIToRenderInDOM } from '../../../../../scripts/utils/_story-utils';
import component from './postcode-suburb-lookup.liquid';
import {
  postcodeOrSuburbField, manualPostcodeOrSuburbField, postcodeOrSuburbFieldValidation,
  ValidationErrorManualSuburbPostcodeField
} from './_postcode-suburb-lookup.mock';
import initPostcodeOrSuburb from './postcode-suburb-lookup';

const meta: Meta = {
  title: 'Atoms/Form Controls/Location Lookup/Postcode Surburb Lookup',
  component,
  args: {
    renderMode: true,
    postcodeOrSuburbField: postcodeOrSuburbField,
    manualPostcodeOrSuburbField: manualPostcodeOrSuburbField,
    searchForAddressButton: 'Use suburb lookup instead',
    postcodeOrSuburbSection: 'search'
  },
  play: async () => {
    waitForUIToRenderInDOM('.postcode-suburb-lookup-container', initPostcodeOrSuburb);
  }
};

export default meta;

type Story = StoryObj;

export const Default: Story = {
  args: {
    postcodeOrSuburbSection: 'search'
  },
  play: async () => {
    waitForUIToRenderInDOM('.postcode-suburb-lookup-container', initPostcodeOrSuburb);
  }
};

export const PostcodeOrSuburbLookupValidationError: Story = {
  args: {
    postcodeOrSuburbField: postcodeOrSuburbFieldValidation
  }
};

export const ManualPostcodeOrSuburbForm: Story = {
  args: {
    postcodeOrSuburbSection: 'manual'
  },
  play: async () => {
    waitForUIToRenderInDOM('.postcode-suburb-lookup-container', initPostcodeOrSuburb);
  }
};

export const ManualPostcodeOrSuburbFormValidation: Story = {
  args: {
    manualPostcodeOrSuburbField: ValidationErrorManualSuburbPostcodeField,
    postcodeOrSuburbSection: 'manual'
  }
};


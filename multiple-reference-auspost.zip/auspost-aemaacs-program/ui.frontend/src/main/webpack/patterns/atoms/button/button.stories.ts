import type { Meta, StoryObj } from '@storybook/html-vite';
import type { ButtonProps } from './interfaces';

import component from './button.liquid';

export default {
  title: 'Atoms/Button',
  component: component,
  argTypes: {
    type: {
      control: { type: 'select' },
      options: ['', 'secondary', 'tertiary', 'tertiary-basic', 'inverted'],
    },
    size: {
      control: { type: 'select' },
      options: ['', 'small', 'medium', 'large'],
    },
    label: { control: 'text' },
    href: { control: 'text' },
    target: { control: 'text' },
    assetTypeAndSize: { control: 'text' },
    loading: { control: { type: 'boolean' } },
    disabled: { control: { type: 'boolean' } },
    iconLeft: {
      control: { type: 'select' },
      options: ['', 'user', 'track', 'convert-currency', 'document'],
    },
    iconRight: {
      control: { type: 'select' },
      options: ['', 'arrow-right-thin', 'arrow-diagonal-right-thin', 'arrow-right', 'arrow-diagonal-right', 'download', 'new-window'],
    }
  },
  args: {
    type: '',
    size: '',
    label: 'Log in',
    href: '',
    target: '',
    assetTypeAndSize: '',
    loading: false,
    disabled: false,
    iconLeft: 'user',
    iconRight: 'arrow-right-thin',
    ariaDescribedBy: ''
  }
} satisfies Meta<ButtonProps>;

type Story = StoryObj<ButtonProps>;

export const Primary: Story = {
  args: {
    label: 'Primary'
  }
};

export const Secondary: Story = {
  args: {
    type: 'secondary',
    label: 'Secondary'
  }
};

export const Tertiary: Story = {
  args: {
    type: 'tertiary',
    label: 'Tertiary'
  }
};

export const TertiaryBasic: Story = {
  args: {
    type: 'tertiary-basic',
    label: 'Tertiary Basic',
    iconLeft: '',
    iconRight: ''
  }
};

export const Inverted: Story = {
  args: {
    type: 'inverted',
    label: 'Inverted'
  }
};

export const Small: Story = {
  args: {
    label: 'Small size',
    size: 'small'
  }
};

export const Medium: Story = {
  args: {
    label: 'Medium size',
    size: 'medium'
  }
};

export const Large: Story = {
  args: {
    label: 'Large size',
    size: 'large'
  }
};

export const Link: Story = {
  args: {
    label: 'Link',
    href: 'https://www.google.com/',
    target: '_blank',
    iconLeft: 'track',
    iconRight: 'new-window'
  }
};

export const IconOnly: Story = {
  args: {
    label: '',
    iconLeft: 'user',
    iconRight: ''
  }
};

export const Loading: Story = {
  args: {
    label: 'Log in',
    loading: true
  }
};

export const Disabled: Story = {
  args: {
    disabled: true
  }
};

export const AssetTypeAndSize: Story = {
  args: {
    label: 'Download',
    assetTypeAndSize: '(JPEG, 40 KB)',
    iconLeft: '',
    iconRight: 'download'
  }
};

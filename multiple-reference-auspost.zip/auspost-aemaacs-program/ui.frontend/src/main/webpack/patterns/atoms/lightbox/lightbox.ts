export function initLightbox(): void {
  const lightboxContainers = document.querySelectorAll<HTMLElement>('.lightbox');

  lightboxContainers.forEach(container => {
    const dialog = container.querySelector<HTMLDialogElement>('.lightbox-dialog');
    const trigger = container.querySelector<HTMLElement>('.lightbox-trigger');
    const openBtn = container.querySelector<HTMLElement>('.lightbox-expand');
    const closeBtn = container.querySelector<HTMLButtonElement>('.lightbox-close');

    if (!dialog || !openBtn || !trigger || !closeBtn) { return; }

    openBtn.addEventListener('click', () => dialog.showModal());
    trigger.addEventListener('click', () => dialog.showModal());
    closeBtn.addEventListener('click', () => dialog.close());
  });
}

initLightbox();

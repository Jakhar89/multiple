import { faker } from '@faker-js/faker';

export const caption = faker.lorem.sentence(3);
export const longCaption = faker.lorem.sentences(10);

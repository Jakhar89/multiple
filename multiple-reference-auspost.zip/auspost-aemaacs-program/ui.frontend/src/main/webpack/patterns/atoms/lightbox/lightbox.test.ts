import { initLightbox } from './lightbox';

describe('lightbox', () => {
  beforeEach(() => {
    document.body.innerHTML = `
      <div class="lightbox">
        <div class="lightbox-trigger">
          <div class="cmp-image">
            <img src="test.jpg" alt="alt text">
          </div>
        </div>
        <div class="lightbox-expand"></div>
        
        <dialog class="lightbox-dialog">
          <button class="lightbox-close">Close</button>
          <div class="lightbox-content">
            <div class="cmp-image">
              <img src="test.jpg" alt="alt text">
            </div>
            <p class="lightbox-description"></p>
          </div>
        </dialog>
      </div>
    `;

    const lightbox = document.querySelector('.lightbox') as HTMLElement;
    const dialog = lightbox.querySelector('.lightbox-dialog') as HTMLDialogElement;
    dialog.showModal = jest.fn();
    dialog.close = jest.fn();

    initLightbox();
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  describe('opening lightbox', () => {
    it('opens when trigger image is clicked', () => {
      const trigger = document.querySelector('.lightbox-trigger') as HTMLImageElement;
      const dialog = document.querySelector('.lightbox-dialog') as HTMLDialogElement;
      
      trigger.click();
      
      expect(dialog.showModal).toHaveBeenCalled();
    });

    it('opens when open button is clicked', () => {
      const openBtn = document.querySelector('.lightbox-expand') as HTMLElement;
      const dialog = document.querySelector('.lightbox-dialog') as HTMLDialogElement;
      
      openBtn.click();
      
      expect(dialog.showModal).toHaveBeenCalled();
    });
  });

  describe('closing lightbox', () => {
    it('closes when close button is clicked', () => {
      const closeBtn = document.querySelector('.lightbox-close') as HTMLButtonElement;
      const dialog = document.querySelector('.lightbox-dialog') as HTMLDialogElement;
      
      closeBtn.click();
      
      expect(dialog.close).toHaveBeenCalled();
    });

    it('does NOT close when clicking inside content image', () => {
      const image = document.querySelector('.cmp-image') as HTMLElement;
      const dialog = document.querySelector('.lightbox-dialog') as HTMLDialogElement;
      
      image.click();
      
      expect(dialog.close).not.toHaveBeenCalled();
    });
  });

  describe('edge cases', () => {
    it('does not throw error when required elements are missing', () => {
      document.body.innerHTML = `
        <div class="lightbox">
          <div class="lightbox-trigger"></div>
          </div>
      `;
      expect(() => initLightbox()).not.toThrow();
    });
  });
});

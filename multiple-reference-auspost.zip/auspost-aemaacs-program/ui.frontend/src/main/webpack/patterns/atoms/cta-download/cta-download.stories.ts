import type { Meta, StoryObj } from '@storybook/html-vite';
import type { CtaDownloadProps } from './interfaces';

import component from './cta-download.liquid';

export default {
  title: 'Atoms/CTA Download',
  component,
  argTypes: {
    variant: { control: 'select', options: ['primary', 'inverted', 'secondary'] },
    size: { control: 'select', options: ['default', 'large'] },
    assetTypeAndSize: { control: 'text' },
    href: { control: 'text' },
    target: { control: 'text' },
    disabled: { control: 'boolean' },
    icon: { control: 'select', options: ['', 'download-alt', 'new-window'] },
    ariaLabel: { control: 'text' },
    ariaDescribedBy: { control: 'text' },
    title: { control: 'text' },
    meta: { control: 'text' }


  },
  args: {
    variant: 'primary',
    title: 'Download the sending guide',
    meta: '(PDF 7MB)',
    size: 'default',
    href: '',
    target: '',
    disabled: false,
    icon: 'download-alt',
    ariaLabel: '',
    ariaDescribedBy: ''
  }
} satisfies Meta<CtaDownloadProps>;

type Story = StoryObj<CtaDownloadProps>;

export const Primary: Story = {
  args: { variant: 'primary' }
};

export const Inverted: Story = {
  args: { variant: 'inverted' }
};

export const Secondary: Story = {
  args: { variant: 'secondary' }
};

export const Disabled: Story = {
  args: { disabled: true }
};

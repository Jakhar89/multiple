import { fetchApiGet, ResponseFormat } from '../../../../scripts/utils/api';
import { pushFormDataToDataLayer } from '../../../../scripts/analytics/analytics';
import { getIconPath } from '../../../../scripts/utils/utils';
import { ABNValidationError, ABNErrorMessages, ABNApiResponse } from './interfaces';

export default function initABNLookup(): void {
  const abnLookupComponent = document.querySelector<HTMLElement>('.cmp-form-abn-lookup');
  if (!abnLookupComponent) {
    return;
  }

  const abnLookupText = abnLookupComponent.querySelector<HTMLInputElement>('.abn-lookup-search__text');
  const abnSearchBtn = abnLookupComponent.querySelector<HTMLButtonElement>('.abn-search-wrapper .cmp-button');
  const abnClearBtn = abnLookupComponent.querySelector<HTMLElement>('.abn-lookup-search__input-clear');
  const abnResultsContainer = abnLookupComponent.querySelector<HTMLElement>('.abn-lookup-info');
  const abnResults = abnLookupComponent.querySelector<HTMLElement>('.abn-lookup-info__results');
  const abnErrorContainer = abnLookupComponent.querySelector<HTMLElement>('.error-message');
  const abnErrorMessage = abnErrorContainer?.querySelector<HTMLElement>('.error-label-item') ?? null;

  let verifiedABN: string | null = null;

  const errorMessages: ABNErrorMessages = {
    empty: abnLookupComponent.dataset.errorEmpty ?? 'ABN hasn\'t been entered',
    format: abnLookupComponent.dataset.errorFormat ?? 'ABN should be an 11-digit number',
    invalid: abnLookupComponent.dataset.errorInvalid ?? 'Enter a valid ABN'
  };

  if (!abnLookupText || !abnClearBtn || !abnSearchBtn || !abnResultsContainer || !abnResults) {
    return;
  }

  abnLookupText.dataset.abnInput = 'true';

  function validateABNFormat(value: string): ABNValidationError {
    const cleaned = value.replace(/\s/g, '');

    if (!cleaned) {
      return 'empty';
    }

    if (!/^\d{11}$/.test(cleaned)) {
      return 'format';
    }

    return null;
  }

  function showABNError(errorType: Exclude<ABNValidationError, null>): void {
    if (abnErrorContainer && abnErrorMessage && abnLookupText) {
      abnErrorMessage.textContent = errorMessages[errorType];
      showElement(abnErrorContainer);
      abnLookupText.classList.add('is-empty');
    }
  }

  function hideABNError(): void {
    if (abnErrorContainer && abnLookupText) {
      hideElement(abnErrorContainer);
      abnLookupText.classList.remove('is-empty');
    }
  }

  function clearInputField(): void {
    if (!abnLookupText || !abnResultsContainer || !abnClearBtn || !abnSearchBtn) {
      return;
    }

    abnLookupText.value = '';
    hideElement(abnResultsContainer);
    hideElement(abnClearBtn, 'd-inline-block');
    abnSearchBtn.disabled = false;
    verifiedABN = null;
    hideABNError();
  }

  async function searchABN(): Promise<boolean> {
    if (!abnLookupText || !abnSearchBtn || !abnResultsContainer || !abnClearBtn || !abnResults) {
      return false;
    }

    hideABNError();

    const currentABNValue = abnLookupText.value.trim();
    const validationError = validateABNFormat(currentABNValue);

    if (validationError) {
      showABNError(validationError);
      return false;
    }

    const cleanedABN = currentABNValue.replace(/\s/g, '');

    try {
      abnSearchBtn.disabled = true;
      setButtonLoading(abnSearchBtn, true);

      const apiResponse: ABNApiResponse = await fetchABNData(cleanedABN);

     if (!apiResponse?.abnDetails?.response) {
      if (apiResponse?.abnDetails?.error) {
        pushFormDataToDataLayer('field-error', 'identifier', [
          `${abnLookupText.name} || ${apiResponse.abnDetails.error}`
        ]);
      }

      showABNError('invalid');
      abnSearchBtn.disabled = false;
      return false;
    }



      const response = apiResponse.abnDetails?.response;

      if (response?.exception) {
        showABNError('invalid');
        abnSearchBtn.disabled = false;
        return false;
      }

      const businessEntity = response?.businessEntity202001;
      const entity = businessEntity?.mainName?.organisationName;
      const status = businessEntity?.entityStatus?.entityStatusCode;
      const type = businessEntity?.entityType?.entityDescription;

      if (!entity || !status || !type) {
        showABNError('invalid');
        abnSearchBtn.disabled = false;
        return false;
      }

      verifiedABN = cleanedABN;

      showElement(abnResultsContainer);
      showElement(abnClearBtn, 'd-inline-block');

      abnResults.innerHTML = `
        <p>
          <span class="abn-info-field">Entity name:</span>
          <span class="abn-info-result">${entity}</span>
        </p>
        <p>
          <span class="abn-info-field">Status:</span>
          <span class="abn-info-result">${status}</span>
        </p>
        <p>
          <span class="abn-info-field">Type:</span>
          <span class="abn-info-result">${type}</span>
        </p>
      `;

      return true;
    } catch {
      showABNError('invalid');
      abnSearchBtn.disabled = false;
      return false;
    } finally {
      setButtonLoading(abnSearchBtn, false);
    }
  }

  function handleInputChange(): void {
    if (!abnLookupText || !abnResultsContainer || !abnClearBtn || !abnSearchBtn) {
      return;
    }

    const currentValue = abnLookupText.value.replace(/\s/g, '');

    if (verifiedABN && currentValue !== verifiedABN) {
      verifiedABN = null;
      hideElement(abnResultsContainer);
      hideElement(abnClearBtn, 'd-inline-block');
      abnSearchBtn.disabled = false;
    }

    hideABNError();
  }


  async function validateForSubmit(): Promise<boolean> {
    if (!abnLookupText) {
      showABNError('invalid');
      return false;
    }

    const currentValue = abnLookupText.value.replace(/\s/g, '');
    const formatError = validateABNFormat(currentValue);

    if (formatError) {
      showABNError(formatError);
      return false;
    }

    if (verifiedABN === currentValue) {
      return true;
    }

    const isValid = await searchABN();
    return isValid;
  }

  async function fetchABNData(abn: string): Promise<ABNApiResponse> {
    const resourcePath: string = abnLookupComponent?.dataset.resourcePath ?? '';
    const url = `${resourcePath}?abn=${abn}`;
    const returnObj = await fetchApiGet(url, ResponseFormat.Json) as unknown as ABNApiResponse;

    return returnObj;
  }

  function setButtonLoading(button: HTMLButtonElement, isLoading: boolean): void {
    if (isLoading) {
      button.classList.add('loading');
      button.setAttribute('aria-busy', 'true');
      button.setAttribute('aria-disabled', 'true');

      if (!button.dataset.originalContent) {
        button.dataset.originalContent = button.innerHTML;
      }

      button.innerHTML = `
        <span class="button-icon spinner" aria-hidden="true">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <use href="${getIconPath()}/loading.svg#loading"/>
          </svg>
        </span>
        <span class="cmp-button__text">Loading</span>
      `;
    } else {
      button.classList.remove('loading');
      button.setAttribute('aria-busy', 'false');
      button.setAttribute('aria-disabled', 'false');

      if (button.dataset.originalContent) {
        button.innerHTML = button.dataset.originalContent;
      }
    }
  }

  function showElement(element: Element, displayClass: string = 'd-flex'): void {
    element.classList.remove('hide');
    element.classList.add(displayClass);
  }

  function hideElement(element: Element, displayClass: string = 'd-flex'): void {
    element.classList.remove(displayClass);
    element.classList.add('hide');
  }

  abnClearBtn.addEventListener('click', clearInputField);
  abnSearchBtn.addEventListener('click', (e) => {
    e.preventDefault();
    void searchABN();
  });
  abnLookupText.addEventListener('input', handleInputChange);
  abnLookupText.addEventListener('blur', () => {
    const currentABNValue = abnLookupText.value.trim();
    const validationError = validateABNFormat(currentABNValue);

    if (validationError) {
      showABNError(validationError);
      return;
    }
  });

  abnLookupText.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();

      if (verifiedABN) {
        return;
      }

      void searchABN();
    }
  });

  (abnLookupComponent as HTMLElement & { validateABN: () => Promise<boolean> }).validateABN = validateForSubmit;
}

import { FormInputFieldItem } from '../input/interfaces';

export interface ABNApiResponse {
  abnDetails: {
    response?: {
      exception?: {
        exceptionDescription: string;
        exceptionCode: string;
      };
      businessEntity202001?: {
        mainName?: {
          organisationName: string;
        };
        entityStatus?: {
          entityStatusCode: string;
        };
        entityType?: {
          entityDescription: string;
        };
      };
    };
    error?: string;
  };
}

export type ABNValidationError = 'empty' | 'format' | 'invalid' | null;

export interface ABNErrorMessages {
  empty: string;
  format: string;
  invalid: string;
}

export interface ABNLookupFieldItem extends FormInputFieldItem {
  errorEmpty?: string;
  errorFormat?: string;
  errorInvalid?: string;
}

export interface ABNLookupField {
  abnField: ABNLookupFieldItem;
  renderMode?: boolean;
}

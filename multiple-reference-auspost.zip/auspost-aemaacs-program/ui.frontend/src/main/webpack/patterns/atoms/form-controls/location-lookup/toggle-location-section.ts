import { addressSection } from '../location-lookup/address/address';
import { postcodeSuburbSection } from '../location-lookup/postcode-suburb-lookup/postcode-suburb-lookup';

export function toggleLocationSection(currentSection: string, newSection: string,
    locationParentComponent: HTMLElement, lookupContainer: HTMLElement) {

    resetSection(currentSection, locationParentComponent);
    showNewSection(currentSection, newSection, locationParentComponent, lookupContainer);
}

function resetSection(sectionClass: string, locationParentComponent: HTMLElement) {
    const section = locationParentComponent?.querySelector(`.${sectionClass}`);
    if (!section) { return; }

    section.querySelectorAll('input, select').forEach(item => {
        const element = item as HTMLInputElement & HTMLSelectElement;
        element.value = '';
        element.checked = false;
        element.classList.remove('is-empty');
    });
    section.querySelectorAll<HTMLElement>('.error-message').forEach(eItem => {
        eItem.style.display = 'none';
    });
}

function showNewSection(currentSection: string, newSection: string, locationParentComponent: HTMLElement, lookupContainer: HTMLElement) {
    const focusableSelector = 'input:not([disabled])';
    if (currentSection === postcodeSuburbSection.PostcodeOrSuburbLookupSection) {
        lookupContainer.classList.remove('active');
    }

    if (currentSection === addressSection.AddressLookupSection) {
        lookupContainer.classList.remove('active');
    }

    locationParentComponent?.querySelectorAll('.section').forEach(item => {
        item.classList.add('hidden');
    });

    locationParentComponent?.querySelector(`.${newSection}`)?.classList.remove('hidden');

    requestAnimationFrame(() => {
        const firstFocusableElement = locationParentComponent?.querySelector(`.${newSection}`)?.querySelector(focusableSelector);
        if (firstFocusableElement instanceof HTMLElement) {
            firstFocusableElement.focus();
        }
    });

    sessionStorage.setItem('activeLookupSection', newSection);
}

import { FormOptionsGroup } from './interfaces';
import { faker } from '@faker-js/faker';

export const SingleCheckboxOption: FormOptionsGroup = {
  id: 'checkbox_id',
  type: 'checkbox',
  name: 'userConsent',
  options: [
    {
      value: 'agree',
      text: 'I acknowledge that I have read and accept the Australia Post <a href="#" >privacy policy.</a>',
      selected: false,
      disabled: false,
    }
  ]

};

export const MultipleCheckboxOption: FormOptionsGroup = {
  id: 'checkbox_id',
  type: 'checkbox',
  name: 'servicesInterested',
  title: 'What service(s) are you interested in? ',
  helpMessage: 'You may select more than one option',
  required: true,
  options: [
    {
      value: 'domestic_parcels',
      text: 'Domestic parcels',
      selected: false,
      disabled: false,
    },
    {
      value: 'international_parcels',
      text: 'International parcels',
      selected: false,
      disabled: false,
    },
    {
      value: 'lettetr_service',
      text: 'Letter service',
      selected: false,
      disabled: false,
    },
    {
      value: 'payment_service',
      text: 'Payment Service',
      selected: false,
      disabled: false,
    },
    {
      value: 'other',
      text: 'others',
      selected: false,
      disabled: false,
    }
  ]
};

export const DisabledCheckboxOption: FormOptionsGroup = {
  id: 'checkbox_id',
  type: 'checkbox',
  name: 'servicesInterested',
  title: 'What service(s) are you interested in? ',
  helpMessage: faker.lorem.sentence(),
  options: [
    {
      value: 'domestic_parcels',
      text: 'Domestic parcels',
      selected: false,
      disabled: false,
    },
    {
      value: 'international_parcels',
      text: 'International parcels',
      selected: true,
      disabled: false,
    },
    {
      value: 'lettetr_service',
      text: 'Letter service',
      selected: true,
      disabled: true,
    },
    {
      value: 'payment_service',
      text: 'Payment Service',
      selected: false,
      disabled: true,
    },
    {
      value: 'other',
      text: 'others',
      selected: false,
      disabled: false,
    }
  ]
};

export const MultipleRadioOption: FormOptionsGroup = {
  id: 'radio-id',
  type: 'radio',
  name: 'radio-name',
  required: false,
  title: 'Size of Business',
  error: 'Select radio button is required',
  options: [{
    text: 'Option1',
    value: 'Option1',
    selected: false,
    disabled: false
  }, {
    text: 'Option2',
    value: 'option2',
    selected: false,
    disabled: false
  }, {
    text: 'Option3',
    value: 'option3',
    selected: false,
    disabled: false
  }, {
    text: 'Option4',
    value: 'option4',
    selected: false,
    disabled: false
  }, {
    text: 'Option5',
    value: 'option5',
    selected: false,
    disabled: false
  }]
};

export const DisabledRadioOption: FormOptionsGroup = {
  id: 'radio-id',
  type: 'radio',
  name: 'radio-name',
  required: false,
  title: 'Size of Business',
  error: 'Select radio button is required',
  options: [{
    text: 'Option1',
    value: 'Option1',
    selected: false,
    disabled: false
  }, {
    text: 'Option2',
    value: 'option2',
    selected: false,
    disabled: false
  }, {
    text: 'Option3',
    value: 'option3',
    selected: true,
    disabled: true
  }, {
    text: 'Option4',
    value: 'option4',
    selected: false,
    disabled: true
  }, {
    text: 'Option5',
    value: 'option5',
    selected: false,
    disabled: false
  }]
};

export const Dropdown: FormOptionsGroup = {
  id: 'cmp-dropdown-options-1',
  title: 'Select value from dropdown',
  type: 'drop-down',
  name: 'form-options',
  helpMessage: 'You may select more than one option',
  required: true,
  options: [
    { value: 'opt1', text: 'Option 1' },
    { value: 'opt2', text: 'Option 2' },
    { value: 'opt3', text: 'Option 3' },
  ]
};

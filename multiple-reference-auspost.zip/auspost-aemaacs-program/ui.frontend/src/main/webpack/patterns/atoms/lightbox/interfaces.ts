export interface LightboxProps {
  caption: string;
  imageHref: string;
  renderMode?: boolean;
} 

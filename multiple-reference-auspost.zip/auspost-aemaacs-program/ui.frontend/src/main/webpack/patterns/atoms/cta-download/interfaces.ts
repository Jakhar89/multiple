import './cta-download.scss';

export interface CtaDownloadProps {
  variant?: 'primary' | 'inverted' | 'secondary';
  size?: 'default' | 'large';
  label?: string;
  assetTypeAndSize?: string;
  href?: string;
  target?: string;
  disabled?: boolean;
  icon?: string;
  ariaLabel?: string;
  ariaDescribedBy?: string;
  title?: string;          
  meta?: string;
}

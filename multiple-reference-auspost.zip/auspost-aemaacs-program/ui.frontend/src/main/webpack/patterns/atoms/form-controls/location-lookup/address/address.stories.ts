import type { Meta, StoryObj } from '@storybook/html-vite';
import { faker } from '@faker-js/faker';
import { waitForUIToRenderInDOM } from '../../../../../scripts/utils/_story-utils';
import component from './address.liquid';
import { searchAddressField, searchAddressFieldValidation, manualAddressField, ValidationErrorManualAddressField } from './_address.mock';
import initAddress from './address';


const meta: Meta = {
  title: 'Atoms/Form Controls/Location Lookup/Address',
  component,
  args: {
    renderMode: true,
    addressField: searchAddressField,
    manualAddressField: manualAddressField,
    searchForAddressButton: 'Search for Address',
    addressSection: 'search'
  }
};

export default meta;

type Story = StoryObj;

export const Default: Story = {
  play: async () => {
    waitForUIToRenderInDOM('.address-lookup-container', initAddress);
  }
};

export const AddressLookupValidationError: Story = {
  args: {
    addressField: searchAddressFieldValidation
  },
  play: async () => {
    waitForUIToRenderInDOM('.address-lookup-container', initAddress);
  }
};

export const ManualAddressForm: Story = {
  args: {
    addressSection: 'manual'
  },
  play: async () => {
    waitForUIToRenderInDOM('.address-lookup-container', initAddress);
  }
};

export const ManualFormValidationError: Story = {
  args: {
    manualAddressField: ValidationErrorManualAddressField,
    addressSection: 'manual'
  }
};


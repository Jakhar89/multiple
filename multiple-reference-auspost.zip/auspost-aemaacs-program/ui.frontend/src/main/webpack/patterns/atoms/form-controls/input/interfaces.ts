export interface FormInputFieldItem {
  label: string;
  id: string;
  name: string;
  type: string;
  placeholder?: string;
  value?: string;
  optional?: boolean;
  helpMessage?: string;
  error?: string;
  disabled?: boolean;
  className?: string;
  charLimit?: number;
}

export interface FormInputField {
  inputField: FormInputFieldItem;
  renderMode?: boolean,
}

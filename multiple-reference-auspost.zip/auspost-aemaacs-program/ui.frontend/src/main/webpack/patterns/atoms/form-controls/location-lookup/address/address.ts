import initLocationLookup from '../location-lookup';

export const addressSection = {
    AddressLookupSection: 'search-address-container',
    ManualAddressSection: 'manual-address-container'
} as const;

export default function initAddress(): void {

    initLocationLookup({
        lookupVariant: 'address',
        parentContainerSelector: '.address-lookup-container',
        lookupInputSelector: '.address-input'
    });
};


document.addEventListener('DOMContentLoaded', initAddress);

import type { Meta, StoryObj } from '@storybook/html-vite';
import { userEvent, within, waitFor } from 'storybook/test';
import component from './abn-lookup.liquid';
import initABNLookup from './abn-lookup';
import { ABNLookupField } from './interfaces';
import { abnLookupFieldMock } from './_abn-lookup.mock';

const meta: Meta<ABNLookupField> = {
  title: 'Atoms/Form Controls/ABN Lookup',
  component,
  args: {
    renderMode: true,
    abnField: abnLookupFieldMock
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initABNLookup();
  }
};
export default meta;

type Story = StoryObj;

export const Default: Story = {};

export const ValidationErrorEmpty: Story = {
  play: async ({ canvasElement }) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initABNLookup();
    
    const canvas = within(canvasElement);
    const searchBtn = await waitFor(() =>
      canvas.getByRole('button', { name: /search/i })
    );
    
    await userEvent.click(searchBtn);
  }
};

export const ValidationErrorFormat: Story = {
  play: async ({ canvasElement }) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initABNLookup();
    
    const canvas = within(canvasElement);
    const input = canvas.getByRole('textbox');
    const searchBtn = await waitFor(() =>
      canvas.getByRole('button', { name: /search/i })
    );
    
    await userEvent.type(input, '12345');
    await userEvent.click(searchBtn);
  }
};

export const APIInvalidABN: Story = {
  play: async ({ canvasElement }) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initABNLookup();
    
    const canvas = within(canvasElement);
    const input = canvas.getByRole('textbox');
    const searchBtn = await waitFor(() =>
      canvas.getByRole('button', { name: /search/i })
    );
    
    await userEvent.type(input, '88888888888');
    await userEvent.click(searchBtn);
  }
};

export const APIError: Story = {
  play: async ({ canvasElement }) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initABNLookup();
    
    const canvas = within(canvasElement);
    const input = canvas.getByRole('textbox');
    const searchBtn = await waitFor(() =>
      canvas.getByRole('button', { name: /search/i })
    );
    
    await userEvent.type(input, '99999999999');
    await userEvent.click(searchBtn);
  }
};

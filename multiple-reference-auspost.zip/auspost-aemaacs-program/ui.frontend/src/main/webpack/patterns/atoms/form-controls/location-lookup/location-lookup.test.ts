import { liquidEngine } from '~/../../../jest.config';
import { searchAddressField, manualAddressField } from '../location-lookup/address/_address.mock';
import initLocationLookup from './location-lookup';
import { LocationLookup } from './interfaces.js';

describe('Location Lookup Component', () => {
  let addressComponent: HTMLElement;
  let addressInputField: HTMLInputElement;
  let addressLookupContainer: HTMLElement;
  let manualFormContainer: HTMLElement;
  let toggleSection: HTMLButtonElement;
  let suggestedList: HTMLElement;

  describe('Address lookup component rendering', () => {
    beforeEach(async () => {
      const html = await liquidEngine.renderFile(
        'src/main/webpack/patterns/atoms/form-controls/location-lookup/location-lookup.liquid',
        {
          renderMode: true
          , containerClass: 'address-lookup-container'
          , inputFieldLookupClass: 'address-input'
          , addressSection: 'search'
          , addressField: searchAddressField
          , manualAddressField: manualAddressField
          , searchForAddressButton: 'Search for Address'
          , dataVar: 'address-url'
          , dataUrl: '/addresslookup.model.json'
        }
      );
      document.body.innerHTML = html;

      const config: LocationLookup = {
        lookupVariant: 'address',
        parentContainerSelector: '.address-lookup-container',
        lookupInputSelector: '.address-input'
      }
      initLocationLookup(config);

      addressComponent = document.querySelector(config.parentContainerSelector) as HTMLElement;
      addressInputField = document.querySelector(config.lookupInputSelector) as HTMLInputElement;
      addressLookupContainer = document.querySelector('.search-address-container') as HTMLElement;
      manualFormContainer = document.querySelector('.manual-address-container') as HTMLElement;
      toggleSection = document.querySelector('.address-lookup-button .cmp-button') as HTMLButtonElement;
      suggestedList = document.querySelector('.suggested-address-container') as HTMLElement;
    });

    test('render Address Lookup component and Address Lookup Input field', () => {
      expect(addressComponent).not.toBeNull();
      expect(addressInputField).not.toBeNull();
    });

    test('show Suggesstion list section when focussed on address lookup field', async () => {
      addressInputField.dispatchEvent(new Event('input'));
      expect(suggestedList.classList.contains('active')).toBe(true);
      addressInputField.value = '';
      addressInputField.dispatchEvent(new Event('focusout'));
      expect(suggestedList.classList.contains('active')).toBe(true);
    });
  });

  describe('Manual form section', () => {
    beforeEach(async () => {
      const html = await liquidEngine.renderFile(
        'src/main/webpack/patterns/atoms/form-controls/location-lookup/location-lookup.liquid',
        {
          renderMode: true
          , containerClass: 'address-lookup-container'
          , inputFieldLookupClass: 'address-input'
          , addressSection: 'manual'
          , addressField: searchAddressField
          , manualAddressField: manualAddressField
          , searchForAddressButton: 'Search for Address'
          , dataVar: 'address-url'
          , dataUrl: '/addresslookup.model.json'
        }
      );
      document.body.innerHTML = html;
      const config: LocationLookup = {
        lookupVariant: 'address',
        parentContainerSelector: '.address-lookup-container',
        lookupInputSelector: '.address-input'
      }
      initLocationLookup(config);

      addressLookupContainer = document.querySelector('.search-address-container') as HTMLElement;
      manualFormContainer = document.querySelector('.manual-address-container') as HTMLElement;
      toggleSection = document.querySelector('.form-section-button .cmp-button') as HTMLButtonElement;
    });

    test('render Manual form and on click show Address Lookup', () => {
      expect(addressLookupContainer.classList.contains('hidden')).toBe(true);
      expect(manualFormContainer.classList.contains('hidden')).toBe(false);

      toggleSection.dispatchEvent(new MouseEvent('click'));

      expect(manualFormContainer.classList.contains('hidden')).toBe(false);
    });
  });
});

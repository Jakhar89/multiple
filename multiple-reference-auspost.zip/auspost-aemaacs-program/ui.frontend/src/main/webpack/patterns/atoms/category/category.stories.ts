import type { Meta, StoryObj } from '@storybook/html-vite';
import type { CategoryProps } from './interfaces';
import component from './category.liquid';
import './category.scss';

export default {
  title: 'Atoms/Category',
  component,
  argTypes: {
    label: { control: 'text' },
    bgColor: {
      control: 'select',
      options: ['red', 'black', 'grey'],
    },
    textColor: {
      control: 'select',
      options: ['white', 'black'],
    },
  },
  args: {
    label: 'Stamp Issue',
    bgColor: 'red',
    textColor: 'white',
  },
} satisfies Meta<CategoryProps>;

type Story = StoryObj<CategoryProps>;

export const Red: Story = {
  args: {
    bgColor: 'red',
    textColor: 'white',
  },
};

export const Black: Story = {
  args: {
    bgColor: 'black',
    textColor: 'white',
  },
};

export const Grey: Story = {
  args: {
    bgColor: 'grey',
    textColor: 'black',
  },
};

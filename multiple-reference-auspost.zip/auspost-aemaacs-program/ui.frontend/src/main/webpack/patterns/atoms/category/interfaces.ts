export interface CategoryProps {
  label: string;
  bgColor?: string;
  textColor?: string;
}

import type { Meta, StoryObj } from '@storybook/html-vite';
import type { FormInputField } from './interfaces';
import { faker } from '@faker-js/faker';
import component from './input.liquid';

const meta: Meta<FormInputField> = {
  title: 'Atoms/Form Controls/Input',
  component,
  args: {
     renderMode: true,
     inputField: {
      id: 'field-id',
      name: 'field-name',
      type: 'text',
      label: 'First name',
      placeholder: '',
      value: '',
      optional: true,
      error: '',
      disabled: false,
      className: '',
      charLimit: 10
    }
  }
};

export default meta;

type Story = StoryObj;

export const Default: Story = {};

export const HelpMessage: Story = {
  args: {
      inputField:{ 
        ...meta.args?.inputField,
        optional: false,
        helpMessage: faker.lorem.sentences(1)
      }
  }
};

export const Placeholder: Story = {
  args: {
    inputField:{ 
       ...meta.args?.inputField,
      helpMessage: faker.lorem.sentences(1),
      placeholder: faker.lorem.words(3)
    }
  }
};

export const EnteredValue: Story = {
  args: {
    inputField:{ 
       ...meta.args?.inputField,
      helpMessage: faker.lorem.sentences(1),
      value: faker.person.firstName()
    }
  }
};

export const Disabled: Story = {
  args: {
    inputField:{ 
       ...meta.args?.inputField,
      helpMessage: faker.lorem.sentences(1),
      placeholder: faker.lorem.words(3),
      disabled: true
    }
  }
};

export const Required: Story = {
  args: {
    inputField:{ 
       ...meta.args?.inputField,
      placeholder: faker.lorem.words(3),
      optional: false
    }
  }
};

export const Email: Story = {
  args: {
    inputField:{ 
       ...meta.args?.inputField,
       type: 'email',
       label: 'Email address',
       placeholder: 'Enter your email',
       optional: false
    }
  }
};

export const ValidationError: Story = {
  args: {
    inputField:{ 
       ...meta.args?.inputField,
      placeholder: faker.lorem.words(3),
      optional: false,
      helpMessage: faker.lorem.sentences(1),
      value: 'This value is invalid',
      error: 'Enter your name'
    }
  }
};

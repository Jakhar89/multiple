import {
    getTabElements,
    updateArrowStates,
    scrollTabs,
    setupTabsScroll,
    activateTab,
    setupTabs,
    initTabs,
} from './tabs';

type AnyEl = HTMLElement & {
    scrollTo?: {
        (options?: ScrollToOptions): void;
        (x: number, y: number): void;
    };
};

const setDim = (el: AnyEl, clientWidth: number, scrollWidth: number) => {
    Object.defineProperty(el, 'clientWidth', { value: clientWidth, configurable: true });
    Object.defineProperty(el, 'scrollWidth', { value: scrollWidth, configurable: true });
};

const setScrollLeft = (el: AnyEl, value: number) => {
    let _val = value;
    Object.defineProperty(el, 'scrollLeft', {
        get: () => _val,
        set: v => {
            _val = v;
        },
        configurable: true,
    });
};

const stubScrollTo = (el: AnyEl) => {
    const fn = jest.fn((...args: any[]) => {
        if (typeof args[0] === 'object' && args[0] !== null) {
            const opts = args[0] as ScrollToOptions & { left?: number };
            if (typeof opts.left === 'number') {
                (el as any).scrollLeft = opts.left;
            }
        } else if (typeof args[0] === 'number') {
            const left = args[0] as number;
            (el as any).scrollLeft = left;
        }
    });
    // Assign as the overloaded signature type
    (el as any).scrollTo = fn as unknown as AnyEl['scrollTo'];
};

const buildTabsContainer = (count = 3, overflow = true, markActiveIndex: number | null = null) => {
    const container = document.createElement('div');
    container.className = 'cmp-tabs';

    const outer = document.createElement('div');
    outer.className = 'tabs-list-wpr';

    const btnPrev = document.createElement('button');
    btnPrev.className = 'tabs-prev';

    const btnNext = document.createElement('button');
    btnNext.className = 'tabs-next';

    const list = document.createElement('div');
    list.className = 'tabs-list';

    for (let i = 0; i < count; i++) {
        const tab = document.createElement('button');
        tab.className = 'cmp-tabs__tab';
        tab.id = `tab-${i}`;
        tab.textContent = `Tab ${i + 1}`;
        if (markActiveIndex === i) {
            tab.classList.add('cmp-tabs__tab--active');
        }
        // track focus calls
        tab.focus = jest.fn();
        list.appendChild(tab);
    }

    const select = document.createElement('select');
    select.className = 'cmp-tabs-select';
    for (let i = 0; i < count; i++) {
        const opt = document.createElement('option');
        opt.value = String(i);
        opt.textContent = `Tab ${i + 1}`;
        select.appendChild(opt);
    }

    for (let i = 0; i < count; i++) {
        const panel = document.createElement('div');
        panel.className = 'cmp-tabs__tabpanel';
        panel.textContent = `Panel ${i + 1}`;
        container.appendChild(panel);
    }

    outer.appendChild(btnPrev);
    outer.appendChild(list);
    outer.appendChild(btnNext);
    container.appendChild(outer);
    container.appendChild(select);

    // dimensions and scrolling
    setDim(list as AnyEl, overflow ? 300 : 600, overflow ? 1000 : 600);
    setDim(outer as AnyEl, 600, 600);

    setScrollLeft(list as AnyEl, 0);
    setScrollLeft(outer as AnyEl, 0);
    stubScrollTo(list as AnyEl);
    stubScrollTo(outer as AnyEl);

    // Ensure style exists
    [btnPrev, btnNext].forEach(b => {
        b.style.display = '';
    });

    document.body.appendChild(container);
    return { container, outer: outer as AnyEl, list: list as AnyEl, btnPrev, btnNext, select };
};

beforeEach(() => {
    document.body.innerHTML = '';
    window.location.hash = '';
    // immediate raf
    (window as any).requestAnimationFrame = (cb: FrameRequestCallback) => {
        cb(performance.now());
        return 1 as unknown as number;
    };
});

describe('getTabElements', () => {
    it('returns all expected elements', () => {
        const { container } = buildTabsContainer(3);
        const els = getTabElements(container);
        expect(els.outer).toBeInstanceOf(HTMLElement);
        expect(els.list).toBeInstanceOf(HTMLElement);
        expect(els.btnNext).toBeInstanceOf(HTMLElement);
        expect(els.btnPrev).toBeInstanceOf(HTMLElement);
        expect(els.tabs.length).toBe(3);
        expect(els.tabpanels.length).toBe(3);
    });
});

describe('updateArrowStates', () => {
    it('hides prev at start and next at end', () => {
        const { list, btnPrev, btnNext } = buildTabsContainer(3);
        setScrollLeft(list, 0);
        updateArrowStates(list, btnPrev, btnNext);
        expect(btnPrev.style.display).toBe('none');
        expect(btnNext.style.display).toBe('');

        setScrollLeft(list, 450); // near end (max = 1000-300 = 700)
        updateArrowStates(list, btnPrev, btnNext);
        expect(btnPrev.style.display).toBe('');
        expect(btnNext.style.display).toBe('');

        setScrollLeft(list, 700); // at end
        updateArrowStates(list, btnPrev, btnNext);
        expect(btnPrev.style.display).toBe('');
        expect(btnNext.style.display).toBe('none');
    });
});

describe('scrollTabs', () => {
    it('scrolls by amount and updates arrow states after animation', () => {
        jest.useFakeTimers();
        const { list, btnPrev, btnNext } = buildTabsContainer(3);
        setScrollLeft(list, 0);

        scrollTabs(list, 180, btnPrev, btnNext);
        expect((list.scrollTo as jest.Mock).mock.calls[0][0]).toMatchObject({ left: 180 });

        jest.advanceTimersByTime(300);
        expect(btnPrev.style.display).toBe(''); // not at start anymore
        expect(btnNext.style.display).toBe(''); // not at end yet
        jest.useRealTimers();
    });
});

describe('setupTabsScroll', () => {
    it('binds click handlers and scroll/resize updates', () => {
        jest.useFakeTimers();
        const { container, btnPrev, btnNext, list, outer } = buildTabsContainer(3);
        setupTabsScroll(container);

        // List overflows; scroller is list, not outer
        btnNext.click();
        expect((list.scrollTo as jest.Mock).mock.calls.length).toBe(1);
        expect((list.scrollTo as jest.Mock).mock.calls[0][0]).toMatchObject({ left: 180 });

        btnPrev.click();
        // second call should reduce to 0
        expect((list.scrollTo as jest.Mock).mock.calls[1][0]).toMatchObject({ left: 0 });

        // Trigger scroll event updates
        list.dispatchEvent(new Event('scroll'));
        // Trigger resize
        window.dispatchEvent(new Event('resize'));

        // Ensure outer was not used
        expect((outer.scrollTo as jest.Mock).mock.calls.length).toBe(0);

        jest.useRealTimers();
    });
});

describe('activateTab', () => {
    it('updates classes, aria, select and hash', () => {
        const { container, select } = buildTabsContainer(3);
        const { tabs, tabpanels } = getTabElements(container);

        activateTab(tabs, tabpanels, select, 1, true);

        expect(tabs[1].classList.contains('cmp-tabs__tab--active')).toBe(true);
        expect(tabs[1].getAttribute('aria-selected')).toBe('true');
        expect(tabs[0].getAttribute('tabindex')).toBe('-1');

        expect(tabpanels[1].classList.contains('cmp-tabs__tabpanel--active')).toBe(true);
        expect(tabpanels[0].getAttribute('aria-hidden')).toBe('true');

        expect(select?.value).toBe('1');
        expect(window.location.hash).toBe('#tab-1');
    });
});

describe('setupTabs', () => {
    it('initializes from hash and handles click/keyboard/hashchange', () => {
        const { container, list } = buildTabsContainer(3);
        // set initial hash to second tab
        window.location.hash = '#tab-1';
    setupTabs(container);
    // Ensure hash initialization is applied in this environment
    window.dispatchEvent(new HashChangeEvent('hashchange'));

        const { tabs, tabpanels, select } = getTabElements(container);
        // initialized from hash (no duplicate hash update)
        expect(tabs[1].classList.contains('cmp-tabs__tab--active')).toBe(true);
        expect(tabpanels[1].classList.contains('cmp-tabs__tabpanel--active')).toBe(true);
        expect(select?.value).toBe('1');

        // Click third tab
        tabs[2].click();
        expect(tabs[2].classList.contains('cmp-tabs__tab--active')).toBe(true);
        expect(window.location.hash).toBe('#tab-2');

        // Keyboard navigate Right from tab2 -> wraps to tab0
        const keyEvent = new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true });
        tabs[2].dispatchEvent(keyEvent);
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);

        // Home -> first
        const homeEvent = new KeyboardEvent('keydown', { key: 'Home', bubbles: true });
        tabs[0].dispatchEvent(homeEvent);
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);

        // End -> last
        const endEvent = new KeyboardEvent('keydown', { key: 'End', bubbles: true });
        tabs[0].dispatchEvent(endEvent);
        expect(tabs[2].classList.contains('cmp-tabs__tab--active')).toBe(true);

        // hashchange sync back to tab 1
        window.location.hash = '#tab-1';
        window.dispatchEvent(new HashChangeEvent('hashchange'));
        expect(tabs[1].classList.contains('cmp-tabs__tab--active')).toBe(true);

        // Space/Enter should activate current focused
        const spaceEvent = new KeyboardEvent('keydown', { key: ' ', bubbles: true });
        tabs[1].dispatchEvent(spaceEvent);
        expect(tabs[1].classList.contains('cmp-tabs__tab--active')).toBe(true);

        // Ensure key listener was attached to list container
        expect(list.className).toBe('tabs-list');
    });

});

describe('initTabs', () => {
    it('initializes all cmp-tabs on page with first tab active by default', () => {
        const { container } = buildTabsContainer(2);
        // No hash; first should be activated
        initTabs();
        const { tabs } = getTabElements(container);
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);
    });
});
describe('setupTabs - additional', () => {
    it('centers the active tab when re-activated (outer scroller)', () => {
        jest.useFakeTimers();
        const { container, list } = buildTabsContainer(5, false, 2);
        const { tabs } = getTabElements(container);

        tabs.forEach((t, i) => {
            Object.defineProperty(t, 'offsetLeft', { value: i * 120, configurable: true });
            Object.defineProperty(t, 'offsetWidth', { value: 100, configurable: true });
        });

    setupTabs(container);

    // Re-activate the already active tab to trigger centering
    const activeIdx = tabs.findIndex(t => t.classList.contains('cmp-tabs__tab--active'));
    const enterEvent = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true });
    tabs[activeIdx].dispatchEvent(enterEvent);

    // Allow any delayed centering to run
    jest.advanceTimersByTime(600);

    expect((list.scrollTo as jest.Mock).mock.calls.length).toBeGreaterThan(0);
        jest.useRealTimers();
    });

    it('select change activates, focuses and centers using list scroller', () => {
        const { container, list, outer, select } = buildTabsContainer(4, true, null);
        const { tabs } = getTabElements(container);

        tabs.forEach((t, i) => {
            Object.defineProperty(t, 'offsetLeft', { value: i * 200, configurable: true });
            Object.defineProperty(t, 'offsetWidth', { value: 100, configurable: true });
        });

        setupTabs(container);

        expect(select).toBeTruthy();
        if (!select) return;

        select.value = '2';
        select.dispatchEvent(new Event('change', { bubbles: true }));

        expect(tabs[2].classList.contains('cmp-tabs__tab--active')).toBe(true);
        expect((tabs[2].focus as jest.Mock)).toHaveBeenCalled();

        expect((list.scrollTo as jest.Mock).mock.calls.length).toBeGreaterThan(0);
        expect((outer.scrollTo as jest.Mock).mock.calls.length).toBe(0);
    });

    it('Enter activates focused tab and centers it', () => {
        const { container, list } = buildTabsContainer(3, true, null);
        const { tabs } = getTabElements(container);

        tabs.forEach((t, i) => {
            Object.defineProperty(t, 'offsetLeft', { value: i * 150, configurable: true });
            Object.defineProperty(t, 'offsetWidth', { value: 100, configurable: true });
        });

        setupTabs(container);

        const enterEvent = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true });
        tabs[1].dispatchEvent(enterEvent);

        expect(tabs[1].classList.contains('cmp-tabs__tab--active')).toBe(true);
        expect((tabs[1].focus as jest.Mock)).toHaveBeenCalled();
        expect((list.scrollTo as jest.Mock).mock.calls.length).toBeGreaterThan(0);
    });

    it('ArrowLeft wraps from first to last', () => {
        const { container } = buildTabsContainer(3, true, null);
        const { tabs } = getTabElements(container);

        setupTabs(container);

        // Initially first tab is active
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);

        const leftEvent = new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true });
        tabs[0].dispatchEvent(leftEvent);

        expect(tabs[2].classList.contains('cmp-tabs__tab--active')).toBe(true);
    });

    it('focusin recenters the focused tab', () => {
        const { container, list } = buildTabsContainer(5, true, null);
        const { tabs } = getTabElements(container);

        tabs.forEach((t, i) => {
            Object.defineProperty(t, 'offsetLeft', { value: i * 180, configurable: true });
            Object.defineProperty(t, 'offsetWidth', { value: 100, configurable: true });
        });

        setupTabs(container);

        (list.scrollTo as jest.Mock).mockClear();

        const focusIn = new FocusEvent('focusin', { bubbles: true });
        tabs[4].dispatchEvent(focusIn);

        expect((list.scrollTo as jest.Mock).mock.calls.length).toBe(1);
        expect((list.scrollTo as jest.Mock).mock.calls[0][0]).toMatchObject({ left: expect.any(Number) });
    });
});

describe('global init and hashchange edge cases', () => {
    it('initializes tabs on window load event', () => {
        const { container } = buildTabsContainer(2, true, null);
        // Do not call initTabs directly; trigger the window load listener
        window.dispatchEvent(new Event('load'));
        const { tabs } = getTabElements(container);
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);
    });

    it('hashchange with non-matching id does not change selection', () => {
        const { container } = buildTabsContainer(3, true, null);
        setupTabs(container);
        const { tabs } = getTabElements(container);
        // Start at first active
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);
        // Change to a hash that doesn’t match any tab id
        window.location.hash = '#nope';
        window.dispatchEvent(new HashChangeEvent('hashchange'));
        // Should remain unchanged
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);
    });
});

describe('additional coverage', () => {
    it('setupTabs works without select element present', () => {
        const { container } = buildTabsContainer(3, true, null);
        const { select, tabs } = getTabElements(container);
        // Remove select
        select?.remove();
        setupTabs(container);
        // Clicking tab 2 should activate it
        tabs[2].click();
        expect(tabs[2].classList.contains('cmp-tabs__tab--active')).toBe(true);
    });

    it('setupTabs sets first tab active when none active and no hash', () => {
        const { container } = buildTabsContainer(3, true, null);
        setupTabs(container);
        const { tabs } = getTabElements(container);
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);
    });

    it('activateTab does not update hash when disabled', () => {
        const { container, select } = buildTabsContainer(2, true, null);
        const { tabs, tabpanels } = getTabElements(container);
        activateTab(tabs, tabpanels, select, 1, false);
        expect(window.location.hash).toBe('');
        expect(tabs[1].classList.contains('cmp-tabs__tab--active')).toBe(true);
    });

    it('select change with invalid value falls back to 0', () => {
        const { container, list } = buildTabsContainer(3, true, null);
        const { select, tabs } = getTabElements(container);
        setupTabs(container);
        if (!select) return;
        select.value = 'junk';
        select.dispatchEvent(new Event('change', { bubbles: true }));
        expect(tabs[0].classList.contains('cmp-tabs__tab--active')).toBe(true);
        // Should have attempted to center
        expect(((list as AnyEl).scrollTo as jest.Mock).mock.calls.length).toBeGreaterThanOrEqual(0);
    });

    it('updateArrowStates hides both arrows when no overflow', () => {
        const { list, btnPrev, btnNext } = buildTabsContainer(3, false, null);
        // When no overflow, maxScroll=0 and scrollLeft=0 -> both hidden
        updateArrowStates(list, btnPrev, btnNext);
        expect(btnPrev.style.display).toBe('none');
        expect(btnNext.style.display).toBe('none');
    });

    it('setupTabs returns early if tabs and panels mismatch', () => {
        // Build a container with 3 tabs but only 2 panels
        const { container } = buildTabsContainer(3, true, null);
        const extraPanel = container.querySelectorAll('.cmp-tabs__tabpanel')[2];
        extraPanel?.remove();
        const { tabs } = getTabElements(container);
        setupTabs(container);
        // Click should not activate (no listeners attached)
        tabs[1].click();
        expect(tabs[1].classList.contains('cmp-tabs__tab--active')).toBe(false);
    });
});
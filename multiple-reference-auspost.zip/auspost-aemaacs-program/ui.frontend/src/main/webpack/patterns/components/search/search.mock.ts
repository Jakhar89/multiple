import { faker } from '@faker-js/faker';
import { PopularSearchItemsProps, PopularSearchProps, QuerySuggestionsProps, SearchFieldProps } from './SearchUtils/interface';

export const popularSearchItems: PopularSearchItemsProps[] = [
    { label: faker.lorem.words(5), href: '#', target: '_blank' },
    { label: faker.lorem.words(3), href: '#' , target: '_blank' },
    { label: faker.lorem.words(8).replace(/\s/g, ''), href: '#' },
    { label: faker.lorem.words(3), href: '#' },
    { label: faker.lorem.words(2), href: '#' }
];

export const popularSearch: PopularSearchProps = {
    title: 'POPULAR SEARCHES',
    items: popularSearchItems
};

export const searchFieldData: SearchFieldProps = {
    label: 'Search results',
    buttonText: 'Search button',
    placeholder: 'Search site',
    redirectUrl: '/search',
    autocomplete: true,
    autocompleteTitle: 'Search suggestions'
};

export const querySuggestions: QuerySuggestionsProps = {
    querySuggestions: [
        {
            suggestion: 'how much did aussies spend on retail in 2023'
        },
        {
            suggestion: 'how to track my parcel'
        },
        {
            suggestion: 'how to bypass parcel delivery redirection'
        },
        {
            suggestion: 'how much stamp do i need for international shipping'
        },
        {
            suggestion: 'how to change my delivery address'
        },
        {
            suggestion: 'how to calculate postage'
        }
    ]
};

// URLs and config used by the Liquid template
export const searchAutocompleteUrl = 'https://digitalapi-ptest.npe.auspost.com.au/website-search/v1/projects/1059627761126/locations/global/dataStores/collectables_1751334621778:completeQuery';
export const searchApiUrl = 'https://digitalapi-ptest.npe.auspost.com.au/website-search/v1beta/projects/1059627761126/locations/global/collections/default_collection/engines/auspost-collectables_1753855879141/servingConfigs/default_search:search';
export const resultPageSize = 10;

export const errorMessage = `
<h3>${faker.lorem.sentence()}</h3>
<p>${faker.lorem.paragraph()}<a href="#">${faker.lorem.word()}</a> </p>
`;
import { faker } from '@faker-js/faker';

export const caption = faker.lorem.sentence(3);
export const longCaption = faker.lorem.sentences(6);
export const downloadCaption = 'Download PDF'
export const downloadSize = `${faker.number.int({ min: 50, max: 5000 })}KB`;

import { faker } from '@faker-js/faker';
import { BannerProps } from '../interfaces';

export const HERO_BANNER_DATA: BannerProps = {
  variant: 'hero',
  category: {
    label: '2025 ANDA Perth Money Expo',
    bgColor: 'red',
    textColor: 'white'
  },
  label: '',
  heading: faker.lorem.sentence(3),
  description: '',
  issueDate: `Issue date: ${faker.date
    .between({ from: '2020-01-01', to: '2025-12-31' })
    .toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    })}`,
  cta: false,
  backgroundImage: {
    src: 'src/main/webpack/patterns/assets/images/landscape.png',
    alt: 'Abstract pastel background'
  },
  image: {
    src: '',
    alt: ''
  }
};

import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './ecommreportsearch.liquid';
import initSearch from './ecommreportsearch';
import { suggestedSearchData, searchFieldData, URLS } from './ecommreportsearch.mock';

const meta = {
  title: 'Components/Ecommerce Report/Search',
  component: component,
  parameters: {},
  args: {
    // Provide JSON strings so Liquid can embed directly
    searchFieldJson: JSON.stringify(searchFieldData),
    suggestedSearchJson: JSON.stringify(suggestedSearchData),
    autocompleteUrl: URLS.autocompleteUrl,
    keywordSearchUrl: URLS.keywordSearchUrl,
    answerUrl: URLS.answerUrl,
    pdfUrl: URLS.pdfUrl,
    homeUrl: URLS.homeUrl
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    initSearch();
  }
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const Default: Story = {};
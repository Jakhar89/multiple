import { faker } from '@faker-js/faker';
import { BreadcrumbItem } from './interfaces';

const generateBreadcrumb = () => {
  return { 
    title: faker.commerce.productName(), 
    href: faker.internet.url()
  }
}

export const mockBreadcrumbs = (length: number = 3): BreadcrumbItem[] => {
  const breadcrumbs = [];

  for (let i = 0; i < length; i++) {
    breadcrumbs.push(generateBreadcrumb());
  }

  return breadcrumbs;
}

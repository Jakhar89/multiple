import React from 'react';
import Skeleton from 'react-loading-skeleton';
import { getHighlightParts } from './Autosuggest.utils';
import type { AutosuggestListProps } from '../SearchUtils/interface';
import Icon from '../../../foundations/iconset/Icon';
import { useSearchContext } from '../SearchUtils/searchContext';
import config from '../util/search.config';
import { createSuggestedSearchDataLayer, pushSuggestedSearchToDataLayer } from '../../../../scripts/analytics/analytics';

export default function AutosuggestList({
    idBase,
    listboxId,
    suggestions,
    activeIndex,
    query,
    title,
    onSelect,
    loading = false,
    skeletonCount = config.autoCompleteMaxResults,
    isResultView = false,
    remoteSuggestions,
}: AutosuggestListProps) {
    const { searchField } = useSearchContext();
    const viewAllHref = (searchField?.redirectUrl || config.defaultRedirectionUrl);

    const handleSuggestionClick = (item: string) => {
        pushSuggestedSearchToDataLayer(item);
        onSelect(item);
    };
    return (
        <div className={`autosuggest-dropdown${isResultView ? ' position-absolute enable-shadow m-t-0 p-t-500 p-x-400 p-b-500' : ' m-t-500'}`}>
            {title && (
                <strong className="suggestions-heading m-b-400 d-flex">
                    {title}
                </strong>
            )}

            <ul
                id={listboxId}
                role="listbox"
                aria-busy={loading}
                className="autosuggest-list list-style-none"
            >
                {loading
                    ? Array.from({ length: skeletonCount }).map((_, index) => (
                        <li
                            key={`skeleton-${index}`}
                            id={`${idBase}-option-skeleton-${index}`}
                            role="option"
                            aria-selected={false}
                            className="autosuggest-item"
                            onMouseDown={(e) => e.preventDefault()}
                        >
                            <span className="suggestions-label suggestions-loading d-inline-flex p-150 w-100">
                                <Skeleton
                                    height={16}
                                    duration={1.2}
                                    direction="ltr"
                                    enableAnimation={true}
                                    width={Math.random() * (80 - 40) + 40 + '%'}
                                />
                            </span>
                        </li>
                    ))
                    : suggestions.map((item, index) => {
                        const { before, match, after } = getHighlightParts(
                            item,
                            query
                        );
                        const elementId = `${idBase}-option-${index}`;
                        const dataLayer = createSuggestedSearchDataLayer(elementId, item);

                        return (
                            <li
                                key={item}
                                id={elementId}
                                role="option"
                                aria-selected={index === activeIndex}
                                aria-label={item}
                                className={`autosuggest-item${index === activeIndex ? ' is-active' : ''
                                    }`}
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => handleSuggestionClick(item)}
                                data-cmp-data-layer={dataLayer}
                            >
                                <span className="suggestions-label d-inline-flex p-150" aria-hidden="true">
                                    <Icon name="search-thin" className='m-r-150' size='sm' />
                                    <span>
                                        <span>{before}</span>
                                        {match && <strong>{match}</strong>}
                                        <span>{after}</span>
                                    </span>
                                </span>
                            </li>
                        );
                    })}
            </ul>

            {(remoteSuggestions && remoteSuggestions.length > config.autoCompleteMaxResults && !loading) && (
                <div className='view-all-link'>
                    <a
                        href={viewAllHref}
                        onClick={(e) => {
                            if (isResultView) {
                                e.preventDefault();
                                onSelect('');
                            }
                        }}
                    >
                        View All results
                    </a>
                </div>
            )}
        </div>
    );
}

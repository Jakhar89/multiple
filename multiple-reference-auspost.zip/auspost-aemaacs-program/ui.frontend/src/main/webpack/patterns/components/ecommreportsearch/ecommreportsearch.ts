import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { SearchProvider } from './store/ERSearchContext';
import EcommReportSearchApp from './EcommReportSearchApp';
import { readSearchDataset } from './ecommreportsearch.util';

let isInitialized = false;
let rootInstance: Root | null = null;

export default function initSearch(): void {
  if (isInitialized) return;

  const mountNode = document.getElementById('ecomm-report-search-app');
  if (!mountNode) return;

  const { suggestedSearch, searchField, autocompleteUrl, keywordSearchUrl, answerUrl, pdfUrl, homeUrl } = readSearchDataset(mountNode);

  rootInstance = createRoot(mountNode);

  rootInstance.render(
    React.createElement(
      SearchProvider,
      {
        value: {
          suggestedSearch,
          searchField,
          autocompleteUrl,
          keywordSearchUrl,
          answerUrl,
          pdfUrl,
          homeUrl
        },
      },
      React.createElement(EcommReportSearchApp)
    )
  );

  isInitialized = true;
}


if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initSearch);
} else {
  initSearch();
}

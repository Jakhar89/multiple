import ERIcon from "../Icons/ERIcon";
import ERLoader from "./ERLoader";

export default function ERAiLoader() {
  return (
    <div className="search-results-container">
      <div className="search-result-query">
        <ERLoader skeletonCount={1} className="white-loader" />
      </div>
      <div className="search-results-wrapper loading">
        <div className="search-ai-disclaimer">
          <ERIcon name="generative-ai" />
          <span>Generating...</span>
        </div>
        <ERLoader skeletonCount={8} className="ai-loader" />
      </div>
    </div>
  );
}

import { faker } from '@faker-js/faker';

export const mockTabsData = {
  // Default variation with 3 tabs
default: {
    activeItem: 0,
    tabs: [
        {
            title: faker.commerce.productName(),
            content: `
                <div class="tab-content">
                    <h3>${faker.commerce.productAdjective()} ${faker.commerce.productMaterial()}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <ul>
                        <li>${faker.commerce.productDescription()}</li>
                        <li>${faker.commerce.productDescription()}</li>
                        <li>${faker.commerce.productDescription()}</li>
                    </ul>
                </div>
            `,
            id: 'shipping-info'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(3)}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <ul>
                        <li>${faker.lorem.sentence()}</li>
                        <li>${faker.lorem.sentence()}</li>
                        <li>${faker.lorem.sentence()}</li>
                    </ul>
                </div>
            `,
            id: 'returns-policy'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <div class="tracking-features">
                        <p>${faker.lorem.sentence()}</p>
                        <ul>
                            <li>${faker.lorem.sentence()}</li>
                            <li>${faker.lorem.sentence()}</li>
                            <li>${faker.lorem.sentence()}</li>
                        </ul>
                    </div>
                </div>
            `,
            id: 'track-order'
        }
    ]
},
// Extended variation with 5 tabs
extended: {
    activeItem: 0,
    tabs: [
        {
            title: faker.commerce.productName(),
            content: `
                <div class="tab-content">
                    <h3>${faker.commerce.productAdjective()} ${faker.commerce.productMaterial()}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <ul>
                        <li>${faker.commerce.productDescription()}</li>
                        <li>${faker.commerce.productDescription()}</li>
                        <li>${faker.commerce.productDescription()}</li>
                    </ul>
                </div>
            `,
            id: 'product-details'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(3)}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <ul>
                        <li>${faker.lorem.sentence()}</li>
                        <li>${faker.lorem.sentence()}</li>
                        <li>${faker.lorem.sentence()}</li>
                    </ul>
                </div>
            `,
            id: 'shipping'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <ul>
                        <li>${faker.lorem.sentence()}</li>
                        <li>${faker.lorem.sentence()}</li>
                        <li>${faker.lorem.sentence()}</li>
                    </ul>
                </div>
            `,
            id: 'returns'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <div class="review-summary">
                        <p>${faker.lorem.sentence()}</p>
                        <p>${faker.lorem.sentence()}</p>
                    </div>
                    <div class="review-highlights">
                        <h4>${faker.lorem.words(3)}</h4>
                        <ul>
                            <li>"${faker.lorem.sentence()}"</li>
                            <li>"${faker.lorem.sentence()}"</li>
                            <li>"${faker.lorem.sentence()}"</li>
                        </ul>
                    </div>
                </div>
            `,
            id: 'reviews'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(3)}</h3>
                    <div class="faq-list">
                        <div class="faq-item">
                            <h4>${faker.lorem.sentence()}</h4>
                            <p>${faker.lorem.sentences(1)}</p>
                        </div>
                        <div class="faq-item">
                            <h4>${faker.lorem.sentence()}</h4>
                            <p>${faker.lorem.sentences(1)}</p>
                        </div>
                        <div class="faq-item">
                            <h4>${faker.lorem.sentence()}</h4>
                            <p>${faker.lorem.sentences(1)}</p>
                        </div>
                    </div>
                </div>
            `,
            id: 'faqs'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <div class="additional-info">
                        <ul>
                            <li>${faker.lorem.sentence()}</li>
                            <li>${faker.lorem.sentence()}</li>
                            <li>${faker.lorem.sentence()}</li>
                        </ul>
                    </div>
                </div>
            `,
            id: 'additional-info'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <div class="warranty-details">
                        <p>${faker.lorem.sentences(2)}</p>
                        <ul>
                            <li>${faker.lorem.sentence()}</li>
                            <li>${faker.lorem.sentence()}</li>
                        </ul>
                    </div>
                </div>
            `,
            id: 'warranty'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <div class="support-info">
                        <p>${faker.lorem.sentences(2)}</p>
                        <ul>
                            <li>${faker.lorem.sentence()}</li>
                            <li>${faker.lorem.sentence()}</li>
                        </ul>
                    </div>
                </div>
            `,
            id: 'support'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <div class="related-products">
                        <ul>
                            <li>${faker.commerce.productName()}</li>
                            <li>${faker.commerce.productName()}</li>
                            <li>${faker.commerce.productName()}</li>
                        </ul>
                    </div>
                </div>
            `,
            id: 'related-products'
        }
    ]
},

// Minimal variation with 2 tabs
minimal: {
    activeItem: 0,
    tabs: [
        {
            title: faker.commerce.productName(),
            content: `
                <div class="tab-content">
                    <h3>${faker.commerce.productAdjective()} ${faker.commerce.productMaterial()}</h3>
                    <p>${faker.lorem.sentences(2)}</p>
                    <ul>
                        <li>${faker.commerce.productDescription()}</li>
                        <li>${faker.commerce.productDescription()}</li>
                        <li>${faker.commerce.productDescription()}</li>
                    </ul>
                </div>
            `,
            id: 'description'
        },
        {
            title: faker.lorem.words(2),
            content: `
                <div class="tab-content">
                    <h3>${faker.lorem.words(2)}</h3>
                    <table class="specs-table">
                        <tr>
                            <th>${faker.commerce.productMaterial()}</th>
                            <td>${faker.commerce.product()}</td>
                        </tr>
                        <tr>
                            <th>${faker.commerce.productMaterial()}</th>
                            <td>${faker.commerce.product()}</td>
                        </tr>
                        <tr>
                            <th>${faker.commerce.productMaterial()}</th>
                            <td>${faker.commerce.product()}</td>
                        </tr>
                    </table>
                </div>
            `,
            id: 'specifications'
        }
    ]
}
};

import initForm from './forms';

describe('legend prefix in error summary', () => {
  let form: HTMLFormElement;

  beforeEach(() => {
    document.body.innerHTML = `
      <form class="cmp-form">
        <fieldset class="form-group">
          <legend>Personal Details</legend>
          <label for="fullname">Full name</label>
          <input id="fullname" class="cmp-form-text__text required" />
          <div class="error-message">Full name is required</div>
        </fieldset>
        <div class="form-error-message" style="display: none;">
          <ul class="form-error-message__list"></ul>
        </div>
        <button type="submit">Submit</button>
      </form>
    `;
    form = document.querySelector('.cmp-form') as HTMLFormElement;
    initForm();
  });

  test('error summary item prefixed with legend text', () => {
    const submitEvent = new Event('submit', { bubbles: true, cancelable: true });
    form.dispatchEvent(submitEvent);

    const errorList = form.querySelector('.form-error-message__list') as HTMLUListElement;
    expect(errorList.children.length).toBeGreaterThan(0);
    const firstItem = errorList.children[0] as HTMLLIElement;
    const anchor = firstItem.querySelector('a') as HTMLAnchorElement;
    expect(anchor.textContent?.startsWith('Personal Details')).toBe(true);
  });
});

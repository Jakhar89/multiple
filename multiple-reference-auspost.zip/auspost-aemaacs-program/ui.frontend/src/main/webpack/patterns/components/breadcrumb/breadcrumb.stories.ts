import type { Meta, StoryObj } from '@storybook/html-vite';
import { BreadcrumbProps } from './interfaces';
import { mockBreadcrumbs } from './_breadcrumb.mock';

import component from './breadcrumb.liquid'

const meta = {
  title: 'Components/Breadcrumb',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
} satisfies Meta<BreadcrumbProps>;

export default meta;
type Story = StoryObj<BreadcrumbProps>;

export const Default: Story = {
  args: {
    items: mockBreadcrumbs(2),
  }
};

export const ThreeItems: Story = {
  args: {
    items: mockBreadcrumbs(3),
  }
};

export const FourItems: Story = {
  args: {
    items: mockBreadcrumbs(4),
  }
};

export const WithEllipsis: Story = {
  args: {
    items: mockBreadcrumbs(5),
  }
};

import { faker } from '@faker-js/faker';
import { BannerProps } from '../interfaces';

export const TEASER_BANNER_DATA: BannerProps = {
  variant: 'teaser',
  label: 'Community & Events',
  heading: 'Australian stamp and coin events',
  description: faker.lorem.sentence(6),
  issueDate: '',
  cta: true,
  backgroundImage: {
    src: 'src/main/webpack/patterns/assets/images/landscape.png',
    alt: 'Stamp image'
  },
  image: {
    src: '',
    alt: ''
  }
};

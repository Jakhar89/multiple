import { faker } from '@faker-js/faker';

export const heading = faker.lorem.sentence(4);
export const text = faker.lorem.sentences(2);
export const listContent = [faker.lorem.words(3), faker.lorem.words(3), faker.lorem.words(3)];

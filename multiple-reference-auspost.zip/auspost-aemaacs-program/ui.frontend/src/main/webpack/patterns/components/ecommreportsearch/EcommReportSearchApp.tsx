import { useId, useMemo, useState } from "react";
import BackToHome from "./ERBackToHome/ERBackToHome";
import ERAiLoader from "./ERLoader/ERAiLoader";
import ERSearchForm from "./ERSearchForm/ERSearchForm";
import ERSearchResult from "./ERSearchResults/ERSearchResults";
import ERSuggestedSearches from "./ERSuggestedSearch/ERSuggestedSearch";
import { useERSearchContext } from "./store/ERSearchContext";
import { AiSearchResult } from "./store/ERSearchInterface";
import { MIN_CHARS_FOR_AUTOSUGGEST_SEARCH } from "./utils/constants";
import { getConfigForAnswerSearch, getAiAnswer } from "./utils/search.utils";

export default function EcommReportSearchApp() {
  const [query, setQuery] = useState<string>("");
  const [firstSearchAnswer, setFirstSearchAnswer] = useState<boolean>(false);
  const [questionSessionId, setQuestionSessionId] = useState<string>("");
  const [followUpMode, setFollowUpMode] = useState<boolean>(false);
  const [aiSearchResults, setAiSearchResults] = useState<AiSearchResult[]>([]);
  const [isLoadingAiSearch, setIsLoadingAiSearch] = useState<boolean>(false);
  const inputId = useId();
  const {
    suggestedSearch = { title: "", items: [] },
    searchField,
    keywordSearchUrl = "",
    answerUrl = "",
  } = useERSearchContext();

  const handleQueryChange = (value: string) => {
    setQuery(value);
  };

  const handleSuggestionSelect = async (value: string) => {
    handleQueryChange(value);
    setIsLoadingAiSearch(true);

    await formSubmit(value);
    setFollowUpMode(false);
    return false;
  };

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    setIsLoadingAiSearch(true);

    await formSubmit(query);
    return false;
  };

  const formSubmit = async (value: string) => {
    const res = await getConfigForAnswerSearch({
      query: value,
      keywordSearchUrl,
      sessionId: followUpMode ? questionSessionId! : "",
    });

    setQuestionSessionId(res?.sessionInfo?.sessionId!);

    if (res?.sessionInfo !== null) {
      const aiAnswer = await getAiAnswer({
        query: value,
        answerUrl,
        session: res?.sessionInfo!,
      });

      if (aiAnswer) {
        setAiSearchResults((prev) => [aiAnswer, ...prev]);
      }

      setIsLoadingAiSearch(false);
      setFirstSearchAnswer(true);
      if (followUpMode) {
        setQuery("");
      }
    }
  };

  const getLatestQuestion = () => {
    return aiSearchResults.length > 0 ? aiSearchResults[0].question : "";
  };

  const handleAskAFollowUpQuestion = () => {
    setFollowUpMode((v) => !v);
    setQuery("");
    followUpMode && setQuestionSessionId("");
  };

  const searchAppClassName = useMemo(
    () => (isLoadingAiSearch || firstSearchAnswer ? "align-top" : ""),
    [isLoadingAiSearch, firstSearchAnswer],
  );

  return (
    <div className={`search-ecomm-report ${searchAppClassName}`}>
      <div className="search-container">
        <div className="search-sticky-header">
          <BackToHome />

          <ERSearchForm
            id={inputId}
            query={query}
            onQueryChange={handleQueryChange}
            onFormSubmit={handleFormSubmit}
            searchField={searchField}
            showFollowUpQuestion={firstSearchAnswer}
            isFollowUpActive={followUpMode}
            onAskFollowUp={handleAskAFollowUpQuestion}
            question={getLatestQuestion()}
          />
        </div>

        {suggestedSearch?.items?.length > 0 &&
          !followUpMode &&
          query.trim().length <= MIN_CHARS_FOR_AUTOSUGGEST_SEARCH &&
          aiSearchResults.length === 0 && (
            <ERSuggestedSearches
              title={suggestedSearch.title}
              items={suggestedSearch.items}
              onSuggestionSelect={handleSuggestionSelect}
            />
          )}

        {isLoadingAiSearch && <ERAiLoader />}

        {aiSearchResults.map((result, index) => {
          return <ERSearchResult key={`results-${index}`} result={result} />;
        })}
      </div>
    </div>
  );
}

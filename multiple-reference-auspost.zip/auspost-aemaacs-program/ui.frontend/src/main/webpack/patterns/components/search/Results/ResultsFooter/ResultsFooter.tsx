import React from 'react';
import ResultsCount from '../ResultsCount';
import Pagination from './Pagination';
import { ResultsFooterProps } from '../../SearchUtils/interface';

export default function ResultsFooter({
    start,
    end,
    total,
    loading = false,
    hasItems = false,
    className,
    nextPageToken,
    lastSearchedQuery,
    performSearch,
}: ResultsFooterProps) {

    if (!hasItems && !loading) {
        return null;
    }

    return (
        <div className='results-footer d-flex'>
            <ResultsCount
                start={start}
                end={end}
                total={total}
                loading={loading}
                hasItems={hasItems}
                className={className}
            />
            <Pagination
                performSearch={performSearch}
                lastSearchedQuery={lastSearchedQuery}
                nextPageToken={nextPageToken}
                loading={loading}
            />
        </div>
    );
}

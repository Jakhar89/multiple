export interface AssetItem {
  imageUrl: string;
  title: string;
  description: string;
  datestamp?: string;
  isBlurred?: boolean;
  cardCtaText?: string;
  cardCtaType?: string;
}

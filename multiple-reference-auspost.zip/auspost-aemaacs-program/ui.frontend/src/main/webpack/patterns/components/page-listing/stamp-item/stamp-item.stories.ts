import type { Meta, StoryObj } from '@storybook/html-vite';
import { handleCardClick } from '../../../../scripts/utils/card-clickable';
import { MOCK_STAMP_ITEM } from './_stamp-item.mock';
import component from './stamp-item.liquid';

export default {
  title: 'Components/Page Listing/Stamp Item',
  component: component,
  argTypes: {},
  args: {
    card: MOCK_STAMP_ITEM,
    renderMode: true
  },
} satisfies Meta;

export const Default: StoryObj = {
  args: {}
};

export const FullCardClickableNoCta: StoryObj = {
  args: {
    card: {
      ...MOCK_STAMP_ITEM,
      cardCtaText: ''
    }
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const cards = document.querySelectorAll<HTMLElement>('.clickable-card');
    handleCardClick(cards);
  }
};

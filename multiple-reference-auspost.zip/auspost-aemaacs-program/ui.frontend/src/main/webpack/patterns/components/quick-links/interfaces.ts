export interface QuickLinkItem {
  icon: string;
  label: string;
  url: string;
}

export interface QuickLinksProps {
  quickLinks: QuickLinkItem[];
  variation?: 'default' | 'icon-only';
}

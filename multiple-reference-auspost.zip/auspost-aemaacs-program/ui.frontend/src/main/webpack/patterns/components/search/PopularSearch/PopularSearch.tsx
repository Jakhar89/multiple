import React from 'react';
import { PopularSearchProps } from '../SearchUtils/interface';
import Icon from '../../../foundations/iconset/Icon';
import { createPopularSearchDataLayer, pushPopularSearchToDataLayer } from '../../../../scripts/analytics/analytics';


export default function PopularSearches({ title, items }: PopularSearchProps) {
    return (
        <>
            <div
                className="popular-searches m-t-500">
                {title &&
                    <strong id="popular-search-heading" className="suggestions-heading m-b-400 d-flex">
                        {title}
                    </strong>
                }
                
                <ul className="popular-search-list list-style-none" aria-labelledby="popular-search-heading">
                    {items.map((item, index) => {
                        const linkId = `popular-search-${index}`;
                        const linkDataLayer = createPopularSearchDataLayer(linkId, item.label);
                        
                        const handleClick = () => {
                            pushPopularSearchToDataLayer(item.label);
                        };
                        
                        return (
                            <li key={index}>
                                <a 
                                    href={item.href} 
                                    className="suggestions-link d-inline-flex p-150" 
                                    target={item.target}
                                    onClick={handleClick}
                                    id={linkId}
                                    data-cmp-data-layer={linkDataLayer}
                                >
                                <span className="suggestions-icon m-r-150" aria-hidden="true">
                                    <Icon name="search-thin" className=' d-flex' size='sm' svgClassName='icon--fill-white' />
                                </span>
                                <span className="suggestions-label">{item.label}</span>
                                </a>
                            </li>
                        );
                    })}
                </ul>
            </div>
        </>
    );
}

import './video.scss';

export interface VideoProps {
  videoPlayer: 'vudoo' | 'youtube';
  showTranscript?: boolean;
  transcriptStyle?: '' | 'floating' | 'connected';
  transcriptBackground?: string;
  transcriptText?: string;
}

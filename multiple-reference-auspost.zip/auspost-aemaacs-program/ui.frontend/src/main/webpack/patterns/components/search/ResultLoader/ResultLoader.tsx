import React from 'react';
import Skeleton from 'react-loading-skeleton';

type ResultLoaderProps = {
  skeletonCount?: number;
};

export default function ResultLoader({ skeletonCount = 5 }: ResultLoaderProps) {
  return (
    <>
      {Array.from({ length: skeletonCount }).map((_, index) => (
        <div
          key={`skeleton-${index}`}
          className={`search-result-item p-y-400${index === skeletonCount - 1 ? ' last-result-item' : ''}`}
        >
          <div className='result-loading result-meta m-b-150'>
            <Skeleton
              height={12}
              width={80}
              duration={1.2}
            />
          </div>
          <h3 className='result-loading result-title m-b-150'>
            <Skeleton
              height={20}
              width={`${Math.random() * (80 - 50) + 50}%`}
              duration={1.2}
            />
          </h3>
          <p className='result-loading result-description m-b-200'>
            <Skeleton
              height={14}
              count={2}
              duration={1.2}
            />
          </p>
          <span className='result-loading result-link'>
            <Skeleton
              height={14}
              width={`${Math.random() * (60 - 30) + 30}%`}
              duration={1.2}
            />
          </span>
        </div>
      ))}
    </>
  );
}

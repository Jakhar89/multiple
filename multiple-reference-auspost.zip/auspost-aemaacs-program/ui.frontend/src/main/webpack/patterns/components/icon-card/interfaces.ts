import type { ButtonProps } from '~/patterns/atoms/button/interfaces';

export interface LinksProp {
  linkStyle: string;
  ctaLabel?: string;
  ctaUrl?: string;
}

export interface IconCardProps {
  renderMode?: boolean;
  containerTheme: string;
  contentAlignment: string;
  heading?: string;
  description?: string;
  icon: string;
  links?: LinksProp[];
}

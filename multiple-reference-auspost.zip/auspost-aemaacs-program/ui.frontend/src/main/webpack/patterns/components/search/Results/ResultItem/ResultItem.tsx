import React, { useId, useRef } from 'react';
import { SearchResultsResponseProps } from '../../SearchUtils/interface';
import { formatLinkDisplay } from '../../util/search.utils';
import { createSearchResultLinkDataLayer, pushSearchResultLinkToDataLayer } from '../../../../../scripts/analytics/analytics';
import { stripTags } from '../../../../../scripts/utils/utils';

type ResultItemProps = {
  item: SearchResultsResponseProps['results'][number];
  isLast?: boolean;
  searchQuery: string;
};

function ResultItem({ item, isLast = false, searchQuery }: ResultItemProps) {
  const anchorRef = useRef<HTMLAnchorElement | null>(null);
  const linkId = `result-link${useId()}`;
  const { derivedStructData, structData } = item.document;
  const title = structData.og_title?.[0] || derivedStructData.title || '';
  const rawDescription = structData.og_description?.filter((str) => !!str).join(', ') || derivedStructData.snippets?.[0]?.snippet || '';
  const description = stripTags(rawDescription);
  const link = derivedStructData.link || '';
  const displayLink = formatLinkDisplay(link);
  const meta = null; //hiding the label for collectables site, it will be used for main site
  const linkDataLayer = createSearchResultLinkDataLayer(linkId, searchQuery, link);

  const handleClick = (e: React.MouseEvent<HTMLLIElement>) => {
    pushSearchResultLinkToDataLayer(searchQuery, link);
    if (anchorRef.current && (e.target as HTMLElement).tagName !== 'A') {
      anchorRef.current.click();
    }
  };

  return (
    <li className={`search-result-item p-y-150 p-y-md-300 ${isLast ? ' last-result-item' : ''}`} id={linkId} onClick={handleClick} 
      data-cmp-data-layer={linkDataLayer} >
      {meta ? <div className="result-meta">{meta}</div> : null}
      {title ? <h3 className="result-title m-b-150">
        <a href={link} ref={anchorRef}>{title}</a>
        </h3> : null}
      {description ? (
        <p
          className="result-description m-t-100 m-t-md-100 m-b-md-200 m-b-100">{description}</p>
      ) : null}
      {link ? (
        <div  className="result-link d-inline-flex m-b-150">
          {displayLink}
        </div>
      ) : null}
    </li>
  );
}

export default ResultItem;

export interface TableComponentProps {
  columnLimit?: number;
  tableCaption?: string;
  tableRows?: string[][];
  contentTitle?: string;
  contentBody?: string[];
}

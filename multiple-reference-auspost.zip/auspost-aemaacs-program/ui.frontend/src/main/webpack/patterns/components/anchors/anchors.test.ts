beforeAll(() => {
  (global as any).IntersectionObserver = class {
    constructor() { }
    observe() { }
    unobserve() { }
    disconnect() { }
  };

  window.scrollTo = jest.fn();
  HTMLElement.prototype.scrollIntoView = jest.fn();
  HTMLElement.prototype.scrollBy = jest.fn();
});


import { liquidEngine } from '~/../../../jest.config';
import { ANCHORS_LIST } from './_anchors.mock.ts';
import initAnchors from './anchors';

describe('initAnchors', () => {
  beforeEach(async () => {
    const html = await liquidEngine.renderFile(
      'src/main/webpack/patterns/components/anchors/anchors.liquid',
      {
        anchors: ANCHORS_LIST.anchors
      }
    );
    document.body.innerHTML = html;
    initAnchors();
  });

  test('initialize all anchor links', () => {
    const anchorsList = document.querySelectorAll('.anchor-item');
    expect(anchorsList.length).toBe(ANCHORS_LIST.anchors.length);
  });

  test('Show anchors in center, when no content overflow', async () => {
    const wrapper = document.querySelector('.anchor-list-wrapper')!;

    Object.defineProperty(wrapper, 'scrollWidth', { value: 100 });
    Object.defineProperty(wrapper, 'clientWidth', { value: 200 });
    await initAnchors();

    expect(wrapper.classList.contains('centered')).toBe(true);

  });

  it('shows next arrow when anchor links overflow', async () => {
    const wrapper = document.querySelector('.anchor-list-wrapper') as HTMLElement;

    Object.defineProperty(wrapper, 'scrollWidth', { value: 500 });
    Object.defineProperty(wrapper, 'clientWidth', { value: 200 });

    await initAnchors();

    const next = document.querySelector('.anchor-next-btn')!;
    expect(next.classList.contains('visible')).toBe(true);
  });

  it('scrolls anchor list when arrow buttons are clicked', async () => {
    const wrapper = document.querySelector('.anchor-list-wrapper')!;
    const spy = jest.spyOn(wrapper, 'scrollBy');

    document.querySelector('.anchor-next-btn')!.click();
    expect(spy).toHaveBeenCalledWith({ left: 150, behavior: 'smooth' });

    document.querySelector('.anchor-previous-btn')!.click();
    expect(spy).toHaveBeenCalledWith({ left: -150, behavior: 'smooth' });
  });

});

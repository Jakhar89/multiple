export interface AnchorsListProp {
  anchorLabel: string;
  anchorPath: string;
}

export interface AnchorsProps {
  anchors: AnchorsListProp[];
}
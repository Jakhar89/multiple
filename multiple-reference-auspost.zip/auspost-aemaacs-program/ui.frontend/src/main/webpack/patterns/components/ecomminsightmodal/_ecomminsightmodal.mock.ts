export const MockEcommInsightModalData = {
  modalId: "insight-01",
  modalImageUrl: "/src/main/webpack/patterns/assets/images/shoppers-stars.png",
  modalImageAlt: "Shopping insights icon",
  modalTitle: "Know your shoppers",
  description:
    "Sale-savvy Aussies are hunting for deals and adding to cart in record numbers. Unbox how the generations shopped and who’s leading the charge.",
  footerSection: {
    title: "Ready to unbox more?",
    description: "Get the full report covering all 4 major trends of 2026",
    primaryCta: {
      label: "Download the 2026 report",
      url: "/some.pdf",
      iconLeft: "download",
      helpText: "No emai or details required",
    },
    secondaryCta: {
      label: "Listen to the podcase",
      iconLeft: "music",
      helpText: "Available on Spotify & iTunes",
      menuItems: [
        {
          label: "Spotify",
          icon: "spotify",
          url: "spotify.com",
        },
        {
          label: "Apple podcast",
          icon: "podcast",
          url: "itunes.com",
        },
      ],
    },
    footer: {
      label: "Up next:",
      title: "Spending",
      imageUrl: "/src/main/webpack/patterns/assets/images/spending.png",
      imageAlt: "Spending",
      nextModalId: "002",
    },
  },
};

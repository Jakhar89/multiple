
import { handleCardClick } from '../../../scripts/utils/card-clickable';

export default function initCardListing(): void {

  const cards = document.querySelectorAll<HTMLElement>('.clickable-card-listing'); 
  handleCardClick(cards);

}

document.addEventListener('DOMContentLoaded', initCardListing);



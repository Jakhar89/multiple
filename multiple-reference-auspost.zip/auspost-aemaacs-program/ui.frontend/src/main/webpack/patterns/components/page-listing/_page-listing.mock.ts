import { faker } from "@faker-js/faker";
import {
    Filter,
    PageListProps
} from "./interfaces";
import { MOCK_ARTICLE_ITEM } from "./article-item/_article-item.mock";
import { AssetListing_FilterResponseHtml } from "./_asset-listing-filter.mock";
import { PageListing_FilterResponseHtml } from "./_page-listing-filter.mock";

const generateFilterData = (index: number) => ({
    id: `dropdown${index}`,
    label: faker.lorem.words(faker.number.int({ min: 2, max: 5 })),
    options: Array.from(
        { length: faker.number.int({ min: 2, max: 5 }) },
        () => [faker.word.words(1), faker.commerce.productName()]
    ),
});

export const pageListDefaultMock: PageListProps = {
    pageListHeading: "Browse our stamp collection",
    filterList: Array.from({ length: 3 }, (_, i) => generateFilterData(i + 1)),
    resultType: 'ArticleItem',
    results: Array.from({ length: 4 }, (_, index) => (MOCK_ARTICLE_ITEM)),
    totalInitialResults: 4,
    totalFilteredResult: 35,
    totalResult: 40
};

export const pageListExtendedMock: Filter[] = Array.from(
    { length: 5 },
    (_, i) => {
        const item = generateFilterData(i + 1);
        if (i === 3) {
            item.label = faker.lorem.words(5);
        }
        return item;
    }
);

/* This is intended to be whitespace - as this is what the BE gives us */
export const PageListing_FilterNoResultsResponseHtml = `
    
    


    

`;

/*
  The following (imported frmo file then) exported filter response variable contents were taken from BE API response when filtering asset and page listings,
  They have been modified to work in the FE (i.e. images, icons, and endpoints updated)
  If the card item markup/styling has changed at all since these were updated, they may display differently in Storybook

  When updating the response content from BE, you will also need to find/replace the following where they are declared:

  ICONS: /etc.clientlibs/auspost-aemaacs-program/clientlibs/clientlib-site/resources/icons WITH /src/main/webpack/resources/icons
  ITEM IMAGES [regex]: src=".*1600w" WITH src="/src/main/webpack/patterns/assets/images/Landscape.png"
  ASSET IMAGES [regex]: WITH /src/main/webpack/patterns/assets/images/stamp-bulletin.jpg
  PAGE RESOURCE PATH (for filtering) [regex]: data-resource-path="/content/collectables/au/en/Personal/page-list-demo.html" WITH data-resource-path="/api/pagelisting.html" data-dev-mode="true"
  ASSET RESOURCE PATH (for filtering): data-resource-path="/content/collectables/au/en/Personal/asset-listing-demo.html" WITH data-resource-path="/api/assetlisting.html" data-dev-mode="true"
*/

export { AssetListing_FilterResponseHtml, PageListing_FilterResponseHtml };

import initInsightModal from "./ecomminsightmodal";

describe("ecomminsightmodal", () => {
  const MODAL_ID = "modal-insight-test";
  const INSIGHT_MODAL_CLASS = "ecomm-insight-modal";
  const TRIGGER_ATTR = "data-modal-target";
  const BODY_LOCK_CLASS = "no-scroll";

  // Ensure dialog showModal/close exist in jsdom
  beforeEach(() => {
    document.body.innerHTML = "";
    if (!(HTMLDialogElement.prototype as any).showModal) {
      (HTMLDialogElement.prototype as any).showModal = function () {
        this.setAttribute("open", "");
      };
    }
    if (!(HTMLDialogElement.prototype as any).close) {
      (HTMLDialogElement.prototype as any).close = function () {
        this.removeAttribute("open");
      };
    }
  });

  afterEach(() => {
    document.body.innerHTML = "";
    jest.resetModules();
  });

  const createModal = (opts?: {
    withClose?: boolean;
    withOpenClass?: boolean;
  }) => {
    const dialog = document.createElement("dialog") as HTMLDialogElement;
    dialog.id = MODAL_ID;
    dialog.scrollTo = jest.fn();
    dialog.classList.add(INSIGHT_MODAL_CLASS);
    if (opts?.withClose) {
      const closeWrap = document.createElement("div");
      closeWrap.className = "modal__close";
      const btn = document.createElement("button");
      closeWrap.appendChild(btn);
      dialog.appendChild(closeWrap);
    }
    document.body.appendChild(dialog);
    return dialog;
  };

  const createTrigger = () => {
    const trigger = document.createElement("a");
    trigger.setAttribute(TRIGGER_ATTR, "test");
    trigger.href = "#";
    document.body.appendChild(trigger);
    return trigger;
  };

  test("opens modal on trigger click and adds body lock", () => {
    const modal = createModal();
    const trigger = createTrigger();

    initInsightModal();
    trigger.click();

    expect(modal.hasAttribute("open")).toBe(true);
    expect(document.body.classList.contains(BODY_LOCK_CLASS)).toBe(true);
  });

  test("close button closes modal and removes body lock", () => {
    const modal = createModal({ withClose: true });
    const trigger = createTrigger();

    initInsightModal();
    trigger.click();

    expect(modal.hasAttribute("open")).toBe(true);
    const closeBtn = modal.querySelector(
      ".modal__close button",
    ) as HTMLButtonElement;
    closeBtn.click();

    expect(modal.hasAttribute("open")).toBe(false);
    expect(document.body.classList.contains(BODY_LOCK_CLASS)).toBe(false);
  });

  test("backdrop click closes the modal", () => {
    const modal = createModal();
    const trigger = createTrigger();

    initInsightModal();
    trigger.click();

    expect(modal.hasAttribute("open")).toBe(true);

    // dispatch click on the dialog element (backdrop)
    modal.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(modal.hasAttribute("open")).toBe(false);
    expect(document.body.classList.contains(BODY_LOCK_CLASS)).toBe(false);
  });

  test("initInsightModal does not throw if no trigger or modal present", () => {
    expect(() => initInsightModal()).not.toThrow();
  });
});

import type { TableComponentProps } from './interface';

export const TABLE_MOCK: TableComponentProps = {
  tableCaption: "Technical specifications",
  tableRows: [
    ["Issue date", "24 June 2025", "Content", "Notes"],
    ["Issue withdrawal date", "TBA", "Content", "Notes"],
    ["Denomination", "1 x $3.50, 1 x $4.35, 1 x $4.80", "Content", "Notes"],
    ["Stamp & product design", "Sharon Rodziewicz, Australia Post Design Studio", "Content", "Notes"],
    ["Paper: gummed", "RA", "Content", "Notes"],
    ["Printing process", "Offset lithography", "Content", "Notes"],
    ["Stamp size (mm)", "26 x 37.5", "Content", "Notes"],
    ["Minisheet size (mm)", "170 x 80", "Content", "Notes"],
    ["Perforations", "14.6 x 13.86", "Content", "Notes"],
    ["Sheet layout", "Module of 50 (2 x 25)", "Content", "Notes"],
    ["FDI postmark", "Andamooka SA 5722", "Content", "Notes"],
    ["FDI withdrawal date", "23 July 2025", "Content", "NotesNotesNotesNotesNotesNotes"],
  ]
}

export const TABLE_CONTENT_MOCK: TableComponentProps = {
  contentTitle: "Overview",
  contentBody: [
    "The opal is Australia's national gemstone, and today the vast majority of the world's precious opals are sourced here. These beautiful gems are unique for their remarkable play of colour, produced by the diffraction and interference of light by the microscopic spheres of silica that form the structure of the opal.",
    "The formation of Australian opals began tens of millions of years ago, when much of central Australia was a vast, shallow inland sea. Fine sands rich in the compound silica were deposited along its shorelines. As the sea receded, the Great Artesian Basin was formed below ground and today's deserts were slowly created. Through millions of years of weathering, a silica-rich solution seeped along faults and joints in the earth, filling in cracks and voids. This gel eventually hardened to form opal. Sometimes fossil remains such as dinosaur bones, shells and plants were replaced with opal, their shapes still apparent.",
    "The opals depicted in this series of stamps show the wide range of opal types found in Australia. They originated in various important opal-mining sites of Queensland, South Australia and New South Wales, and are now among the treasures of museum collections across the country."
  ]
};

import React from "react";
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from "@testing-library/react";
import ERSearchForm from "./ERSearchForm";
import { ASK_A_NEW_QUESTION, ASK_FOLLOW_UP_QUESTION, AUTOCOMPLETE_TITLE } from "../utils/constants";

jest.mock("../ERAutoSuggest/ERAutoSuggest", () => {
  return {
    __esModule: true,
    default: (props: any) => {
      // expose props via data- attributes and render an input to simulate onChange
      const { id, value, placeholder, title, autocomplete } = props;
      return (
        <div data-testid="autosuggest-mock" data-id={id} data-value={value} data-placeholder={placeholder} data-title={title} data-autocomplete={String(autocomplete)}>
          <input
            aria-label={props["aria-label"] || "autosuggest-input"}
            defaultValue={value}
            onChange={(e) => props.onChange && props.onChange({ currentTarget: { value: e.target.value } })}
            data-testid="autosuggest-input"
          />
        </div>
      );
    },
  };
});

jest.mock("../Icons/ERIcon", () => {
  return {
    __esModule: true,
    default: (props: any) => <span data-testid={`icon-${props.name}`} data-name={props.name} />,
  };
});

const baseSearchField = {
  label: "Search Label",
  placeholder: "Search...",
  buttonText: "Go",
  autocomplete: true,
  autocompleteTitle: "Custom Autocomplete Title",
};

describe("ERSearchForm", () => {
  test("renders title when not follow-up active and not showing follow up", () => {
    render(
      <ERSearchForm
        id="test"
        query=""
        onQueryChange={() => {}}
        searchField={baseSearchField as any}
        showFollowUpQuestion={false}
        isFollowUpActive={false}
      />
    );
    expect(screen.getByText(baseSearchField.label)).toBeInTheDocument();
  });

  test("does not render title when showFollowUpQuestion is true", () => {
    render(
      <ERSearchForm
        id="test"
        query=""
        onQueryChange={() => {}}
        searchField={baseSearchField as any}
        showFollowUpQuestion={true}
        isFollowUpActive={false}
      />
    );
    expect(screen.queryByText(baseSearchField.label)).toBeNull();
  });

  test("form has follow-up-mode class and displays question when isFollowUpActive is true", () => {
    const q = "Follow up question text";
    render(
      <ERSearchForm
        id="test"
        query=""
        onQueryChange={() => {}}
        searchField={baseSearchField as any}
        showFollowUpQuestion={true}
        isFollowUpActive={true}
        question={q}
      />
    );
    const form = screen.getByRole("form", { name: /Search Ecommerce reports insights/i });
    expect(form.className).toContain("follow-up-mode");
    expect(screen.getByText(q)).toBeInTheDocument();
    expect(screen.getByTestId("icon-search")).toBeInTheDocument();
  });

  test("onFormSubmit is called when form is submitted", () => {
    const onFormSubmit = jest.fn((e) => e.preventDefault());
    render(
      <ERSearchForm
        id="test"
        query=""
        onQueryChange={() => {}}
        onFormSubmit={onFormSubmit}
        searchField={baseSearchField as any}
        showFollowUpQuestion={false}
        isFollowUpActive={false}
      />
    );
    const form = screen.getByRole("form", { name: /Search Ecommerce reports insights/i });
    fireEvent.submit(form);
    expect(onFormSubmit).toHaveBeenCalled();
  });

  test("AutoSuggest receives autocomplete=false when showFollowUpQuestion is true", () => {
    render(
      <ERSearchForm
        id="test"
        query="q"
        onQueryChange={() => {}}
        searchField={baseSearchField as any}
        showFollowUpQuestion={true}
        isFollowUpActive={false}
      />
    );
    const auto = screen.getByTestId("autosuggest-mock");
    expect(auto.getAttribute("data-autocomplete")).toBe("false");
  });

  test("AutoSuggest receives custom autocomplete title when autocomplete is enabled", () => {
    render(
      <ERSearchForm
        id="test"
        query="q"
        onQueryChange={() => {}}
        searchField={baseSearchField as any}
        showFollowUpQuestion={false}
        isFollowUpActive={false}
      />
    );
    const auto = screen.getByTestId("autosuggest-mock");
    expect(auto.getAttribute("data-title")).toBe(baseSearchField.autocompleteTitle);
  });

  test("typing in AutoSuggest input calls onQueryChange with new value", () => {
    const onQueryChange = jest.fn();
    render(
      <ERSearchForm
        id="test"
        query=""
        onQueryChange={onQueryChange}
        searchField={baseSearchField as any}
        showFollowUpQuestion={false}
        isFollowUpActive={false}
      />
    );
    const input = screen.getByTestId("autosuggest-input") as HTMLInputElement;
    fireEvent.change(input, { target: { value: "new value" } });
    expect(onQueryChange).toHaveBeenCalledWith("new value");
  });

  test("follow-up button is shown when showFollowUpQuestion is true and toggles label based on isFollowUpActive", () => {
    const onAskFollowUp = jest.fn();
    const { rerender } = render(
      <ERSearchForm
        id="test"
        query=""
        onQueryChange={() => {}}
        searchField={baseSearchField as any}
        showFollowUpQuestion={true}
        isFollowUpActive={false}
        onAskFollowUp={onAskFollowUp}
      />
    );

    // when not active
    const btn = screen.getByRole("button", { name: /Ask a follow up question/i });
    expect(screen.getByText(ASK_FOLLOW_UP_QUESTION)).toBeInTheDocument();
    fireEvent.click(btn);
    expect(onAskFollowUp).toHaveBeenCalledTimes(1);

    // when active -> label changes
    rerender(
      <ERSearchForm
        id="test"
        query=""
        onQueryChange={() => {}}
        searchField={baseSearchField as any}
        showFollowUpQuestion={true}
        isFollowUpActive={true}
        onAskFollowUp={onAskFollowUp}
      />
    );
    expect(screen.getByText(ASK_A_NEW_QUESTION)).toBeInTheDocument();
  });
});
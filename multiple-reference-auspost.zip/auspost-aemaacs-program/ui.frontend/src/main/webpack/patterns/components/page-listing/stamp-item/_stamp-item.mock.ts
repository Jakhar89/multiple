import { faker } from '@faker-js/faker';
import { StampItem } from './interfaces';

export const MOCK_STAMP_ITEM: StampItem = {
    backgroundStyle: 'grey',
    imageUrl: '/src/main/webpack/patterns/assets/images/stamp-landscape.png',
    category: {
        label: '',
        bgColor: '',
        textColor: '',
    },
    datestamp: 'Issue date: 26 August 2025',
    title: faker.lorem.sentence(),
    description: faker.lorem.paragraph(),
    cardCtaText: faker.helpers.arrayElement([
        'Contact Mailorder',
        'View Collection',
        'Read Guide',
        'Book Tickets',
    ]),
    cardCtaType: 'tertiary',
};

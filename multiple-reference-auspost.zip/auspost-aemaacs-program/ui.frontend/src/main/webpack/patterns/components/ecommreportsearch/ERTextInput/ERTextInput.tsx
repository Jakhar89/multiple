import React from "react";
import { MAX_ROWS } from "../utils/constants";
import { TextInputProps } from "../store/ERSearchInterface";

export default function ERTextInput({ label, ...props }: TextInputProps) {
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);

  const getLineHeight = (el: HTMLElement) => {
    const lh = window.getComputedStyle(el).lineHeight;
    if (!lh || lh === "normal") return 20; // fallback
    return parseFloat(lh);
  };

  const adjustHeight = (textarea: HTMLTextAreaElement) => {
    textarea.style.height = "auto";
    const maxHeight = getLineHeight(textarea) * MAX_ROWS;
    const newHeight = Math.min(textarea.scrollHeight, maxHeight);
    textarea.style.height = `${newHeight}px`;
    textarea.style.overflowY =
      textarea.scrollHeight > maxHeight ? "auto" : "hidden";
  };

  React.useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    window.addEventListener("resize", () => adjustHeight(textarea));

    // Initial sizing
    adjustHeight(textarea);

    return () => {
      window.removeEventListener("resize", () => adjustHeight(textarea));
    };
  }, []);

  const onKeyDownHandler: React.KeyboardEventHandler<HTMLTextAreaElement> = (
    e,
  ) => {
    const form: HTMLFormElement | null = (
      e.currentTarget as HTMLTextAreaElement
    ).closest("form") as HTMLFormElement | null;
    if (props.onKeyDown) {
      props.onKeyDown(e);
    }
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (form) {
        form.requestSubmit();
      }
    }
  };

  return (
    <>
      <label htmlFor="ecomm-report-search-input" className="visually-hidden">
        {label}
      </label>
      <textarea
        {...props}
        id="ecomm-report-search-input"
        className="ecomm-search-input"
        autoComplete="off"
        aria-label="Search input"
        onPaste={() => setTimeout(() => adjustHeight(textareaRef.current!), 0)}
        onInput={() => adjustHeight(textareaRef.current!)}
        rows={1}
        onKeyDown={onKeyDownHandler}
        ref={textareaRef}
      ></textarea>
    </>
  );
}

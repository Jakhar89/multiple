import type { Meta, StoryObj } from "@storybook/html-vite";
import type { CardListingProps } from "./interfaces";
import { MOCK_CARD, MOCK_POSTMARK_CARD, MOCK_STAMP_CARD_1, MOCK_STAMP_CARD_2 } from "./_card-list.mock";
import CardList from "./card-list.liquid";
import { faker } from "@faker-js/faker";
import initCardListing from './card-list';

export default {
  title: "Components/Card Listing",
  component: CardList,
  argTypes: {
    columns: {
      control: { type: "radio" },
      options: ["2", "3", "4"],
    },
    clickableMode: {
      control: { type: "radio" },
      options: ["full-card", "cta-only"],
    },
    aspectRatio: {
      control: { type: "select" },
      options: ["", "aspect-16x9", "aspect-4x3", "aspect-3x4", "aspect-1x1"],
    },
    imageStyle: {
      control: { type: "select" },
      options: ["default", "full"],
    },
    heading: {
      control: { type: "text" },
    },
    contentAlignment: {
      control: { type: "radio" },
      options: ["left", "center"],
    },
    listingCtaText: {
      control: { type: "text" },
    },
  },
  args: {
    columns: "3",
    clickableMode: "cta-only",
    aspectRatio: "",
    imageStyle: "full",
    heading: "Themes",
    contentAlignment: "left",
    cards: Array.from({ length: 4 }, (_, index) => (MOCK_CARD)),
    listingCtaText: "",
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    initCardListing();
  }
} satisfies Meta<CardListingProps>;

type Story = StoryObj<CardListingProps>;

export const Default: Story = {};

export const GreyCardBackground: Story = {
  args: {
    cards: Array.from({ length: 4 }, (_, index) => (
      {
        ...MOCK_CARD,
        backgroundStyle: "grey",
      })),
  },
};

export const AspectRatio16x9: Story = {
  args: {
    aspectRatio: "aspect-16x9",
  },
};

export const AspectRatio4x3: Story = {
  args: {
    aspectRatio: "aspect-4x3",
  },
};

export const AspectRatio3x4: Story = {
  args: {
    aspectRatio: "aspect-3x4",
  },
};

export const AspectRatio1x1: Story = {
  args: {
    aspectRatio: "aspect-1x1",
  },
};

export const WithCategory: Story = {
  args: {
    cards: Array.from({ length: 4 }, (_, index) => (
      {
        ...MOCK_CARD,
        category: {
          label: faker.lorem.words(3),
          bgColor: 'red',
          textColor: 'white'
        },
      })),
  },
};

export const WithLabel: Story = {
  args: {
    cards: Array.from({ length: 4 }, (_, index) => (
      {
        ...MOCK_CARD,
        label: faker.lorem.words(3)
      })),
  },
};

export const CenteredContent: Story = {
  args: {
    contentAlignment: "center",
  },
};

export const WithPrimaryCta: Story = {
  args: {
    cards: Array.from({ length: 4 }, (_, index) => (
      {
        ...MOCK_CARD,
        cardCtaType: 'primary'
      }
    )),
  },
};

export const TwoColumnsLisitngCta: Story = {
  args: {
    columns: "2",
    listingCtaText: "View all",
  },
};

export const FourColumnsLisitngCta: Story = {
  args: {
    columns: "4",
    listingCtaText: "View all",
  },
};

export const Stamps2Columns: Story = {
  args: {
    clickableMode: "full-card",
    imageStyle: 'card-image-center',
    cards: [MOCK_STAMP_CARD_1, MOCK_STAMP_CARD_2],
    columns: "2",
  },
};

export const Stamps3Columns: Story = {
  args: {
    clickableMode: "full-card",
    imageStyle: 'card-image-center',
    cards: [MOCK_STAMP_CARD_1, MOCK_STAMP_CARD_1, MOCK_STAMP_CARD_2]
  },
};

export const Stamps4Columns: Story = {
  args: {
    clickableMode: "full-card",
    imageStyle: 'card-image-center',
    cards: [MOCK_STAMP_CARD_1, MOCK_STAMP_CARD_1, MOCK_STAMP_CARD_2, MOCK_STAMP_CARD_1],
    columns: "4",
  },
};

export const Postmarks: Story = {
  args: {
    clickableMode: "cta-only",
    aspectRatio: "aspect-1x1",
    imageStyle: "default",
    heading: "Other Postmarks",
    contentAlignment: "center",
    cards: Array.from({ length: 4 }, (_, index) => (
      {
        ...MOCK_POSTMARK_CARD,
        description: "",
        cardCtaText: ""
      }
    )),
    listingCtaText: "View all postmarks",
  },
};

export const FullCardClickable: Story = {
  args: {
    clickableMode: "full-card",
  },
};

export const FullCardClickableNoCta: Story = {
  args: {
    clickableMode: "full-card",
    cards: Array.from({ length: 4 }, (_, index) => (
      {
        ...MOCK_CARD,
        cardCtaText: ""
      })),
  },
};

export const FullCardGreyBackground: Story = {
  args: {
    clickableMode: "full-card",
    cards: Array.from({ length: 4 }, (_, index) => (
      {
        ...MOCK_CARD,
        backgroundStyle: "grey",
      })),
  },
};

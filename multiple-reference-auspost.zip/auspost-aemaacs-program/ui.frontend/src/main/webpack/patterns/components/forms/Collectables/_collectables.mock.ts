import { FormInputFieldItem } from "../../../atoms/form-controls/input/interfaces";
import { FormOptionsGroup } from '~/patterns/atoms/form-controls/checkbox/interfaces';

export const collectableFormFields: FormInputFieldItem[] = [
    {
        label: 'First Name',
        id: 'form-text-firstname',
        name: 'First Name',
        type: 'text',
        placeholder: 'Enter your first name',
        optional: true,
    },
    {
        label: 'Last Name',
        id: 'form-text-lastname',
        name: 'Last Name',
        type: 'text',
        placeholder: 'Enter your last name',
        optional: true,
    },
    {
        label: 'Email',
        id: 'form-text-email',
        name: 'Email',
        type: 'email',
        placeholder: 'Enter your email',
        optional: true,
    },
];

export const collectableFormFieldsWithErrors: FormInputFieldItem[] = [
    {
        label: 'First Name',
        id: 'form-text-firstname',
        name: 'First Name',
        type: 'text',
        placeholder: 'Enter your first name',
        optional: false,
        error: 'First Name is required',
    },
    {
        label: 'Last Name',
        id: 'form-text-lastname',
        name: 'Last Name',
        type: 'text',
        placeholder: 'Enter your last name',
        error: 'Last Name is required',
        optional: false,
    },
    {
        label: 'Email',
        id: 'form-text-email',
        name: 'Email',
        type: 'email',
        placeholder: 'Enter your email',
        optional: false,
        error: 'Email is required',
    },
];

export const collectableFormCheckboxField: FormOptionsGroup = {
    id: 'checkbox-id',
    type: 'checkbox',
    name: 'checbox-name',
    required: false,
    error: 'This field is required',
    options: [{
        text: 'I acknowledge that I have read and accept the Australia Post <a href="#" >privacy policy.</a>',
        value: 'option1',
        selected: false,
        disabled: false,
    }]
};

export const allCollectableFormFieldsWithErrors = [
    ...collectableFormFieldsWithErrors,
    { ...collectableFormCheckboxField, required: true}
];



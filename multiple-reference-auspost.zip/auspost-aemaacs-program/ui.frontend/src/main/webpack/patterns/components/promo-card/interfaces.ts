import { ButtonProps } from '../../atoms/button/interfaces';

export interface PromoCardProps {
  bgGrey?: boolean;
  blockQuote?: string;
  categoryLabel?: string;
  categoryBgColor?: string;
  categoryTextColor?: string;
  ctas?: ButtonProps[];
  description?: string;
  enableLightbox?: boolean;
  imageCaption?: string;
  imageHref?: string;
  imageRight?: boolean;
  info?: string;
  price?: string;
  roundedImage?: boolean;
  title?: string;
} 

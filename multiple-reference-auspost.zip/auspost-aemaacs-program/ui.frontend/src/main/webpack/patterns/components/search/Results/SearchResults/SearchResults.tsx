import React from 'react';
import type { SearchResultsResponseProps, SearchResultsViewProps } from '../../SearchUtils/interface';
import ResultItem from '../ResultItem/ResultItem';
import ResultLoader from '../../ResultLoader/ResultLoader';
import ResultsCount from '../ResultsCount';
import ResultsFooter from '../ResultsFooter/ResultsFooter';
import ErrorMessage from '../../ErrorMessage/ErrorMessage';

export default function SearchResults({
  items,
  loading,
  pageStart,
  pageEnd,
  total,
  skeletonCount,
  lastSearchedQuery,
  showError,
  nextPageToken,
  performSearch,
  dataCmpDataLayer,
  searchQuery
}: SearchResultsViewProps) {
  return (
    <div className='search-results' aria-live='polite' aria-busy={loading} data-cmp-data-layer={dataCmpDataLayer} >
      <h2 className='results-heading h3 m-b-100 m-b-md-200'>Showing results for {' \u00A0'}
        <span className='search-query'>{lastSearchedQuery === '' ? ' \u00A0 ' : lastSearchedQuery}</span>
      </h2>

      {(loading || items.length > 0) && (
        <ResultsCount
          start={pageStart}
          end={pageEnd}
          total={total}
          className='p-y-400 p-y-md-0 m-b-md-200'
        />
      )}

      {loading
        ? (
          <ResultLoader skeletonCount={skeletonCount} />
        )
        : (items.length > 0 ? <ul className='list-style-none'>
          {items.map((item, index) => (
            <ResultItem
              key={item.id}
              item={item}
              isLast={index === items.length - 1}
              searchQuery={searchQuery || ''}
            />))
          }
        </ul> : (!showError && <ErrorMessage visible={true} systemError={false} />)
        )}

       <ResultsFooter
          start={pageStart}
          end={pageEnd}
          total={total}
          loading={loading}
          hasItems={items.length > 0}
          className='m-y-400 m-y-sm-400  m-y-md-400'
          nextPageToken={nextPageToken}
          performSearch={performSearch}
          lastSearchedQuery={lastSearchedQuery}
        />

      <ErrorMessage visible={showError} systemError={true} />
    </div>
  );
}

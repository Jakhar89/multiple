
import { liquidEngine } from '~/../../../jest.config';
import { searchAddressField, manualAddressField } from '../../atoms/form-controls/location-lookup/address/_address.mock';
import { postcodeOrSuburbField, manualPostcodeOrSuburbField }
  from '../../atoms/form-controls/location-lookup/postcode-suburb-lookup/_postcode-suburb-lookup.mock';
import { formFields, formFieldsWithErrors, formCheckboxField, formRadioButton, formDropdown } from './_forms.mock';
import initForm from './forms';

describe('initForm (vanilla Jest)', () => {
  beforeEach(async () => {
    const html = await liquidEngine.renderFile(
      'src/main/webpack/patterns/components/forms/forms.liquid',
      {
        fields: formFieldsWithErrors, errorMessage: true,
        checkboxFields: formCheckboxField,
        radioFields: formRadioButton,
        dropdownFields: formDropdown,
        addressLookup: {
          searchAddressField: searchAddressField,
          searchForAddressButton: 'Search for Address',
          manualAddressField: manualAddressField,
          addressSection: 'search'
        },
        postcodeOrSuburbLookup: {
          postcodeOrSuburbField: postcodeOrSuburbField,
          manualPostcodeOrSuburbField: manualPostcodeOrSuburbField,
          searchForAddressButton: 'Use suburb lookup instead',
          postcodeOrSuburbSection: 'search-postcode-or-suburb'
        }
      }
    );
    document.body.innerHTML = html;
    initForm();
  });

  test('render all the input field', () => {
    const inputContainer = document.querySelectorAll('.text');
    expect(inputContainer.length).toBe(formFields.length);
  });

  test('show error message and check if it has is-empty class on blur of input field', () => {
    const input = document.querySelector('#form-text-firstname') as HTMLInputElement;
    const errorMessageEl = document.querySelector('.error-message') as HTMLElement;
    input.value = '';
    input.dispatchEvent(new Event('blur'));
    expect(input.classList.contains('is-empty')).toBe(true);
    expect(errorMessageEl.textContent).toContain(formFieldsWithErrors[0].error);
  });

  test('render address lookup and on click render manual lookup form', () => {
    const addressLookup = document.querySelector('.search-address-container') as HTMLElement;
    const manualForm = document.querySelector('.manual-address-container') as HTMLElement;
    const toggleSection = document.querySelector('.form-section-button .cmp-button') as HTMLElement;
    expect(manualForm.classList.contains('hidden')).toBe(true);
    toggleSection.click();
    expect(addressLookup.classList.contains('hidden')).toBe(false);
  });

});

describe('initForm (Jest with JSDOM)', () => {
  beforeEach(async () => {
    const html = await liquidEngine.renderFile(
      'src/main/webpack/patterns/components/forms/forms.liquid',
      {
        fields: formFieldsWithErrors, errorMessage: true,

      }
    );
    document.body.innerHTML = html;
    initForm();
  });

  test('show error when invalid email is entered and blurred', () => {
    const input = document.querySelector('#form-text-email') as HTMLInputElement;
    const errorMessageEl = input.closest('.cmp-form-text')?.querySelector('.error-message') as HTMLElement;

    input.value = '';
    input.dispatchEvent(new Event('blur'));

    expect(input.classList.contains('is-empty')).toBe(true);
    expect(errorMessageEl.textContent).toContain(formFieldsWithErrors[2].error);
    expect(input.getAttribute('aria-invalid')).toBe('true');

    input.value = 'hello';
    input.dispatchEvent(new Event('blur'));

    expect(input.classList.contains('is-empty')).toBe(false);
    expect(errorMessageEl.textContent).toContain(formFieldsWithErrors[2].error);

    input.value = 'hello@domainname'; // missing TLD
    input.dispatchEvent(new Event('blur'));

    expect(input.classList.contains('is-empty')).toBe(false);
    expect(errorMessageEl.textContent).toContain(formFieldsWithErrors[2].error);

  });

  test('no error for valid email and aria-invalid removed', () => {
    const input = document.querySelector('#form-text-email') as HTMLInputElement;
    const errorMessageEl = input.closest('.cmp-form-text')?.querySelector('.error-message') as HTMLElement;
    // Valid email
    input.value = 'test@example.com';
    input.dispatchEvent(new Event('blur'));
    expect(input.classList.contains('is-empty')).toBe(false);
    // either hidden or empty
    expect(errorMessageEl.style.display === 'none' || errorMessageEl.textContent === '').toBe(true);
    expect(input.getAttribute('aria-invalid')).toBe(null);
  });
});

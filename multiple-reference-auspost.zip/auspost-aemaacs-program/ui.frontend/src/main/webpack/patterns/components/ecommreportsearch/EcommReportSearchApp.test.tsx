import React from "react";
import { render } from "@testing-library/react";
import EcommReportSearchApp from "./EcommReportSearchApp";
import { SearchProvider } from "./store/ERSearchContext";

jest.mock("react-markdown", () => (props: any) => (
  <div data-testid="markdown">{props.children}</div>
));

function createContextValue() {
  return {
    searchField: {
      label: "Ask AI about eCommerce trends",
      buttonText: "Search",
      placeholder: "Type to search",
      redirectUrl: "/search",
    },
    suggestedSearch: {
      title: "Popular",
      items: [{ href: "#", target: "_self", label: "Track" }],
    },
    keywordSearchUrl: "/keywords-search-url",
    answerUrl: "/answer-url",
  };
}

describe("EcommReportSearchApp", () => {
  it("renders label, input and submit button", () => {
    const value = createContextValue();
    render(
      <SearchProvider value={value}>
        <EcommReportSearchApp />
      </SearchProvider>,
    );

    const label = document.querySelector(".search-title");
    expect(label).not.toBeNull();
    expect(label!.textContent).toBe("Ask AI about eCommerce trends");

    const input = document.querySelector('textarea[aria-label="Search input"]');
    expect(input).not.toBeNull();

    const submitBtn = document.querySelector('button[aria-label="Search"]');
    expect(submitBtn).not.toBeNull();
  });
});

import { ButtonProps } from '../../atoms/button/interfaces';

export interface KeyBenefitsProps {
  image: {
    src: string;
    alt: string;
  };
  imagePosition?: string;
  heading?: string;
  description?: string;
  listContent?: string[];
  listBackgroundColor?: string;
  iconColor?: string;
  ctas?: ButtonProps[];
}
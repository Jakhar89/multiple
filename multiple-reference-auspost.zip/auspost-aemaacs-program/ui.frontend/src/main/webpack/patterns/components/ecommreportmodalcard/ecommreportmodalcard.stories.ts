import type { Meta, StoryObj } from "@storybook/html-vite";
import component from "./ecommreportmodalcard.liquid";
import {
  MockModalCardWithBarGraphData,
  MockModalCardWithImageGreyData,
  MockModalCardWithImageTransparentData,
  MockModalCardWithPieGraphData,
} from "./ecommreportmodalcard.mock";
import { initBarGraph, initPieGraph } from "./ecommreportmodalcard";

const meta = {
  title: "Components/Ecommerce Report/Modal Card",
  component,
  args: MockModalCardWithBarGraphData,
  play: async () => {
    await new Promise((resolve) => setTimeout(resolve, 500));
    initBarGraph();
  },
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const WithBarGraph: Story = {};

export const WithPieGraph: Story = {
  args: MockModalCardWithPieGraphData,
  play: async () => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    initPieGraph();
  },
};

export const WithImageTransparent: Story = {
  args: MockModalCardWithImageTransparentData,
  play: async () => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    initPieGraph();
  },
};

export const WithImageGrey: Story = {
  args: MockModalCardWithImageGreyData,
  play: async () => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    initPieGraph();
  },
};

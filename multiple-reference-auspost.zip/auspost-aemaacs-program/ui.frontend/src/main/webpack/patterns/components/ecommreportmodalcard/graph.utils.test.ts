import {
  getTransition,
  animateNumber,
  handleIntersectionObserver,
  handleViewportIntersectionObserverAnimation,
} from "./graph.utils";

describe("getTransition", () => {
  it("should generate correct transition string", () => {
    expect(getTransition(1000)).toBe("stroke-dashoffset 900ms ease-in-out");
    expect(getTransition(2000)).toBe("stroke-dashoffset 1800ms ease-in-out");
  });
});

describe("animateNumber", () => {
  beforeEach(() => {
    jest.useFakeTimers();
    jest.spyOn(window, "requestAnimationFrame").mockImplementation((cb) => {
      cb(0);
      return 0 as any;
    });
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.restoreAllMocks();
  });

  it("should update element innerHTML and include suffix", () => {
    const el = document.createElement("div");
    animateNumber(el, 0, 50, 1000, "%");
    expect(el.innerHTML).toContain("%");
    expect(el.innerHTML.length).toBeGreaterThan(0);
  });

  it("should pad single digit numbers to two characters", () => {
    const el = document.createElement("div");
    animateNumber(el, 0, 5, 1000, "%");
    expect(el.innerHTML).toMatch(/0\d/);
  });

  it("should start at provided start value", () => {
    const el = document.createElement("div");
    animateNumber(el, 10, 15, 1000, "");
    const value = parseInt(el.innerHTML, 10);
    expect(value).toBeGreaterThanOrEqual(10);
  });
});

describe("handleIntersectionObserver", () => {
  it("should create an IntersectionObserver, observe the container and call callback for entries", () => {
    const observeMock = jest.fn();
    let savedCallback: any = null;

    (window as any).IntersectionObserver = jest.fn((cb: any, options: any) => {
      savedCallback = cb;
      return {
        observe: observeMock,
        unobserve: jest.fn(),
        disconnect: jest.fn(),
      } as any;
    });

    const container = document.createElement("div");
    const cb = jest.fn();

    const observer = handleIntersectionObserver(cb, container, { threshold: 0.5 });

    // should have observed the container
    expect(observeMock).toHaveBeenCalledWith(container);

    // simulate entries being reported
    savedCallback([{ isIntersecting: true }]);
    expect(cb).toHaveBeenCalled();

    // cleanup
    delete (window as any).IntersectionObserver;
  });
});

describe("handleViewportIntersectionObserverAnimation", () => {
  afterEach(() => {
    jest.restoreAllMocks();
    if ((window as any).IntersectionObserver) delete (window as any).IntersectionObserver;
  });

  it("should call animationCallback immediately when IntersectionObserver is not available", () => {
    const animationCallback = jest.fn();
    const removeCallback = jest.fn();
    // ensure IntersectionObserver is not present
    delete (window as any).IntersectionObserver;

    const container = document.createElement("div");
    handleViewportIntersectionObserverAnimation(container, animationCallback, removeCallback);

    expect(animationCallback).toHaveBeenCalled();
    expect(removeCallback).not.toHaveBeenCalled();
  });

  it("should call animationCallback or removeCallback based on intersection entries when supported", () => {
    const observeMock = jest.fn();
    let savedCallback: any = null;

    (window as any).IntersectionObserver = jest.fn((cb: any) => {
      savedCallback = cb;
      return {
        observe: observeMock,
        unobserve: jest.fn(),
        disconnect: jest.fn(),
      } as any;
    });

    const animationCallback = jest.fn();
    const removeCallback = jest.fn();
    const container = document.createElement("div");

    handleViewportIntersectionObserverAnimation(container, animationCallback, removeCallback);

    // simulate intersecting
    savedCallback([{ isIntersecting: true }]);
    expect(animationCallback).toHaveBeenCalled();

    // simulate not intersecting
    savedCallback([{ isIntersecting: false }]);
    expect(removeCallback).toHaveBeenCalled();
  });
});

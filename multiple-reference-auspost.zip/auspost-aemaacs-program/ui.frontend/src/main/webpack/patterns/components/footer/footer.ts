import { ToggleConfig } from './interfaces';

function handleToggle(event: Event, config: ToggleConfig) {
  const button = event.currentTarget as HTMLButtonElement;
  const container = button.closest(config.containerSelector);

  if (!container) return;

  const target = container.querySelector<HTMLElement>(config.childSelector);
  if (!target) return;

  target.classList.toggle(config.hideClass);
  container.classList.toggle('expanded');

  const expanded = button.getAttribute('aria-expanded') === 'true';
  button.setAttribute('aria-expanded', String(!expanded));
}


export function initToggle(config: ToggleConfig): void {
    const buttons = document.querySelectorAll<HTMLButtonElement>(config.toggleButtonSelector);
    buttons.forEach(button => {
      button.addEventListener('click', (e) => handleToggle(e, config));
    });
}

export default function initFooter(): void {
    if(document.querySelector('footer')){
      initToggle({
        toggleButtonSelector: '.js-toggle-child-links',
        containerSelector: '.footer-primary-links',
        childSelector: '.footer-child-links',
        hideClass: 'hide-xs'
      });
    }
};

initFooter();
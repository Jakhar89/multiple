import type { Meta, StoryObj } from '@storybook/html-vite';
import initForm from '../forms';
import component from './collectables.liquid';
import { collectableFormFields, collectableFormFieldsWithErrors, collectableFormCheckboxField, allCollectableFormFieldsWithErrors }
 from './_collectables.mock';

const meta = {
  title: 'Components/Forms/Collectables',
  component: component,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: 'Simple form using AEM Core Components'
      }
    }
  },
  argTypes: {
    message: { control: 'text' },
    errors: { control: 'object' },
    fields: { control: 'object' },
  },
  args: {
    fields: collectableFormFields,
    checkboxFields: collectableFormCheckboxField
  }
}

export default meta;

type Story = StoryObj;

export const Default: Story = {
  args: {},
};

export const ValidationError: Story = {
  args: {
    errorMessage: 'Please fix the following issues before submitting',
    errors: allCollectableFormFieldsWithErrors.map(x => x.error),
    fields: collectableFormFieldsWithErrors,
    checkboxFields: {
      ...collectableFormCheckboxField,
      required: true
    },
  }
};

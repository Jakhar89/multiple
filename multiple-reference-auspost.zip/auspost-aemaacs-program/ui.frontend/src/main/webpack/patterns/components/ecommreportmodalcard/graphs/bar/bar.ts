import { ANIMATION_CLASS_NAME } from "../../ecommreportmodalcard.constants";
import { handleIntersectionObserver } from "../../graph.utils";

export function initBarGraph(): void {
  const chartContainers = document.querySelectorAll(".ecomm-report-bar-graph");
  const barWidthPropertyName = "--bar-width";
  const barIndexPropertyName = "--bar-index";

  if (!chartContainers) return;

  const initBarData = (barRows: NodeListOf<HTMLElement>) => {
    barRows.forEach((row, idx) => {
      const rawWidth = row.dataset.barWidth ?? "0";
      const rawIndex = row.dataset.barIndex ?? String(idx);

      // barWidth is a number 0-100; store with percentage unit for use in SCSS
      const cssWidth = `${rawWidth}%`;

      row.style.setProperty(barWidthPropertyName, cssWidth);
      row.style.setProperty(barIndexPropertyName, rawIndex);
    });
  };

  const addAnimation = (barRows: NodeListOf<HTMLElement>) => {
    barRows.forEach((row) => row.classList.add(ANIMATION_CLASS_NAME));
  };

  const removeAnimation = (barRows: NodeListOf<HTMLElement>) => {
    barRows.forEach((row) => row.classList.remove(ANIMATION_CLASS_NAME));
  };

  chartContainers.forEach((chartContainer) => {
    const barRows: NodeListOf<HTMLElement> =
      chartContainer.querySelectorAll(".bar-row");

    // Initialize CSS custom properties from data attributes
    initBarData(barRows);

    if (!("IntersectionObserver" in window)) {
      addAnimation(barRows);
    } else {
      handleIntersectionObserver((entry) => {
        if (entry.isIntersecting) {
          addAnimation(barRows);
        } else {
          removeAnimation(barRows);
        }
      }, chartContainer);
    }
  });
}

document.addEventListener("DOMContentLoaded", initBarGraph);

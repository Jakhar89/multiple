import type { Meta, StoryObj } from "@storybook/html-vite";
import ecommlinkcapture from "./ecommlinkcapture.liquid";
import { MockLinkCaptureData } from "./_ecommlinkcapture.mock";

const meta = {
    title: "Components/Ecommerce Report/Link Capture",
    component: ecommlinkcapture,
    parameters: {
        layout: "fullscreen",
    },
    args: MockLinkCaptureData,
    play: async () => {},
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const Default: Story = {};

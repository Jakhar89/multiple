import { faker } from "@faker-js/faker";
import {
    AssetItem
} from './interfaces';

export const MOCK_ASSET_ITEM: AssetItem = {
    imageUrl: '/src/main/webpack/patterns/assets/images/stamp-bulletin.jpg',
    datestamp: 'Issue date: 26 August 2025',
    title: faker.lorem.sentence(),
    description: faker.lorem.sentence(),
    isBlurred: true,
    cardCtaText: faker.helpers.arrayElement([
        "Contact Mailorder",
        "View Collection",
        "Read Guide",
        "Book Tickets",
    ]),
    cardCtaType: 'primary',
};

export const MOCK_ASSET_ITEM_LANDSCAPE: AssetItem = {
    ...MOCK_ASSET_ITEM,
    imageUrl: 'src/main/webpack/patterns/assets/images/stamp-landscape.png'
};

export const MOCK_ASSET_ITEM_SQUARE: AssetItem = {
    ...MOCK_ASSET_ITEM,
    imageUrl: 'src/main/webpack/patterns/assets/images/stamp-square.png'
};

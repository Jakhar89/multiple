import React, { useMemo } from "react";
import ERAutosuggestList from "../ERAutoSuggestList/ERAutosuggestList";
import ERTextInput from "../ERTextInput/ERTextInput";
import { useAutosuggest } from "../hooks/useERAutosuggest";
import ERIcon from "../Icons/ERIcon";
import { MIN_CHARS_FOR_AUTOSUGGEST_SEARCH } from "../utils/constants";
import { AutoSuggestProps } from "../store/ERSearchInterface";

export default function ERAutoSuggest({
  autocomplete = true,
  minChars = MIN_CHARS_FOR_AUTOSUGGEST_SEARCH,
  suggestions,
  value,
  onChange,
  onSelect,
  className = "",
  label,
  title,
  searchLabel,
  showFollowUpQuestion,
  isFollowUpActive,
  onAskFollowUp,
  ...inputProps
}: AutoSuggestProps) {
  const {
    inputValue,
    setInputValue,
    activeIndex,
    setActiveIndex,
    isOpen,
    setIsOpen,
    visibleSuggestions,
    handleKeyDown: hookKeyDown,
    isLoading,
  } = useAutosuggest({
    autocomplete,
    minChars,
    suggestions,
    value,
  });

  const baseId = useMemo(
    () => `autosuggest-${Math.random().toString(36).slice(2, 9)}`,
    [],
  );
  const listboxId = `${baseId}-listbox`;

  const handleChange: React.ChangeEventHandler<HTMLTextAreaElement> = (e) => {
    const nextValue = e.target.value;
    setInputValue(nextValue);
    setActiveIndex(-1);
    setIsOpen(nextValue.length >= minChars && !isFollowUpActive);
    onChange && onChange(e);
  };

  const handleSelect = (selectedValue: string) => {
    setInputValue(selectedValue);
    setIsOpen(false);
    setActiveIndex(-1);

    onSelect?.(selectedValue);

    // Keep compatibility with controlled inputs
    onChange?.({
      currentTarget: { value: selectedValue },
    } as React.ChangeEvent<HTMLTextAreaElement>);
  };

  const handleKeyDown: React.KeyboardEventHandler<HTMLTextAreaElement> = (
    e,
  ) => {
    hookKeyDown(e);

    if (
      e.key === "Enter" &&
      activeIndex >= 0 &&
      activeIndex < visibleSuggestions.length
    ) {
      e.preventDefault();
      handleSelect(visibleSuggestions[activeIndex]);
    }
  };

  return (
    <>
      <div className={`ecomm-search-input-wrapper ${className}`}>
        {isFollowUpActive && (
          <span className="follow-up-icon hide">
            <ERIcon
              name="arrow-curve-right"
              colorClass="icon--fill-black"
            />
          </span>
        )}
        <ERTextInput
          {...inputProps}
          label={label}
          value={inputValue || value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          autoComplete="off"
          role="combobox"
          aria-autocomplete="list"
          aria-expanded={isOpen && visibleSuggestions.length > 0}
          aria-controls={listboxId}
          aria-activedescendant={
            activeIndex >= 0 ? `${baseId}-option-${activeIndex}` : undefined
          }
        />
        <button
          type="submit"
          className="cmp-button button ecomm-search-btn"
          aria-label={searchLabel}
        >
          <span className="search-icon hide-md">
            <ERIcon name="search" />
          </span>
          <span className="hide show-md">{searchLabel}</span>
        </button>
      </div>

      {isOpen && (isLoading || visibleSuggestions.length > 0) && (
        <ERAutosuggestList
          idBase={baseId}
          listboxId={listboxId}
          suggestions={visibleSuggestions}
          activeIndex={activeIndex}
          query={inputValue}
          title={title}
          onSelect={handleSelect}
          loading={isLoading}
        />
      )}
    </>
  );
}

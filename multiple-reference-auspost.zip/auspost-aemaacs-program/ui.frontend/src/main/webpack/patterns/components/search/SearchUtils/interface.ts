import type { InputHTMLAttributes } from 'react';
export interface PopularSearchItemsProps {
    label: string;
    href: string;
    target?: string;
}

export interface PopularSearchProps {
    title: string;
    items: PopularSearchItemsProps[];
}

export interface SearchFieldProps {
    label: string;
    buttonText: string;
    placeholder: string;
    redirectUrl: string;
    autocomplete?: boolean;
    autocompleteTitle?: string;
}

export interface QuerySuggestionItemProps {
    suggestion: string
}

export interface QuerySuggestionsProps {
    querySuggestions: QuerySuggestionItemProps[]
}

export interface AutoSuggestProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onSelect'> {
  autocomplete?: boolean;
  minChars?: number;
  suggestions?: string[];
  value?: string;
  label?: string;
  title?: string;
  className?: string;
    isResultView?: boolean;
  onSelect?: (value: string) => void;
}

export interface AutosuggestListProps {
    idBase: string;
    listboxId: string;
    suggestions: string[];
    activeIndex: number;
    query: string;
    title?: string;
    onSelect: (value: string) => void;
    loading?: boolean;
    skeletonCount?: number;
    isResultView?: boolean;
    remoteSuggestions?: string[];
}

export interface SearchSnippetProps {
    snippet: string;
    snippet_status: 'SUCCESS' | string;
}

export interface DerivedStructDataProps {
    htmlTitle?: string;
    datePublished?: number;
    dateModified?: number;
    snippets?: SearchSnippetProps[];
    link?: string;
    can_fetch_raw_content?: string;
    title?: string;
    displayLink?: string;
}

export interface DocumentProps {
    name: string;
    id: string;
    structData: Record<string, string[]>;
    derivedStructData: DerivedStructDataProps;
}

export interface SearchResultItemProps {
    id: string;
    document: DocumentProps;
    rankSignals?: any;
}

export interface SessionInfoProps {
    name: string;
    queryId?: string;
}

export interface SearchResultsResponseProps {
    results: SearchResultItemProps[];
    totalSize: number;
    attributionToken?: string;
    nextPageToken?: string;
    guidedSearchResult?: Record<string, unknown>;
    summary?: Record<string, unknown>;
    appliedControls?: string[];
    queryExpansionInfo?: Record<string, unknown>;
    sessionInfo?: SessionInfoProps;
    semanticState?: string;
}

export interface ResultsCountProps {
    start: number;
    end: number;
    total: number;
    loading?: boolean;
    hasItems?: boolean;
    className?: string;
}

export interface SearchResultsViewProps {
    items: SearchResultsResponseProps['results'];
    loading: boolean;
    pageStart: number;
    pageEnd: number;
    total: number;
    skeletonCount: number;
    lastSearchedQuery: string;
    showError: boolean;
    nextPageToken?: string | null;
    performSearch?: (q: string, pageToken?: string | null, pageIndex?: number) => Promise<void> | void;
    dataCmpDataLayer?: string;
    searchQuery?: string;
}

export interface ResultsFooterProps {
    start: number;
    end: number;
    total: number;
    loading?: boolean;
    hasItems?: boolean;
    className?: string;
    nextPageToken?: string | null;
    lastSearchedQuery?: string;
    performSearch?: (q: string, pageToken?: string | null, pageIndex?: number) => Promise<void> | void;
};
export interface PaginationProps {
    performSearch?: (q: string, pageToken?: string | null, pageIndex?: number) => Promise<void> | void;
    lastSearchedQuery?: string;
    nextPageToken?: string | null;
    loading?: boolean;
}
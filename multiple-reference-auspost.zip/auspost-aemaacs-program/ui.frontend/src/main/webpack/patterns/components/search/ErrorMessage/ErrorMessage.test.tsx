import React from 'react';
import { render, screen, cleanup } from '@testing-library/react';
import ErrorMessage from './ErrorMessage';

afterEach(() => {
  document.querySelectorAll('.search-error').forEach((n) => n.parentElement?.removeChild(n));
  cleanup();
});

describe('ErrorMessage', () => {
  it('renders nothing when not visible', () => {
    const { container } = render(<ErrorMessage visible={false} />);
    expect(container.innerHTML).toBe('');
  });

  it('renders server-provided HTML when available', async () => {
    const server = document.createElement('div');
    server.className = 'search-error';
    server.innerHTML = '<p><strong>Server error:</strong> Please try again later.</p>';
    document.body.appendChild(server);

    const { container } = render(<ErrorMessage visible={true} />);

    const wrapper = container.querySelector('.search-error-message');
    expect(!!wrapper).toBe(true);
    expect(wrapper?.textContent || '').toContain('Server error:');
    expect(document.querySelector('.search-icon svg')).not.toBeNull();
  });

  it('renders fallback message when server element is missing', async () => {
    render(<ErrorMessage visible={true} />);

    const heading = await screen.findByRole('heading');
    expect(heading.textContent).toContain('An error occurred while fetching search results');
  });
});

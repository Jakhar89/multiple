// interfaces.ts
import { BannerProps } from '~/patterns/components/banner/interfaces';

export interface CarouselItem {
  id: string;
  banner: BannerProps;
}

export interface CtaContent {
  label: string,
  href: string,
  target: string,
}
export interface Carousel {
  id: string;
  heading: string,
  gradientBackground: boolean,
  cta?: boolean,
  ctaContent: CtaContent,
  items: CarouselItem[];
}

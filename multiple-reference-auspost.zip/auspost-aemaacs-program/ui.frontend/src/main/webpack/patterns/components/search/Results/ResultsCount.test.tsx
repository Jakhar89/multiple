import React from 'react';
import { render, screen } from '@testing-library/react';
import ResultsCount from './ResultsCount';

describe('ResultsCount', () => {
  test('renders the count range and total', () => {
    render(<ResultsCount start={1} end={10} total={100} />);
    const el = screen.getByText('1 - 10 of 100 items');
    expect(el).toBeTruthy();
  });

  test('applies provided className alongside base class', () => {
    const { container } = render(<ResultsCount start={5} end={15} total={20} className="custom" />);
    const root = container.querySelector('.results-count.custom');
    expect(root).toBeTruthy();
    expect(root?.textContent).toBe('5 - 15 of 20 items');
  });

  test('defaults to only base class when className not provided', () => {
    const { container } = render(<ResultsCount start={2} end={3} total={5} />);
    const root = container.firstChild as HTMLElement;
    expect(root.className).toBe('results-count');
    expect(root.textContent).toBe('2 - 3 of 5 items');
  });
});

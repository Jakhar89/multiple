import { scrollTo } from '../../../scripts/utils/scroll';
import { isTouchDevice } from '../../../scripts/utils/utils';

export default function initHeader(): void {

  // Utility function to restore header element accessibility
  const restoreHeaderElements = () => {
    const header = document.querySelector('header');
    if (header) {
      const headerElements = header.querySelectorAll<HTMLElement>('button, a');
      headerElements.forEach((el) => {
        el.removeAttribute('tabindex');
        el.removeAttribute('aria-hidden');
      });
    }
  };

  // Make function globally accessible for SearchApp
  (window as any).restoreHeaderElements = restoreHeaderElements;

  /*
   * *****************************************
   * Desktop megamenu
   * *****************************************
   */

  const backdrop = document.querySelector<HTMLElement>('.menu-backdrop');
  const navGroups = document.querySelectorAll<HTMLElement>('.level-one-nav-group');

  // All cleanup required when closing desktop menu
  const closeDesktopMenus = () => {
    const backdrop = document.querySelector<HTMLElement>('.menu-backdrop');
    backdrop?.classList.remove('active');
    const openMenus = document.querySelectorAll<HTMLElement>('.mega-menu-dropdown.open');
    openMenus?.forEach((menu: HTMLElement) => {
      menu.previousElementSibling?.querySelector('button.level-one-expand-button')?.setAttribute('aria-expanded', 'false');
      menu.classList.remove('open');
    });
  };

  navGroups.forEach((group) => {
    const navItem = group.querySelector<HTMLElement>('.level-one-nav-item');
    const button = navItem?.querySelector<HTMLButtonElement>('button.level-one-expand-button');
    const dropdownId = navItem?.dataset.dropdownId;
    const dropdown = group.querySelector<HTMLElement>(`.mega-menu-dropdown[data-dropdown-id="${dropdownId}"]`);

    if(!dropdown || !button) return;

    //Open Menu
    const openMenu = () => {
      closeDesktopMenus();
      backdrop?.classList.add('active');
      dropdown.classList.add('open');
      button.setAttribute('aria-expanded', 'true');
    };

    //Close Menu
    const closeMenu = () => {
      dropdown.classList.remove('open');
      button.setAttribute('aria-expanded', 'false');
      backdrop?.classList.remove('active');
    };

    const toggleMenu = () => {
      dropdown.classList.contains('open') ? closeMenu() : openMenu();
    };
    
    if(!isTouchDevice()) {
      group.addEventListener('mouseenter', openMenu);
      group.addEventListener('mouseleave', closeMenu);
    }

    button.addEventListener('click', (e) => {
      if(!isTouchDevice() && e.detail !== 0) {
        return;
      }
      e.preventDefault();
      toggleMenu();
    });

    button.addEventListener('keydown', (e) => {
      if(e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggleMenu();
      }

      if(e.key === 'Escape') {
        closeMenu();
        button.focus();
      }
    });

  });

  // --- Click outside to close nav-details-wrapper ---
  document.addEventListener('mouseup', function (event) {
    const openMenu = document.querySelector<HTMLElement>('.mega-menu-dropdown.open');
    if (!openMenu) return;

    const associatedButton = openMenu.parentElement?.querySelector('button.level-one-expand-button');
    if (!associatedButton) return;

    // We are purposely excluding the associated toggle button so the click eventhandler can run
    const target = event.target as Node;
    const isInsideMenu = openMenu.contains(target) || associatedButton.contains(target);

    if (!isInsideMenu) {
      closeDesktopMenus();
    }
  });

  // --- Close megamenu on Escape key ---
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closeDesktopMenus();
    }
  });

  // --- Close open nav-details-wrapper when focus leaves it (keyboard navigation) esc ---
  document.addEventListener('focusin', function (event) {
    const openMenu = document.querySelector<HTMLElement>('.mega-menu-dropdown.open');
    if (!openMenu) return;

    // If focused item isn't within an open mega menu (or its parent toggle button), we should close
    const { dropdownId } = openMenu.dataset;
    const newlyFocused = event.target as HTMLElement;
    const dropdownIsNotInFocus = newlyFocused.closest('.mega-menu-dropdown.open') == null;
    const newlyFocusedClosestParent = newlyFocused.closest<HTMLElement>('.level-one-nav-item');
    const newFocusedToggleId = newlyFocusedClosestParent?.dataset.dropdownId;

    // If the current focus dropdownId doesn't match the active dropdowns id, the user has moved outside of the active parent button
    if (dropdownIsNotInFocus && dropdownId !== newFocusedToggleId) {
      closeDesktopMenus();
    }
  });


  /*
   * *****************************************
   * Login and search menu toggles
   * *****************************************
   */

  const loginDropdownToggle = document.querySelector('.btn-login-trigger') as HTMLButtonElement | null;
  const loginDropdown = document.querySelector('.login-dropdown');

  const closeLoginDropdown = () => {
    backdrop?.classList.remove('active');
    loginDropdownToggle?.setAttribute('aria-expanded', 'false');
    loginDropdown?.classList.remove('open');

    const ariaLabel = loginDropdownToggle?.getAttribute('aria-label');
    const newAriaLabel = `Expand ${ariaLabel?.replace('Collapse', '').trim()}`;
    loginDropdownToggle?.setAttribute('aria-label', newAriaLabel);
  };

  loginDropdownToggle?.addEventListener('click', () => {
    const wasExpanded = loginDropdownToggle.getAttribute('aria-expanded') === 'true';
    const isExpanding = !wasExpanded;

    if (isExpanding) {
      backdrop?.classList.add('active');
      loginDropdownToggle.setAttribute('aria-expanded', 'true');
      loginDropdown?.classList.add('open');
    } else {
      closeLoginDropdown();
    }

    const ariaLabel = loginDropdownToggle.getAttribute('aria-label');
    const newAriaLabel = `${isExpanding ? 'Collapse' : 'Expand'} ${ariaLabel?.replace('Collapse', '').replace('Expand', '').trim()}`;
    loginDropdownToggle.setAttribute('aria-label', newAriaLabel);
  });

  // Close login dropdown when clicking outside it
  document.addEventListener('mouseup', function (event) {
    const openMenu = document.querySelector<HTMLElement>('.login-dropdown.open');
    if (!openMenu) return;

    const associatedButton = openMenu.closest('.login-container');
    if (!associatedButton) return;

    // We are purposely excluding the associated toggle button so the click eventhandler can run
    const target = event.target as Node;
    const isInsideMenu = openMenu.contains(target) || associatedButton.contains(target);

    if (!isInsideMenu) {
      closeLoginDropdown();
    }
  });

  // Close login dropdown when focus leaves it
  document.addEventListener('focusin', function (event) {
    const loginDropdownOpen = document.querySelector<HTMLElement>('.login-dropdown.open');
    if (!loginDropdownOpen)
      return;

    const newlyFocused = event.target as HTMLElement;
    const dropdownIsNotInFocus = newlyFocused.closest('.login-container') == null;

    // If focused item isn't within the login container we should close
    if (dropdownIsNotInFocus) {
      closeLoginDropdown();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeLoginDropdown();
    }
  });


  /*
   * *****************************************
   * Mobile nav menu
   * *****************************************
   */
  const globalAlerts = document.querySelectorAll<HTMLElement>('.globalalert');
  const mobileMenuButton = document.querySelector<HTMLButtonElement>('#mobile-menu-button');
  const mobileMenuOverlay = document.querySelector<HTMLElement>('.mobile-menu-overlay');
  const mobileSubMenuOverlay = document.querySelector<HTMLElement>('.mobile-submenu-overlay');
  const allSubMenus = mobileSubMenuOverlay?.querySelectorAll<HTMLElement>('.submenu-wrapper');
  let scrollPosition = 0;

  window.addEventListener('scroll', function () {
    // Don't run in desktop resolution
    if (!mobileMenuButton || mobileMenuButton == undefined || !mobileMenuButton.offsetParent)
      return;

    const header = document.querySelector<HTMLElement>('.header-corporate');
    if (!header)
      return;

    let heighToFixPosition = 0;
    if (globalAlerts.length > 0) {
      heighToFixPosition = Array.from(globalAlerts).reduce(function (a, b) {
        return a + b.offsetHeight;
      }, 0);
    }

    // To prevent janky movement when setting fixed position, when .fix-position is applied
    // hide all global alerts, and add padding to main content to componensate for the headers height
    const main = document.querySelector<HTMLElement>('main');
    const { scrollY } = window;
    if (scrollY > heighToFixPosition) {
      const headerHeight = header.offsetHeight;
      header.classList.add('fix-position');

      // And set padding on main to prevent janky movement when global alerts exist
      if (main)
        main.style.paddingTop = `${headerHeight}px`;

      for (const alert of globalAlerts) {
        alert.classList.remove('visible');
        alert.classList.add('invisible');
      }
    } else {
      header.classList.remove('fix-position');

      if (main)
        main.style.paddingTop = '0';

      for (const alert of globalAlerts) {
        alert.classList.add('visible');
        alert.classList.remove('invisible');
      }
    }
  });

  // All cleanup required when closing mobile menu
  const closeMobileMenu = () => {
    mobileMenuOverlay?.classList.remove('active');
    mobileMenuButton?.setAttribute('aria-expanded', 'false');
    mobileSubMenuOverlay?.classList.remove('active');

    for (const submenu of allSubMenus ?? []) {
      if (!submenu.classList.contains('hide'))
        submenu.classList.add('hide');
    }
  };

  if (mobileMenuButton && mobileMenuOverlay && mobileSubMenuOverlay) {
    // Open/close mobile main menu
    mobileMenuButton.addEventListener('click', () => {
      const wasExpanded = mobileMenuButton.getAttribute('aria-expanded') === 'true';
      const isExpanding = !wasExpanded;

      if (isExpanding) {
        const { scrollY } = window;
        scrollPosition = scrollY;
        mobileMenuOverlay.classList.add('active');
      } else {
        closeMobileMenu();
        scrollTo(scrollPosition);
      }

      mobileMenuButton.setAttribute('aria-expanded', isExpanding.toString());

      // iOS VoiceOver: using only aria-expanded does not get announced, using aria-live as well
      const mobileMenuStatus = document.getElementById('mobile-menu-status');
      if (mobileMenuStatus) {
        mobileMenuStatus.textContent = isExpanding ? 'Main menu opened' : 'Main menu closed';
        
        setTimeout(() => {
          mobileMenuStatus.textContent = '';
        }, 250); 
      }

      // Hide global alerts (if any) when tablet/mobile menu opens
      for (const alert of globalAlerts) {
        if (isExpanding) {
          alert.classList.remove('show');
          alert.classList.add('hide');
        } else {
          alert.classList.add('show');
          alert.classList.remove('hide');
        }
      }
    });

    const openMobileSubmenuButtonList = mobileMenuOverlay.querySelectorAll<HTMLElement>('.open-mobile-submenu-button');

    // Hook all mobile submenu OPEN buttons up
    for (const openMobileSubmenuButton of openMobileSubmenuButtonList) {
      // Open submenu click event
      openMobileSubmenuButton.addEventListener('click', (event: Event) => {
        // Ensure all submenu content is hidden before opening submenu
        for (const submenu of allSubMenus ?? []) {
          if (!submenu.classList.contains('hide'))
            submenu.classList.add('hide');
        }

        // Open submenu
        const openSubmenuButton = event.target as HTMLButtonElement;
        const sectionToggleId = openSubmenuButton.closest<HTMLElement>('.open-mobile-submenu-button')?.dataset.toggleId;
        mobileMenuOverlay.classList.remove('active');
        mobileSubMenuOverlay.classList.add('active');

        // Display selected menu content
        for (const submenu of allSubMenus ?? []) {
          if (submenu.dataset.toggleId == sectionToggleId) {
            submenu.classList.remove('hide');
            break;
          }
        }

        //Intentional set focus state
        mobileMenuButton.focus();
        mobileMenuButton.blur();
      });
    }

    const closeMobileSubmenuButtonList = mobileSubMenuOverlay.querySelectorAll<HTMLElement>('.close-mobile-submenu-button');

    // Hook all mobile submenu CLOSE buttons up
    for (const closeMobileSubmenuButton of closeMobileSubmenuButtonList) {
      // Close submenu click event
      if (closeMobileSubmenuButton) {
        closeMobileSubmenuButton.addEventListener('click', (event: Event) => {
          const clickTarget = event.target as HTMLElement;
          const closeSubmenuButton = clickTarget.closest('button');
          const sectionToggleId = closeSubmenuButton?.closest('section')?.dataset.toggleId;

          // Close level 2, open level 1 menu
          mobileMenuOverlay.classList.add('active');
          mobileSubMenuOverlay.classList.remove('active');

          // Set keyboard focus to corresponding OPEN button
          const relatedOpenButton = mobileMenuOverlay.querySelector(`.open-mobile-submenu-button[data-toggle-id="${sectionToggleId}"]`);
          if (relatedOpenButton) {
            const previousElement = relatedOpenButton.parentElement?.previousElementSibling as HTMLElement;
            previousElement.focus();
            previousElement.blur();
          }
        });
      }
    }

    // Close mobile menus when user presses Escape key
    document.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closeMobileMenu();
      }
    });

    // All level 2 accordion actions
    const level2AccordionToggles = mobileSubMenuOverlay.querySelectorAll<HTMLButtonElement>('.accordion-toggle');
    for (const toggle of level2AccordionToggles) {
      toggle.addEventListener('click', () => {
        const { accordionId } = toggle.dataset;
        const accordionItemElement = mobileSubMenuOverlay.querySelector<HTMLElement>(`#${accordionId}`);
        accordionItemElement?.classList.toggle('expanded');
        toggle.setAttribute('aria-expanded', (toggle.getAttribute('aria-expanded') != 'true').toString());
      });
    }
  }


  
  const searchButton = document.querySelector<HTMLButtonElement>('.header-search-btn');
  const searchModal = document.querySelector<HTMLElement>('.search-modal');
  if (searchModal && searchButton) {
    searchButton.addEventListener('click', () => {
      searchModal.classList.add('active');
      searchButton.setAttribute('aria-expanded', 'true');

      // Prevent focus on header elements when modal is open
      const header = document.querySelector('header');
      if (header) {
        const headerElements = header.querySelectorAll<HTMLElement>('button, a');
        headerElements.forEach((el) => {
          if (!searchModal.contains(el)) {
            el.setAttribute('tabindex', '-1');
            el.setAttribute('aria-hidden', 'true');
          }
        });
      }

      const searchInput = searchModal.querySelector<HTMLInputElement>('.standalone-search input');
      if (searchInput) {
        searchInput.focus();
      }
      document.body.classList.add('no-scroll');
    });

    document.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.key === 'Escape' && searchModal.classList.contains('active')) {
        searchModal.classList.remove('active');
        searchButton.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('no-scroll');
        
        // Restore focus capability to header elements
        restoreHeaderElements();
        
        searchButton.focus();
      }
    });
  }
}

window.addEventListener('load', () => {
  initHeader();
});

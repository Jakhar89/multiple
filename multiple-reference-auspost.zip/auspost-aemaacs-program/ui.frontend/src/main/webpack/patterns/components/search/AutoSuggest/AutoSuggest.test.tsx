import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import Autosuggest from './AutoSuggest';
import { SearchProvider } from '../SearchUtils/searchContext';

function renderWithProvider(ui: React.ReactElement) {
  const value = {
    searchField: {
      label: 'Search',
      buttonText: 'Search',
      placeholder: 'Type here',
      redirectUrl: '/search',
    },
    popularSearch: { title: '', items: [] },
    autocompleteUrl: '',
    resultPageSize: 10,
  };

  return render(<SearchProvider value={value}>{ui}</SearchProvider>);
}

describe('AutoSuggest', () => {
  const baseSuggestions = [
    'auspost',
    'Australia Post',
    'passport',
    'package',
    'address',
    'postal service',
    'australia day',
    'post office',
    'bus',
  ];

  it('renders input with combobox role and a11y attributes', () => {
    renderWithProvider(
      <Autosuggest label="Search" suggestions={baseSuggestions} />
    );

    const input = screen.getByRole('combobox');
    expect(input).toBeInTheDocument();
    expect(input).toHaveAttribute('aria-autocomplete', 'list');
    expect(input).toHaveAttribute('aria-expanded', 'false');
  });

  it('opens list when typing minChars and shows filtered suggestions', () => {
    renderWithProvider(
      <Autosuggest label="Search" suggestions={baseSuggestions} />
    );

    const input = screen.getByRole('combobox');
    fireEvent.change(input, { target: { value: 'aus' } });

    const listbox = screen.getByRole('listbox');
    expect(listbox).toBeInTheDocument();

    const options = screen.getAllByRole('option');
    expect(options.length).toBeGreaterThan(0);
    expect(options.some((li) => li.textContent?.toLowerCase().includes('aus'))).toBe(true);
  });

  it('navigates suggestions with keyboard and selects with Enter', () => {
    let selected = '';
    let changed = '';

    const handleSelect = (v: string) => {
      selected = v;
    };
    const handleChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
      changed = e.currentTarget.value;
    };

    renderWithProvider(
      <Autosuggest
        label="Search"
        suggestions={baseSuggestions}
        onSelect={handleSelect}
        onChange={handleChange}
      />
    );

    const input = screen.getByRole('combobox');
    fireEvent.change(input, { target: { value: 'aus' } });

    fireEvent.keyDown(input, { key: 'ArrowDown' });
    fireEvent.keyDown(input, { key: 'Enter' });

    expect(selected).toBeTruthy();
    expect(changed).toBe(selected);

    const listboxes = screen.queryAllByRole('listbox');
    expect(listboxes.length).toBe(0);
  });

  it('renders title when provided', () => {
    renderWithProvider(
      <Autosuggest label="Search" title="Suggestions" suggestions={baseSuggestions} />
    );

    const input = screen.getByRole('combobox');
    fireEvent.change(input, { target: { value: 'aus' } });

    expect(screen.getByText('Suggestions')).toBeInTheDocument();
  });
});

import { ButtonProps } from '../../atoms/button/interfaces';

export interface MarketingBlockProps {
  backgroundColor?: string;
  fullWidth?: string;
  image: {
    src: string;
    alt: string;
  };
  imagePosition?: string;
  imageType?: string;
  heading?: string;
  description?: string;
  ctas?: ButtonProps[];
  logo?:boolean;
  logoList?: string[];
  qrBlock?:boolean;
  qrCode?: string;
  qrText?: string;
  qrCTA:string[];
}
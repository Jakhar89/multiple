import Markdown from "react-markdown";
import ERSearchResultDownload from "../ERSearchResultDownload/ERSearchResultDownload";
import ERIcon from "../Icons/ERIcon";
import { SearchResultProps } from "../store/ERSearchInterface";

export default function ERSearchResult({
  result,
}: SearchResultProps) {
  return (
    <div className="search-results-container">
      {result ? (
        <>
          <div className="search-result-query">
            {result.question}
          </div>
          <div className="search-results-wrapper">
            <div className="search-ai-disclaimer">
              <ERIcon name="generative-ai" />
              <span>
                Generative AI may display inaccurate information, including
                about people, so double check its responses
              </span>
            </div>
            <div className="ai-search-markdown">
              <Markdown>{result?.answer?.text}</Markdown>
            </div>
            <ERSearchResultDownload />
          </div>
        </>
      ) : null}
    </div>
  );
}

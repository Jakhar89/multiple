import type { Meta, StoryObj } from '@storybook/html-vite';
import type { HeaderProps } from './interfaces';
import { HEADER_MOCK, PROMO_CARD_GREY } from './_header.mock';
import header from './header.liquid';
import initHeader from './header';
import initSearch from '../search/search';

const meta = {
  title: 'Components/Header',
  component: header,
  parameters: {
    layout: 'fullscreen'
  },
  args: {
    header: HEADER_MOCK,
    hideSearch: false,
    showGlobalAlert: true
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    initHeader();
    initSearch();
  }
} satisfies Meta<HeaderProps>;

export default meta;
type Story = StoryObj<HeaderProps>;

export const Default: Story = {};

export const GreyPromoCard: Story = {
  args: {
    header: {
      ...HEADER_MOCK,
      mainNav: HEADER_MOCK.mainNav.map((x) => ({
        ...x,
        megaMenu: {
          ...x.megaMenu,
          featureCard: PROMO_CARD_GREY
        }
      }))
    }
  }
};

export const MinimalHeader: Story = {
  args: {
    minimalHeader: true
  }
};

export const WithoutSearch: Story = {
  args: {
    minimalHeader: true,
    hideSearch: true
  }
};

import React, { useEffect, useMemo, useRef } from 'react';
import TextInput from '../TextInput/TextInput';
import { useAutosuggest } from './useAutosuggest';
import AutosuggestList from './AutosuggestList';
import { AutoSuggestProps } from '../SearchUtils/interface';
import config from '../util/search.config';

export default function Autosuggest({
  autocomplete = true,
  minChars = config.minCharactersLimit,
  suggestions,
  value,
  onChange,
  onSelect,
  className = '',
  label,
  title,
  isResultView = false,
  ...inputProps
}: AutoSuggestProps) {
  const {
    inputValue,
    setInputValue,
    activeIndex,
    setActiveIndex,
    isOpen,
    setIsOpen,
    visibleSuggestions,
    handleKeyDown: hookKeyDown,
    isLoading,
    remoteSuggestions
  } = useAutosuggest({
    autocomplete,
    minChars,
    suggestions,
    value,
    isResultView
  });

  const baseId = useMemo(
    () => `autosuggest-${Math.random().toString(36).slice(2, 9)}`,
    []
  );
  const listboxId = `${baseId}-listbox`;
  const containerRef = useRef<HTMLDivElement>(null);

  const handleChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    const nextValue = e.target.value;
    setInputValue(nextValue);
    setActiveIndex(-1);
    setIsOpen(nextValue.length >= minChars);
    onChange?.(e);
  };

  const handleSelect = (selectedValue: string) => {
    setInputValue(selectedValue);
    setIsOpen(false);
    setActiveIndex(-1);

    onSelect?.(selectedValue);

    // Keep compatibility with controlled inputs
    onChange?.({
      currentTarget: { value: selectedValue }
    } as React.ChangeEvent<HTMLInputElement>);
  };

  const handleKeyDown: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
    hookKeyDown(e);

    if (e.key === 'Enter') {
      if (activeIndex >= 0 && activeIndex < visibleSuggestions.length) {
        e.preventDefault();
        handleSelect(visibleSuggestions[activeIndex]);
        return;
      }

      // Otherwise, on results page, hide the autocomplete list
      if (isResultView && isOpen) {
        setIsOpen(false);
        setActiveIndex(-1);
      }
    }
  };

  useEffect(() => {
    if (!isResultView || !isOpen) return;

    const onDocClick = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node | null;
      if (target && containerRef.current && !containerRef.current.contains(target)) {
        setIsOpen(false);
        setActiveIndex(-1);
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
        setActiveIndex(-1);
      }
    };

    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('touchstart', onDocClick);
    document.addEventListener('keydown', onKeyDown);

    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('touchstart', onDocClick);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [isResultView, isOpen, setIsOpen, setActiveIndex]);

  return (
    <div ref={containerRef} className={`autosuggest position-relative ${className}`}>
      <TextInput
        {...inputProps}
        label={label}
        value={inputValue}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        autoComplete="off"
        role="combobox"
        aria-autocomplete="list"
        aria-expanded={isOpen && visibleSuggestions.length > 0}
        aria-controls={listboxId}
        aria-activedescendant={
          activeIndex >= 0
            ? `${baseId}-option-${activeIndex}`
            : undefined
        }
      />

      {isOpen && (isLoading || visibleSuggestions.length > 0) && (
        <AutosuggestList
          idBase={baseId}
          listboxId={listboxId}
          suggestions={visibleSuggestions}
          activeIndex={activeIndex}
          query={inputValue}
          title={title}
          onSelect={handleSelect}
          loading={isLoading}
          remoteSuggestions={remoteSuggestions}
          isResultView={isResultView}
        />
      )}
    </div>
  );
}

const initInsightModal = () => {
  const TRIGGER_ATTR = "data-modal-target";
  const INSIGHT_MODAL_CLASS = "ecomm-insight-modal";
  const BODY_LOCK_CLASS = "no-scroll";

  const openModal = (modal: HTMLDialogElement) => {
    modal.showModal();
    modal.scrollTo({ top: 0, behavior: "smooth" });
    document.body.classList.add(BODY_LOCK_CLASS);
  };

  const closeModal = (modal: HTMLDialogElement) => {
    modal.close();
    document.body.classList.remove(BODY_LOCK_CLASS);
  };

  const closeAllModal = () => {
    // get all existing modals and close them.
    const allModalDialogs = document.querySelectorAll(
      `dialog.${INSIGHT_MODAL_CLASS}`,
    );
    allModalDialogs.forEach((dialog) => {
      closeModal(dialog as HTMLDialogElement);
    });
  };

  const bindCloseButtons = (modal: HTMLDialogElement) => {
    const buttons = modal.querySelectorAll(".modal__close button");
    buttons.forEach((btn) => {
      const el = btn as HTMLElement;
      if (el.dataset?.bound === "true") return;
      el.dataset.bound = "true";
      el.addEventListener("click", (e) => {
        e.preventDefault();
        closeModal(modal);
      });
    });

    // backdrop click to close (only bind once)
    if (modal.dataset.backdropBound !== "true") {
      modal.addEventListener("click", (e) => {
        if (e.target === modal) {
          closeModal(modal);
        }
      });
      modal.dataset.backdropBound = "true";
    }
  };

  const bindAllTriggers = () => {
    const triggers = document.querySelectorAll(`[${TRIGGER_ATTR}]`);
    triggers.forEach((t) => {
      const trigger = t as HTMLElement;
      if (trigger.dataset?.bound === "true") return;
      trigger.dataset.bound = "true";

      trigger.addEventListener("click", (e) => {
        e.preventDefault();
        closeAllModal();

        const modalId = trigger.getAttribute(TRIGGER_ATTR)?.trim();
        if (!modalId) return;

        // try exact id first, then fallback to prefixed id used in templates
        let modal = document.getElementById(
          `modal-insight-${modalId}`,
        ) as HTMLDialogElement | null;
        if (!modal) return;

        openModal(modal);
        bindCloseButtons(modal);
      });
    });
  };

  const bindBodyKeyDown = () => {
    document.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      closeAllModal();
    });
  };

  bindAllTriggers();
  bindBodyKeyDown();
};

document.addEventListener("DOMContentLoaded", initInsightModal);

export default initInsightModal;

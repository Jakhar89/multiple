import {
  ModalCardGraphTypeEnum,
  ModalCardMediaAlignmentEnum,
  ModalCardMediaEnum,
  ModalCardProps,
  ModalCardBgVariantEnum,
} from "./interfaces";

export const MockModalCardWithBarGraphData: ModalCardProps = {
  mediaType: ModalCardMediaEnum.GRAPH,
  variant: ModalCardBgVariantEnum.DEFAULT,
  mediaAlignment: ModalCardMediaAlignmentEnum.LEFT,
  graphType: ModalCardGraphTypeEnum.BAR,
  graphData: [
    {
      value: 82.6,
      prefix: "$",
      suffix: "B",
      label: "2025",
    },
    {
      value: 72.5,
      prefix: "$",
      suffix: "B",
      label: "2024",
    },
  ],
  maxValue: 82.6,
  title: "Millennials were Australia’s top shoppers in 2025 ",
  description:
    "Driven by a strong focus on convenience and value, this generation spent $29.7B online, up 13.1% year-on-year. But it was Builders ($3.4B, +16.9%) who recorded greatest spend growth<sup>1</sup>.",
};

export const MockModalCardWithPieGraphData: ModalCardProps = {
  title: "Millennials",
  description: `<p>remained Australia’s top eCommerce enthusiasts in 2025, spending $29B – that’s 38% of their total retail spend. But it was Builders (+18.7%) and Baby Boomers (+16.4%) who recorded greatest spend growth<sup>1</sup>.</p>`,
  mediaType: ModalCardMediaEnum.GRAPH,
  variant: ModalCardBgVariantEnum.DEFAULT,
  mediaAlignment: ModalCardMediaAlignmentEnum.RIGHT,
  graphType: ModalCardGraphTypeEnum.PIE,
  graphData: [
    {
      value: 82,
      prefix: "",
      suffix: "%",
      label: "",
    },
  ],
};

export const MockModalCardWithImageTransparentData: ModalCardProps = {
  title: "What defines today’s online shopper?",
  description:
    "They’re value seekers - 81% shop around for the best deals - and they’re making 5 additional online purchases, compared to last year3.Marketplace apps (69%) almost as common as retailer websites (78%) for buying online<sup>4</sup>.",
  mediaType: ModalCardMediaEnum.IMAGE,
  variant: ModalCardBgVariantEnum.DEFAULT,
  mediaAlignment: ModalCardMediaAlignmentEnum.LEFT,
  image: {
    url: "/src/main/webpack/patterns/assets/images/photo-father-son-sending-parcels.jpeg",
    alt: "What defines today’s online shopper?",
  },
};

export const MockModalCardWithImageGreyData: ModalCardProps = {
  title: "Top 5 shopping categories of 2025",
  description: `1. Online Marketplaces: $17.8B (+17.7% YoY)
2. Food & Liquor: $15.7B (+14.7% YoY)
3. Fashion & Apparel: $11.0B (+10.3% YoY)
4. Home & Garden: $10.6B (+10.0% YoY)
5. Consumer Electronics: $8.9B (+16.0% YoY)2`,
  mediaType: ModalCardMediaEnum.IMAGE,
  variant: ModalCardBgVariantEnum.GREY,
  mediaAlignment: ModalCardMediaAlignmentEnum.RIGHT,
  image: {
    url: "/src/main/webpack/patterns/assets/images/dot-graph.png",
    alt: "Top 5 shopping categories of 2025",
  },
};

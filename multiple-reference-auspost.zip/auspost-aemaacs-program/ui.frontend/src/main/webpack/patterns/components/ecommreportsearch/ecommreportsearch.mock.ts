import { faker } from '@faker-js/faker';
import { SuggestedSearchItemsProps, SuggestedSearchProps, SearchFieldProps } from './store/ERSearchInterface';

export const suggestedSearchItems: SuggestedSearchItemsProps[] = [
    { label: "What are the key eCommerce trends in Australia this year?" },
    { label: "What challenges are Australian online retailers facing right now?" },
    { label: "How is customer delivery behaviour changing in Australia?" },
    { label: "What should retailers focus on to stay competitive in eCommerce?" },
    { label: "Which eCommerce categories are seeing the fastest growth in Australia?" },
];

export const suggestedSearchData: SuggestedSearchProps = {
    title: 'Try asking',
    items: suggestedSearchItems,
};

export const searchFieldData: SearchFieldProps = {
    label: 'Ask AI about eCommerce trends',
    buttonText: 'Search',
    placeholder: 'Search for insights',
    redirectUrl: '/search',
    autocomplete: true,
    autocompleteTitle: 'Search suggestions',
};

export const VERTEX_HOST_URL = "https://digitalapi-ptest.npe.auspost.com.au/website-search";
export const VERTEX_ENGINE_ID = "ecom-report-test_1762830143354";
export const DATASTORE_ID = "default_collection";
export const PROJECT_ID = "1059627761126";
export const BASE_API_PATH = `projects/${PROJECT_ID}/locations/global/collections/${DATASTORE_ID}`;
export const SEARCH_PATH = `engines/${VERTEX_ENGINE_ID}/servingConfigs/default_search`;
export const URLS = {
    autocompleteUrl: `${VERTEX_HOST_URL}/v1/${BASE_API_PATH}/engines/${VERTEX_ENGINE_ID}/completionConfig:completeQuery`,
    keywordSearchUrl: `${VERTEX_HOST_URL}/v1beta/${BASE_API_PATH}/${SEARCH_PATH}:search`,
    answerUrl: `${VERTEX_HOST_URL}/v1beta/${BASE_API_PATH}/${SEARCH_PATH}:answer`,
    pdfUrl: "abc.pdf",
    homeUrl: "../"
};

import { ANIMATION_CLASS_NAME } from "../../ecommreportmodalcard.constants";
import {
  animateNumber,
  getTransition,
  handleViewportIntersectionObserverAnimation,
} from "../../graph.utils";

export const initPieGraph = () => {
  const containers = document.querySelectorAll<HTMLElement>(
    ".ecomm-report-pie-graph",
  );
  const percentagePropertyName = "--percentage-value";
  const duration = 1000;

  const initPieData = (container: HTMLElement) => {
    container.style.setProperty(percentagePropertyName, "0");
  };

  const addAnimation = (
    container: HTMLElement,
    circle: SVGCircleElement,
    textElement: HTMLElement,
    targetValue: number,
    suffix: string,
  ) => {
    container.classList.add(ANIMATION_CLASS_NAME);
    if (circle) circle.style.transition = getTransition(duration);
    // set the final value once so CSS transitions the stroke-dashoffset a single time
    container.style.setProperty(percentagePropertyName, String(targetValue));
    // animate the number separately
    animateNumber(textElement!, 0, targetValue, duration, suffix);
  };

  const removeAnimation = (
    container: HTMLElement,
    textElement: HTMLElement,
    resetValue: string,
  ) => {
    container.classList.remove(ANIMATION_CLASS_NAME);
    if (textElement) textElement.innerHTML = resetValue;
    container.style.setProperty(percentagePropertyName, "0");
  };

  if (!containers) return;
  containers.forEach((container) => {
    const textElement =
      container.querySelector<HTMLElement>(".percentage-text");
    const suffix: string = textElement?.dataset?.graphSuffix || "%";
    const resetValue: string = `00${suffix}`;

    const circle = container.querySelector<SVGCircleElement>(
      ".ecomm-report-pie-graph__progress-circle",
    );
    const targetValue = parseInt(textElement?.dataset?.graphValue ?? "0", 10);

    // Initialize CSS custom properties from data attributes
    initPieData(container);

    handleViewportIntersectionObserverAnimation(
      container,
      () => {
        addAnimation(container, circle!, textElement!, targetValue, suffix);
      },
      () => {
        removeAnimation(container, textElement!, resetValue);
      },
    );
  });
};

document.addEventListener("DOMContentLoaded", initPieGraph);

import { faker } from '@faker-js/faker';
import { PromoCardProps } from './interfaces';

export const PROMO_CARD_MOCK: PromoCardProps = {
  bgGrey: false,
  categoryLabel: 'Stamp Issue',
  categoryBgColor: 'red',
  categoryTextColor: 'white',
  ctas: [{ type: 'primary', label: 'Buy now' }],
  description: faker.lorem.sentences(2),
  enableLightbox: true,
  imageCaption: faker.lorem.sentences(2),
  imageHref: '/src/main/webpack/patterns/assets/images/stamp-portrait.png',
  imageRight: false,
  info: '9 March 2018 | 3 min read | Article',
  price: faker.finance.amount({ min: 5, max: 100, dec: 2, symbol: '$' }),
  roundedImage: false,
  title: faker.lorem.sentences(1),
};

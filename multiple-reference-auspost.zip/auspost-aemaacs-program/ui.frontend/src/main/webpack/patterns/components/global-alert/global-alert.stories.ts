import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './global-alert.liquid';
import { GlobalAlertProps } from './interfaces';
import { message, messageWithLink } from './_global-alert.mock';
import { initGlobalAlertClose } from './global-alert';

const meta = {
  title: 'Components/Global Alert',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  args: {
    message,
    dismissible: true,
    showIcon: true
  }
} satisfies Meta<GlobalAlertProps>;

export default meta;
type Story = StoryObj<GlobalAlertProps>;

export const Information: Story = {
  args: {
    alertType: 'information',
    message: message,
    renderMode: false
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initGlobalAlertClose();
  }
};

export const Warning: Story = {
  args: {
    alertType: 'warning',
    message: message
  },
  play: async () => {
    initGlobalAlertClose();
  }
};

export const Error: Story = {
  args: {
    alertType: 'error',
    message: message
  },
  play: async () => {
    initGlobalAlertClose();
  }
};

export const Success: Story = {
  args: {
    alertType: 'success',
    message: message
  },
  play: async () => {
    initGlobalAlertClose();
  }
};

export const WithoutIcon: Story = {
  args: {
    alertType: 'information',
    message: message,
    showIcon: false
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initGlobalAlertClose();
  }
};

export const NonDismissible: Story = {
  args: {
    alertType: 'warning',
    message: message,
    dismissible: false
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initGlobalAlertClose();
  }
};

export const LongText: Story = {
  args: {
    alertType: 'information',
    message: messageWithLink
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initGlobalAlertClose();
  }
};

/**
 * Footer component interfaces matching Footer.json
 */

export interface FooterProps {
  desktopLogo: {
    externalIconReference: string;
    iconReference: string;
  };
  tabletLogo: {
    externalIconReference: string;
    iconReference: string;
  };
  mobileLogo: {
    externalIconReference: string;
    iconReference: string;
  };
  logoLink: {
    externalizedURL?: string;
    linkURL?: string;
    mappedURL?: string;
    url: string;
  };
  logoAlt?: string;
  primaryLinks: Array<{
    parentLink: {
      externalizedURL?: string;
      label: string;
      linkTarget?: string;
      linkURL?: string;
      mappedURL?: string;
      url: string;
    };
    childLinks: Array<{
      externalizedURL?: string;
      label: string;
      linkTarget?: string;
      linkURL?: string;
      mappedURL?: string;
      url: string;
    }>;
  }>;
  promoTitle: string;
  promoDescription: string;
  promoCards: Array<{
    promoColour: string;
    promoTitle: string;
    promoDescription: string;
    promoLink: {
        externalizedURL?: string;
        label: string;
        linkTarget?: string;
        linkURL?: string;
        mappedURL?: string;
        url: string;
  }
}>,
secondaryLinks: Array<{
    externalizedURL?: string;
    label: string;
    linkTarget?: string;
    linkURL?: string;
    mappedURL?: string;
    url: string;
  }>;
  socialLinks: Array<{
    externalizedURL?: string;
    icon: string;
    linkURL?: string;
    mappedURL?: string;
    url: string;
    label?: string;
  }>;
  footnoteLogo: {
    externalIconReference: string;
    iconReference: string;
  };
  footnoteLogoAlt?: string;
  footnote: string;
  data?: any; // Accept any for data property (stringified JSON)
  footer?: any; // Accept any for footer property (used in liquid template)
  footerData?: string; // Accept string for footerData property (JSON stringified)
}

export interface ToggleConfig {
  toggleButtonSelector: string;
  containerSelector: string;
  childSelector: string;
  hideClass: string;
}
import { useEffect, useMemo, useRef, useState } from 'react';
import { fetchApiGet, ResponseFormat } from '../../../../scripts/utils/api';
import { normalizeSuggestions } from './Autosuggest.utils';
import { useSearchContext } from '../SearchUtils/searchContext';
import config from '../util/search.config';

interface Params {
  autocomplete: boolean;
  minChars: number;
  suggestions?: string[];
  value?: string;
  isResultView?: boolean;
}

export function useAutosuggest({
  autocomplete,
  minChars,
  suggestions = [],
  value = '',
  isResultView = false,
}: Params) {
  const { autocompleteUrl } = useSearchContext();
  const [inputValue, setInputValue] = useState(value);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [isOpen, setIsOpen] = useState(false);
  const [remoteSuggestions, setRemoteSuggestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const isFirstRun = useRef(true);

  const query = inputValue.trim();

  const sourceSuggestions = suggestions.length
    ? suggestions
    : remoteSuggestions;

  const visibleSuggestions = useMemo(() => {
    if (!autocomplete || query.length < minChars) return [];

    return sourceSuggestions
      .filter((item) =>
        item.toLowerCase().includes(query.toLowerCase())
      )
      .slice(0, config.autoCompleteMaxResults);
  }, [autocomplete, query, minChars, sourceSuggestions]);
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!visibleSuggestions.length) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setIsOpen(true);
        setActiveIndex((prev) =>
          prev < 0 ? 0 : (prev + 1) % visibleSuggestions.length
        );
        break;

      case 'ArrowUp':
        e.preventDefault();
        setIsOpen(true);
        setActiveIndex((prev) =>
          prev < 0
            ? visibleSuggestions.length - 1
            : (prev - 1 + visibleSuggestions.length) %
              visibleSuggestions.length
        );
        break;
    }
  };

  /* Remote fetch */
  useEffect(() => {
    if (!autocomplete || suggestions.length || query.length < minChars) {
      setRemoteSuggestions([]);
      setIsLoading(false);
      return;
    }
    
    if (isResultView && isFirstRun.current && inputValue === value && inputValue.length === 0) {
      isFirstRun.current = false;
      setIsLoading(false);
      return;
    }
    
    const apiBase = autocompleteUrl;
    if (!apiBase) {
      setIsLoading(false);
      return;
    }

    let active = true;

    setIsLoading(true);
    const timer = setTimeout(async () => {
      try {
        const sep = apiBase.includes('?') ? '&' : '?';
        const url = `${apiBase}${sep}query=${encodeURIComponent(query)}`;
        const response = await fetchApiGet(url, ResponseFormat.Json);

        if (active) {
          setRemoteSuggestions(normalizeSuggestions(response));
          setIsLoading(false);
        }
      } catch {
        if (active) {
          setRemoteSuggestions([]);
          setIsLoading(false);
        }
      }
    }, 200);

    isFirstRun.current = false;
    return () => {
      active = false;
      clearTimeout(timer);
      setIsLoading(false);
    };
  }, [autocomplete, query, minChars, suggestions.length, autocompleteUrl, isResultView, inputValue, value]);

  return {
    inputValue,
    setInputValue,
    activeIndex,
    setActiveIndex,
    isOpen,
    setIsOpen,
    visibleSuggestions,
    handleKeyDown,
    isLoading,
    remoteSuggestions
  };
}

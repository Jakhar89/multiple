import type { Meta, StoryObj } from '@storybook/html-vite';
import { PRODUCT_BANNER_DATA as BANNER_DATA } from './_product.mock';
import { BannerProps } from '../interfaces';
import component from './product.liquid';

const meta: Meta<BannerProps> = {
  title: 'Components/Banner/Product',
  component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {},
  args: {
    ...BANNER_DATA
  }
};

export default meta;

type Story = StoryObj<BannerProps>;

export const Portrait: Story = {
  args: {
    ...BANNER_DATA
  }
};

export const Landscape: Story = {
  args: {
    ...BANNER_DATA,
    backgroundImage: {
      src: 'src/main/webpack/patterns/assets/images/stamp-landscape.png',
      alt: 'Stamp image'
    }
  }
};

export const Square: Story = {
  args: {
    ...BANNER_DATA,
    backgroundImage: {
      src: 'src/main/webpack/patterns/assets/images/stamp-square.png',
      alt: 'Stamp image'
    }
  }
};

export const Ultrawide: Story = {
  args: {
    ...BANNER_DATA,
    backgroundImage: {
      src: 'src/main/webpack/patterns/assets/images/stamp-ultrawide.png',
      alt: 'Stamp image'
    }
  }
};

export const PastelGreyBackground: Story = {
  args: {
    backgroundColor: 'pastel-grey'
  }
};

export const PastelBlueBackground: Story = {
  args: {
    backgroundColor: 'pastel-blue'
  }
};

export const PastelGreenBackground: Story = {
  args: {
    backgroundColor: 'pastel-green'
  }
};

export const PastelPurpleBackground: Story = {
  args: {
    backgroundColor: 'pastel-purple'
  }
};

export const PastelOrangeBackground: Story = {
  args: {
    backgroundColor: 'pastel-orange'
  }
};

export const PastelCreamBackground: Story = {
  args: {
    backgroundColor: 'pastel-cream'
  }
};

// accordionData.ts
import { Carousel } from './interfaces';
import { PROMO_BANNER_DATA as BANNER_DATA } from '../banner/promo/_promo.mock';

export const CAROUSEL_DATA: Carousel = {
  id: 'carousel-123',
  gradientBackground: false,
  heading: 'Stamp issues',
  cta: true,
  ctaContent: {
    label: 'View all stamps',
    href: '',
    target: ''
  },
  items: [
    {
      id: 'item1',
      banner: {
        ...BANNER_DATA,

      }
    },
    {
      id: 'item2',
      banner: {
        ...BANNER_DATA,
        image: {
          src: "src/main/webpack/patterns/assets/images/stamp-landscape.png",
          alt: "Stamp image"
        }
      }
    },
    {
      id: 'item3',
      banner: {
        ...BANNER_DATA,
        image: {
          src: "src/main/webpack/patterns/assets/images/stamp-square.png",
          alt: "Stamp image"
        }
      }
    }
  ]
};

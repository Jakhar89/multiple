import type { Meta, StoryObj } from "@storybook/html-vite";
import component from "./ecommreportctasection.liquid";
import { MockCTASectionDataDefault, MockCTASectionDataModalVariant } from "./_ecommreportctasection.mock";
import initCTASection from "./ecommreportctasection";
import { CTASectionDataProps } from "./interfaces";

const meta = {
  title: "Components/Ecommerce Report/CTA Section",
  component,
  args: MockCTASectionDataDefault,
  play: async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      initCTASection();
    },
} satisfies Meta<CTASectionDataProps>;

export default meta;
type Story = StoryObj;

export const Default: Story = {};

export const InsideModalVariant: Story = {
  args: MockCTASectionDataModalVariant,
  play: async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      initCTASection();
    },
};

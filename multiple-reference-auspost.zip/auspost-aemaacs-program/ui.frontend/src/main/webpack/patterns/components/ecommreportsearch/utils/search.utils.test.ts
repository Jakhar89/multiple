import {
  normalizeSuggestions,
  getHighlightParts,
  extractInfoForAIApi,
  getConfigForAnswerSearch,
} from "./search.utils";
import { fetchApiPost } from "../../../../scripts/utils/api";

jest.mock("../../../../scripts/utils/api", () => ({ fetchApiPost: jest.fn() }));

describe("normalizeSuggestions", () => {
  test("returns strings when given an array of strings", () => {
    const input = ["one", "two", "three"];
    expect(normalizeSuggestions(input)).toEqual(["one", "two", "three"]);
  });

  test("coerces array items to strings and filters only empty strings", () => {
    const input = [
      "a",
      2 as any,
      null as any,
      undefined as any,
      "",
      true as any,
    ];
    expect(normalizeSuggestions(input)).toEqual([
      "a",
      "2",
      "null",
      "undefined",
      "true",
    ]);
  });

  test("reads from object.suggestions array (strings)", () => {
    const input = { suggestions: ["alpha", "beta"] } as any;
    expect(normalizeSuggestions(input)).toEqual(["alpha", "beta"]);
  });

  test("reads from object.querySuggestions array (objects with suggestion)", () => {
    const input = {
      querySuggestions: [{ suggestion: "mail" }, { suggestion: "map" }],
    } as any;
    expect(normalizeSuggestions(input)).toEqual(["mail", "map"]);
  });

  test("reads from object.items array with various keys", () => {
    const input = {
      items: [
        { text: "textVal" },
        { label: "labelVal" },
        { value: "valueVal" },
        { suggestion: "suggestionVal" },
        { other: "x" },
      ],
    } as any;
    expect(normalizeSuggestions(input)).toEqual([
      "textVal",
      "labelVal",
      "valueVal",
      "suggestionVal",
    ]);
  });

  test("returns empty array for invalid inputs", () => {
    expect(normalizeSuggestions(undefined as any)).toEqual([]);
    expect(normalizeSuggestions(null as any)).toEqual([]);
    expect(normalizeSuggestions({} as any)).toEqual([]);
    expect(normalizeSuggestions({ items: {} } as any)).toEqual([]);
  });
});

describe("getHighlightParts", () => {
  test("returns full text in before when query is empty", () => {
    expect(getHighlightParts("Australia Post", "")).toEqual({
      before: "Australia Post",
      match: "",
      after: "",
    });
  });

  test("returns no match when query not found", () => {
    expect(getHighlightParts("Australia Post", "xyz")).toEqual({
      before: "Australia Post",
      match: "",
      after: "",
    });
  });

  test("matches case-insensitively and splits before/match/after", () => {
    expect(getHighlightParts("Australia Post", "post")).toEqual({
      before: "Australia ",
      match: "Post",
      after: "",
    });
    expect(getHighlightParts("Find a Post Office", "post")).toEqual({
      before: "Find a ",
      match: "Post",
      after: " Office",
    });
  });

  test("matches first occurrence only", () => {
    expect(getHighlightParts("post post", "post")).toEqual({
      before: "",
      match: "post",
      after: " post",
    });
  });

  test("handles query at start and end boundaries", () => {
    expect(getHighlightParts("Postbox", "post")).toEqual({
      before: "",
      match: "Post",
      after: "box",
    });
    expect(getHighlightParts("Letterpost", "post")).toEqual({
      before: "Letter",
      match: "post",
      after: "",
    });
  });
});

describe("extractInfoForAIApi", () => {
  test("returns empty object for non-object input", () => {
    expect(extractInfoForAIApi(null as any)).toEqual({});
    expect(extractInfoForAIApi(undefined as any)).toEqual({});
  });

  test("sets items when answers array provided", () => {
    const res = extractInfoForAIApi({ answers: ["a", "b"] });
    expect(res.items).toEqual(["a", "b"]);
  });

  test("sets items when results array provided", () => {
    const res = extractInfoForAIApi({ results: [1, 2] });
    expect(res.items).toEqual([1, 2]);
  });

  test("sets items when items array provided", () => {
    const res = extractInfoForAIApi({ items: ["x"] });
    expect(res.items).toEqual(["x"]);
  });

  test("does not set items when list is not an array", () => {
    expect(extractInfoForAIApi({ answers: {} } as any)).toEqual({});
  });

  test("extracts sessionId from sessionInfo.name and preserves other sessionInfo properties", () => {
    const data = {
      sessionInfo: {
        name: "projects/p/locations/global/collections/c/engines/e/sessions/SESSION123/",
        queryId: "q1",
      },
    };
    const res = extractInfoForAIApi(data);
    expect(res.sessionInfo).toEqual({
      name: data.sessionInfo.name,
      queryId: "q1",
      sessionId: "SESSION123",
    });
  });

  test("does not set sessionInfo when name missing or no match", () => {
    expect(extractInfoForAIApi({ sessionInfo: {} } as any)).toEqual({
      items: [],
    });
    expect(
      extractInfoForAIApi({ sessionInfo: { name: "no-sessions-here" } } as any),
    ).toEqual({ items: [] });
  });

  test("returns both items and sessionInfo when both present", () => {
    const data = {
      results: ["r"],
      sessionInfo: { name: "/sessions/ID123", foo: "bar" },
    };
    const res = extractInfoForAIApi(data);
    expect(res.items).toEqual(["r"]);
    expect(res.sessionInfo).toEqual({
      name: data.sessionInfo.name,
      foo: "bar",
      sessionId: "ID123",
    });
  });
});

describe("getConfigForAnswerSearch", () => {
  beforeEach(() => {
    (fetchApiPost as jest.Mock).mockClear();
  });

  test("returns undefined and does not call fetchApiPost for blank query", async () => {
    const res = await getConfigForAnswerSearch({
      query: "   ",
      keywordSearchUrl: "https://example.com/",
      sessionId: "S",
    });
    expect(res).toBeUndefined();
    expect(fetchApiPost).not.toHaveBeenCalled();
  });

  test("adds session path when enginePathMatch present and returns extracted info", async () => {
    const keywordSearchUrl =
      "https://host/projects/p/locations/global/collections/c/engines/e/";
    const sessionId = "S123";
    const apiResponse = {
      results: ["r"],
      sessionInfo: { name: "/sessions/ID123", foo: "bar" },
    };
    (fetchApiPost as jest.Mock).mockResolvedValueOnce(apiResponse);

    const res = await getConfigForAnswerSearch({
      query: "my query",
      keywordSearchUrl,
      sessionId,
    });

    expect(fetchApiPost).toHaveBeenCalledWith(
      keywordSearchUrl,
      expect.objectContaining({
        query: "my query",
        session:
          "projects/p/locations/global/collections/c/engines/e/sessions/S123",
      }),
    );

    expect(res).toEqual({
      items: ["r"],
      sessionInfo: {
        name: apiResponse.sessionInfo.name,
        foo: "bar",
        sessionId: "ID123",
      },
    });
  });

  test('uses "-" for empty sessionId when enginePathMatch present', async () => {
    const keywordSearchUrl =
      "https://host/projects/p/locations/global/collections/c/engines/e/";
    const sessionId = "";
    (fetchApiPost as jest.Mock).mockResolvedValueOnce({ results: [] });

    await getConfigForAnswerSearch({ query: "q", keywordSearchUrl, sessionId });

    expect(fetchApiPost).toHaveBeenCalledWith(
      keywordSearchUrl,
      expect.objectContaining({
        query: "q",
        session:
          "projects/p/locations/global/collections/c/engines/e/sessions/-",
      }),
    );
  });

  test("does not set session when enginePathMatch is absent", async () => {
    const keywordSearchUrl = "https://host/search";
    (fetchApiPost as jest.Mock).mockResolvedValueOnce({ results: ["x"] });

    await getConfigForAnswerSearch({
      query: "q2",
      keywordSearchUrl,
      sessionId: "S",
    });

    expect(fetchApiPost).toHaveBeenCalledWith(keywordSearchUrl, {
      contentSearchSpec: { snippetSpec: { returnSnippet: true } },
      languageCode: "en-GB",
      pageSize: 10,
      query: "q2",
      queryExpansionSpec: { condition: "AUTO" },
      safeSearch: true,
      session: "projects/p/locations/global/collections/c/engines/e/sessions/-",
      spellCorrectionSpec: { mode: "AUTO" },
      userInfo: { timeZone: "Australia/Sydney" },
    });
  });
});

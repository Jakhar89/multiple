import React, { InputHTMLAttributes, useRef } from 'react';
import Icon from '../../../foundations/iconset/Icon';

interface TextInputProps extends InputHTMLAttributes<HTMLInputElement> {
    label?: string;
    className?: string;
    clearable?: boolean;
    onClear?: () => void;
}

export default function TextInput({
    label,
    className = '',
    id,
    clearable = true,
    onClear,
    ...props
}: TextInputProps) {
    const inputId = id || `text-input-${Math.random().toString(36).substr(2, 9)}`;
    const inputRef = useRef<HTMLInputElement>(null);

    const showClear =
        !!clearable &&
        !props.disabled &&
        typeof props.value === 'string' &&
        props.value.length > 0;

    const handleClear = () => {
        if (onClear) {
            onClear();
            return;
        }
        if (inputRef.current) {
            inputRef.current.value = '';
        }
        if (props.onChange && inputRef.current) {
            const ev = {
                target: inputRef.current,
                currentTarget: inputRef.current,
            } as React.ChangeEvent<HTMLInputElement>;
            props.onChange(ev);
        }
    };

    const onKeyDown: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
        if (props.onKeyDown) { props.onKeyDown(e); }
    };

    return (
        <div className={`text-input position-relative ${className}`}>

            <div className="text-input-wpr">
                <input
                    ref={inputRef}
                    name="q"
                    id={inputId}
                    type="text"
                    className="text-input-field"
                    aria-label={label}
                    onKeyDown={onKeyDown}
                    {...props}
                />
                {showClear && (
                    <button
                        type="button"
                        className="text-input-clear d-flex align-items-center justify-content-center cursor-pointer"
                        aria-label="Clear text"
                        onClick={handleClear}
                    >
                        <Icon name="cross" className="d-flex" svgClassName="icon--fill-default" />
                    </button>
                )}
            </div>
        </div>
    );
};


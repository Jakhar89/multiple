import type { Meta, StoryObj } from "@storybook/html-vite";
import ecommherobanner from "./ecommherobanner.liquid";

const meta = {
    title: "Components/Ecommerce Report/Hero Banner",
    component: ecommherobanner,
    parameters: {
        layout: "fullscreen",
    },
    args: {
        heading: "Unbox eCommerce insights from now to next",
        description:
            "Explore Australian and international eCommerce insights, emerging trends and what shoppers want - backed by data from millions of deliveries. Plus, dive deeper with AI-powered search.",
        primaryCta: {
            label: "Download the 2026 report • 5.5MB ",
            iconLeft: "download",
        },
    },
    play: async () => {},
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const Default: Story = {};

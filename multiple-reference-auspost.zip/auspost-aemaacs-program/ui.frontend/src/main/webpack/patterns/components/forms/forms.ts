import { pushFormDataToDataLayer, handleFormAnalyticsOnSubmit } from '../../../scripts/analytics/analytics';
import { scrollTo } from '../../../scripts/utils/scroll';
import { addressState } from '../../atoms/form-controls/location-lookup/location-lookup';
import initABNLookup from '../../atoms/form-controls/abn-lookup/abn-lookup';
import { ErrorInfo } from './interfaces';

export default function initForm(): void {
  initABNLookup();

  const form = document.querySelector('.cmp-form') as HTMLFormElement;
  if (!form) {
    return;
  }

  const inputs = form.querySelectorAll(
    `.cmp-form-text__text:not([data-abn-input]),
    .cmp-form-text__textarea,
    .cmp-form-options__field--drop-down,
    .cmp-form-options__field--checkbox,
    .cmp-form-options__field--radio`
  ) as NodeListOf<HTMLInputElement | HTMLTextAreaElement>;
  const errorMessageBlock = form.querySelector('.form-error-message') as HTMLElement;
  const errorList = errorMessageBlock?.querySelector('.form-error-message__list') as HTMLUListElement;

  // Scroll to error block if it's visible or flagged by session (e.g., after API failure)
  const hasApiError = sessionStorage.getItem('apiError');
  const isErrorVisible = errorMessageBlock && errorMessageBlock.style.display !== 'none';

  if (hasApiError || isErrorVisible) {
    scrollAndFocusErrorBlock(errorMessageBlock, errorList);
  }


  const validateField = (input: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement): string | null => {
    const manualParentGroup = input.closest('.manual-address-container') as HTMLElement;
    const addressParentGroup = input.closest('.search-address-container') as HTMLElement;
    if ((manualParentGroup && manualParentGroup.offsetParent === null) || (addressParentGroup && addressParentGroup.offsetParent === null)) {
      return null;
    }
    const isRequired = input.classList.contains('required') || input.required;
    let isEmpty: boolean = false;

    const isCheckbox = input instanceof HTMLInputElement && input.type === 'checkbox';
    const isRadio = input instanceof HTMLInputElement && input.type === 'radio';
    const isAddressInput = input.classList.contains('address-input');
    const isPostcodeOrSuburbInput = input.classList.contains('postcode-suburb-input');
    const isEmailField = input.classList.contains('email-input');

    const errorMessage = getErrorMessage(input);

    if (isCheckbox) {
      const group = input.closest('.cmp-form-options')?.querySelectorAll<HTMLInputElement>('input[type="checkbox"]');
      if (group && group[group.length - 1] === input) {
        const allUnchecked = Array.from(group).every(cb => !cb.checked);
        if (allUnchecked) {
          isEmpty = isRequired && allUnchecked;
        }
      }
      handleCheckboxRadioErrorVisibility(input);
    } else if (isRadio) {
      isEmpty = isRequired && isOptionGroupEmpty(input);
      handleCheckboxRadioErrorVisibility(input);
    } else if (isAddressInput || isPostcodeOrSuburbInput) {
      isEmpty = isRequired && !addressState[input.id];
    } else {
      isEmpty = isRequired && input.value.trim() === '';
    }

    let isInvalidEmail = false;
    if (isEmailField) {
      const emailPatternString = input.getAttribute('data-email-pattern');
      if (input.value.trim() === '' && !isRequired) {
        isInvalidEmail = false;
      } else if (emailPatternString) {
        const emailPattern = new RegExp(emailPatternString);
        isInvalidEmail = !emailPattern.test(input.value);
      } else {
        isInvalidEmail = true;
      }
    }
    const hasError = (isRequired && isEmpty) || isInvalidEmail;
    if (isCheckbox && isEmpty) {
      const group = input.closest('.cmp-form-options')?.querySelectorAll<HTMLInputElement>('input[type="checkbox"]');
      group?.forEach(optionItem => {
        optionItem.classList.add('is-empty');
      });
    } else {
      input.classList.toggle('is-empty', hasError);
    }

    if (errorMessage) {
      const errorId = `${input.id}-error`;
      errorMessage.id = errorId;
      errorMessage.setAttribute('role', 'alert');
      errorMessage.setAttribute('aria-live', 'assertive');
      errorMessage.setAttribute('aria-hidden', hasError ? 'false' : 'true');
      errorMessage.style.display = hasError ? 'flex' : 'none';
      if (hasError) {
        if (!isRadio && !isCheckbox) {
          input.setAttribute('aria-invalid', 'true');
        }
        input.setAttribute('aria-describedby', errorId);
      } else {
        input.removeAttribute('aria-invalid');
        // input.removeAttribute('aria-describedby');

        // Restore help text reference if it exists
        const helpRef = document.getElementById(`${input.id}-helpMessage`)
          ? `${input.id}-helpMessage`
          : null;

        if (helpRef) {
          input.setAttribute('aria-describedby', helpRef);
        } else {
          input.removeAttribute('aria-describedby');
        }
      }
    }

    if (isRequired && isEmpty) {
      return errorMessage?.textContent?.trim() ?? 'This field is required';
    }

    if (isInvalidEmail) {
      return errorMessage?.textContent?.trim() ?? 'Please enter a valid email address';
    }

    return null;
  };

  function isOptionGroupEmpty(input: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement) {
    const optionList = Array.from(input.closest('.cmp-form-options')?.querySelectorAll<HTMLInputElement>(`input[type=${input.type}]`) ??
      [input]) as HTMLInputElement[];
    return !optionList.some(item => item.checked);
  }

  function getErrorMessage(input: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement) {
    let group;
    if (input.type === 'checkbox' || input.type === 'radio' || input.tagName.toLowerCase() === 'select') {
      group = input.closest('.cmp-form-options');
    } else {
      group = input.closest('.cmp-form-text');
    }
    return group?.querySelector('.error-message') as HTMLElement ?? null;
  };

  function handleCheckboxRadioErrorVisibility(input: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement) {
    const optionGroup = input.closest('.cmp-form-options');
    const optionList = Array.from(input.closest('.cmp-form-options')?.querySelectorAll<HTMLInputElement>(`input[type=${input.type}]`) ??
      [input]) as HTMLInputElement[];
    optionList?.forEach(optionItem => {
      const handleOptionSelection = () => {
        if (optionItem.checked) {
          optionList.forEach(radioClass => radioClass.classList.remove('is-empty'));
          const errorMessageRadio = optionGroup?.querySelector('.error-message') as HTMLElement;
          errorMessageRadio.style.display = 'none';
        }
      };
      optionItem.addEventListener('change', handleOptionSelection);
      optionItem.addEventListener('click', handleOptionSelection);
    });
  }

  inputs.forEach((input) => {
    input.addEventListener('blur', () => {
      validateField(input);
    });
  });

  // Analytics - when user interacting first time with the form
  handleFormFirstInteractionAnalytics(form, inputs);

  // Analytics - On refresh of page check if form is submitted once
  handleFormAnalyticsOnSubmit();

    const handleSubmit = async (e: Event) => {
    e.preventDefault();

    const errors: string[] = [];
    const errorsMapping: ErrorInfo[] = [];

    // Clear previous errors
    if (errorList) {
      errorList.innerHTML = '';
    }

    // Hide error block initially
    if (errorMessageBlock) {
      errorMessageBlock.style.display = 'none';
    }

    inputs.forEach((input) => {
      const errorText = validateField(input);
      if (errorText) {
        let label: HTMLElement | null | undefined;
        if (input.type === 'checkbox') {
          const checkboxGroup = input.closest('.cmp-form-options');
          if (checkboxGroup) {
            const checkboxGroupTitle = checkboxGroup.querySelector('.cmp-form-options__title') as HTMLElement | null;
            if (!checkboxGroupTitle) {
              label = checkboxGroup?.querySelector('.error-message') as HTMLElement | null;
            } else {
              label = checkboxGroupTitle;
            }
          }
        } else if (input.type === 'radio') {
          const radioGroup = input.closest('.cmp-form-options');
          if (radioGroup) {
            const radioGroupTitle = radioGroup.querySelector('.cmp-form-options__title') as HTMLElement | null;
            const allRadios = Array.from(radioGroup.querySelectorAll<HTMLInputElement>('input[type="radio"]'));
            const firstRadio = allRadios[0];
            if (!radioGroupTitle && allRadios.length === 1) {
              label = radioGroup?.querySelector('.error-message') as HTMLElement | null;
            } else {
              if (input !== firstRadio) {return;}
              label = radioGroupTitle;
            }
          }
        } else {
          label = form.querySelector(`label[for='${input.id}']`) as HTMLElement | null;
        }
        const labelText = label?.textContent?.trim() ?? 'This field is required';
        errors.push(labelText);
        errorsMapping.push({ fieldId: input.id, message: labelText, fieldElement: input });
      }
    });

    const abnComponents = form.querySelectorAll<HTMLElement>('.cmp-form-abn-lookup');

    for (const component of Array.from(abnComponents)) {
      if ('validateABN' in component) {
        const validate = (component as HTMLElement & { validateABN: () => Promise<boolean> }).validateABN;
        const isValid = await validate();
        if (!isValid) {
          const abnInput = component.querySelector<HTMLInputElement>('.abn-lookup-search__text');
          const abnLabel = component.querySelector('label .title')?.textContent?.trim() ?? 'Australian Business Number (ABN)';
          errors.push(abnLabel);
          errorsMapping.push({
            fieldId: abnInput?.id ?? 'abn-input',
            message: abnLabel,
            fieldElement: abnInput ?? component as unknown as HTMLInputElement
          });
        }
      }
    }

    if (errors.length > 0 && errorMessageBlock && errorMessageBlock?.querySelector('.form-error-message__list') as HTMLUListElement) {
      const fragment = document.createDocumentFragment();
      errorsMapping.forEach((errorItem) => {
        const li = document.createElement('li');
        li.className = 'form-error-message__item';
        li.dataset.errorFor = errorItem.fieldId;
        li.id = `error-summary-${errorItem.fieldId}`;
        const link = document.createElement('a');
        link.href = `#${errorItem.fieldId}`;
        let errorLabel = errorItem.message;
        if (errorItem.fieldElement?.closest('.form-group')) {
          const legend = errorItem.fieldElement.closest('.form-group')?.querySelector('legend');
          const legendText = legend?.textContent?.trim() ?? '';
          errorLabel = legendText + ': ' + errorLabel;
        }
        link.textContent = errorLabel;
        li.appendChild(link);
        fragment.appendChild(li);
      });

      errorList.innerHTML = '';
      errorList.appendChild(fragment);
      errorMessageBlock.style.display = 'flex';
      // Scroll and focus after rendering errors
      scrollAndFocusErrorBlock(errorMessageBlock, errorList);

      // Analytics- when there is validation error message
      pushFormDataToDataLayer('submit-error', 'single-page', errors);
    } else {
      //Remove select attribute from payload when value is default/empty
      const emptySelectAttribute = form.querySelector('select');
      if (!emptySelectAttribute?.value) {
        emptySelectAttribute?.removeAttribute('name');
      }

      // Submit if no errors
      sessionStorage.setItem('formSubmitted', 'inProgress');
      form.submit();
    }
  };

  form.addEventListener('submit', handleSubmit);
}

// When user interact first time with form
let isInputFieldTracked = false;

function handleFormFirstInteractionAnalytics(form: HTMLFormElement, inputs: NodeListOf<HTMLInputElement | HTMLTextAreaElement>): void {
  inputs.forEach(input => {
    input.addEventListener('focus', function () {
      storeFirstInteractionDataToSession(form);
    });
  });

  const abnComponents = form.querySelectorAll<HTMLElement>('.cmp-form-abn-lookup');
  abnComponents.forEach((component) => {
    const abnInput = component.querySelector<HTMLInputElement>('.abn-lookup-search__text');
    abnInput?.addEventListener('focus', function () {
      storeFirstInteractionDataToSession(form);
    });
  });

}

function storeFirstInteractionDataToSession(form: HTMLFormElement) {

  const isFormDataStored = sessionStorage.getItem('formInteractionDataStored');

  if (isFormDataStored) {
    isInputFieldTracked = true;
  }

  if (isInputFieldTracked) {
    return;
  }
  isInputFieldTracked = true;

  const formData = new FormData(form);
  const referenceId = formData.get('campaignId') as string;

  sessionStorage.setItem('formInteractionDataStored', JSON.stringify({
    formId: form.id,
    name: form.name,
    referenceId: referenceId
  }));
  pushFormDataToDataLayer('start', 'single-page', []);
}

function scrollAndFocusErrorBlock(errorMessageBlock: HTMLElement, errorList: HTMLUListElement): void {
  setTimeout(() => {
    scrollTo(errorMessageBlock.offsetTop);

    // Temporarily make error block focusable
    errorMessageBlock.setAttribute('tabindex', '0');
    errorMessageBlock.focus();

    // Remove tabindex after focus to clean up
    setTimeout(() => {
      errorMessageBlock.removeAttribute('tabindex');
    }, 100);

    const firstErrorLink = errorList?.querySelector('a[href]') as HTMLAnchorElement;
    if (!firstErrorLink) {
      const form = document.querySelector('.cmp-form') as HTMLFormElement;
      if (!form) {return;}

      const focusableSelector = [
        'input:not([type="hidden"]):not([disabled])',
        'textarea:not([disabled])',
        'select:not([disabled])',
        'button:not([disabled])',
        '[tabindex]:not([tabindex="-1"])'
      ].join(', ');

      const firstFocusable = form.querySelector(focusableSelector) as HTMLElement;

      if (firstFocusable && firstFocusable.offsetParent !== null) {
        firstFocusable.scrollIntoView({ behavior: 'smooth', block: 'center' });
        firstFocusable.focus();
      }
    }
    sessionStorage.removeItem('apiError');
  }, 0);
}


const forms = document.querySelectorAll<HTMLFormElement>("form");

forms.forEach((form) => {

    form.addEventListener("submit", () => {

        const containers = form.querySelectorAll<HTMLElement>(
            ".address-lookup-container, .postcode-suburb-lookup-container"
        );

        const addressList: string[] = [];

        containers.forEach((container) => {

            let fullAddress = "";

            const manualContainer = container.querySelector<HTMLElement>(".manual-address-container");
            const searchContainer = container.querySelector<HTMLElement>(".search-address-container");

            if (manualContainer && !manualContainer.classList.contains("hidden")) {

                const address1 = manualContainer.querySelector<HTMLInputElement>('input[name="address-1"]');
                const address2 = manualContainer.querySelector<HTMLInputElement>('input[name="address-2"]');
                const address3 = manualContainer.querySelector<HTMLInputElement>('input[name="address-3"]');

                const suburb = manualContainer.querySelector<HTMLInputElement>('input[name="City"]');
                const state = manualContainer.querySelector<HTMLSelectElement>('select[name="State"]');
                const postcode = manualContainer.querySelector<HTMLInputElement>('input[name="PostalCode"]');

                const address1Val = address1?.value.trim();
                const address2Val = address2?.value.trim();
                const address3Val = address3?.value.trim();

                const suburbVal = suburb?.value.trim();
                const stateVal = state?.value.trim();
                const postcodeVal = postcode?.value.trim();

                if (address1Val || address2Val || address3Val || suburbVal || stateVal || postcodeVal) {

                    const addressVal = [address1Val, address2Val, address3Val]
                        .filter((val): val is string => Boolean(val))
                        .join(", ");

                    const suburbStatePostcode = [suburbVal, stateVal, postcodeVal]
                        .filter((val): val is string => Boolean(val))
                        .join(" ");

                    fullAddress = [addressVal, suburbStatePostcode]
                        .filter((val): val is string => Boolean(val))
                        .join(", ");

                    address1?.removeAttribute("name");
                    address2?.removeAttribute("name");
                    address3?.removeAttribute("name");
                    suburb?.removeAttribute("name");
                    state?.removeAttribute("name");
                    postcode?.removeAttribute("name");
                }
            }
            else if (searchContainer) {

                const searchInput =
                    searchContainer.querySelector<HTMLInputElement>(".address-input") ||
                    searchContainer.querySelector<HTMLInputElement>(".postcode-suburb-input");

                fullAddress = searchInput?.value.trim() || "";
            }

            if (fullAddress) {
                addressList.push(fullAddress);
            }
        });

        const combinedAddress = addressList.join(" || ");

        const existingHidden = form.querySelector<HTMLInputElement>('input[name="Street"]');
        existingHidden?.remove();

        if (combinedAddress) {
            const hiddenInput = document.createElement("input");
            hiddenInput.type = "hidden";
            hiddenInput.name = "Street";
            hiddenInput.value = combinedAddress;
            form.appendChild(hiddenInput);
        }
    });

});

document.addEventListener('DOMContentLoaded', initForm);

import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './marketing-block.liquid';
import type { MarketingBlockProps } from './interfaces';
import { MARKETING_BLOCK_DATA } from './_marketing-block.mock';


const meta = {
  title: 'Components/Marketing Block',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {
    description: { control: 'text' },
    backgroundColor: {
      control: { type: 'select' },
      options: ['bg-white', 'bg-grey', 'bg-red', 'bg-blue']
    },
    fullWidth: {
      control: { type: 'select' },
      options: ['default', 'full-width']
    },
    imagePosition: {
      control: { type: 'select' },
      options: ['image-left', 'image-right']
    },
    imageType: {
      control: { type: 'select' },
      options: ['default', 'swoosh-image']
    }
  },
  args: {
    ...MARKETING_BLOCK_DATA
  }
} satisfies Meta<MarketingBlockProps>;

export default meta;
type Story = StoryObj<MarketingBlockProps>;

export const Default: Story = {
  args: {
  }
};

export const BrandPromoFullWidth: Story = {
  args: {
    backgroundColor: 'bg-red',
    imagePosition: 'image-left',
    fullWidth: 'full-width',
    image: {
      src: "/src/main/webpack/patterns/assets/images/marketing-block-img2.png",
      alt: MARKETING_BLOCK_DATA.image.alt, 
    }
  }
};

export const BrandPromoFullWidthImageRight: Story = {
  args: {
    backgroundColor: 'bg-red',
    imagePosition: 'image-right',
    fullWidth: 'full-width',
    image: {
      src: "/src/main/webpack/patterns/assets/images/marketing-block-img2.png",
      alt: MARKETING_BLOCK_DATA.image.alt, 
    }
  }
};


export const BrandPromoDefault: Story = {
  args: {
    backgroundColor: 'bg-red',
    image: {
      src: "/src/main/webpack/patterns/assets/images/marketing-block-img2.png",
      alt: MARKETING_BLOCK_DATA.image.alt, 
    }
  }
};

export const BrandPromoDefaultImageRight: Story = {
  args: {
    backgroundColor: 'bg-red',
    imagePosition: 'image-right',
    image: {
      src: "/src/main/webpack/patterns/assets/images/marketing-block-img2.png",
      alt: MARKETING_BLOCK_DATA.image.alt, 
    }
  }
};

export const BrandPromoFullWidthWithQR: Story = {
  args: {
    backgroundColor: 'bg-red',
    fullWidth: 'full-width',
    qrBlock:true,
    image: {
      src: "/src/main/webpack/patterns/assets/images/marketing-block-img2.png",
      alt: MARKETING_BLOCK_DATA.image.alt, 
    }
  }
};

export const PartnershipFullWidth: Story = {
  args: {
    imageType: 'swoosh-image',
    fullWidth: 'full-width',
    logo: true,
    imagePosition: 'image-left'

  }
};

export const PartnershipFullWidthImageRight: Story = {
  args: {
    imageType: 'swoosh-image',
    fullWidth: 'full-width',
    imagePosition: 'image-right',
    logo:true
  }
};

export const PartnershipDefault: Story = {
  args: {
    imageType: 'swoosh-image',
    logo:true
  }
};

export const PartnershipDefaultImageRight: Story = {
  args: {
    imageType: 'swoosh-image',
    logo:true,
    imagePosition: 'image-right'

  }
};

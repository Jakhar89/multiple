/**
 * Breadcrumb component interfaces
 */

export interface BreadcrumbItem {
  title: string;
  href: string;
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[];
}
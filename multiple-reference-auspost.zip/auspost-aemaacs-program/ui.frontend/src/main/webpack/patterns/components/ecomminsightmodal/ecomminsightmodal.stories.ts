import type { Meta, StoryObj } from "@storybook/html-vite";
import component from "./ecomminsightmodal.liquid";
import { MockEcommInsightModalData } from "./_ecomminsightmodal.mock";
import initInsightModal from "./ecomminsightmodal";

const meta = {
  title: "Components/Ecommerce Report/Insight Modal",
  component,
  parameters: {
    layout: "fullscreen",
  },
  args: MockEcommInsightModalData,
  play: async () => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    initInsightModal();
  },
} satisfies Meta;

export default meta;

type Story = StoryObj;

export const Default: Story = {};

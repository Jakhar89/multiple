import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { SearchProvider } from './SearchUtils/searchContext';
import SearchApp from './SearchApp';
import { readSearchDataset } from './SearchUtils/readDataset';

const rootMap: WeakMap<HTMLElement, Root> = new WeakMap();

export default function initSearch(): void {
    const nodes = Array.from(document.querySelectorAll('.search-app')) as HTMLElement[];
    if (nodes.length === 0) return;

    nodes.forEach((node) => {
        if (rootMap.has(node) || node.dataset.searchInitialized === 'true') return;

        const { popularSearch, searchField, autocompleteUrl, searchApiUrl, resultPageSize } = readSearchDataset(node);

        const root = createRoot(node);
        rootMap.set(node, root);

        root.render(
            React.createElement(
            SearchProvider,
            {
                value: { popularSearch, searchField, autocompleteUrl, searchApiUrl, resultPageSize }
            },
            React.createElement(SearchApp, {
                isResultsView: (node.getAttribute('data-variant') || '').toLowerCase() === 'results'
            })
            )
        );

        node.dataset.searchInitialized = 'true';
    });
}


if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSearch);
} else {
    initSearch();
}

export interface NavLink {
  label: string;
  url: string;
  icon?: string;
}

export interface Submenu {
  heading: string;
  submenuChildren: NavLink[];
}

export interface FeatureCard {
  style: 'red' | 'grey';
  image: string;
  heading: string;
  description: string;
  links: NavLink[];
}

export interface MegaMenu {
  id: string;
  submenu: Submenu[];
  customSubmenu?: Submenu[];
  featureCard?: FeatureCard;
}

export interface MainMenuNavItem {
  label: string;
  toggleId: string;
  megaMenu: MegaMenu;
}

export interface TopNav {
  utilityLinks: NavLink[];
  search: {
    icon: string;
    placeholder: string;
  };
  login: {
    label: string;
    dropdownItems?: NavLink[];
  };
}

export interface HeaderContent {
  mainNav: MainMenuNavItem[];
  topNav: TopNav;
}

export interface HeaderProps {
  header: HeaderContent;
  minimalHeader?: boolean;
  hideSearch?: boolean;
  showGlobalAlert?: boolean;
}

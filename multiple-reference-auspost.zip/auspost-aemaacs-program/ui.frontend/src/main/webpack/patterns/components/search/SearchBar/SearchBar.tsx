import React from 'react';
import AutoSuggest from '../AutoSuggest/AutoSuggest';
import { SearchFieldProps } from '../SearchUtils/interface';
import Icon from '../../../foundations/iconset/Icon';

type Props = {
  id: string;
  query: string;
  onQueryChange: (_value: string) => void;
  searchField: SearchFieldProps;
  isResultView?: boolean;
};

export default function SearchBar({ id, query, onQueryChange, searchField, isResultView = false }: Props) {
  return (
    <div className='d-flex search-bar w-100'>
      <div className="search-field">
        <AutoSuggest
          id={id}
          placeholder={searchField.placeholder || ''}
          value={query}
          onChange={(e) => onQueryChange(e.currentTarget.value)}
          aria-label="Search input"
          title={searchField.autocomplete ? searchField.autocompleteTitle : "SUGGESTED SEARCHES"}
          autocomplete={searchField.autocomplete}
          isResultView={isResultView}
          onSelect={(value: string) => {
            onQueryChange(value);

            try {
              const inputEl = document.getElementById(id) as HTMLInputElement | null;
              if (inputEl) inputEl.value = value;

              const form = inputEl?.closest('form') as HTMLFormElement | null;
              if (form) {
                if (typeof (form as any).requestSubmit === 'function') {
                  (form as any).requestSubmit();
                } else {
                  form.submit();
                }
              }
            } catch {
              // ignore
            }
          }}
        />
      </div>
      <div className="search-action button">
        <button type="submit" className="cmp-button search-btn">
          <span className='hide-md' aria-hidden="true">
            <Icon name="search" size="sm" className="d-flex search-icon" svgClassName="icon--fill-white" />
          </span>
          <span className='hide show-md'>{searchField.buttonText}</span>
        </button>
      </div>
    </div>
  );
}

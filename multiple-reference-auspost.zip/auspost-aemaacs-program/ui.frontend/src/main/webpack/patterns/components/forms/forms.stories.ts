import type { Meta, StoryObj } from '@storybook/html-vite';
import { waitForUIToRenderInDOM } from '../../../scripts/utils/_story-utils';
import { abnLookupFieldMock, abnLookupFieldWithErrorMock } from '../../atoms/form-controls/abn-lookup/_abn-lookup.mock';
import { searchAddressField, manualAddressField, searchAddressFieldValidation }
  from '../../atoms/form-controls/location-lookup/address/_address.mock';
import { postcodeOrSuburbField, manualPostcodeOrSuburbField }
  from '../../atoms/form-controls/location-lookup/postcode-suburb-lookup/_postcode-suburb-lookup.mock';
import initAddress from '../../atoms/form-controls/location-lookup/address/address';
import initPostcodeOrSuburb from '../../atoms/form-controls/location-lookup/postcode-suburb-lookup/postcode-suburb-lookup';
import component from './forms.liquid';
import initForm from './forms';
import {
  formFields, formFieldsWithErrors, formCheckboxField, formRadioButton,
  formWithMultipleOption, formDropdown, allFormFieldsWithErrors, formFieldsGrouped
} from './_forms.mock';


const meta: Meta = {
  title: 'Components/Forms',
  component,
  argTypes: {
    message: { control: 'text' },
    errors: { control: 'object' },
    fields: { control: 'object' }
  },
  args: {
    fields: formFields,
    checkboxFields: formCheckboxField,
    radioFields: formRadioButton,
    dropdownFields: formDropdown,
    abnField: abnLookupFieldMock,
    addressLookup: {
      searchAddressField: searchAddressField,
      searchForAddressButton: 'Search for Address',
      manualAddressField: manualAddressField,
      addressSection: 'search'
    },
    postcodeOrSuburbLookup: {
      postcodeOrSuburbField: postcodeOrSuburbField,
      manualPostcodeOrSuburbField: manualPostcodeOrSuburbField,
      searchForAddressButton: 'Use suburb lookup instead',
      postcodeOrSuburbSection: 'search-postcode-or-suburb',
      addressSection: 'search'
    }
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    initForm();
  }
};

export default meta;

type Story = StoryObj;

export const Default: Story = {
  play: async () => {
    waitForUIToRenderInDOM('.address-lookup-container', initAddress);
    waitForUIToRenderInDOM('.postcode-suburb-lookup-container', initPostcodeOrSuburb);
  }
};

export const ValidationError: Story = {
  args: {
    errorMessage: 'Please fix the following issues before submitting',
    errorsMapping: allFormFieldsWithErrors.map(x => { return { fieldId: x.id, message: x.error } }),
    fields: formFieldsWithErrors,
    checkboxFields: {
      ...formWithMultipleOption,
      required: true
    },
    radioFields: {
      ...formRadioButton,
      required: true
    },
    dropdownFields: {
      ...formDropdown,
      required: true
    },
    abnField: abnLookupFieldWithErrorMock,
    addressLookup: {
      searchAddressField: searchAddressFieldValidation
    },
    postcodeOrSuburbLookup: {
      postcodeOrSuburbField: {
        ...postcodeOrSuburbField,
        error: 'Please select suburb or postcode'
      }
    }
  }
};

export const FormWithMultipleOptions: Story = {
  args: {
    checkboxFields: formWithMultipleOption
  }
};

export const GroupedFields: Story = {
  args: {
    fields: formFieldsGrouped,
    dropdownFields: formDropdown,
    checkboxFields: formCheckboxField
  }
};

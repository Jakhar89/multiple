import React from 'react';
import { getHighlightParts } from '../utils/search.utils';
import ERIcon from '../Icons/ERIcon';
import ERLoader from '../ERLoader/ERLoader';
import { AutosuggestListProps } from '../store/ERSearchInterface';

export default function ERAutosuggestList({
  idBase,
  listboxId,
  suggestions,
  activeIndex,
  query,
  title,
  onSelect,
  loading = false,
}: AutosuggestListProps) {
  return (
    <div className="search-suggestions">
      {title && (
        <strong className="heading m-b-400 d-flex">
          {title}
        </strong>
      )}
      {loading
        ? <ERLoader />
        : <ul
            id={listboxId}
            role="listbox"
            aria-busy={loading}
            className="search-list list-style-none"
        >
          {
            suggestions.map((item, index) => {
              const { before, match, after } = getHighlightParts(item, query);

              return (
                <li
                  key={item}
                  id={`${idBase}-option-${index}`}
                  role="option"
                  aria-selected={index === activeIndex}
                  className={`autosuggest-item${index === activeIndex ? ' is-active' : ''
                    }`}
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => onSelect(item)}
                >
                  <span className="search-label d-inline-flex suggestion-label">
                    <span className="search-icon m-t-100 m-r-150" aria-hidden="true">
                      <ERIcon name="search"/>
                    </span>
                    <span>{before}</span>
                    {match && <strong>{match}</strong>}
                    <span>{after}</span>
                  </span>
                </li>
              );
            })}
        </ul>
      }
    </div>
  );
}

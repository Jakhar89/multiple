import { FooterProps } from './interfaces';
import { faker } from '@faker-js/faker';

export const FOOTER_DATA: FooterProps = {
  desktopLogo: {
    externalIconReference: "/src/main/webpack/resources/images/footer-logo-desktop.svg",
    iconReference: "/src/main/webpack/patterns/assets/images/footer-logo-desktop.svg",
  },
  tabletLogo: {
    externalIconReference: "/src/main/webpack/resources/images/logo-tablet.png",
    iconReference: "/src/main/webpack/patterns/assets/images/logo-tablet.png",
  },
  mobileLogo: {
    externalIconReference: "/src/main/webpack/resources/images/logo-mobile.png",
    iconReference: "/src/main/webpack/patterns/assets/images/logo-mobile.png",
  },
  logoLink: {
    externalizedURL: faker.internet.url(),
    linkURL: faker.internet.url(),
    mappedURL: faker.internet.url(),
    url: faker.internet.url(),
  },
  logoAlt: faker.company.name(),
  primaryLinks: [
    {
      parentLink: {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.department(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      childLinks: [
        {
          externalizedURL: faker.internet.url(),
          label: faker.commerce.product(),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          label: faker.commerce.product(),
          linkTarget: '_blank',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
      ],
    },
  ],
  promoTitle: faker.lorem.words(2),
  promoDescription: faker.lorem.sentence(),
  promoCards: [
    {
      promoColour: "white",
      promoTitle: faker.lorem.words(3),
      promoDescription: faker.lorem.sentence(),
      promoLink: {
        externalizedURL: faker.internet.url(),
        label: faker.lorem.words(2),
        linkTarget: "_self",
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url()
      }
    }
  ],
  secondaryLinks: [
    {
      externalizedURL: faker.internet.url(),
      label: faker.lorem.words(2),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    {
      externalizedURL: faker.internet.url(),
      label: faker.lorem.words(2),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    {
      externalizedURL: faker.internet.url(),
      label: faker.lorem.words(2),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    {
      externalizedURL: faker.internet.url(),
      label: faker.lorem.words(2),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
  ],
  socialLinks: [
    {
      externalizedURL: faker.internet.url(),
      icon: 'facebook',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'Facebook'
    },
    {
      externalizedURL: faker.internet.url(),
      icon: 'instagram',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'Instagram'
    },
    {
      externalizedURL: faker.internet.url(),
      icon: 'twitter',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'twitter'
    },
    {
      externalizedURL: faker.internet.url(),
      icon: 'linkedin',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'linkedin'
    },
  ],
  footnoteLogo: {
    externalIconReference: "http://localhost:4503/content/dam/collectables/ap-acknowledgement-logos.svg",
    iconReference: "/src/main/webpack/patterns/assets/images/acknowledgement.png",
  },
  footnoteLogoAlt: faker.company.name(),
  footnote: `<p>${faker.lorem.paragraph()}</p>`,
  data: JSON.stringify({
    "footer-cd24421be3": {
      "@type": "auspost-aemaacs-program/components/footer",
      desktopLogo: {
        externalIconReference: faker.image.url(),
        iconReference: faker.image.url(),
      },
      tabletLogo: {
        externalIconReference: faker.image.url(),
        iconReference: faker.image.url(),
      },
      mobileLogo: {
        externalIconReference: faker.image.url(),
        iconReference: faker.image.url(),
      },
      logoLink: {
        externalizedURL: faker.internet.url(),
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      logoAlt: faker.company.name(),
      primaryLinks: [
        {
          parentLink: {
            externalizedURL: faker.internet.url(),
            label: faker.commerce.department(),
            linkTarget: '_self',
            linkURL: faker.internet.url(),
            mappedURL: faker.internet.url(),
            url: faker.internet.url(),
          },
          childLinks: [
            {
              externalizedURL: faker.internet.url(),
              label: faker.commerce.product(),
              linkTarget: '_self',
              linkURL: faker.internet.url(),
              mappedURL: faker.internet.url(),
              url: faker.internet.url(),
            },
            {
              externalizedURL: faker.internet.url(),
              label: faker.commerce.product(),
              linkTarget: '_blank',
              linkURL: faker.internet.url(),
              mappedURL: faker.internet.url(),
              url: faker.internet.url(),
            },
          ],
        },
      ],
      promoTitle: faker.lorem.words(2),
      promoDescription: faker.lorem.sentence(),
      promoLink: {
        externalizedURL: faker.internet.url(),
        label: faker.lorem.words(2),
        linkTarget: '_blank',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      secondaryLinks: [
        {
          externalizedURL: faker.internet.url(),
          label: faker.lorem.words(2),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          label: faker.lorem.words(2),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          label: faker.lorem.words(2),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          label: faker.lorem.words(2),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
      ],
      socialLinks: [
        {
          externalizedURL: faker.internet.url(),
          icon: 'facebook',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          icon: 'instagram',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          icon: 'twitter',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          icon: 'linkedin',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
      ],
      footnoteLogo: {
        externalIconReference: "http://localhost:4503/content/dam/collectables/ap-acknowledgement-logos.svg",
        iconReference: "/src/main/webpack/resources/images/acknowledgement.png",
      },
      footnote: `<p>${faker.lorem.paragraph()}</p>\r\n`,
    },
  }),
};


export const FOOTER_DATA_WITH_MULTIPLE_PRIMARY_LINKS: FooterProps["primaryLinks"] = [
  {
    parentLink: {
      externalizedURL: faker.internet.url(),
      label: faker.commerce.department(),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    childLinks: [
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      }
    ],
  },{
    parentLink: {
      externalizedURL: faker.internet.url(),
      label: faker.commerce.department(),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    childLinks: [
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      }
    ],
  },{
    parentLink: {
      externalizedURL: faker.internet.url(),
      label: faker.commerce.department(),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    childLinks: [
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      }
    ],
  },{
    parentLink: {
      externalizedURL: faker.internet.url(),
      label: faker.commerce.department(),
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    childLinks: [
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.product(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      }
    ],
  },
];

export const FOOTER_DATA_COLLECTABLE: Pick<FooterProps, "primaryLinks" | "promoCards"> = {
  primaryLinks: [
    {
      parentLink: {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.department(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      childLinks: [
        {
          externalizedURL: faker.internet.url(),
          label: faker.commerce.product(),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          label: faker.commerce.product(),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        }
      ],
    },{
      parentLink: {
        externalizedURL: faker.internet.url(),
        label: faker.commerce.department(),
        linkTarget: '_self',
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url(),
      },
      childLinks: [
        {
          externalizedURL: faker.internet.url(),
          label: faker.commerce.product(),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        },
        {
          externalizedURL: faker.internet.url(),
          label: faker.commerce.product(),
          linkTarget: '_self',
          linkURL: faker.internet.url(),
          mappedURL: faker.internet.url(),
          url: faker.internet.url(),
        }
      ],
    },
  ],
  promoCards: [
    {
      promoColour: "white",
      promoTitle: faker.lorem.words(3),
      promoDescription: faker.lorem.sentence(),
      promoLink: {
        externalizedURL: faker.internet.url(),
        label: faker.lorem.words(2),
        linkTarget: "_self",
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url()
      }
    },
    {
      promoColour: "grey",
      promoTitle: faker.lorem.words(3),
      promoDescription: faker.lorem.sentence(),
      promoLink: {
        externalizedURL: faker.internet.url(),
        label: faker.lorem.words(2),
        linkTarget: "_blank",
        linkURL: faker.internet.url(),
        mappedURL: faker.internet.url(),
        url: faker.internet.url()
      }
    }
  ]
};
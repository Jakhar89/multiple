import type {
  SuggestedSearchProps,
  SuggestedSearchItemsProps,
  SearchFieldProps
} from './store/ERSearchInterface';

export function safeParseJSON<T>(value: string, fallback: T): T {
  try {
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function parseSuggestedSearch(value: string): SuggestedSearchProps {
  const fallback: SuggestedSearchProps = { title: '', items: [] };
  const parsed = safeParseJSON<SuggestedSearchProps | SuggestedSearchItemsProps[]>(value, fallback);
  return Array.isArray(parsed) ? { title: '', items: parsed } : parsed;
}

export function readSearchDataset(root: HTMLElement): {
  suggestedSearch: SuggestedSearchProps;
  searchField: SearchFieldProps;
  autocompleteUrl: string;
  keywordSearchUrl: string;
  answerUrl: string;
  pdfUrl: string;
  homeUrl: string;
} {
  const { 
    suggestedSearch = '',
    searchField = '',
    searchAutocompleteurl = '',
    searchKeywordsearchurl = '',
    searchAnswerurl = '',
    searchPdfUrl = '',
    searchHomeUrl = ''
  } = root.dataset;

  return {
    suggestedSearch: parseSuggestedSearch(suggestedSearch),
    searchField: safeParseJSON<SearchFieldProps>(searchField, {
      label: '',
      buttonText: '',
      placeholder: '',
      redirectUrl: '',
    }),
    autocompleteUrl: searchAutocompleteurl || '',
    keywordSearchUrl: searchKeywordsearchurl || '',
    answerUrl: searchAnswerurl || '',
    pdfUrl: searchPdfUrl || '',
    homeUrl: searchHomeUrl || ''
  };
}

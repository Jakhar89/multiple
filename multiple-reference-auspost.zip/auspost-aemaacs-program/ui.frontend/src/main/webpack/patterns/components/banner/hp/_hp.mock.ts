import { faker } from '@faker-js/faker';
import { HPBannerProps } from './interface';

export const HOMEPAGE_BANNER_DATA: HPBannerProps = {
    variant: 'homepage',
    homepageBanner: {
        categoryLabel: faker.lorem.words(4),
        heading: faker.lorem.sentence(6),
        description: faker.lorem.sentence(16),
        primaryCtaLabel: 'View issue',
        primaryCtaHref: '#',
        secondaryCtaLabel: 'Shop now',
        secondaryCtaHref: '#',
        headingAccessibility: faker.lorem.sentence(8)
    },
    homepageFeatureImage: {
        src: 'src/main/webpack/patterns/assets/images/hp-banner.png',
        alt: faker.lorem.words(4)
    },
    homepageSidebarCards: [
        {
            categoryLabel: faker.lorem.words(2),
            title: faker.lorem.words(50).slice(0, 30),
            image: {
                src: 'src/main/webpack/patterns/assets/images/Stamp bulletin top.png',
                alt: faker.lorem.words(4)
            },
            href: '#'
        },
        {
            categoryLabel: faker.lorem.words(3),
            title: faker.lorem.sentence(4),
            image: {
                src: 'src/main/webpack/patterns/assets/images/stamp-landscape.png',
                alt: faker.lorem.words(4)
            },
            href: '#'
        }
    ]
};

const noSpaces = (s: string) => s.replace(/\s+/g, '');

export const HOMEPAGE_BANNER_DATA_WITHOUT_SPACES: HPBannerProps = {
    variant: 'homepage',
    homepageBanner: {
        categoryLabel: noSpaces(faker.lorem.words(4)),
        heading: noSpaces(faker.lorem.sentence(6)),
        description: noSpaces(faker.lorem.sentence(16)),
        primaryCtaLabel: 'View issue',
        primaryCtaHref: '#',
        secondaryCtaLabel: 'Shop now',
        secondaryCtaHref: '#',
        headingAccessibility: noSpaces(faker.lorem.sentence(8))
    },
    homepageFeatureImage: {
        src: 'src/main/webpack/patterns/assets/images/hp-banner.png',
        alt: noSpaces(faker.lorem.words(4))
    },
    homepageSidebarCards: [
        {
            categoryLabel: noSpaces(faker.lorem.words(2)),
            title: noSpaces(faker.lorem.words(50).slice(0, 30)),
            image: {
                src: 'src/main/webpack/patterns/assets/images/Stamp bulletin top.png',
                alt: noSpaces(faker.lorem.words(4))
            },
            href: '#'
        },
        {
            categoryLabel: noSpaces(faker.lorem.words(3)),
            title: noSpaces(faker.lorem.sentence(4)),
            image: {
                src: 'src/main/webpack/patterns/assets/images/stamp-landscape.png',
                alt: noSpaces(faker.lorem.words(4))
            },
            href: '#'
        }
    ]
};


export const sidebarCardsReverseAlignment: HPBannerProps['homepageSidebarCards'] = [
    {
        categoryLabel: faker.lorem.words(2),
        title: faker.lorem.words(50).slice(0, 30),
        titleAccessibility: faker.lorem.sentence(8),
        image: {
            src: 'src/main/webpack/patterns/assets/images/Stamp bulletin top.png',
            alt: faker.lorem.words(3)
        },
        href: '#',
        order: 'reverse'
    },
    {
        categoryLabel: faker.lorem.words(3),
        title: faker.lorem.sentence(4),
        titleAccessibility: faker.lorem.sentence(8),
        image: {
            src: 'src/main/webpack/patterns/assets/images/stamp-landscape.png',
            alt: faker.lorem.words(3)
        },
        href: '#',
        order: 'reverse'
    }
];


export const sidebarCardsWithSquareStamps: HPBannerProps['homepageSidebarCards'] = [
    {
        categoryLabel: faker.lorem.words(3),
        title: faker.lorem.sentence(4),
        titleAccessibility: faker.lorem.sentence(8),
        image: {
            src: 'src/main/webpack/patterns/assets/images/stamp-square.png',
            alt: faker.lorem.words(3)
        },
        href: '#'
    }
];

export const sidebarCardsWithUltrawideStamp: HPBannerProps['homepageSidebarCards'] = [
    {
        categoryLabel: faker.lorem.words(3),
        title: faker.lorem.sentence(4),
        titleAccessibility: faker.lorem.sentence(8),
        image: {
            src: 'src/main/webpack/patterns/assets/images/stamp-ultrawide.png',
            alt: faker.lorem.words(3)
        },
        href: '#'
    }
];


export const sidebarCardsWithPortraitStamp: HPBannerProps['homepageSidebarCards'] = [
    {
        categoryLabel: faker.lorem.words(3),
        title: faker.lorem.sentence(4),
        titleAccessibility: faker.lorem.sentence(8),
        image: {
            src: 'src/main/webpack/patterns/assets/images/stamp-portrait.png',
            alt: faker.lorem.words(3)
        },
        href: '#'
    }
];

export const OpenNewWindow: HPBannerProps = {
    variant: 'homepage',
    homepageBanner: {
        categoryLabel: faker.lorem.words(4),
        heading: faker.lorem.sentence(6),
        description: faker.lorem.sentence(16),
        primaryCtaLabel: 'View issue',
        primaryCtaHref: '#',
        secondaryCtaLabel: 'Shop now',
        secondaryCtaHref: '#',
        hrefTarget: '_blank',
        headingAccessibility: faker.lorem.sentence(8)
    },
    homepageFeatureImage: {
        src: 'src/main/webpack/patterns/assets/images/hp-banner.png',
        alt: faker.lorem.words(4)
    },
    homepageSidebarCards: [
        {
            categoryLabel: faker.lorem.words(2),
            title: faker.lorem.words(50).slice(0, 30),
            titleAccessibility: faker.lorem.sentence(8),
            image: {
                src: 'src/main/webpack/patterns/assets/images/Stamp bulletin top.png',
                alt: faker.lorem.words(4)
            },
            href: '#',
            hrefTarget: '_blank'
        },
        {
            categoryLabel: faker.lorem.words(3),
            title: faker.lorem.sentence(4),
            image: {
                src: 'src/main/webpack/patterns/assets/images/stamp-landscape.png',
                alt: faker.lorem.words(4)
            },
            href: '#',
            hrefTarget: '_blank'
        }
    ]
};

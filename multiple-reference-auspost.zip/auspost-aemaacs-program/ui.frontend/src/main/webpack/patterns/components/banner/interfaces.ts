export interface BannerProps {
  variant: 'hero' | 'teaser' | 'product' | 'promo',
  backgroundColor?: 'none' | 'white' | 'grey' | 'pastel-grey' | 'pastel-green' | 'pastel-orange' | 'pastel-blue' | 'pastel-cream' | 'pastel-purple';
  backLink?: string;
  category?: {
    label: string;
    bgColor: string;
    textColor: string;
  };
  label?: string;
  heading: string;
  description: string;
  issueDate: string;
  cta?: boolean;
  backgroundImage?: {
    src: string;
    alt: string;
  };
  image: {
    src: string;
    alt: string;
  };
}

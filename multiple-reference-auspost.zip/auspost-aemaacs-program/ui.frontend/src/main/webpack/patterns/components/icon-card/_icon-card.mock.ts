import type { IconCardProps } from './interfaces';

export const ICON_CARD: IconCardProps = {
    containerTheme: 'theme-auspost',
    contentAlignment: 'left',
    heading: 'Same day',
    description: 'Same day delivery within metro areas of major cities, and fast interstate delivery for urgent items.',
    icon: 'cube',
    links: []
};
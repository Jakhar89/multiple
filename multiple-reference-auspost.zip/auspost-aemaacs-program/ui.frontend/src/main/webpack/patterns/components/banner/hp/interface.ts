export interface HPBannerProps {
    variant: string;
    homepageBanner: {
        categoryLabel: string;
        heading: string;
        description: string;
        primaryCtaLabel: string;
        primaryCtaHref: string;
        secondaryCtaLabel: string;
        secondaryCtaHref: string;
        headingAccessibility?: string;
        hrefTarget?: string;
    };
    homepageFeatureImage: {
        src: string;
        alt: string;
    };
    homepageSidebarCards: {
        categoryLabel: string;
        title: string;
        titleAccessibility?: string;
        image: {
            src: string;
            alt: string;
        };
        href: string;
        hrefTarget?: string;
        order?: string;
    }[];
}
import React from "react";
import '@testing-library/jest-dom';
import { render, screen } from "@testing-library/react";
import BackToHome from "./ERBackToHome";
const { useERSearchContext } = require("../store/ERSearchContext");

jest.mock("../Icons/ERIcon", () => ({
  __esModule: true,
  default: (props: any) => (
    <svg data-testid="er-search-icon" data-name={props.name} />
  ),
}));

jest.mock("../store/ERSearchContext", () => ({
  useERSearchContext: jest.fn(),
}));

describe("BackToHome", () => {
  const homeUrl = "https://example.com/home";

  beforeEach(() => {
    (useERSearchContext as jest.Mock).mockReturnValue({ homeUrl });
  });

  it("renders anchor with correct href, aria-label and text", () => {
    render(<BackToHome />);
    const anchor = screen.getByRole("link", { name: /Back to home/i });
    expect(anchor).toHaveAttribute("href", homeUrl);
    expect(anchor).toHaveClass("cmp-button");
    expect(screen.getByText("Back to home")).toBeInTheDocument();
  });

  it("renders ERIcon with correct name prop", () => {
    render(<BackToHome />);
    const icon = screen.getByTestId("er-search-icon");
    expect(icon).toBeInTheDocument();
    expect(icon).toHaveAttribute("data-name", "arrow-left");
  });
});

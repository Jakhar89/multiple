import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import ERSuggestedSearches from './ERSuggestedSearch';

jest.mock('../Icons/ERIcon', () => (props: any) => <span data-testid="er-icon">{props.name}</span>);

describe('ERSuggestedSearches', () => {
  const items = [{ label: 'First', href:'#' }, { label: 'Second', href:'#' }];

  test('renders title, list and items', () => {
    render(<ERSuggestedSearches title="Suggested" items={items} onSuggestionSelect={jest.fn()} />);

    expect(screen.getByText('Suggested')).toBeInTheDocument();
    expect(screen.getByRole('list')).toBeInTheDocument();
    expect(screen.getAllByRole('listitem')).toHaveLength(2);
    expect(screen.getByText('First')).toBeInTheDocument();
    expect(screen.getAllByTestId('er-icon')).toHaveLength(2);
  });

  test('calls onSuggestionSelect with item text when suggestion clicked', () => {
    const onSelect = jest.fn();
    render(<ERSuggestedSearches title="Suggested" items={items} onSuggestionSelect={onSelect} />);

    const secondLabel = screen.getByText('Second');

    fireEvent.click(secondLabel);

    expect(onSelect).toHaveBeenCalledTimes(1);
    expect(onSelect).toHaveBeenCalledWith('Second');
  });
});
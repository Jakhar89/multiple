import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import PopularSearches from './PopularSearch';

describe('PopularSearches', () => {
  const items = [
    { href: '/search/track', label: 'Track' },
    { href: '/search/postcode', label: 'Postcode' },
    { href: '/search/calc', label: 'Calculate postage' }
  ];

  it('renders title when provided and associates aria-labelledby', () => {
    render(<PopularSearches title="Popular searches" items={items} />);

    const heading = document.getElementById('popular-search-heading');
    expect(heading).toBeInTheDocument();
    expect(heading).toHaveTextContent('Popular searches');

    const labelledBy = document.querySelector('.popular-searches');
    expect(labelledBy).toBeInTheDocument();
  });

  it('renders a list of items with correct labels and hrefs', () => {
    render(<PopularSearches title="Popular searches" items={items} />);

    const list = screen.getByRole('list');
    const listItems = screen.getAllByRole('listitem');

    expect(list).toBeInTheDocument();
    expect(listItems).toHaveLength(items.length);

    for (const item of items) {
      const link = screen.getByRole('link', { name: item.label });
      expect(link).toBeInTheDocument();
      expect(link).toHaveAttribute('href', item.href);
      expect(link).toHaveClass('suggestions-link');
    }
  });

  it('does not render heading when title is empty', () => {
    render(<PopularSearches title="" items={items} />);

    const heading = document.getElementById('popular-search-heading');
    expect(heading).toBeNull();

    const listItems = screen.getAllByRole('listitem');
    expect(listItems).toHaveLength(items.length);
  });
});

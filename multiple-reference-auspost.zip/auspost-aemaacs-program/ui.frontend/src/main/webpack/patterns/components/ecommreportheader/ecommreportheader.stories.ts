import type { Meta, StoryObj } from '@storybook/html-vite';
import ecommreportheader from './ecommreportheader.liquid';

const meta = {
  title: 'Components/Ecommerce Report/Header',
  component: ecommreportheader,
  parameters: {
    layout: 'fullscreen'
  },
  args: {},
  play: async () => {}
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const Default: Story = {};

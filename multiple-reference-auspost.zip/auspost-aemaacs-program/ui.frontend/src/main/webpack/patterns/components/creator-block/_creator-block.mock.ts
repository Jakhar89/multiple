import { faker } from '@faker-js/faker';
import type { CreatorBlockProps } from './interfaces';

export const CREATOR_BLOCK_DATA: CreatorBlockProps = {
  authorName: faker.person.fullName(),
  authorTitle: faker.person.jobTitle(),
  fileReference: '/src/main/webpack/patterns/assets/images/creator.jpg',
  articleLink:'https://auspost.com.au/community-hub/inspiring-people/wendy-page',
  facebookLink: 'https://www.facebook.com/sharer.php?u=',
  xLink: 'https://twitter.com/intent/tweet?url=',
  linkedinLink: 'https://www.linkedin.com/shareArticle?mini=true&url=',
  socialShareTitle: 'Share this article',
  authorDescription: faker.lorem.paragraph()
};

import type { Meta, StoryObj } from '@storybook/html-vite';
import type { CreatorBlockProps } from './interfaces';
import { CREATOR_BLOCK_DATA } from './_creator-block.mock';
import component from './creator-block.liquid';

const meta = {
  title: 'Components/Creator Block',
  component: component,
  parameters: {
    docs: {
      description: {
        component: `
### Creator Block
A block to showcase a creator, author, or team member.`
      }
    }
  },
  args: { ...CREATOR_BLOCK_DATA }
} satisfies Meta<CreatorBlockProps>;

export default meta;
type Story = StoryObj<CreatorBlockProps>;

export const Default: Story = {};

export const WithDefaultImage: Story = {
  args: {
    ...CREATOR_BLOCK_DATA,
    fileReference: undefined
  }
};

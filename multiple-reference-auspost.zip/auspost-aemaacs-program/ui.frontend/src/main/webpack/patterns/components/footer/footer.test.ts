import { initToggle } from './footer';

describe('Footer Toggle', () => {
  let container: HTMLElement;
  let button: HTMLButtonElement;
  let childList: HTMLElement;
  const config = {
    toggleButtonSelector: '.js-toggle-child-links',
    containerSelector: '.footer-primary-links',
    childSelector: '.footer-child-links',
    hideClass: 'hide-xs'
  };

  beforeEach(() => {
    document.body.innerHTML = `
      <div class="footer-primary-links">
        <button class="js-toggle-child-links" aria-expanded="false"></button>
        <ul class="footer-child-links hide-xs">
          <li>Link 1</li>
        </ul>
      </div>
    `;
    container = document.querySelector('.footer-primary-links')!;
    button = container.querySelector('button')!;
    childList = container.querySelector('.footer-child-links')!;
    initToggle(config);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('should toggle hide class and aria-expanded on click', () => {
    expect(childList.classList.contains('hide-xs')).toBe(true);
    expect(button.getAttribute('aria-expanded')).toBe('false');
    button.click();
    expect(childList.classList.contains('hide-xs')).toBe(false);
    expect(button.getAttribute('aria-expanded')).toBe('true');
    button.click();
    expect(childList.classList.contains('hide-xs')).toBe(true);
    expect(button.getAttribute('aria-expanded')).toBe('false');
  });

  it('should do nothing if container is not found', () => {
    // Remove container
    container.remove();
    // Should not throw
    expect(() => button.click()).not.toThrow();
  });

  it('should do nothing if child list is not found', () => {
    childList.remove();
    expect(() => button.click()).not.toThrow();
  });

  it('should attach click event to all toggle buttons', () => {
    const spy = jest.spyOn(button, 'addEventListener');
    initToggle(config);
    expect(spy).toHaveBeenCalledWith('click', expect.any(Function));
  });
});

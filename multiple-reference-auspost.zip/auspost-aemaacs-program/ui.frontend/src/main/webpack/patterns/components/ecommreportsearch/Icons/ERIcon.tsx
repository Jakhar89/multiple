import React from "react";
import { getIconPath } from "../../../../scripts/utils/utils";
import { ERIconProps } from "../store/ERSearchInterface";

export default function ERIcon({
  name,
  colorClass = 'icon--fill-white'
}: ERIconProps) {
  return (
    <svg
      className={`${name}-icon ${colorClass}`}
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
    >
      <use href={`${getIconPath()}/${name}.svg#${name}`}></use>
    </svg>
  );
}

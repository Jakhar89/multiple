import type { Meta, StoryObj } from '@storybook/html-vite';
import { PROMO_BANNER_DATA as BANNER_DATA } from './_promo.mock';
import { BannerProps } from '../interfaces';
import component from './promo.liquid';

const meta: Meta<BannerProps> = {
  title: 'Components/Banner/Promo',
  component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {},
  args: {
    ...BANNER_DATA
  }
};

export default meta;

type Story = StoryObj<BannerProps>;

export const Portrait: Story = {
  args: {}
};

export const Landscape: Story = {
  args: {
    ...BANNER_DATA,
    image: {
      src: 'src/main/webpack/patterns/assets/images/stamp-landscape.png',
      alt: 'Stamp image'
    }
  }
};

export const Square: Story = {
  args: {
    ...BANNER_DATA,
    image: {
      src: 'src/main/webpack/patterns/assets/images/stamp-square.png',
      alt: 'Stamp image'
    }
  }
};

export const Ultrawide: Story = {
  args: {
    ...BANNER_DATA,
    image: {
      src: 'src/main/webpack/patterns/assets/images/stamp-ultrawide.png',
      alt: 'Stamp image'
    }
  }
};

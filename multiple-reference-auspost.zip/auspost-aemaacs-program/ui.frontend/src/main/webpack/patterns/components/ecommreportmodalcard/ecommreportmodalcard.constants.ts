export const VIEWPORT_THRESHOLD = 0.5;
export const ANIMATION_CLASS_NAME = "animate";
import { AssetItem } from "./asset-item/interfaces";
import { StampItem } from './stamp-item/interfaces';
import { ArticleItem } from './article-item/interfaces';

export interface PageListProps {
  pageListHeading?: string;
  filterList: Filter[];
  resultType: 'AssetItem' | 'StampItem' | 'ArticleItem';
  results: AssetItem[] | StampItem[] | ArticleItem[];
  totalInitialResults?: number;
  totalFilteredResult?: number;
  totalResult?: number;
}

export interface Filter {
  id: string;
  label: string;
  options: string[][];
}

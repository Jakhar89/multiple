import { CategoryProps } from "../../atoms/category/interfaces";

export interface CardProps {
  backgroundStyle: string;
  imageUrl: string;
  category?: CategoryProps;
  label?: string;
  title: string;
  description: string;
  cardCtaText: string;
  cardCtaType: string;
  cardCtaUrl?: string;
}

export interface CardListingProps {
  columns: string;
  clickableMode: "full-card" | "cta-only";
  aspectRatio?: "aspect-16x9" | "aspect-4x3" | "aspect-3x4" | "aspect-1x1" | "";
  imageStyle?: "default" | "card-image-center" | "full";
  heading?: string;
  contentAlignment?: "left" | "center";
  cards: CardProps[];
  listingCtaText?: string;
}

import { faker } from '@faker-js/faker';
import { ArticleItem } from './interfaces';

export const MOCK_ARTICLE_ITEM: ArticleItem = {
    backgroundStyle: 'grey',
    imageUrl: '/src/main/webpack/patterns/assets/images/Landscape.png',
    category: {
        label: '',
        bgColor: '',
        textColor: '',
    },
    datestamp: 'Issue date: 26 August 2025',
    title: faker.lorem.sentence(),
    description: faker.lorem.paragraph(),
    cardCtaText: faker.helpers.arrayElement([
        'Contact Mailorder',
        'View Collection',
        'Read Guide',
        'Book Tickets',
    ]),
    cardCtaType: 'tertiary',
};

import React from 'react';
import { render } from '@testing-library/react';
import ERLoader from './ERLoader';

describe('ERLoader', () => {
  it('renders default number of skeleton items', () => {
    const { container } = render(<ERLoader />);
    const items = container.querySelectorAll('li');
    expect(items.length).toBe(5);
  });

  it('renders provided skeletonCount', () => {
    const { container } = render(<ERLoader skeletonCount={3} />);
    const items = container.querySelectorAll('li');
    expect(items.length).toBe(3);
  });
});

import { Liquid } from 'liquidjs';
import {MARKETING_BLOCK_DATA} from './_marketing-block.mock';
import fs from 'fs';
import path from 'path';

describe('Marketing Block Liquid Template', () => {
    let engine: Liquid;
    let template: string;

    beforeAll(() => {
        engine =new Liquid({cache: false});

        template = fs.readFileSync(
            path.resolve(
                __dirname,
                './marketing-block.liquid'
            ),
            'utf-8'
        );
    });

    const render = async (data: Record<string, any>) => {
        return engine.parseAndRender(template, data);
    };

    it('renders marketing block wrapper', async() => {
        const html = await render(MARKETING_BLOCK_DATA);

        expect(html).toContain('class="marketing-block');
        expect(html).toContain('marketing-block-wrap');
    });

    it('renders standard image', async () => {
        const html = await render({
            ...MARKETING_BLOCK_DATA,
            image: {
                src: "marketing-block-img2.png",
                alt: "Marketing Block image",
            },
        });

        expect(html).toContain('<img');
        expect(html).toContain('src="marketing-block-img2.png"');
        expect(html).toContain('alt="Marketing Block image"');
        expect(html).not.toContain('class="swoosh-image');
    });

    it('renders swoosh SVG images for swoosh image variation', async () => {
        const html = await render({
            ...MARKETING_BLOCK_DATA,
            imageType: 'swoosh-image'
        });

        expect(html).toContain('swoosh-image');
    });

    it('renders image on right for imagePosition right', async () => {
        const html = await render({
            ...MARKETING_BLOCK_DATA,
            imagePosition: 'image-right'
        });

        expect(html).toContain('image-right');
    });

    it('renders heading and description', async () => {
        const html = await render({
            ...MARKETING_BLOCK_DATA,
            heading : 'Test heading',
            description : 'Test description',
        });

        expect(html).toContain('<h2 class="heading">Test heading</h2>');
        expect(html).toContain('<p>Test description</p>');
    });

    it('renders QR block when qrBlock is true', async () => {
        const html = await render({
            ...MARKETING_BLOCK_DATA,
            qrBlock: true,
            qrText: 'Scan to download',
            qrCode: '/qr/code.png',
        });

        expect(html).toContain('marketing-block-qrblock');
        expect(html).toContain('Scan to download');
        expect(html).toContain('src="/qr/code.png"');
    });

    it('renders CTA buttons when qrBlock is false', async () => {
        const html = await render({
            ...MARKETING_BLOCK_DATA,
            ctas: [
                {
                    label: 'Register online',
                    type: 'primary',
                },
            ],
        });

        expect(html).toContain('marketing-block-buttons');
        expect(html).toContain('Register online');
    });

    it('renders logo sectionwhen logo is enabled', async () => {
        const html = await render({
            ...MARKETING_BLOCK_DATA,
            logo: true,
        });

        expect(html).toContain('marketing-block-logo-wrapper');
        expect(html).toContain('marketing-block-logo');
    });
});
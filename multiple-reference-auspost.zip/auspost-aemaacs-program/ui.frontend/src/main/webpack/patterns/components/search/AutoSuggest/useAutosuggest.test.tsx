import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { SearchProvider } from '../SearchUtils/searchContext';
import type { SearchAppContext } from '../SearchUtils/searchContext';
import Autosuggest from './AutoSuggest';

if (!(global as any).fetch) {
  const http = require('http');
  (global as any).fetch = (input: string, init?: any) => {
    return new Promise((resolve, reject) => {
      try {
        const url = new URL(input);
        const options = {
          method: init?.method || 'GET',
          headers: init?.headers || {},
          hostname: url.hostname,
          port: url.port ? Number(url.port) : 80,
          path: url.pathname + url.search,
        };
        const req = http.request(options, (res: any) => {
          const chunks: Buffer[] = [];
          res.on('data', (d: Buffer) => chunks.push(d));
          res.on('end', () => {
            const body = Buffer.concat(chunks).toString('utf-8');
            resolve({
              ok: res.statusCode >= 200 && res.statusCode < 300,
              status: res.statusCode,
              statusText: res.statusMessage,
              json: async () => JSON.parse(body),
              text: async () => body,
              blob: async () => body as any,
            } as any);
          });
        });
        req.on('error', (err: any) => reject(err));
        if (init?.body) {
          req.write(init.body);
        }
        req.end();
      } catch (err) {
        reject(err);
      }
    });
  };
}

function renderAutosuggest(props: React.ComponentProps<typeof Autosuggest>, ctx: SearchAppContext) {
  return render(
    <SearchProvider value={ctx}>
      <Autosuggest {...props} label="Search" />
    </SearchProvider>
  );
}

// Minimal context shape
const baseCtx: SearchAppContext = {
  searchField: {
    label: 'Search',
    buttonText: 'Go',
    placeholder: 'Type…',
    redirectUrl: '/search',
  },
  popularSearch: { title: 'Popular', items: [] },
  resultPageSize: 10,
};

describe('useAutosuggest - local suggestions and navigation', () => {
  test('filters visible suggestions when autocomplete and minChars satisfied', () => {
    const ctx = { ...baseCtx };
    renderAutosuggest({ autocomplete: true, minChars: 2, suggestions: ['Alpha','Beta','Gamma','delta','alpaca'] }, ctx);

    const input = screen.getByLabelText('Search');
    fireEvent.change(input, { target: { value: 'al' } });

    const listbox = screen.getByRole('listbox');
    expect(listbox).toBeTruthy();
    const options = screen.getAllByRole('option');
    expect(options).toHaveLength(2);
    expect(options.map(o => o.textContent)).toEqual(['Alpha','alpaca']);
  });

  test('ArrowDown/ArrowUp cycles active index and opens list', () => {
    const ctx = { ...baseCtx };
    renderAutosuggest({ autocomplete: true, minChars: 1, suggestions: ['mail','map','mars'] }, ctx);

    const input = screen.getByLabelText('Search');
    fireEvent.change(input, { target: { value: 'ma' } });

    // ArrowDown sets isOpen true and advances active option
    fireEvent.keyDown(input, { key: 'ArrowDown' });
    let options = screen.getAllByRole('option');
    expect(options[0].getAttribute('aria-selected')).toBe('true');

    fireEvent.keyDown(input, { key: 'ArrowDown' });
    options = screen.getAllByRole('option');
    expect(options[1].getAttribute('aria-selected')).toBe('true');

    fireEvent.keyDown(input, { key: 'ArrowUp' });
    options = screen.getAllByRole('option');
    expect(options[0].getAttribute('aria-selected')).toBe('true');

    fireEvent.keyDown(input, { key: 'ArrowUp' });
    options = screen.getAllByRole('option');
    expect(options[2].getAttribute('aria-selected')).toBe('true'); // wrap-around
  });
});

describe('useAutosuggest - remote fetch and edge cases', () => {
  function startServer(handlers: { ok: (q: string) => string; bad?: (q: string) => string }) {
    const http = require('http');
    const server = http.createServer((req: any, res: any) => {
      const url = new URL(req.url, `http://${req.headers.host}`);
      const q = url.searchParams.get('query') || '';
      if (url.pathname === '/bad') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(handlers.bad ? handlers.bad(q) : 'not json');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(handlers.ok(q));
    });
    return new Promise<{ url: string; close: () => Promise<void> }>((resolve) => {
      server.listen(0, '127.0.0.1', () => {
        const { port } = server.address();
        const base = `http://127.0.0.1:${port}`;
        resolve({ url: base, close: () => new Promise<void>((r) => server.close(() => r())) });
      });
    });
  }

  test('remote suggestions fetched and normalized', async () => {
    const srv = await startServer({
      ok: () => JSON.stringify({ suggestions: ['mail', 'map', 'mars'] })
    });

    const ctx = { ...baseCtx, autocompleteUrl: `${srv.url}/suggest` };
    renderAutosuggest({ autocomplete: true, minChars: 1 }, ctx);

    const input = screen.getByLabelText('Search');
    fireEvent.change(input, { target: { value: 'ma' } });

    await waitFor(() => {
      const options = screen.getAllByRole('option');
      expect(options.map(o => o.textContent)).toEqual(['mail','map','mars']);
    }, { timeout: 3000 });

    await srv.close();
  });

  test('invalid JSON triggers catch and clears remoteSuggestions', async () => {
    const srv = await startServer({ bad: () => 'not json', ok: () => '{}' });
    const ctx = { ...baseCtx, autocompleteUrl: `${srv.url}/bad` };
    renderAutosuggest({ autocomplete: true, minChars: 1 }, ctx);

    const input = screen.getByLabelText('Search');
    fireEvent.change(input, { target: { value: 'x' } });
    await waitFor(() => {
      expect(screen.queryByRole('listbox')).toBeNull();
    }, { timeout: 3000 });

    await srv.close();
  });

  test('result view first run does not fetch on empty value', async () => {
    const ctx = { ...baseCtx, autocompleteUrl: 'http://localhost/any' };
    renderAutosuggest({ autocomplete: true, minChars: 1, isResultView: true, value: '' }, ctx);
    // no input change; should not be loading and no remote items
    await waitFor(() => {
      expect(screen.queryByRole('listbox')).toBeNull();
    });
  });

  test('no autocomplete disables suggestions and remote fetch', () => {
    const ctx = { ...baseCtx, autocompleteUrl: 'http://localhost/any' };
    renderAutosuggest({ autocomplete: false, minChars: 1, suggestions: ['A','B'] }, ctx);
    const input = screen.getByLabelText('Search');
    fireEvent.change(input, { target: { value: 'A' } });
    expect(screen.queryByRole('listbox')).toBeNull();
  });

  test('no apiBase keeps isLoading false and clears remoteSuggestions', () => {
    const ctx = { ...baseCtx }; // no autocompleteUrl
    renderAutosuggest({ autocomplete: true, minChars: 1 }, ctx);
    const input = screen.getByLabelText('Search');
    fireEvent.change(input, { target: { value: 'abc' } });
    expect(screen.queryByRole('listbox')).toBeNull();
  });
});

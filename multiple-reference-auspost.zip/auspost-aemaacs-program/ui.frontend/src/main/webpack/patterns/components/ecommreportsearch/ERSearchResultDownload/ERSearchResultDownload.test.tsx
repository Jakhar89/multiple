import React from "react";
import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import ERSearchResultDownload from "./ERSearchResultDownload";
import { useERSearchContext } from "../store/ERSearchContext";

jest.mock("../Icons/ERIcon", () => {
  return {
    __esModule: true,
    default: (props: any) => <span data-testid={`er-icon-${props.name}`} />,
  };
});

jest.mock("../store/ERSearchContext", () => {
  return {
    __esModule: true,
    useERSearchContext: jest.fn(),
  };
});

const mockedUseERSearchContext = useERSearchContext as jest.MockedFunction<
  typeof useERSearchContext
>;

describe("ERSearchResultDownload", () => {
  beforeEach(() => {
    mockedUseERSearchContext.mockReturnValue({
      pdfUrl: "https://example.com/report.pdf",
    } as any);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("renders label and download button text", () => {
    render(<ERSearchResultDownload />);

    expect(
      screen.getByText(
        /This insight is a summary - download the full report for details\./i,
      ),
    ).toBeInTheDocument();

    expect(screen.getByText(/Download full PDF/i)).toBeInTheDocument();
  });

  it("uses pdfUrl from context for anchor href and has correct attributes and icon", () => {
    render(<ERSearchResultDownload />);

    const link = screen.getByRole("link", {
      name: /Download ecommerce report/i,
    }) as HTMLAnchorElement;

    expect(link).toBeInTheDocument();
    expect(link.href).toBe("https://example.com/report.pdf");
    expect(link.target).toBe("_blank");
    expect(link).toHaveClass("cmp-button");

    expect(screen.getByTestId("er-icon-download")).toBeInTheDocument();
  });
});

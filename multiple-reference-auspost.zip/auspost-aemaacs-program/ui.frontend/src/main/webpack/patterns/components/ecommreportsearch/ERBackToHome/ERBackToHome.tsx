import ERIcon from "../Icons/ERIcon";
import { useERSearchContext } from "../store/ERSearchContext";

export default function BackToHome() {
  const {homeUrl} = useERSearchContext();

  return (
    <div className="back-to-home-btn">
      <a
        href={homeUrl}
        className="cmp-button"
        aria-label="Back to home"
      >
        <span className="button-icon icon-left">
          <ERIcon name="arrow-left" />
        </span>

        <span className="cmp-button__text">Back to home</span>
      </a>
    </div>
  );
}

import './image.scss';

export interface ImageProps {
  aspectRatio?: '' | 'aspect-16x9' | 'aspect-4x3' | 'aspect-1x1';
  captionStyle?: '' | 'floating' | 'connected';
  captionText?: string;
  downloadHref?: string;
  downloadSize?: string;
  imageHref?: string;
  rounded?: boolean;
  showCaption?: boolean;
}

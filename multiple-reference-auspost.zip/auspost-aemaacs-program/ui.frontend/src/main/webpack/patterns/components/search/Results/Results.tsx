import React, { useEffect, useId, useRef, useState } from 'react';
import { useSearchContext } from '../SearchUtils/searchContext';
import SearchBar from '../SearchBar/SearchBar';
import type { SearchResultsResponseProps } from '../SearchUtils/interface';
import SearchResults from './SearchResults/SearchResults';
import { getQueryFromLocation } from '../util/search.utils';
import { fetchApiPost, ResponseFormat } from '../../../../scripts/utils/api';
import config from '../util/search.config';
import { createSearchResultsDataLayer, pushSearchResultsToDataLayer } from '../../../../scripts/analytics/analytics';

export default function Results({
  query = ''
}: {
  query?: string;
}) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [currentQuery, setCurrentQuery] = useState(() => getQueryFromLocation() ?? query);
  const [lastSearchedQuery, setLastSearchedQuery] = useState(() => getQueryFromLocation() ?? query);
  const inputId = useId();
  
  // Get element ID from parent search-app container
  const getSearchResultsId = (): string => {
    const searchAppElement = wrapperRef.current?.closest('.search-app');
    return searchAppElement?.id || 'search-results';
  };
  
  const { searchField, searchApiUrl, resultPageSize } = useSearchContext();

  const [resultsData, setResultsData] = useState<SearchResultsResponseProps>({ results: [], totalSize: 0 });
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showError, setShowError] = useState(false);
  const hasSearchedRef = useRef(false);

  const performSearch = async (q: string, pageToken?: string | null, pageIndex?: number) => {
    const url = searchApiUrl;
    if (!url) {
      return;
    }
    setLoading(true);
    try {
      const resp = await fetchApiPost(
        url,
        {
          query: q ?? '',
          pageSize: resultPageSize,
          pageToken,
          languageCode: config.languageCode,
          userInfo: { timeZone: config.zone },
          ...config.searchRequestSpec
        },
        ResponseFormat.Json,
        { 'Content-Type': 'application/json' },
        () => setShowError(true)
      );
      const response = resp as unknown as SearchResultsResponseProps;
      setResultsData(response);
      hasSearchedRef.current = true;
      if (typeof pageIndex === 'number') {
        setCurrentPageIndex(pageIndex);
      }
    } catch (err) {
      setShowError(true);
    } finally {
      setLoading(false);
    }
  };

  const onSubmit: React.FormEventHandler<HTMLFormElement> = async (e) => {
    e.preventDefault();
    let queryToUse = currentQuery;
    try {
      const form = e.currentTarget;
      const input = form.querySelector<HTMLInputElement>(`input[name=\"q\"]`);
      if (input) {
        queryToUse = input.value ?? currentQuery;
      }
    } catch {
      queryToUse = currentQuery;
    }

    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.href);
        if (queryToUse) {
          url.searchParams.set('q', queryToUse);
        } else {
          url.searchParams.delete('q');
        }
        window.history.replaceState(null, '', url.toString());
      } catch {
        // ignore URL update errors
      }
    }

    setLastSearchedQuery(queryToUse);
    setCurrentPageIndex(0);
    performSearch(queryToUse, null, 0);
  };

  const items = Array.isArray(resultsData?.results) ? resultsData.results : [];
  const total = typeof resultsData?.totalSize === 'number' ? resultsData.totalSize : 0;
  const pageSize = typeof resultPageSize === 'number' && resultPageSize > 0 ? resultPageSize : (items?.length || 0);
  const pageStart = items.length > 0 && pageSize > 0 ? (currentPageIndex * pageSize) + 1 : 0;
  const pageEnd = items.length > 0 ? pageStart + items.length - 1 : 0;
  const skeletonCount = typeof resultPageSize === 'number' && resultPageSize > 0 ? resultPageSize : 5;

  const searchResultsId = getSearchResultsId();
  const dataLayer = createSearchResultsDataLayer(searchResultsId, lastSearchedQuery, total);
  const lastPushedRef = useRef<string>('');

  // Push to Adobe Data Layer only when search results change and after a search has been performed
  useEffect(() => {
    const currentKey = `${lastSearchedQuery}-${total}`;
    if (!loading && hasSearchedRef.current && lastPushedRef.current !== currentKey) {
      pushSearchResultsToDataLayer(lastSearchedQuery, total);
      lastPushedRef.current = currentKey;
    }
  }, [total, lastSearchedQuery, loading]);

  useEffect(() => {
    const q = getQueryFromLocation();
    if (q && q !== currentQuery) {
      setCurrentQuery(q);
    }

    if (q || q === '') {
      setLastSearchedQuery(q);
      setCurrentPageIndex(0);
      performSearch(q);
    }

    if (!searchApiUrl) {
      setShowError(true);
    }
  }, []);

  return (
    <div ref={wrapperRef}>
      <div role='search' className='search-bar p-y-500 p-y-md-600'>
        <form className='search-form d-flex' role='search' onSubmit={onSubmit}>
          <label className='search-label h4 m-r-400' htmlFor={inputId}>{searchField.label}</label>
          <div className='w-100'>
            <SearchBar
              id={inputId}
              query={currentQuery}
              onQueryChange={setCurrentQuery}
              searchField={searchField}
              isResultView
            />
          </div>
        </form>
      </div>

      <SearchResults
        items={items}
        loading={loading}
        pageStart={pageStart}
        pageEnd={pageEnd}
        total={total}
        skeletonCount={skeletonCount}
        lastSearchedQuery={lastSearchedQuery}
        showError={showError}
        nextPageToken={resultsData?.nextPageToken}
        performSearch={performSearch}
        dataCmpDataLayer={dataLayer}
        searchQuery={lastSearchedQuery}
      />
    </div>
  );
}

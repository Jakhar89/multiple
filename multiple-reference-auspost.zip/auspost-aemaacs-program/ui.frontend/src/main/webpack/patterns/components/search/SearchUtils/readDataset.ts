import type {
    PopularSearchProps,
    PopularSearchItemsProps,
    SearchFieldProps
} from './interface';
import config from '../util/search.config';

export function safeParseJSON<T>(value: string, fallback: T): T {
    try {
        return value ? (JSON.parse(value) as T) : fallback;
    } catch {
        return fallback;
    }
}

function parsePopularSearch(value: string): PopularSearchProps {
    const fallback: PopularSearchProps = { title: '', items: [] };
    const parsed = safeParseJSON<PopularSearchProps | PopularSearchItemsProps[]>(value, fallback);
    return Array.isArray(parsed) ? { title: '', items: parsed } : parsed;
}

export function readSearchDataset(root: HTMLElement): {
    popularSearch: PopularSearchProps;
    searchField: SearchFieldProps;
    autocompleteUrl: string;
    searchApiUrl?: string;
    resultPageSize: number;
} {
    const {
        popularSearch = '',
        searchField = '',
        searchBasicAutocompleteUrl = '',
        searchapiUrl = '',
        resultPagesize = config.pagesize.toString()
    } = root.dataset;

    return {
        popularSearch: parsePopularSearch(popularSearch),
        searchField: safeParseJSON<SearchFieldProps>(searchField, {
            label: '',
            buttonText: '',
            placeholder: '',
            redirectUrl: '',
        }),
        autocompleteUrl: searchBasicAutocompleteUrl || '',
        searchApiUrl: searchapiUrl || undefined,
        resultPageSize: Number.parseInt(resultPagesize, 10) || config.pagesize
    };
}

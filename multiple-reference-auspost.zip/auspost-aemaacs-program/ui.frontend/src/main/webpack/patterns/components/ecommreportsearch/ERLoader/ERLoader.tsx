import React from 'react';
import Skeleton from 'react-loading-skeleton';
import { LoaderProps } from '../store/ERSearchInterface';

export default function ERLoader({ skeletonCount = 5, className = '' }: LoaderProps) {
  return (
    <ul role="listbox"
        aria-busy={true}
        className="search-loader list-style-none">
      {
        Array.from({ length: skeletonCount }).map((_, index) => (
          <li
            key={`skeleton-${index}`}
            id={`skeleton-${index}-bar`}
            role="option"
            aria-selected={false}
            className={className}
          >
            <span className="search-loader-line d-inline-flex p-150 w-100">
              <Skeleton
                height={16}
                duration={1}
                direction="ltr"
                enableAnimation={true}
                width={Math.random() * (80 - 40) + 40 + '%'}
              />
            </span>
          </li>
        ))
      }
    </ul>
  )
}
import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ResultItem from './ResultItem';

const makeItem = (overrides: Partial<any> = {}) => {
  return {
    id: 'item-1',
    document: {
      name: 'doc-1',
      id: 'doc-1',
      structData: {},
      derivedStructData: {},
      ...(overrides.document || {})
    },
    ...(overrides)
  } as any;
};

describe('ResultItem', () => {
  test('renders title, description and formatted link', () => {
    const item = makeItem({
      document: {
        structData: {
          og_title: ['My Title'],
          og_description: ['<strong>My description</strong>'],
          og_type: ['Article']
        },
        derivedStructData: {
          link: 'https://example.com/path'
        }
      }
    });

    const { container } = render(<ResultItem item={item} searchQuery="test query" />);

    expect(screen.queryByText('Article')).not.toBeInTheDocument();
    expect(screen.getByText('My Title')).toBeInTheDocument();

    const desc = container.querySelector('.result-description') as HTMLElement;
    expect(desc).toBeInTheDocument();
    expect(desc.innerHTML).toContain('My description');

    const link = screen.getByRole('link', { name: 'My Title' });
    expect(link).toHaveAttribute('href', 'https://example.com/path');
    const formattedLink = container.querySelector('.result-link') as HTMLElement;
    expect(formattedLink).toBeInTheDocument();
    expect(formattedLink.textContent).toBe('example.com/path');
  });

  test('falls back to derived title when struct title missing', () => {
    const item = makeItem({
      document: {
        structData: {
          og_description: ['desc']
        },
        derivedStructData: {
          title: 'Derived Title',
          link: 'https://foo.bar/baz'
        }
      }
    });

    render(<ResultItem item={item} searchQuery="test query" />);
    expect(screen.getByText('Derived Title')).toBeInTheDocument();
  });

  test('uses snippet when struct description missing', () => {
    const item = makeItem({
      document: {
        structData: {
          og_title: ['T']
        },
        derivedStructData: {
          snippets: [{ snippet: 'Snippet <em>HTML</em>', snippet_status: 'SUCCESS' }]
        }
      }
    });

    const { container } = render(<ResultItem item={item} searchQuery="test query" />);
    const desc = container.querySelector('.result-description') as HTMLElement;
    expect(desc.innerHTML).toContain('Snippet HTML');
  });

  test('joins multiple og_description entries with a comma', () => {
    const item = makeItem({
      document: {
        structData: {
          og_title: ['T'],
          og_description: ['First part', 'Second part']
        },
        derivedStructData: {
          link: 'https://example.com'
        }
      }
    });

    const { container } = render(<ResultItem item={item} searchQuery="test query" />);
    const desc = container.querySelector('.result-description') as HTMLElement;
    expect(desc).toBeInTheDocument();
    expect(desc.textContent).toContain('First part, Second part');
  });

  test('filters out empty og_description entries before joining', () => {
    const item = makeItem({
      document: {
        structData: {
          og_title: ['T'],
          og_description: ['One', '', '<b>Three</b>']
        },
        derivedStructData: {
          link: 'https://example.com'
        }
      }
    });

    const { container } = render(<ResultItem item={item} searchQuery="test query" />);
    const desc = container.querySelector('.result-description') as HTMLElement;
    expect(desc).toBeInTheDocument();
    expect(desc.textContent).toContain('One, Three');
  });

  test('does not render meta when missing and adds last class when isLast', () => {
    const item = makeItem({
      document: {
        structData: {},
        derivedStructData: {}
      }
    });

    const { container } = render(<ResultItem item={item} searchQuery="test query" isLast />);

    expect(container.querySelector('.result-meta')).toBeNull();
    const resultItem = container.querySelector('.search-result-item') as HTMLElement;
    expect(resultItem.className).toMatch(/last-result-item/);
  });
});

import { initPieGraph } from "./pie";
import { getTransition, animateNumber } from "../../graph.utils";
import { ANIMATION_CLASS_NAME } from "../../ecommreportmodalcard.constants";

describe("initPieGraph", () => {
  let container: HTMLElement;

  beforeEach(() => {
    document.body.innerHTML = "";
    jest.useFakeTimers();
    jest.spyOn(window, "requestAnimationFrame").mockImplementation((cb) => {
      cb(0);
      return 0;
    });
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.restoreAllMocks();
    document.body.innerHTML = "";
  });

  it("should return early if no containers found", () => {
    document.body.innerHTML = "<div></div>";
    expect(() => initPieGraph()).not.toThrow();
  });

  it("should initialize pie graph containers", () => {
    const originalIO = (window as any).IntersectionObserver;
    // provide a noop IntersectionObserver so initPieGraph does not treat
    // the element as intersecting immediately in JSDOM environments
    (window as any).IntersectionObserver = class {
      observe() {}
      disconnect() {}
    } as any;
    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="75" data-graph-suffix="%"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
            <circle class="ecomm-report-pie-graph__base-circle"></circle>
        </div>
    `;

    initPieGraph();
    container = document.querySelector(".ecomm-report-pie-graph")!;

    expect(container.style.getPropertyValue("--percentage-value")).toBe("0");
    if (originalIO === undefined) delete (window as any).IntersectionObserver;
    else (window as any).IntersectionObserver = originalIO;
  });

  it("should use fallback animation when IntersectionObserver is not supported", () => {
    const originalIO = (window as any).IntersectionObserver;
    delete (window as any).IntersectionObserver;

    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="50" data-graph-suffix="%"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
            <circle class="ecomm-report-pie-graph__base-circle"></circle>
        </div>
    `;

    initPieGraph();
    container = document.querySelector(".ecomm-report-pie-graph")!;

    expect(container.classList.contains(ANIMATION_CLASS_NAME)).toBe(true);
    expect(container.style.getPropertyValue("--percentage-value")).toBe("50");

    if (originalIO === undefined) delete (window as any).IntersectionObserver;
    else (window as any).IntersectionObserver = originalIO;
  });

  it("should set default suffix to % when data-graph-suffix is not provided", () => {
    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="100"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
        </div>
    `;

    initPieGraph();
    const textElement = document.querySelector(".percentage-text")!;

    expect(textElement.innerHTML).toContain("%");
  });

  it("should handle multiple containers", () => {
    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="25" data-graph-suffix="%"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
            <circle class="ecomm-report-pie-graph__base-circle"></circle>
        </div>
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="75" data-graph-suffix="%"></div>
            <circle class="ecomm-report-pie-graph__base-circle"></circle>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
        </div>
    `;

    initPieGraph();
    const containers = document.querySelectorAll(".ecomm-report-pie-graph");

    expect(containers.length).toBe(2);
  });

  it("should set circle transition on fallback animation", () => {
    const originalIO = (window as any).IntersectionObserver;
    delete (window as any).IntersectionObserver;

    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="50" data-graph-suffix="%"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
        </div>
    `;

    initPieGraph();
    const circle = document.querySelector(".ecomm-report-pie-graph__progress-circle") as SVGCircleElement;

    expect(circle.style.transition).toBeTruthy();
    expect(circle.style.transition).toContain("stroke-dashoffset");
    if (originalIO === undefined) delete (window as any).IntersectionObserver;
    else (window as any).IntersectionObserver = originalIO;
  });

  it("should use custom suffix when provided", () => {
    const originalIO = (window as any).IntersectionObserver;
    delete (window as any).IntersectionObserver;

    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="50" data-graph-suffix="pts"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
        </div>
    `;

    initPieGraph();
    const textElement = document.querySelector(".percentage-text")!;

    expect(textElement.innerHTML).toContain("pts");
    if (originalIO === undefined) delete (window as any).IntersectionObserver;
    else (window as any).IntersectionObserver = originalIO;
  });

  it("should handle missing percentage-text element gracefully", () => {
    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
        </div>
    `;

    expect(() => initPieGraph()).not.toThrow();
  });

  it("should handle zero value correctly", () => {
    const originalIO = (window as any).IntersectionObserver;
    delete (window as any).IntersectionObserver;

    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="0" data-graph-suffix="%"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
        </div>
    `;

    initPieGraph();
    container = document.querySelector(".ecomm-report-pie-graph")!;

    expect(container.style.getPropertyValue("--percentage-value")).toBe("0");
    if (originalIO === undefined) delete (window as any).IntersectionObserver;
    else (window as any).IntersectionObserver = originalIO;
  });

  it("should handle invalid graph-value gracefully", () => {
    const originalIO = (window as any).IntersectionObserver;
    delete (window as any).IntersectionObserver;

    document.body.innerHTML = `
        <div class="ecomm-report-pie-graph">
            <div class="percentage-text" data-graph-value="invalid" data-graph-suffix="%"></div>
            <circle class="ecomm-report-pie-graph__progress-circle"></circle>
        </div>
    `;

    expect(() => initPieGraph()).not.toThrow();
    (window as any).IntersectionObserver = originalIO;
  });
});

describe("getTransition", () => {
  it("should generate correct transition string", () => {
    const result = getTransition(1000);
    expect(result).toBe("stroke-dashoffset 900ms ease-in-out");
  });

  it("should calculate duration correctly for different values", () => {
    const result = getTransition(2000);
    expect(result).toBe("stroke-dashoffset 1800ms ease-in-out");
  });
});

describe("animateNumber", () => {
  beforeEach(() => {
    jest.useFakeTimers();
    jest.spyOn(window, "requestAnimationFrame").mockImplementation((cb) => {
      cb(0);
      return 0;
    });
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.restoreAllMocks();
  });

  it("should animate from start to end value", () => {
    const element = document.createElement("div");
    animateNumber(element, 0, 100, 1000, "%");

    expect(element.innerHTML).toBeTruthy();
  });

  it("should pad numbers to 2 digits", () => {
    const element = document.createElement("div");
    animateNumber(element, 0, 5, 1000, "%");

    expect(element.innerHTML).toContain("0");
  });

  it("should apply suffix to animated number", () => {
    const element = document.createElement("div");
    animateNumber(element, 0, 50, 1000, "%");

    expect(element.innerHTML).toContain("%");
  });

  it("should work without suffix", () => {
    const element = document.createElement("div");
    animateNumber(element, 0, 75, 1000);

    expect(element.innerHTML).toBeTruthy();
  });

  it("should handle animation start correctly", () => {
    const element = document.createElement("div");
    animateNumber(element, 10, 50, 1000, "");

    expect(parseInt(element.innerHTML)).toBeGreaterThanOrEqual(10);
  });
});

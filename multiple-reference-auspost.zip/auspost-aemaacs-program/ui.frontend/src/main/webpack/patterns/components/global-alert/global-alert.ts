export function showAlertIfNotDismissed(alert: Element, alertId: string): boolean {
  if (sessionStorage.getItem(`alert-dismissed-${alertId}`)) {
    // User has dismissed alert previously, do not show it and remove from the DOM
    alert.remove();
    return true;
  } else {
    // Show alert if user hasn't dismissed it previously, preventing flash on load
    alert.classList.remove('hide');
    return false;
  }
}

export function dismissAlert(closeBtn: Element, alert: Element, alertId: string): void {
  closeBtn.addEventListener('click', () => {
    alert.remove();
    sessionStorage.setItem(`alert-dismissed-${alertId}`, 'true');
  });
}

export function initGlobalAlertClose(): void {
  const alerts = document.querySelectorAll('.global-alert');
  alerts.forEach(alert => {
    const closeBtn = alert.querySelector('.alert-close');
    if (!closeBtn) return;

    const alertId = alert.id;

    showAlertIfNotDismissed(alert, alertId);
    dismissAlert(closeBtn, alert, alertId);
  });
}


window.addEventListener('load', () => {
  initGlobalAlertClose();
});

export default function initCTASection(): void {
  const contentToggleClass = "show-menu";
  const dropdownBtns = document.querySelectorAll<HTMLButtonElement>(
    ".ecomm-cta-section__dropdown > .button"
  );
  const dropdownMenus = document.querySelectorAll<HTMLElement>(
    ".ecomm-cta-section__dropdown-content"
  );

  const closeAll = (): void => {
    dropdownMenus.forEach((menu) => menu.classList.remove(contentToggleClass));
  };

  const toggleDropdown = (menu: HTMLElement): void => {
    menu.classList.toggle(contentToggleClass);
  };

  dropdownBtns.forEach((btn, index) => {
    const menu = dropdownMenus[index] ?? (btn.nextElementSibling as HTMLElement | null);
    if (!menu) return;
    btn.addEventListener("click", (e: MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      toggleDropdown(menu);
    });
  });

  document.addEventListener("click", (e: MouseEvent) => {
    const target = e.target as Node | null;
    let clickedInside = false;

    dropdownBtns.forEach((btn) => {
      if ((btn as Node).contains(target)) clickedInside = true;
    });

    dropdownMenus.forEach((menu) => {
      if (menu.contains(target)) clickedInside = true;
    });

    if (!clickedInside) {
      closeAll();
    }
  });
}

initCTASection();
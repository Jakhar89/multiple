import React from "react";
import ERIcon from "../Icons/ERIcon";
import { SuggestedSearchProps } from "../store/ERSearchInterface";

export default function ERSuggestedSearches({
  title,
  items,
  onSuggestionSelect,
}: SuggestedSearchProps) {
  const handleClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    value: string,
  ) => {
    e.preventDefault();
    onSuggestionSelect && onSuggestionSelect(value);
  };

  return (
    <div className="search-suggestions" aria-labelledby="search-heading">
      {title && (
        <strong id="search-heading" className="heading m-b-400 d-flex">
          {title}
        </strong>
      )}

      <ul className="search-list list-style-none" role="list">
        {items.map((item, index) => (
          <li key={index} className="search-list-item">
            <a
              href="#"
              className="search-label"
              onClick={(e) => handleClick(e, item.label)}
              aria-label={item.label}
            >
              <span className="search-icon m-t-50" aria-hidden="true">
                <ERIcon name="search" colorClass="icon--fill-grey" />
              </span>
              <span className="search-text">{item.label}</span>
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

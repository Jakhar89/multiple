import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import TextInput from './TextInput';

describe('TextInput', () => {
  test('shows clear button when value present and clearable', () => {
    render(<TextInput value="abc" onChange={jest.fn()} />);
    const input = screen.getByRole('textbox');
    expect(input).toBeTruthy();
    const clearBtn = screen.getByRole('button', { name: /clear text/i });
    expect(clearBtn).toBeTruthy();
  });

  test('hides clear button when value empty or clearable=false', () => {
    const { rerender } = render(<TextInput value="" onChange={jest.fn()} />);
    expect(screen.queryByRole('button', { name: /clear text/i })).toBeNull();

    rerender(<TextInput value="abc" clearable={false} onChange={jest.fn()} />);
    expect(screen.queryByRole('button', { name: /clear text/i })).toBeNull();
  });

  test('hides clear button when disabled', () => {
    render(<TextInput value="abc" disabled onChange={jest.fn()} />);
    expect(screen.queryByRole('button', { name: /clear text/i })).toBeNull();
  });

  test('clicking clear calls onClear when provided and does not call onChange', () => {
    
    const onChange = jest.fn();
    const onClear = jest.fn();
    render(<TextInput value="abc" onChange={onChange} onClear={onClear} />);

    const clearBtn = screen.getByRole('button', { name: /clear text/i });
    fireEvent.click(clearBtn);

    expect(onChange).not.toHaveBeenCalled();
    expect(onClear).toHaveBeenCalledTimes(1);
  });

  test('clicking clear without onClear empties and calls onChange with empty value', () => {
    const onChange = jest.fn();
    render(<TextInput value="abc" onChange={onChange} />);

    const clearBtn = screen.getByRole('button', { name: /clear text/i });
    fireEvent.click(clearBtn);

    expect(onChange).toHaveBeenCalledTimes(1);
    const ev = onChange.mock.calls[0][0] as React.ChangeEvent<HTMLInputElement>;
    expect(ev.currentTarget.value).toBe('');
  });

  test('Escape key does not clear but still calls onKeyDown', () => {
    const onChange = jest.fn();
    const onKeyDown = jest.fn();
    render(<TextInput value="abc" onChange={onChange} onKeyDown={onKeyDown} />);

    const input = screen.getByRole('textbox');
    fireEvent.keyDown(input, { key: 'Escape' });

    expect(onChange).not.toHaveBeenCalled();
    expect(onKeyDown).toHaveBeenCalledTimes(1);
  });
});

import { faker } from '@faker-js/faker';

export const message = `${faker.lorem.sentence(20)} <a href="#">${faker.lorem.words(3)}</a> ${faker.lorem.sentence(5)}`;
export const messageWithLink = `${faker.lorem.sentence(50)} <a href="#">${faker.lorem.words(3)}</a> ${faker.lorem.sentence(5)}`;


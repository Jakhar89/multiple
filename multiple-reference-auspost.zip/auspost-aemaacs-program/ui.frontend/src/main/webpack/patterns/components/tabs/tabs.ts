import { TabElements } from './interfaces';

export function getTabElements(container: HTMLElement): TabElements {
    return {
        outer: container.querySelector<HTMLElement>('.tabs-list-wpr')!,
        list: container.querySelector<HTMLElement>('.tabs-list')!,
        btnNext: container.querySelector<HTMLButtonElement>('.tabs-next')!,
        btnPrev: container.querySelector<HTMLButtonElement>('.tabs-prev')!,
        select: container.querySelector<HTMLSelectElement>('.cmp-tabs-select'),
        tabs: Array.from(container.querySelectorAll<HTMLElement>('.cmp-tabs__tab')),
        tabpanels: Array.from(container.querySelectorAll<HTMLElement>('.cmp-tabs__tabpanel'))
    };
}

export function updateArrowStates(
    scroller: HTMLElement,
    btnPrev: HTMLButtonElement,
    btnNext: HTMLButtonElement
): void {
    const maxScroll = Math.max(scroller.scrollWidth - scroller.clientWidth, 0);
    const { scrollLeft } = scroller as HTMLElement & { scrollLeft: number };

    const atStart = scrollLeft <= 10;
    const atEnd = scrollLeft >= maxScroll - 10;

    btnPrev.style.display = atStart ? 'none' : '';
    btnNext.style.display = atEnd ? 'none' : '';
}

/**
 * Scroll the given tab into the horizontal center of the scrollable list.
 * Keeps arrow states in sync after the scroll animation.
 */
function scrollTabIntoCenter(
    scroller: HTMLElement,
    tab: HTMLElement,
    btnPrev?: HTMLButtonElement,
    btnNext?: HTMLButtonElement
): void {
    const tabCenter = tab.offsetLeft + tab.offsetWidth / 2;
    const maxScroll = Math.max(scroller.scrollWidth - scroller.clientWidth, 0);
    const target = Math.min(Math.max(tabCenter - scroller.clientWidth / 2, 0), maxScroll);

    scroller.scrollTo({ left: target, behavior: 'smooth' });

    if (btnPrev && btnNext) {
        setTimeout(() => updateArrowStates(scroller, btnPrev, btnNext), 200);
    }
}

export function scrollTabs(
    scroller: HTMLElement,
    amount: number,
    btnPrev: HTMLButtonElement,
    btnNext: HTMLButtonElement
): void {
    const currentScroll = scroller.scrollLeft;
    const maxScroll = Math.max(scroller.scrollWidth - scroller.clientWidth, 0);
    const newScroll = Math.min(Math.max(currentScroll + amount, 0), maxScroll);

    scroller.scrollTo({ left: newScroll, behavior: 'smooth' });

    setTimeout(() => updateArrowStates(scroller, btnPrev, btnNext), 300);
}

export function setupTabsScroll(container: HTMLElement): void {
    const { outer, list, btnPrev, btnNext } = getTabElements(container);
    if (!outer || !list || !btnPrev || !btnNext) return;

    const SCROLL_AMOUNT = 180;

    btnPrev.addEventListener('click', () => scrollTabs(list, -SCROLL_AMOUNT, btnPrev, btnNext));
    btnNext.addEventListener('click', () => scrollTabs(list, SCROLL_AMOUNT, btnPrev, btnNext));
    // Bind scroll only on the chosen scroller
    list.addEventListener('scroll', () => updateArrowStates(list, btnPrev, btnNext));
    window.addEventListener('resize', () => {
        updateArrowStates(list, btnPrev, btnNext);

        const activeTab = list.querySelector<HTMLElement>('.cmp-tabs__tab--active');
        if (activeTab) {
            scrollTabIntoCenter(list, activeTab, btnPrev, btnNext);
    }
});

    updateArrowStates(list, btnPrev, btnNext);
}

export function activateTab(
    tabs: HTMLElement[],
    tabpanels: HTMLElement[],
    select: HTMLSelectElement | null,
    index: number,
    updateHash = true
): void {
    tabs.forEach((tab, i) => {
        const isActive = i === index;
        tab.classList.toggle('cmp-tabs__tab--active', isActive);
        tab.setAttribute('tabindex', isActive ? '0' : '-1');
        tab.setAttribute('aria-selected', String(isActive));
    });

    tabpanels.forEach((panel, i) => {
        const isActive = i === index;
        panel.classList.toggle('cmp-tabs__tabpanel--active', isActive);
        panel.setAttribute('aria-hidden', String(!isActive));
    });

    if (select) select.value = String(index);

    if (updateHash && tabs[index]?.id) {
        window.location.hash = `#${tabs[index].id}`;
    }
}

export function setupTabs(container: HTMLElement): void {
    setupTabsScroll(container);

    const { select, tabs, tabpanels, list, btnPrev, btnNext } = getTabElements(container);
    if (!tabs.length || tabs.length !== tabpanels.length) return;

    const total = tabs.length;

    const setActive = (index: number, updateHash = true) => {
        if (index < 0 || index >= total) return;
        activateTab(tabs, tabpanels, select, index, updateHash);
        const tab = tabs[index];
        if (tab && list) {
            scrollTabIntoCenter(list, tab, btnPrev ?? undefined, btnNext ?? undefined);
        }
    };

    const focusTab = (index: number) => tabs[index]?.focus();

    if (select) {
        select.addEventListener('change', () => {
            const idx = Math.min(Math.max(Number(select.value) || 0, 0), total - 1);
            setActive(idx);
            focusTab(idx);
        });
    }

    // Delegated events on the tab list container
    if (list) {
        list.addEventListener('click', (e: Event) => {
            const target = (e.target as HTMLElement).closest<HTMLElement>('.cmp-tabs__tab');
            if (!target) return;
            e.preventDefault();
            const i = tabs.indexOf(target);
            if (i !== -1) setActive(i);
        });

        list.addEventListener('keydown', (e: KeyboardEvent) => {
            const activeEl = (e.target as HTMLElement).closest<HTMLElement>('.cmp-tabs__tab');
            if (!activeEl) return;
            const i = tabs.indexOf(activeEl);
            if (i === -1) return;

            const { key } = e;
            let next = -1;

            if (key === 'ArrowRight') next = (i + 1) % total;
            else if (key === 'ArrowLeft') next = (i - 1 + total) % total;
            else if (key === 'Home') next = 0;
            else if (key === 'End') next = total - 1;
            else if (key === 'Enter' || key === ' ') next = i;

            if (next !== -1) {
                e.preventDefault();
                setActive(next);
                focusTab(next);
            }
        });

        // When a tab gains focus (e.g., via Tab key), center it in the scroller
        list.addEventListener('focusin', (e: FocusEvent) => {
            const target = (e.target as HTMLElement).closest<HTMLElement>('.cmp-tabs__tab');
            if (!target) return;
            if (list) {
                scrollTabIntoCenter(list, target, btnPrev ?? undefined, btnNext ?? undefined);
            }
        });
    }

    const { hash } = window.location;
    const initialIndex = hash ? tabs.findIndex(t => `#${t.id}` === hash) : -1;
    if (initialIndex >= 0) {
        setTimeout(() => setActive(initialIndex, false), 300);
        focusTab(initialIndex);
    } else {
        const currentActive = tabs.findIndex(t => t.classList.contains('cmp-tabs__tab--active'));
        if (currentActive === -1) {
            setActive(0, false);
        } else if (list && currentActive >= 0) {

            const center = () => scrollTabIntoCenter(list, tabs[currentActive], btnPrev ?? undefined, btnNext ?? undefined);

            requestAnimationFrame(center);
            setTimeout(center, 0);
        }
    }

    // Keep selection in sync when the URL hash changes (e.g., back/forward)
    const onHashChange = () => {
        const { hash: newHash } = window.location;
        if (!newHash) return;
        const idx = tabs.findIndex(t => `#${t.id}` === newHash);
        if (idx >= 0) {
            setActive(idx, false);
            focusTab(idx);
        }
    };
    window.addEventListener('hashchange', onHashChange);
}

export function initTabs(): void {
    document.querySelectorAll<HTMLElement>('.cmp-tabs').forEach(setupTabs);
}

window.addEventListener('load', initTabs);

import React from 'react';
import { render, screen } from '@testing-library/react';
import { fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import Results from './Results';
import { SearchProvider } from '../SearchUtils/searchContext';

function renderWithContext(ui: React.ReactElement, { url = 'https://example.com/', ctxOverrides = {} } = {}) {
  window.history.replaceState(null, '', url);

  const ctx = {
    searchField: {
      label: 'Search',
      buttonText: 'Search',
      placeholder: 'Search…',
      redirectUrl: '/search',
      autocomplete: false
    },
    popularSearch: { title: '', items: [] },
    autocompleteUrl: undefined,
    searchApiUrl: '',
    resultPageSize: 5,
    ...ctxOverrides
  };

  return render(<SearchProvider value={ctx}>{ui}</SearchProvider>);
}

describe('Results', () => {
  test('uses query from URL on mount and shows heading', () => {
    renderWithContext(<Results />, { url: '/?q=hello' });

    const heading = screen.getByRole('heading', { level: 2 });
    expect(heading).toHaveTextContent('Showing results for');
    expect(heading).toHaveTextContent('hello');

    const input = screen.getByRole('combobox');
    expect(input).toHaveValue('hello');
  });

  test('updates URL and heading on submit', async () => {
    renderWithContext(<Results />, { url: '/page' });

    const input = screen.getByRole('combobox');
    fireEvent.change(input, { target: { value: 'world' } });

    const submitBtn = screen.getByRole('button', { name: 'Search' });
    fireEvent.click(submitBtn);

    const heading = await screen.findByRole('heading', { level: 2 });
    expect(heading).toHaveTextContent('world');
    expect(window.location.search).toBe('?q=world');
  });

  test('does not show results count when there are no items', () => {
    renderWithContext(<Results />, { url: '/?q=' });

    expect(screen.queryByText(/of .* items/i)).toBeNull();

    const resultsContainer = screen.getByText(/Showing results for/i).parentElement as HTMLElement;
    expect(resultsContainer).toHaveAttribute('aria-live', 'polite');
  });
});

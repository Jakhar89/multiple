import type { Meta, StoryObj } from '@storybook/html-vite';
import { IconCardProps } from './interfaces';
import { ICON_CARD } from './_icon-card.mock';
import component from './icon-card.liquid';

const meta = {
  title: 'Components/Icon Card',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  argTypes: {
    containerTheme: {
      control: { type: 'select' },
      options: ['theme-auspost', 'theme-startrack']
    },
    contentAlignment: {
      control: { type: 'select' },
      options: ['left', 'center']
    }
  },
  args: {
    renderMode: true,
    containerTheme: 'theme-auspost',
    contentAlignment: ICON_CARD.contentAlignment,
    heading: ICON_CARD.heading,
    description: ICON_CARD.description,
    icon: ICON_CARD.icon,
    links: ICON_CARD.links
  }
} satisfies Meta<IconCardProps>;

export default meta;
type Story = StoryObj<IconCardProps>;

export const IconCard: Story = {
};

export const IconCardCenterAligned: Story = {
  args: {
    contentAlignment: 'center'
  }
};

export const IconCardWithSingleLinks: Story = {
  args: {
    links: [{ linkStyle: 'tertiary-link', ctaLabel: 'Courier', ctaUrl: '#' }]
  }
};

export const IconCardWithMultipleLinks: Story = {
  args: {
    links: [{ linkStyle: 'standard-link', ctaLabel: 'Courier', ctaUrl: '#' }, { linkStyle: 'standard-link', ctaLabel: 'Next Flight', ctaUrl: '#' }]
  }
};

export const IconCardWithBlueTheme: Story = {
  args: {
    containerTheme: 'theme-startrack',
    links: [{ linkStyle: 'standard-link', ctaLabel: 'Courier', ctaUrl: '#' }, { linkStyle: 'standard-link', ctaLabel: 'Next Flight', ctaUrl: '#' }]
  }
};
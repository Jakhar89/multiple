import type { Meta, StoryObj } from '@storybook/html-vite';
import type { TextProps } from './interface';
import { mockText, mockTextLong, mockTextShort } from './_text.mock';
import textComponent from './text.liquid';
import initText from './text';

const meta: Meta<TextProps> = {
  title: 'Components/Text',
  component: textComponent,
  parameters: {},
  args: mockText,
};

export default meta;
type Story = StoryObj<TextProps>;

export const Default: Story = {
  args: {
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initText();
  }
};

export const LongQuote: Story = { args: mockTextLong };

export const ShortQuote: Story = { args: mockTextShort };

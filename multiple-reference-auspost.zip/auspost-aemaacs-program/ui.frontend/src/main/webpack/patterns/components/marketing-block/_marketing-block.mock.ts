import { faker } from '@faker-js/faker';
import type { MarketingBlockProps } from './interfaces';

export const MARKETING_BLOCK_DATA: MarketingBlockProps = {
  fullWidth: 'default',
  backgroundColor: 'bg-grey',
  image: {
    src: "/src/main/webpack/patterns/assets/images/marketing-block-img.jpg",
    alt: faker.lorem.words(2),
  },
  imagePosition: 'image-left',
  imageType: 'swoosh-image', 
  heading : faker.lorem.sentence(4),
  description : faker.lorem.sentences(2),
  ctas: [{ type: 'primary', label: faker.lorem.words(2) }, { type: 'tertiary', label: faker.lorem.words(2) }],
  logoList: ['/src/main/webpack/patterns/assets/images/shopify-logo.png',
    '/src/main/webpack/patterns/assets/images/bigcommerce-logo.png',
    '/src/main/webpack/patterns/assets/images/salesforce-logo.png',
    '/src/main/webpack/patterns/assets/images/shipstation-logo.png'],
  qrBlock:false,
  qrCode: '/src/main/webpack/patterns/assets/images/qr-code.png',
  qrText: 'Scan the QR code or tap the buttons below to download the AusPost app.',
  qrCTA: ['/src/main/webpack/patterns/assets/images/appstore-button.png','/src/main/webpack/patterns/assets/images/googlePlay-button.png']
}

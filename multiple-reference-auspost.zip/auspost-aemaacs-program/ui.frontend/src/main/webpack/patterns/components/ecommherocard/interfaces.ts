export interface EcommHeroCardItem {
    title: string;
    description: string;
    imageUrl: string;
    imageAlt: string;
    href: string;
    titleIcon?: string;
}

export interface EcommHeroSearchTile {
    label: string;
    title: string;
    placeholder: string;
    description: string;
    labelIcon?: string;
    searchIcon?: string;
    searchBgImageUrl?: string;
    searchBgImageAlt?: string;
}

export interface EcommHeroCardProps {
    cards: EcommHeroCardItem[];
    searchTile: EcommHeroSearchTile;
}

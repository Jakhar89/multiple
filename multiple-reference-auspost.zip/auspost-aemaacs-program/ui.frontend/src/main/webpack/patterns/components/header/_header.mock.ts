import { faker } from '@faker-js/faker';
import { FeatureCard, HeaderContent, HeaderProps, MainMenuNavItem } from './interfaces';

export const PROMO_CARD_RED: FeatureCard = {
  style: 'red',
  image: '/src/main/webpack/patterns/assets/images/businessCard.svg',
  heading: faker.company.name(),
  description: faker.lorem.sentence(),
  links: [
    {
      label: faker.lorem.words(3),
      url: '#',
      icon: 'arrow-right',
    },
  ],
}

export const PROMO_CARD_GREY: FeatureCard = {
  ...PROMO_CARD_RED,
  style: 'grey'
}

export const personalNavItem: MainMenuNavItem = {
  toggleId: 'personal',
  label: 'Personal',
  megaMenu: {
    id: 'item-1',
    submenu: Array.from({ length: faker.number.int({ min: 1, max: 3 }) }).map(() => ({
      heading: faker.lorem.words(3),
      submenuChildren: Array.from({ length: 3 }).map(() => ({
        label: faker.company.catchPhrase(),
        url: '#',
      })),
    })).concat([
      {
        heading: "Single header",
        submenuChildren: [],
      }
    ]),
    customSubmenu: [
      {
        heading: `Personal Custom Nav`,
        submenuChildren: Array.from({ length: 3 }).map(() => ({
          label: faker.lorem.words(3),
          url: '#',
        })),
      },
    ],
    featureCard: undefined,
  },
};

export const businessNavItem: MainMenuNavItem = {
  toggleId: 'business',
  label: 'Business',
  megaMenu: {
    id: 'item-2',
    submenu: Array.from({ length: faker.number.int({ min: 1, max: 3 }) }).map(() => ({
      heading: faker.lorem.words(3),
      submenuChildren: Array.from({ length: 3 }).map(() => ({
        label: faker.company.catchPhrase(),
        url: '#',
      })),
    })).concat([
      {
        heading: "Single header",
        submenuChildren: [],
      }
    ]),
    customSubmenu: [
      {
        heading: `Business Custom Nav`,
        submenuChildren: Array.from({ length: 3 }).map(() => ({
          label: faker.lorem.words(3),
          url: '#',
        })),
      },
    ],
    featureCard: PROMO_CARD_RED,
  },
};

export const enterpriseNavItem: MainMenuNavItem = {
  toggleId: 'enterprise',
  label: 'Enterprise',
  megaMenu: {
    id: 'item-3',
    submenu: Array.from({ length: faker.number.int({ min: 1, max: 3 }) }).map(() => ({
      heading: faker.lorem.words(3),
      submenuChildren: Array.from({ length: 3 }).map(() => ({
        label: faker.company.catchPhrase(),
        url: '#',
      })),
    })).concat([
      {
        heading: "Single header",
        submenuChildren: [],
      }
    ]),
    customSubmenu: [
      {
        heading: `Enterprise Custom Nav`,
        submenuChildren: Array.from({ length: 3 }).map(() => ({
          label: faker.lorem.words(3),
          url: '#',
        })),
      },
    ],
    featureCard: PROMO_CARD_RED,
  },
};

export const emptyNavItem: MainMenuNavItem = {
  toggleId: 'empty',
  label: 'Empty Link',
  megaMenu: {
    id: 'item-4',
    submenu: [],
    customSubmenu: [],
    featureCard: PROMO_CARD_RED,
  },
};

export const HEADER_MOCK: HeaderContent = {
  mainNav: [personalNavItem, businessNavItem, enterpriseNavItem, emptyNavItem],
  topNav: {
    utilityLinks: [
      {
        label: 'Support',
        url: '#',
        icon: 'support',
      },
      {
        label: 'Locations',
        url: '#',
        icon: 'location',
      },
    ],
    search: {
      icon: 'search',
      placeholder: faker.lorem.words(3),
    },
    login: {
      label: 'Log in',
      dropdownItems: Array.from({ length: 6 }).map(() => ({
        label: faker.company.name(),
        url: '#',
      })),
    },
  },
};

import { fetchApiPost } from "../../../../scripts/utils/api";
import { AiSearchInsight, AiSearchResult, KeywordSearchProps } from "../store/ERSearchInterface";
import {
  ANSWER_QUERY_REQUEST_BODY_STRUCTURE,
  SEARCH_QUERY_REQUEST_BODY_STRUCTURE,
} from "./constants";

export function normalizeSuggestions(data: unknown): string[] {
  if (Array.isArray(data)) {
    return data.map(String).filter(Boolean);
  }

  if (data && typeof data === "object") {
    const list =
      (data as any).suggestions ||
      (data as any).querySuggestions ||
      (data as any).items ||
      [];

    if (Array.isArray(list)) {
      return list
        .map((item: any) =>
          typeof item === "string"
            ? item
            : (item?.suggestion ??
              item?.text ??
              item?.label ??
              item?.value ??
              ""),
        )
        .filter(Boolean);
    }
  }

  return [];
}

export type SessionInfoProps = {
  name?: string;
  queryId?: string;
  sessionId?: string;
};

export type KeywordSearchResultProps = {
  items?: string[];
  sessionInfo: SessionInfoProps;
};

export function extractInfoForAIApi(data: any): KeywordSearchResultProps {
  const result: KeywordSearchResultProps = {} as any;
  if (data && typeof data === "object") {
    const list = data?.answers || data?.results || data?.items || [];

    if (Array.isArray(list)) {
      result.items = list;
    }
  }

  if (typeof data?.sessionInfo?.name === "string") {
    const m = data.sessionInfo.name.match(/\/sessions\/([^\/]+)(?:\/|$)/);
    if (m) {
      result.sessionInfo = { ...(data.sessionInfo || {}), sessionId: m[1] };
    }
  }

  return result;
}

export function getHighlightParts(text: string, query: string) {
  if (!query) {
    return { before: text, match: "", after: "" };
  }

  const lowerText = text.toLowerCase();
  const lowerQuery = query.toLowerCase();
  const index = lowerText.indexOf(lowerQuery);

  if (index === -1) {
    return { before: text, match: "", after: "" };
  }

  return {
    before: text.slice(0, index),
    match: text.slice(index, index + query.length),
    after: text.slice(index + query.length),
  };
}

export async function getConfigForAnswerSearch({
  query,
  keywordSearchUrl,
  sessionId,
}: KeywordSearchProps) {
  let active = true;
  if (!query.trim()) {
    return;
  }

  try {
    const requestBody = SEARCH_QUERY_REQUEST_BODY_STRUCTURE;
    requestBody.query = query;
    const enginePathMatch = keywordSearchUrl.match(
      /projects\/[^\/]+\/locations\/global\/collections\/[^\/]+\/engines\/[^\/]+\//,
    );

    if (enginePathMatch) {
      requestBody.session = `${enginePathMatch[0]}sessions/${sessionId !== "" ? sessionId : "-"}`;
    }

    const response = await fetchApiPost(keywordSearchUrl, requestBody);

    if (active) {
      return extractInfoForAIApi(response);
    }
  } catch {
  } finally {
    active = false;
  }
}

export async function getAiAnswer({
  query,
  answerUrl,
  session,
}: {
  query: string;
  answerUrl: string;
  session: SessionInfoProps;
}): Promise<AiSearchResult | null> {
  const requestBody = ANSWER_QUERY_REQUEST_BODY_STRUCTURE;
  requestBody.query = {
    text: `${query} :answer`,
    queryId: session.queryId!,
  };
  requestBody.session = session.name!;
  const result = await fetchApiPost(answerUrl, requestBody);

  return transformAiAnswerResult(query, result);
}

export function transformAiAnswerResult(
  question: string,
  result: any,
): AiSearchResult | null {
  if (result === null || result === "") return null;

  const insights: AiSearchInsight[] = result.answer.references?.map(
    (ref: any) => ({
      content: ref.chunkInfo.content || "",
      documnentTitle: ref.chunkInfo.documentMetadata.title,
      documentId: ref.chunkInfo.documentMetadata.document,
      documentUrl: ref.chunkInfo.documentMetadata.url,
      relevanceScore: ref.chunkInfo.relevanceScore,
    }),
  );

  const answer = {
    text: result.answer.answerText,
    answerId: result.answer.name,
  };

  return {
    question,
    answer,
    insights,
  };
}

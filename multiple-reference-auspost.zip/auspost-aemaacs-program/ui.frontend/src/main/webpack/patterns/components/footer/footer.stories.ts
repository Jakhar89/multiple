import type { Meta, StoryObj } from '@storybook/html-vite';
import type { FooterProps } from './interfaces';
import { FOOTER_DATA, FOOTER_DATA_WITH_MULTIPLE_PRIMARY_LINKS, FOOTER_DATA_COLLECTABLE } from './_footer.mock';
import initFooter from './footer';

import component from './footer.liquid';

const meta = {
  title: 'Components/Footer',
  component: component,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: 'Footer component with collapsible navigation sections for mobile devices.'
      }
    }
  },
  args: {
    footer: FOOTER_DATA
  },
  argTypes: {
    footer: {
      description: 'Footer data object containing all navigation links and content'
    }
  }
} satisfies Meta<FooterProps>;

export default meta;
type Story = StoryObj<FooterProps>;

export const Default: Story = {
  args: {
    footer: FOOTER_DATA,
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initFooter();
  }
};

export const WithMultiplePrimaryLinks: Story = {
  args: {
    footer: {
      ...FOOTER_DATA,
      primaryLinks: FOOTER_DATA_WITH_MULTIPLE_PRIMARY_LINKS
    }
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initFooter();
  }
};

export const WithCollectableFooter: Story = {
  args: {
    footer: {
      ...FOOTER_DATA,
      ...FOOTER_DATA_COLLECTABLE
    }
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initFooter();
  }
};



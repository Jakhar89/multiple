import { normalizeSuggestions, getHighlightParts } from './Autosuggest.utils';

describe('normalizeSuggestions', () => {
  it('returns strings when given an array of strings', () => {
    const input = ['one', 'two', 'three'];
    expect(normalizeSuggestions(input)).toEqual(['one', 'two', 'three']);
  });

  it('coerces array items to strings and filters only empty strings', () => {
    const input = ['a', 2 as any, null as any, undefined as any, '', true as any];
    expect(normalizeSuggestions(input)).toEqual(['a', '2', 'null', 'undefined', 'true']);
  });

  it('reads from object.suggestions array (strings)', () => {
    const input = { suggestions: ['alpha', 'beta'] } as any;
    expect(normalizeSuggestions(input)).toEqual(['alpha', 'beta']);
  });

  it('reads from object.querySuggestions array (objects with suggestion)', () => {
    const input = { querySuggestions: [{ suggestion: 'mail' }, { suggestion: 'map' }] } as any;
    expect(normalizeSuggestions(input)).toEqual(['mail', 'map']);
  });

  it('reads from object.items array with various keys', () => {
    const input = {
      items: [
        { text: 'textVal' },
        { label: 'labelVal' },
        { value: 'valueVal' },
        { suggestion: 'suggestionVal' },
        { other: 'x' },
      ],
    } as any;
    expect(normalizeSuggestions(input)).toEqual([
      'textVal',
      'labelVal',
      'valueVal',
      'suggestionVal',
    ]);
  });

  it('returns empty array for invalid inputs', () => {
    expect(normalizeSuggestions(undefined as any)).toEqual([]);
    expect(normalizeSuggestions(null as any)).toEqual([]);
    expect(normalizeSuggestions({} as any)).toEqual([]);
    expect(normalizeSuggestions({ items: {} } as any)).toEqual([]);
  });
});

describe('getHighlightParts', () => {
  it('returns full text in before when query is empty', () => {
    expect(getHighlightParts('Australia Post', '')).toEqual({ before: 'Australia Post', match: '', after: '' });
  });

  it('returns no match when query not found', () => {
    expect(getHighlightParts('Australia Post', 'xyz')).toEqual({ before: 'Australia Post', match: '', after: '' });
  });

  it('matches case-insensitively and splits before/match/after', () => {
    expect(getHighlightParts('Australia Post', 'post')).toEqual({ before: 'Australia ', match: 'Post', after: '' });
    expect(getHighlightParts('Find a Post Office', 'post')).toEqual({ before: 'Find a ', match: 'Post', after: ' Office' });
  });

  it('matches first occurrence only', () => {
    expect(getHighlightParts('post post', 'post')).toEqual({ before: '', match: 'post', after: ' post' });
  });

  it('handles query at start and end boundaries', () => {
    expect(getHighlightParts('Postbox', 'post')).toEqual({ before: '', match: 'Post', after: 'box' });
    expect(getHighlightParts('Letterpost', 'post')).toEqual({ before: 'Letter', match: 'post', after: '' });
  });
});

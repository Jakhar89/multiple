import type { AnchorsProps } from './interfaces';

export const ANCHORS_LIST: AnchorsProps = {
    anchors: [
        {
            anchorLabel: 'Why us?',
            anchorPath: 'why-us-123'
        },
        {
            anchorLabel: 'Accordion',
            anchorPath: 'accordion-123'
        },
        {
            anchorLabel: 'Internation business letters and greeting cards',
            anchorPath: 'compare-id'
        },
        {
            anchorLabel: 'Shipping solution for business',
            anchorPath: 'eparcel-id'
        },
        {
            anchorLabel: 'Calculate postage',
            anchorPath: 'calculate-postage-id'
        },
        {
            anchorLabel: 'Help',
            anchorPath: 'help-id'
        },
        {
            anchorLabel: 'Text Component',
            anchorPath: 'text-id'
        },
        {
            anchorLabel: 'Text Component 2',
            anchorPath: 'text-id2'
        }
    ]
};

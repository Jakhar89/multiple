import { faker } from '@faker-js/faker';
import { BannerProps } from '../interfaces';

export const PROMO_BANNER_DATA: BannerProps = {
  variant: 'promo',
  backgroundColor: 'white',
  category: {
    label: '2025 ANDA Perth Money Expo',
    bgColor: 'red',
    textColor: 'white'
  },
  label: '',
  heading: faker.lorem.sentence(3),
  description: '',
  issueDate: `Issue date: ${faker.date
    .between({ from: '2020-01-01', to: '2025-12-31' })
    .toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    })}`,
  cta: true,
  backgroundImage: {
    src: 'src/main/webpack/patterns/assets/images/banner-background.png',
    alt: 'Abstract pastel background'
  },
  image: {
    src: 'src/main/webpack/patterns/assets/images/stamp-portrait.png',
    alt: 'Abstract pastel background'
  }
};

import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './column-container.liquid';

const meta = {
  title: 'Components/Column Container',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {
    desktopColumnCount: {
      control: { type: 'select' },
      options: ['4', '3', '2', '1'],
    },
    tabletColumnCount: {
      control: { type: 'select' },
      options: ['3', '2', '1'],
    },
    gap: {
      control: { type: 'select' },
      options: ['0', '8', '12', '16','24', '32', '40'],
    }
  },
  args: {
    desktopColumnCount:'4',
    tabletColumnCount:'3',
    gap:'32'
  }
} satisfies Meta;

export default meta;

export const Default: StoryObj = {
  args: {
    desktopColumnCount:'4',
    tabletColumnCount:'3',
    gap:'32'
  }
};

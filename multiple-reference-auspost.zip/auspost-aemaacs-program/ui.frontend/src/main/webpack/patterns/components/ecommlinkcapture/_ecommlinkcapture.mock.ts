export const MockLinkCaptureData = {
    title: "Ready to turn insights into action with Australia Post?",
    description:
        "Talk to one of our eCommerce specialists about how we can help grow your business.",
    cta: {
        label: "Get in touch",
        iconRight: "arrow-right-thin",
    },
};

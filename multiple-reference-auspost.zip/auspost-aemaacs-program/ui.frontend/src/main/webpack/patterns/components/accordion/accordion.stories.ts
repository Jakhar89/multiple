import type { Meta, StoryObj } from '@storybook/html-vite';
import type { Accordion } from './interfaces';
import { ACCORDION_DATA } from './_accordion.mock';

import accordion from './accordion.liquid';

const meta = {
  title: 'Components/Accordion',
  component: accordion,
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    accordion: ACCORDION_DATA,
  },
} satisfies Meta<{ accordion: Accordion }>;

export default meta;
type Story = StoryObj<{ accordion: Accordion }>;

export const Default: Story = {
  args: {
  },
};

export const AllClosed: Story = {
  args: {
    accordion: {
      ...ACCORDION_DATA,
      items: ACCORDION_DATA.items.map(item => ({
        ...item,
        expanded: false,
      })),
    },
  },
};

export const AllOpen: Story = {
  args: {
    accordion: {
      ...ACCORDION_DATA,
      items: ACCORDION_DATA.items.map(item => ({
        ...item,
        expanded: true,
      })),
    },
  },
};

export const FirstOpenOnly: Story = {
  args: {
    accordion: {
      ...ACCORDION_DATA,
      items: ACCORDION_DATA.items.map((item, index) => ({
        ...item,
        expanded: index === 0,
      })),
    },
  },
};




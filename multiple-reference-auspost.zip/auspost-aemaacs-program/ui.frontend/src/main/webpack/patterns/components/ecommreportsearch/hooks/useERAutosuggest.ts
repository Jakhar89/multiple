import { useEffect, useMemo, useState } from "react";
import { fetchApiPost } from "../../../../scripts/utils/api";
import { normalizeSuggestions } from "../utils/search.utils";
import { useERSearchContext } from "../store/ERSearchContext";
import { DEBOUNCE_DELAY_MS, MAX_SUGGESTIONS } from "../utils/constants";
import { AutoSuggestHookParams } from "../store/ERSearchInterface";

export function useAutosuggest({
  autocomplete,
  minChars,
  suggestions = [],
  value = "",
}: AutoSuggestHookParams) {
  const { autocompleteUrl } = useERSearchContext();
  const [inputValue, setInputValue] = useState("");
  const [activeIndex, setActiveIndex] = useState(-1);
  const [isOpen, setIsOpen] = useState(false);
  const [remoteSuggestions, setRemoteSuggestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const query = inputValue.trim();

  const sourceSuggestions = suggestions.length
    ? suggestions
    : remoteSuggestions;

  const visibleSuggestions = useMemo(() => {
    if (!autocomplete || query.length < minChars) return [];

    return sourceSuggestions
      .filter((item) => item.toLowerCase().includes(query.toLowerCase()))
      .slice(0, MAX_SUGGESTIONS);
  }, [autocomplete, query, minChars, sourceSuggestions]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (!visibleSuggestions.length) return;

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault();
        setIsOpen(true);
        setActiveIndex((prev) =>
          prev < 0 ? 0 : (prev + 1) % visibleSuggestions.length,
        );
        break;

      case "ArrowUp":
        e.preventDefault();
        setIsOpen(true);
        setActiveIndex((prev) =>
          prev < 0
            ? visibleSuggestions.length - 1
            : (prev - 1 + visibleSuggestions.length) %
              visibleSuggestions.length,
        );
        break;
    }
  };

  /* Remote fetch */
  useEffect(() => {
    if (value !== inputValue) {
      setInputValue(value);
    }

    if (!autocomplete || suggestions.length || query.length < minChars) {
      setRemoteSuggestions([]);
      setIsLoading(false);
      return;
    }
    const apiBase = autocompleteUrl;
    if (!apiBase) {
      setIsLoading(false);
      return;
    }

    let active = true;

    setIsLoading(true);
    const timer = setTimeout(async () => {
      try {
        const separator = apiBase.includes("?") ? "&" : "?";
        const url = `${apiBase}${separator}query=${encodeURIComponent(query)}`;
        const response = await fetchApiPost(url, {});

        if (active) {
          setRemoteSuggestions(normalizeSuggestions(response));
          setIsLoading(false);
        }
      } catch {
        if (active) {
          setRemoteSuggestions([]);
          setIsLoading(false);
        }
      }
    }, DEBOUNCE_DELAY_MS);

    return () => {
      active = false;
      clearTimeout(timer);
      setIsLoading(false);
    };
  }, [
    autocomplete,
    query,
    minChars,
    suggestions.length,
    autocompleteUrl,
    value,
  ]);

  return {
    inputValue,
    setInputValue,
    activeIndex,
    setActiveIndex,
    isOpen,
    setIsOpen,
    visibleSuggestions,
    handleKeyDown,
    isLoading,
  };
}

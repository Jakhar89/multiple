import React from "react";
import '@testing-library/jest-dom';
import { render, screen, within } from "@testing-library/react";
import ERAiLoader from "./ERAiLoader";

jest.mock("../Icons/ERIcon", () => {
  return {
    __esModule: true,
    default: ({ name }: { name?: string }) => (
      <svg data-testid="ERIcon" data-name={name} />
    ),
  };
});

jest.mock("./ERLoader", () => {
  return {
    __esModule: true,
    default: ({ skeletonCount, className }: any) => (
      <div
        data-testid="ERLoader"
        data-skeleton={String(skeletonCount)}
        data-class={className}
      />
    ),
  };
});

describe("ERAiLoader", () => {
  test("renders container, generating text and icon", () => {
    const { container } = render(<ERAiLoader />);
    expect(container.querySelector(".search-results-container")).toBeTruthy();
    expect(screen.getByText("Generating...")).toBeInTheDocument();
    const icon = screen.getByTestId("ERIcon");
    expect(icon).toHaveAttribute("data-name", "generative-ai");
  });

  test("renders top loader with skeletonCount=1 and className='white-loader'", () => {
    const { container } = render(<ERAiLoader />);
    const queryDiv = container.querySelector(".search-result-query")!;
    const loader = within(queryDiv as any).getByTestId("ERLoader");
    expect(loader).toHaveAttribute("data-skeleton", "1");
    expect(loader).toHaveAttribute("data-class", "white-loader");
  });

  test("renders AI results loader with skeletonCount=8 and className='ai-loader' inside loading wrapper", () => {
    const { container } = render(<ERAiLoader />);
    const resultsWrapper = container.querySelector(".search-results-wrapper.loading")!;
    const loader = within(resultsWrapper as any).getByTestId("ERLoader");
    expect(loader).toHaveAttribute("data-skeleton", "8");
    expect(loader).toHaveAttribute("data-class", "ai-loader");
  });
});

export type CTASectionMenuItem = {
  label: string;
  icon: string;
  url: string;
}

export type CTASectionButtonProps = {
  label: string;
  url?: string;
  iconLeft: string;
  helpText: string;
  menuItems?: CTASectionMenuItem[]
};

export enum CTASectionVariationEnum {
  FULL_PAGE = "full-page",
  INSIDE_MODAL = "inside-modal"

}

export type CTASectionFooterProps = {
  label: string;
  title: string;
  imageUrl: string;
  imageAlt: string;
  nextModalId: string;
}

export interface CTASectionDataProps {
  title: string;
  variant: CTASectionVariationEnum;
  description: string;
  primaryCta: CTASectionButtonProps;
  secondaryCta: CTASectionButtonProps;
  footer?: CTASectionFooterProps;
}

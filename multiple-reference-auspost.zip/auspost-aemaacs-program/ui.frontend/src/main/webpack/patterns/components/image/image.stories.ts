import type { Meta, StoryObj } from '@storybook/html-vite';
import type { ImageProps } from './interfaces';
import { caption, longCaption, downloadCaption, downloadSize } from './_image.mock';

import component from './image.liquid';

export default {
  title: 'Components/Image',
  component: component,
  argTypes: {
    aspectRatio: {
      control: { type: 'select' },
      options: ['', 'aspect-16x9', 'aspect-4x3'],
    },
    captionText: { control: 'text' },
    captionStyle: {
      control: { type: 'select' },
      options: ['', 'floating', 'connected'],
    },
    downloadHref: {
      control: { type: 'select' },
      options: ['', '/src/main/webpack/patterns/assets/files/australia-post-collectables-terms-of-use.pdf'],
    },
    downloadSize: { control: 'text'},
    imageHref: {
      control: { type: 'select' },
      options: ['', '/src/main/webpack/patterns/assets/images/photo-father-son-sending-parcels.jpeg'],
    },
    showCaption: { control: 'boolean'},

  },
  args: {
    aspectRatio: 'aspect-16x9',
    captionText: caption,
    imageHref: '/src/main/webpack/patterns/assets/images/photo-father-son-sending-parcels.jpeg',
    rounded: true,
    showCaption: true
  },
} satisfies Meta<ImageProps>;

type Story = StoryObj<ImageProps>;

export const Default: Story = {
};


export const Download: Story = {
  args: {
    captionText: downloadCaption,
    downloadHref: '/src/main/webpack/patterns/assets/files/australia-post-collectables-terms-of-use.pdf',
    downloadSize: downloadSize
  }
};

export const Connected: Story = {
  args: {
    captionStyle: 'connected'
  }
};

export const AspectRatio4x3: Story = {
  args: {
    aspectRatio: 'aspect-4x3',
    captionText: '4 / 3 aspect ratio',
  }
};

export const InheritAspectRatio: Story = {
  args: {
    aspectRatio: '',
    captionText: 'Inherit aspect ratio',
  }
};

export const LongCaption: Story = {
  args: {
    captionText: longCaption,
  }
};


export const NoCaption: Story = {
  args: {
    showCaption: false,
  }
};
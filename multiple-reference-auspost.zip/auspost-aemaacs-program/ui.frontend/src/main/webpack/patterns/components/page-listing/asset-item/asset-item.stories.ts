import type { Meta, StoryObj } from '@storybook/html-vite';
import { handleCardClick } from '../../../../scripts/utils/card-clickable';
import { MOCK_ASSET_ITEM, MOCK_ASSET_ITEM_LANDSCAPE, MOCK_ASSET_ITEM_SQUARE } from './_asset-listing.mock';
import component from './asset-item.liquid';

export default {
  title: 'Components/Page Listing/Asset Item',
  component: component,
  argTypes: {},
  args: {
    card: MOCK_ASSET_ITEM,
    isBlurred: true,
    renderMode: true
  }
} satisfies Meta;

export const Default: StoryObj = {
  args: {}
};

export const LandscapeImage: StoryObj = {
  args: {
    card: MOCK_ASSET_ITEM_LANDSCAPE
  }
};

export const SquareImage: StoryObj = {
  args: {
    card: MOCK_ASSET_ITEM_SQUARE
  }
};

export const FullCardClickableNoCta: StoryObj = {
  args: {
    card: {
      ...MOCK_ASSET_ITEM,
      cardCtaText: ''
    }
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const cards = document.querySelectorAll<HTMLElement>('.clickable-card');
    handleCardClick(cards);
  }
};

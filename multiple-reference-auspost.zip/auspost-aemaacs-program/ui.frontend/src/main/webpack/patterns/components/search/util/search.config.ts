import { sys } from "typescript";

const config = {
	pagesize: 10,
    minCharactersLimit: 3,
    zone: 'Australia/Sydney',
    languageCode: 'en-GB',
    autoCompleteMaxResults: 5,
    errorMessage: 'An error occurred while fetching search results',
    defaultRedirectionUrl: '/search',
    searchRequestSpec: {
        queryExpansionSpec: { condition: 'AUTO' },
        spellCorrectionSpec: { mode: 'AUTO' },
        safeSearch: true,
        contentSearchSpec: { snippetSpec: { returnSnippet: true } },
        session: ''
    },
    systemErrorTitle: 'Service unavailable',
    systemErrorDescription: 'We’re having trouble completing your search. We’re working to fix the issue - please try again soon.',
};

export default config;

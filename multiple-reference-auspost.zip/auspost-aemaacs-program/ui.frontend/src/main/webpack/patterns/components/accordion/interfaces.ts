// interfaces.ts
export interface AccordionItem {
  id: string;
  heading: string;
  content: string;
}

export interface Accordion {
  id: string;
  items: AccordionItem[];
}

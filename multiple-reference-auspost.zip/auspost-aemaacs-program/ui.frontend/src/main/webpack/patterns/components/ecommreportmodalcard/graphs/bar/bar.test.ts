import { ANIMATION_CLASS_NAME } from "../../ecommreportmodalcard.constants";
import { initBarGraph } from "./bar";

describe("initBarGraph", () => {
  let container: HTMLElement;

  beforeEach(() => {
    document.body.innerHTML = "";
    container = document.createElement("div");
    container.className = "ecomm-report-bar-graph";
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.innerHTML = "";
    jest.clearAllMocks();
  });

  it("should return early if chart container does not exist", () => {
    document.body.innerHTML = "";
    expect(() => initBarGraph()).not.toThrow();
  });

  it("should set CSS custom properties from data attributes", () => {
    const row = document.createElement("div");
    row.className = "bar-row";
    row.dataset.barWidth = "50";
    row.dataset.barIndex = "1";
    container.appendChild(row);

    initBarGraph();

    expect(row.style.getPropertyValue("--bar-width")).toBe("50%");
    expect(row.style.getPropertyValue("--bar-index")).toBe("1");
  });

  it("should use default values when data attributes are missing", () => {
    const row = document.createElement("div");
    row.className = "bar-row";
    container.appendChild(row);

    initBarGraph();

    expect(row.style.getPropertyValue("--bar-width")).toBe("0%");
    expect(row.style.getPropertyValue("--bar-index")).toBe("0");
  });

  it("should add animation class when IntersectionObserver is not available", () => {
    const row = document.createElement("div");
    row.className = "bar-row";
    container.appendChild(row);

    const originalIO = (window as any).IntersectionObserver;
    delete (window as any).IntersectionObserver;

    initBarGraph();

    expect(row.classList.contains(ANIMATION_CLASS_NAME)).toBe(true);

    (window as any).IntersectionObserver = originalIO;
  });

  it("should observe container with IntersectionObserver when available", () => {
    const row = document.createElement("div");
    row.className = "bar-row";
    container.appendChild(row);

    const observeMock = jest.fn();
    const observerCallback = jest.fn();

    (window as any).IntersectionObserver = jest.fn((cb) => ({
      observe: observeMock,
      unobserve: jest.fn(),
      disconnect: jest.fn(),
    }));

    initBarGraph();

    expect(observeMock).toHaveBeenCalledWith(container);
  });

  it("should handle multiple chart containers", () => {
    // create second container
    const container2 = document.createElement("div");
    container2.className = "ecomm-report-bar-graph";
    document.body.appendChild(container2);

    const row1 = document.createElement("div");
    row1.className = "bar-row";
    row1.dataset.barWidth = "20";
    row1.dataset.barIndex = "0";
    container.appendChild(row1);

    const row2 = document.createElement("div");
    row2.className = "bar-row";
    row2.dataset.barWidth = "80";
    row2.dataset.barIndex = "1";
    container2.appendChild(row2);

    initBarGraph();

    // both rows should have their CSS custom properties set independently
    expect(row1.style.getPropertyValue("--bar-width")).toBe("20%");
    expect(row1.style.getPropertyValue("--bar-index")).toBe("0");
    expect(row2.style.getPropertyValue("--bar-width")).toBe("80%");
    expect(row2.style.getPropertyValue("--bar-index")).toBe("1");
  });

  it("should observe each container when multiple exist", () => {
    const container2 = document.createElement("div");
    container2.className = "ecomm-report-bar-graph";
    document.body.appendChild(container2);

    const observeMock = jest.fn();

    (window as any).IntersectionObserver = jest.fn((cb) => ({
      observe: observeMock,
      unobserve: jest.fn(),
      disconnect: jest.fn(),
    }));

    initBarGraph();

    // should have been called for both containers
    expect(observeMock).toHaveBeenCalledTimes(2);
    expect(observeMock).toHaveBeenCalledWith(container);
    expect(observeMock).toHaveBeenCalledWith(container2);
  });

  it("should add/remove animation class per container on intersection", () => {
    const container2 = document.createElement("div");
    container2.className = "ecomm-report-bar-graph";
    document.body.appendChild(container2);

    const row1 = document.createElement("div");
    row1.className = "bar-row";
    container.appendChild(row1);

    const row2 = document.createElement("div");
    row2.className = "bar-row";
    container2.appendChild(row2);

    const callbacks: IntersectionObserverCallback[] = [];

    (window as any).IntersectionObserver = jest.fn((cb) => {
      callbacks.push(cb);
      return {
        observe: jest.fn(),
        unobserve: jest.fn(),
        disconnect: jest.fn(),
      };
    });

    initBarGraph();

    // simulate first container intersecting, second not
    callbacks[0]([{ isIntersecting: true } as IntersectionObserverEntry]);
    callbacks[1]([{ isIntersecting: false } as IntersectionObserverEntry]);

    expect(row1.classList.contains(ANIMATION_CLASS_NAME)).toBe(true);
    expect(row2.classList.contains(ANIMATION_CLASS_NAME)).toBe(false);
  });

  it("should add animation class when container intersects viewport", () => {
    const row = document.createElement("div");
    row.className = "bar-row";
    container.appendChild(row);

    let observerCallback: IntersectionObserverCallback | null = null;

    (window as any).IntersectionObserver = jest.fn((cb) => {
      observerCallback = cb;
      return {
        observe: jest.fn(),
        unobserve: jest.fn(),
        disconnect: jest.fn(),
      };
    });

    initBarGraph();

    const entry = {
      isIntersecting: true,
    } as IntersectionObserverEntry;

    observerCallback?.([entry]);

    expect(row.classList.contains(ANIMATION_CLASS_NAME)).toBe(true);
  });

  it("should remove animation class when container leaves viewport", () => {
    const row = document.createElement("div");
    row.className = "bar-row";
    row.classList.add(ANIMATION_CLASS_NAME);
    container.appendChild(row);

    let observerCallback: IntersectionObserverCallback | null = null;

    (window as any).IntersectionObserver = jest.fn((cb) => {
      observerCallback = cb;
      return {
        observe: jest.fn(),
        unobserve: jest.fn(),
        disconnect: jest.fn(),
      };
    });

    initBarGraph();

    const entry = {
      isIntersecting: false,
    } as IntersectionObserverEntry;

    observerCallback?.([entry]);

    expect(row.classList.contains(ANIMATION_CLASS_NAME)).toBe(false);
  });
});

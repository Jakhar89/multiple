
import { handleCardClick } from '../../../../scripts/utils/card-clickable';
export default function initHpBanner(): void {
  const cards = document.querySelectorAll<HTMLElement>('.hpb-card');
  handleCardClick(cards);
}

initHpBanner();


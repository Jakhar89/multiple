import { faker } from '@faker-js/faker';
import type { KeyBenefitsProps } from './interfaces';

export const Key_Benefits_DATA: KeyBenefitsProps = {
  image: {
    src: "/src/main/webpack/patterns/assets/images/key-benefits.png",
    alt: faker.lorem.words(2),
  },
  imagePosition: 'image-left',
  heading : faker.lorem.sentence(4),
  description : faker.lorem.sentences(2),
  listContent: [faker.lorem.words(3), faker.lorem.words(3), faker.lorem.words(3),faker.lorem.words(3), faker.lorem.words(3)],
  listBackgroundColor: 'bg-white',
  iconColor:'default',
  ctas: [{ type: 'primary', label: faker.lorem.words(2) }, { type: 'tertiary', label: faker.lorem.words(2) }],
}

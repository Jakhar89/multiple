import { CategoryProps } from '../../../atoms/category/interfaces';

export interface ArticleItem {
  backgroundStyle: string;
  imageUrl: string;
  category?: CategoryProps;
  datestamp: string;
  title: string;
  description: string;
  cardCtaText: string;
  cardCtaType: string;
}

import { HEADER_MOCK } from './_header.mock';
import { liquidEngine } from '~/../../../jest.config';
import initHeader from './header';
import * as utils from '../../../scripts/utils/utils';

describe('Header Component (Static HTML)', () => {
  beforeEach(async () => {
    const html = await liquidEngine.renderFile(
      'src/main/webpack/patterns/components/header/header.liquid',
      { header: HEADER_MOCK, showGlobalAlert: true }
    );
    document.body.innerHTML = html;
    initHeader();
  });

  it('renders all level one nav items', () => {
    const mainNav = document.querySelectorAll('.level-one-nav-item');
    expect(mainNav.length).toBe(HEADER_MOCK.mainNav.length);
  });

  it('renders desktop feature card for each nav item with featureCard', () => {
    HEADER_MOCK.mainNav.forEach((nav) => {
      if (nav.megaMenu.featureCard) {
        const card = document.querySelector('.level-one-nav-group .feature-card');
        expect(card).not.toBeNull();
        expect(card?.textContent).toContain(nav.megaMenu.featureCard.heading);
      }
    });
  });

  it('renders utility top links', () => {
    HEADER_MOCK.topNav.utilityLinks.forEach((link) => {
      expect(document.body.textContent).toContain(link.label);
    });
  });

  it('renders login dropdown items', () => {
    if (HEADER_MOCK.topNav.login.dropdownItems) {
      HEADER_MOCK.topNav.login.dropdownItems.forEach((item) => {
        expect(document.body.textContent).toContain(item.label);
      });
    }
  });

  it('renders the hamburger and close icons', () => {
    expect(document.querySelector('.menu-trigger-open')).not.toBeNull();
    expect(document.querySelector('.menu-trigger-close')).not.toBeNull();
  });

  // it('renders the search input', () => {
  //   expect(document.getElementById('search-field')).not.toBeNull();
  // });

  it('renders nav-list and utility-links', () => {
    expect(document.querySelector('.utility-links')).not.toBeNull();
    expect(document.querySelector('.level-one-nav-group')).not.toBeNull();
    expect(document.querySelector('.mobile-nav-level-one')).not.toBeNull();
  });

  it('renders all nav-link titles', () => {
    HEADER_MOCK.mainNav.forEach((nav) => {
      expect(document.body.textContent).toContain(nav.label);
    });
  });

  it('desktop megamenu toggles on mouseenter and mouseleave', async () => {
    jest.spyOn(utils, 'isTouchDevice').mockReturnValue(false);
    initHeader();
    const navGroup = document.body.querySelectorAll<HTMLElement>('.level-one-nav-group')[0];
    const desktopMegaMenuToggle = document.body.querySelectorAll<HTMLButtonElement>('.level-one-expand-button')[0];
    const desktopMegaMenu = document.body.querySelectorAll<HTMLElement>('.mega-menu-dropdown')[0];

    expect(desktopMegaMenuToggle.getAttribute('aria-expanded')).toBe('false');
    expect(desktopMegaMenu.classList.contains('open')).toBe(false);

    navGroup.dispatchEvent(new Event('mouseenter', {bubbles: true }));
    expect(desktopMegaMenuToggle.getAttribute('aria-expanded')).toBe('true');
    expect(desktopMegaMenu.classList.contains('open')).toBe(true);

    navGroup.dispatchEvent(new Event('mouseleave', {bubbles: true }));
    expect(desktopMegaMenuToggle.getAttribute('aria-expanded')).toBe('false');
    expect(desktopMegaMenu.classList.contains('open')).toBe(false);

    navGroup.dispatchEvent(new Event('mouseenter', {bubbles: true }));
    expect(desktopMegaMenuToggle.getAttribute('aria-expanded')).toBe('true');
    expect(desktopMegaMenu.classList.contains('open')).toBe(true);

    const escapeEvent = new KeyboardEvent('keydown', {key: 'Escape' });
    document.dispatchEvent(escapeEvent);
    expect(desktopMegaMenuToggle.getAttribute('aria-expanded')).toBe('false');
    expect(desktopMegaMenu.classList.contains('open')).toBe(false);
  });


  // TODO: Search tests go here

  it('Login dropdown toggles when when clicked', async () => {
    const loginButton = document.body.querySelector<HTMLButtonElement>('.btn-login-trigger');
    const loginDropdown = document.body.querySelector<HTMLElement>('.login-dropdown');
    expect(loginButton).not.toBeNull();
    expect(loginButton!.getAttribute('aria-expanded')).toBe('false');
    expect(loginDropdown!.classList.contains('open')).toBe(false);

    loginButton!.click();
    expect(loginButton!.getAttribute('aria-expanded')).toBe('true');
    expect(loginDropdown!.classList.contains('open')).toBe(true);

    loginButton!.click();
    expect(loginButton!.getAttribute('aria-expanded')).toBe('false');
    expect(loginDropdown!.classList.contains('open')).toBe(false);

    // Close with escape key
    loginButton!.click();
    const keydownEvent = new KeyboardEvent('keydown', {
      key: 'Escape',
    });
    document.dispatchEvent(keydownEvent);
    expect(loginButton!.getAttribute('aria-expanded')).toBe('false');
    expect(loginDropdown!.classList.contains('open')).toBe(false);
  });

  // it('mobile menu levels one and two toggle when clicked', async () => {
  //   // Mobile menu overlay (level one) opens
  //   const mobileMenuToggle = document.body.querySelector<HTMLButtonElement>('#mobile-menu-button');
  //   const mobileMenuLevelOneOverlay = document.body.querySelector<HTMLElement>('.mobile-menu-overlay');
  //   expect(mobileMenuToggle).not.toBeNull();
  //   expect(mobileMenuToggle!.getAttribute('aria-expanded')).toBe('false');
  //   expect(mobileMenuLevelOneOverlay!.classList.contains('active')).toBe(false);
  //   mobileMenuToggle!.click();
  //   expect(mobileMenuToggle!.getAttribute('aria-expanded')).toBe('true');
  //   expect(mobileMenuLevelOneOverlay!.classList.contains('active')).toBe(true);
  //
  //   // Mobile submenu overlay (level two) opens
  //   const openSubmenuButton = document.body.querySelectorAll<HTMLButtonElement>('.open-mobile-submenu-button')[0];
  //   const mobileMenuLevelTwoOverlay = document.body.querySelector<HTMLElement>('.mobile-submenu-overlay');
  //   expect(openSubmenuButton).not.toBeNull();
  //   expect(mobileMenuLevelOneOverlay!.classList.contains('active')).toBe(true);
  //   expect(mobileMenuLevelTwoOverlay!.classList.contains('active')).toBe(false);
  //   openSubmenuButton!.click();
  //   expect(mobileMenuLevelOneOverlay!.classList.contains('active')).toBe(false);
  //   expect(mobileMenuLevelTwoOverlay!.classList.contains('active')).toBe(true);
  //
  //   // Level two accordion expands and collapses
  //   const firstAccordion = document.body.querySelectorAll<HTMLButtonElement>('.accordion-toggle')[0];
  //   expect(firstAccordion).not.toBeNull();
  //   expect(firstAccordion!.getAttribute('aria-expanded')).toBe('false');
  //   firstAccordion!.click();
  //   expect(firstAccordion!.getAttribute('aria-expanded')).toBe('true');
  //   firstAccordion!.click();
  //   expect(firstAccordion!.getAttribute('aria-expanded')).toBe('false');
  //
  //   // Level two submenu overlay (level two) closes
  //   const submenuBackButton = document.body.querySelectorAll<HTMLButtonElement>('.close-mobile-submenu-button')[0];
  //   expect(submenuBackButton).not.toBeNull();
  //   submenuBackButton!.click();
  //   expect(mobileMenuLevelOneOverlay!.classList.contains('active')).toBe(true);
  //   expect(mobileMenuLevelTwoOverlay!.classList.contains('active')).toBe(false);
  //
  //   // Mobile submenu overlay (level two) closes
  //   openSubmenuButton!.click();
  //   expect(mobileMenuLevelOneOverlay!.classList.contains('active')).toBe(false);
  //
  //   // Close with escape key
  //   mobileMenuToggle!.click();
  //   const keydownEvent = new KeyboardEvent('keydown', {
  //     key: 'Escape',
  //   });
  //   document.dispatchEvent(keydownEvent);
  //   expect(mobileMenuToggle!.getAttribute('aria-expanded')).toBe('false');
  //   expect(mobileMenuLevelOneOverlay!.classList.contains('open')).toBe(false);
  //
  //   // Global alert is hidden when mobile menu opens
  //   const globalAert = document.body.querySelector<HTMLButtonElement>('.globalalert');
  //   expect(globalAert!.classList.contains('show')).toBe(true);
  //   mobileMenuToggle!.click();
  //   expect(globalAert!.classList.contains('show')).toBe(false);
  //   mobileMenuToggle!.click();
  //   expect(globalAert!.classList.contains('show')).toBe(true);
  // });
});

export default function initCarousel(): void {
    document.querySelectorAll<HTMLElement>('.cmp-carousel').forEach(carouselSlide => {
        // updateDots function to enable inactive slide dots using keyboard tab for a bug raised. 
        const updateDots = () => {
            carouselSlide.querySelectorAll<HTMLElement>('.cmp-carousel__indicator').forEach(dot => {
                dot.setAttribute('tabindex', '0');
            });
        };

        updateDots();

        // enable inactive slide dots again when next and previous button is clicked
        carouselSlide.querySelectorAll<HTMLElement>('.cmp-carousel__action').forEach(buttonEvent => {
            buttonEvent.addEventListener('click', () => {
                setTimeout(updateDots, 0);
            });
        });

        //Enable keyboard enter event to move to next slide on inactive tab
        carouselSlide.querySelectorAll<HTMLElement>('.cmp-carousel__indicator').forEach(dot => {
            dot.addEventListener('click', () => {
                setTimeout(updateDots, 0);
            });

            dot.addEventListener('keydown', (event: KeyboardEvent) => {
                if(event.key === 'Enter' || event.key === ' ' || event.key === 'Space'){
                    event.preventDefault();
                    dot.click();
                    setTimeout(updateDots, 0);
                }
            });
        });
    });
};

initCarousel();

import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import Pagination from './Pagination';

describe('Pagination', () => {
  beforeAll(() => {
    // ensure requestAnimationFrame runs synchronously in tests
    (global as any).requestAnimationFrame = (cb: FrameRequestCallback) => cb(0);
  });

  test('prev disabled initially; next disabled without token', () => {
    const calls: Array<[string, string | null, number]> = [];
    const performSearch = async (q: string, token?: string | null, index?: number) => {
      calls.push([q, token ?? null, index ?? 0]);
    };

    render(
      <Pagination
        performSearch={performSearch}
        lastSearchedQuery="q"
        nextPageToken={null}
        loading={false}
      />
    );

    const prev = screen.getByRole('button', { name: /previous/i });
    const next = screen.getByRole('button', { name: /next/i });
    expect(prev).toBeDisabled();
    expect(next).toBeDisabled();
    expect(calls.length).toBe(0);
  });

  test('next then prev triggers performSearch with correct args', async () => {
    const calls: Array<[string, string | null, number]> = [];
    const performSearch = async (q: string, token?: string | null, index?: number) => {
      calls.push([q, token ?? null, index ?? 0]);
    };

    render(
      <Pagination
        performSearch={performSearch}
        lastSearchedQuery="query"
        nextPageToken="tok1"
        loading={false}
      />
    );

    const prev = screen.getByRole('button', { name: /previous/i });
    const next = screen.getByRole('button', { name: /next/i });
    expect(next).not.toBeDisabled();

    fireEvent.click(next);
    await waitFor(() => expect(calls.length).toBe(1));
    expect(calls[0]).toEqual(['query', 'tok1', 1]);
    expect(prev).not.toBeDisabled();

    fireEvent.click(prev);
    await waitFor(() => expect(calls.length).toBe(2));
    expect(calls[1]).toEqual(['query', null, 0]);
  });

  test('buttons disabled when loading', () => {
    const calls: Array<[string, string | null, number]> = [];
    const performSearch = async (q: string, token?: string | null, index?: number) => {
      calls.push([q, token ?? null, index ?? 0]);
    };

    render(
      <Pagination
        performSearch={performSearch}
        lastSearchedQuery="q"
        nextPageToken="tok"
        loading={true}
      />
    );

    const prev = screen.getByRole('button', { name: /previous/i });
    const next = screen.getByRole('button', { name: /next/i });
    expect(prev).toBeDisabled();
    expect(next).toBeDisabled();

    fireEvent.click(next);
    fireEvent.click(prev);
    expect(calls.length).toBe(0);
  });

  test('resets to first page on query change', async () => {
    const calls: Array<[string, string | null, number]> = [];
    const performSearch = async (q: string, token?: string | null, index?: number) => {
      calls.push([q, token ?? null, index ?? 0]);
    };

    const { rerender } = render(
      <Pagination
        performSearch={performSearch}
        lastSearchedQuery="q1"
        nextPageToken="t1"
        loading={false}
      />
    );

    const prev = screen.getByRole('button', { name: /previous/i });
    const next = screen.getByRole('button', { name: /next/i });

    fireEvent.click(next);
    await waitFor(() => expect(calls.length).toBe(1));
    expect(prev).not.toBeDisabled();

    rerender(
      <Pagination
        performSearch={performSearch}
        lastSearchedQuery="q2"
        nextPageToken={null}
        loading={false}
      />
    );

    expect(prev).toBeDisabled();
    expect(next).toBeDisabled();
  });

  test('focuses first result anchor after navigation', async () => {
    const calls: Array<[string, string | null, number]> = [];
    const performSearch = async (q: string, token?: string | null, index?: number) => {
      calls.push([q, token ?? null, index ?? 0]);
    };

    // add DOM for search-results and first result anchor
    const container = document.createElement('div');
    container.className = 'search-results';
    container.innerHTML = `<ul><li class="search-result-item"><a href="/test">First result</a></li></ul>`;
    document.body.appendChild(container);

    render(
      <Pagination
        performSearch={performSearch}
        lastSearchedQuery="query"
        nextPageToken="tok1"
        loading={false}
      />
    );

    const next = screen.getByRole('button', { name: /next/i });
    fireEvent.click(next);
    await waitFor(() => expect(calls.length).toBe(1));

    const firstAnchor = container.querySelector('a') as HTMLElement;
    await waitFor(() => expect(document.activeElement).toBe(firstAnchor));

    // cleanup
    document.body.removeChild(container);
  });
});

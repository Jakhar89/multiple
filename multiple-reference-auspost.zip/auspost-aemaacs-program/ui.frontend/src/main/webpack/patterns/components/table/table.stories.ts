import type { Meta, StoryObj } from '@storybook/html-vite';
import type { TableComponentProps } from './interface';
import { TABLE_MOCK, TABLE_CONTENT_MOCK } from './_table.mock';
import tableComponent from './table.liquid';

const meta = {
  title: 'Components/Table',
  component: tableComponent,
  parameters: {},
  args: {
    columnLimit: 2,
    ...TABLE_MOCK
  }
} satisfies Meta<TableComponentProps>;

export default meta;
type Story = StoryObj<TableComponentProps>;

export const Default: Story = {};

export const AroundContent: Story = {
  args: {
    ...TABLE_CONTENT_MOCK
  }
};

export const MultipleColumns: Story = {
  args: {
    columnLimit: 4
  }
};

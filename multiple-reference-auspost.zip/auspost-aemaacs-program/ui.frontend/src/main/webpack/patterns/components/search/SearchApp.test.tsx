import React from 'react';
import { render } from '@testing-library/react';
import SearchApp from './SearchApp';
import { SearchProvider } from './SearchUtils/searchContext';

function createContextValue() {
  return {
    searchField: { label: 'Search', buttonText: 'Go', placeholder: 'Type to search', redirectUrl: '/search' },
    popularSearch: { title: 'Popular', items: [{ href: '#', target: '_self', label: 'Track' }] },
    resultPageSize: 10
  };
}

function setupModal(active = true) {
  const modal = document.createElement('div');
  modal.className = active ? 'search-modal active' : 'search-modal';
  document.body.appendChild(modal);
  return modal;
}

describe('SearchApp', () => {
  it('renders label, input and submit button', () => {
    const value = createContextValue();
    render(
      <SearchProvider value={value}>
        <SearchApp />
      </SearchProvider>
    );

    const label = document.querySelector('.search-label');
    expect(label).not.toBeNull();
    expect(label!.textContent).toBe('Search');

    const input = document.querySelector('input[aria-label="Search input"]');
    expect(input).not.toBeNull();

    const submitBtn = document.querySelector('button[type="submit"].search-btn');
    expect(submitBtn).not.toBeNull();
    expect(submitBtn!.textContent).toContain('Go');
  });

  it('removes active class on close button click', () => {
    const value = createContextValue();
    setupModal(true);

    render(
      <SearchProvider value={value}>
        <SearchApp />
      </SearchProvider>
    );

    const closeBtn = document.querySelector('button[aria-label="Close search"]');
    expect(closeBtn).not.toBeNull();

    const modal = document.querySelector('.search-modal') as HTMLElement | null;
    expect(modal).not.toBeNull();
    expect(modal!.classList.contains('active')).toBe(true);

    closeBtn!.dispatchEvent(new MouseEvent('click', { bubbles: true }));

    expect(modal!.classList.contains('active')).toBe(false);
  });
});

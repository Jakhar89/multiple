import { faker } from '@faker-js/faker';
import { TextProps } from './interface';

export const mockText: TextProps = {
  textContent: faker.lorem.sentences(4),
  quote: faker.lorem.sentences(2),
  name: faker.lorem.words(2),
  designation: faker.lorem.words(3),
  listContent: [faker.lorem.words(3), faker.lorem.words(3), faker.lorem.words(3)],
};

export const mockTextLong: TextProps = {
  ...mockText,
  quote: faker.lorem.sentences(5)
};

export const mockTextShort: TextProps = {
  ...mockText,
  textContent: faker.lorem.words(4)
};

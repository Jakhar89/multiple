export const AUTOCOMPLETE_TITLE = "Try this";
export const MIN_CHARS_FOR_AUTOSUGGEST_SEARCH = 3;
export const MAX_ROWS = 10;

export const DEBOUNCE_DELAY_MS = 300;
export const MAX_SUGGESTIONS = 10;

export const PROMPTSPEC_PREAMBLE = `
### ROLE
You are a professional Market Insights Assistant.
Your goal is to provide a high-level overview of shopper trends based on provided search results.

### DATA SOURCE
<search_results>
{search_results}
</search_results>

### RULES
1. Use ONLY information found within the <search_results> tags.
2. If the answer is not in the results, state "I cannot find this information in the current report."
3. Do NOT include the words "Executive Summary" or "Content Summary" in the output.
4. Format the first line (the summary theme) as a Bold H3 Header.
5. Do NOT use years or specific dates in the Bold Header.
6. The descriptive paragraph must be 3-4 concise and factual sentences that flow naturally.

### STRICT OUTPUT FORMAT
###
## **<Core Theme: 5-10 words maximum;>**
<3-4 concise sentences summarizing the findings. Ensure it flows naturally and acts as a generative summary.>

Key highlights: <Format this line as a Bold H3 header>.
- <Insight 1: High-impact observation>
- <Insight 2: Category-specific detail>
- <Insight 3: Growth driver>
- <Insight 4: Shopper behavior note>
- <Insight 5: Additional key trend>
###
`;
export const ANSWER_QUERY_REQUEST_BODY_STRUCTURE = {
  query: {
    text: "{{QUERY}} :answer",
    queryId: "{{QUERY_ID}}",
  },
  session: "placholder",
  safetySpec: {
    enable: true,
  },
  answerGenerationSpec: {
    ignoreAdversarialQuery: true,
    ignoreNonAnswerSeekingQuery: false,
    ignoreLowRelevantContent: true,
    includeCitations: true,
    promptSpec: {
      preamble: PROMPTSPEC_PREAMBLE,
    },
    answerLanguageCode: "en",
    modelSpec: {
      modelVersion: "stable",
    },
  },
};

export const ASK_FOLLOW_UP_QUESTION = "Ask a follow-up";
export const ASK_A_NEW_QUESTION = "Ask a new question";

export const SEARCH_QUERY_REQUEST_BODY_STRUCTURE = {
  query: "{{QUERY}}",
  pageSize: 10,
  queryExpansionSpec: {
    condition: "AUTO",
  },
  spellCorrectionSpec: {
    mode: "AUTO",
  },
  languageCode: "en-GB",
  safeSearch: true,
  contentSearchSpec: {
    snippetSpec: {
      returnSnippet: true,
    },
  },
  userInfo: {
    timeZone: "Australia/Sydney",
  },
  session: "{{SESSION_ID}}",
};

import initText from './text';

describe('text', () => {
  let anchorElement: HTMLElement;
  let wrappingElement: HTMLElement;

  beforeEach(() => {
    document.body.innerHTML = '';
    wrappingElement = document.createElement('div');
    wrappingElement.classList.add('rich-text');
    anchorElement = document.createElement('a');
    wrappingElement.appendChild(anchorElement);
    document.body.appendChild(wrappingElement);
  });

  it('Anchor tags set as external links has svg icon added', () => {
    const span = document.createElement('span');
    span.classList.add('external-link');
    anchorElement.appendChild(span);
    initText();
    const svg = document.querySelector('svg');
    expect(svg).not.toBeNull();
  });

  it('Anchor tag with target of new tab have svg icon added', () => {
    anchorElement.setAttribute('target', "_blank");
    initText();
    const svg = document.querySelector('svg');
    expect(svg).not.toBeNull();
  });

  it('Normal anchor tag has no svg icon added', () => {
    initText();
    const svg = document.querySelector('svg');
    expect(document.querySelector('svg')).toBeNull();
  });

  it('No svg icon added outside .text CSS scope', () => {
    document.body.innerHTML = '';
    document.body.appendChild(anchorElement);
    initText();
    const svg = document.querySelector('svg');
    expect(document.querySelector('svg')).toBeNull();
  });
});

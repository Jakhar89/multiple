import { showAlertIfNotDismissed, dismissAlert, initGlobalAlertClose } from './global-alert';

describe('global-alert', () => {
  let alertDiv: HTMLDivElement;
  let closeBtn: HTMLButtonElement;

  beforeEach(() => {
    sessionStorage.clear();
    document.body.innerHTML = '';
    alertDiv = document.createElement('div');
    alertDiv.className = 'global-alert';
    alertDiv.id = 'test-alert';
    closeBtn = document.createElement('button');
    closeBtn.className = 'alert-close';
    alertDiv.appendChild(closeBtn);
    document.body.appendChild(alertDiv);
  });

  afterEach(() => {
    document.body.innerHTML = '';
    sessionStorage.clear();
  });

  // showAlertIfNotDismissed
  it('showAlertIfNotDismissed: removes alert and returns true if dismissed in session', () => {
    sessionStorage.setItem('alert-dismissed-test-alert', 'true');
    expect(showAlertIfNotDismissed(alertDiv, 'test-alert')).toBe(true);
    expect(document.body.contains(alertDiv)).toBe(false);
  });

  it('showAlertIfNotDismissed: returns false and does not remove alert if not dismissed', () => {
    expect(showAlertIfNotDismissed(alertDiv, 'test-alert')).toBe(false);
    expect(document.body.contains(alertDiv)).toBe(true);
  });

  // dismissAlert
  it('dismissAlert: removes alert and sets sessionStorage on click', () => {
    dismissAlert(closeBtn, alertDiv, 'test-alert');
    closeBtn.click();
    expect(document.body.contains(alertDiv)).toBe(false);
    expect(sessionStorage.getItem('alert-dismissed-test-alert')).toBe('true');
  });

  // initGlobalAlertClose
  it('initGlobalAlertClose: does nothing if alert is not present', () => {
    document.body.innerHTML = '';
    expect(() => initGlobalAlertClose()).not.toThrow();
  });

  it('initGlobalAlertClose: does nothing if close button is not present', () => {
    alertDiv.removeChild(closeBtn);
    expect(() => initGlobalAlertClose()).not.toThrow();
    expect(document.body.contains(alertDiv)).toBe(true);
  });

  it('initGlobalAlertClose: removes alert immediately if dismissed in session', () => {
    sessionStorage.setItem('alert-dismissed-test-alert', 'true');
    initGlobalAlertClose();
    expect(document.body.contains(alertDiv)).toBe(false);
  });

  it('initGlobalAlertClose: removes alert and sets sessionStorage on close button click', () => {
    initGlobalAlertClose();
    closeBtn.click();
    expect(document.body.contains(alertDiv)).toBe(false);
    expect(sessionStorage.getItem('alert-dismissed-test-alert')).toBe('true');
  });

  it('initGlobalAlertClose: does not remove alert if not dismissed and not clicked', () => {
    initGlobalAlertClose();
    expect(document.body.contains(alertDiv)).toBe(true);
    expect(sessionStorage.getItem('alert-dismissed-test-alert')).toBeNull();
  });
});

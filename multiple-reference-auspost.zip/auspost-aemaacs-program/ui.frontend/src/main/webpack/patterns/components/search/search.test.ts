import initSearch from './search';
import { act } from 'react';

describe('search init', () => {
  test('initial no mount, then render, then idempotent', async () => {
    document.body.innerHTML = '';

    await act(async () => {
      initSearch();
      document.dispatchEvent(new Event('DOMContentLoaded'));
    });
    await new Promise((r) => setTimeout(r, 0));

    expect(document.querySelectorAll('.standalone-search').length).toBe(0);

    document.body.innerHTML = `
      <div class="search-app"
        data-search-field='{"label":"Search","buttonText":"Go","placeholder":"Type"}'
        data-popular-search='{"title":"Popular","items":[{"label":"Postcode","href":"/p"}]}'
      ></div>
    `;

    await act(async () => {
      initSearch();
      document.dispatchEvent(new Event('DOMContentLoaded'));
    });
    await new Promise((r) => setTimeout(r, 0));

    const label = document.querySelector('.search-label') as HTMLElement | null;
    expect(label && label.textContent).toBe('Search');

    const button = document.querySelector('.search-btn') as HTMLElement | null;
    expect(button && button.textContent).toContain('Go');

    const items = Array.from(document.querySelectorAll('.suggestions-label')) as HTMLElement[];
    expect(items.length).toBe(1);
    expect(items[0].textContent).toBe('Postcode');

    await act(async () => {
      initSearch();
    });
    await new Promise((r) => setTimeout(r, 0));

    expect(document.querySelectorAll('.standalone-search').length).toBe(1);
    expect(document.querySelectorAll('.suggestions-label').length).toBe(1);
  });
});

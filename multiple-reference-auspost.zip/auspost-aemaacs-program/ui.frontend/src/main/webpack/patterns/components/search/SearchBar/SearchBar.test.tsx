import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';

jest.mock('../AutoSuggest/AutoSuggest', () => {
	return {
		__esModule: true,
		default: (props: any) => (
			<div>
				<input
					id={props.id}
					placeholder={props.placeholder}
					value={props.value}
					onChange={props.onChange}
					aria-label={props['aria-label']}
					title={props.title}
				/>
				<button onClick={() => props.onSelect && props.onSelect('picked')}>pick</button>
			</div>
		)
	};
});

import SearchBar from './SearchBar';
import { SearchProvider } from '../SearchUtils/searchContext';

describe('SearchForm', () => {
	const baseProps = {
		id: 'search-input',
		query: 'initial',
		searchField: {
			label: 'Search input',
			placeholder: 'Search',
			buttonText: 'Search',
			redirectUrl: '/search',
			autocomplete: false,
			autocompleteTitle: 'Suggested'
		}
	};

	const providerValue = {
		searchField: baseProps.searchField,
		popularSearch: { title: '', items: [] },
		autocompleteUrl: '',
		resultPageSize: 10
	};

	it('renders the search form with role and label', () => {
		const onQueryChange = (_v: string) => {};

		render(
			<SearchProvider value={providerValue}>
				<form role="search" aria-label="Site">
					<SearchBar
						id={baseProps.id}
						query={baseProps.query}
						onQueryChange={onQueryChange}
						searchField={baseProps.searchField}
					/>
				</form>
			</SearchProvider>
		);

		const form = screen.getByRole('search', { name: 'Site' });
		expect(form).toBeInTheDocument();
	});

	it('shows the button with proper accessible label and text', () => {
		const onQueryChange = (_v: string) => {};

		render(
			<SearchProvider value={providerValue}>
				<SearchBar
					id={baseProps.id}
					query={baseProps.query}
					onQueryChange={onQueryChange}
					searchField={baseProps.searchField}
				/>
			</SearchProvider>
		);

		const button = screen.getByRole('button', { name: baseProps.searchField.buttonText });
		expect(button).toBeInTheDocument();
		expect(screen.getByText(baseProps.searchField.buttonText)).toBeInTheDocument();
	});

	it('calls onQueryChange with typed value', () => {
		let changedValue = '';
		const onQueryChange = (v: string) => {
			changedValue = v;
		};
		render(
			<SearchProvider value={providerValue}>
				<SearchBar
					id={baseProps.id}
					query={baseProps.query}
					onQueryChange={onQueryChange}
					searchField={baseProps.searchField}
				/>
			</SearchProvider>
		);

		const input = screen.getByLabelText('Search input');
		fireEvent.change(input, { target: { value: 'new query' } });

		expect(changedValue).toBe('new query');
	});

	it('submits the form when clicking the button', () => {
		let submitted = false;
		const onQueryChange = (_v: string) => {};
		const onSubmit: React.FormEventHandler<HTMLFormElement> = (e) => {
			e.preventDefault();
			submitted = true;
		};

		render(
			<SearchProvider value={providerValue}>
				<form onSubmit={onSubmit}>
					<SearchBar
						id={baseProps.id}
						query={baseProps.query}
						onQueryChange={onQueryChange}
						searchField={baseProps.searchField}
					/>
				</form>
			</SearchProvider>
		);

		const button = screen.getByRole('button', { name: baseProps.searchField.buttonText });
		fireEvent.click(button);

		expect(submitted).toBe(true);
	});

	it('renders the SVG icon in the button', () => {
		const onQueryChange = (_v: string) => {};

		const { container } = render(
			<SearchProvider value={providerValue}>
				<SearchBar
					id={baseProps.id}
					query={baseProps.query}
					onQueryChange={onQueryChange}
					searchField={baseProps.searchField}
				/>
			</SearchProvider>
		);

		const icon = container.querySelector('.search-icon');
		expect(icon).toBeTruthy();
	});

	it('sets default title when autocomplete is false', () => {
		const onQueryChange = (_v: string) => {};

		render(
			<SearchProvider value={providerValue}>
				<SearchBar
					id={baseProps.id}
					query={baseProps.query}
					onQueryChange={onQueryChange}
					searchField={{ ...baseProps.searchField, autocomplete: false, autocompleteTitle: 'Custom' }}
				/>
			</SearchProvider>
		);

		const input = screen.getByLabelText('Search input');
		expect(input).toHaveAttribute('title', 'SUGGESTED SEARCHES');
	});

	it('uses provided autocompleteTitle when autocomplete is true', () => {
		const onQueryChange = (_v: string) => {};

		render(
			<SearchProvider value={providerValue}>
				<SearchBar
					id={baseProps.id}
					query={baseProps.query}
					onQueryChange={onQueryChange}
					searchField={{ ...baseProps.searchField, autocomplete: true, autocompleteTitle: 'Recommended' }}
				/>
			</SearchProvider>
		);

		const input = screen.getByLabelText('Search input');
		expect(input).toHaveAttribute('title', 'Recommended');
	});

	it('onSelect updates input and calls form.requestSubmit', () => {
		const onQueryChange = jest.fn();

		render(
			<SearchProvider value={providerValue}>
				<form data-testid="form-a">
					<SearchBar
						id={baseProps.id}
						query={baseProps.query}
						onQueryChange={onQueryChange}
						searchField={baseProps.searchField}
					/>
				</form>
			</SearchProvider>
		);

		const form = screen.getByTestId('form-a') as HTMLFormElement;
		const reqSpy = jest.fn();
		(form as any).requestSubmit = reqSpy;

		fireEvent.click(screen.getByText('pick'));

		const input = document.getElementById(baseProps.id) as HTMLInputElement;
		expect(input.value).toBe('picked');
		expect(onQueryChange).toHaveBeenCalledWith('picked');
		expect(reqSpy).toHaveBeenCalled();
	});

	it('onSelect falls back to form.submit when requestSubmit is unavailable', () => {
		const onQueryChange = jest.fn();

		render(
			<SearchProvider value={providerValue}>
				<form data-testid="form-b">
					<SearchBar
						id={baseProps.id}
						query={baseProps.query}
						onQueryChange={onQueryChange}
						searchField={baseProps.searchField}
					/>
				</form>
			</SearchProvider>
		);

		const form = screen.getByTestId('form-b') as HTMLFormElement;
		Object.defineProperty(form, 'requestSubmit', { value: undefined, configurable: true });
		const submitSpy = jest.fn();
		(form as any).submit = submitSpy;

		fireEvent.click(screen.getByText('pick'));

		const input = document.getElementById(baseProps.id) as HTMLInputElement;
		expect(input.value).toBe('picked');
		expect(onQueryChange).toHaveBeenCalledWith('picked');
		expect(submitSpy).toHaveBeenCalled();
	});
});


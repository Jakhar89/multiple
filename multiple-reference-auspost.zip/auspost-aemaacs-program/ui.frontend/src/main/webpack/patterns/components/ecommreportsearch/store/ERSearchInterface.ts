import { InputHTMLAttributes, TextareaHTMLAttributes } from "react";

export interface SuggestedSearchItemsProps {
  label: string;
}

export interface SuggestedSearchProps {
  title: string;
  items: SuggestedSearchItemsProps[];
  onSuggestionSelect?: (suggestion: string) => void;
}

export interface SearchFieldProps {
  label: string;
  buttonText: string;
  placeholder: string;
  redirectUrl?: string;
  autocomplete?: boolean;
  autocompleteTitle?: string;
}

export interface AiSearchAnswer {
  text: string;
  answerId?: string;
}

export interface AiSearchInsight {
  content: string;
  documnentTitle?: string;
  documentId?: string;
  documentUrl?: string;
  relevanceScore?: number;
}

export interface AiSearchResult {
  question: string;
  answer: AiSearchAnswer;
  insights: AiSearchInsight[];
}

export interface AutoSuggestProps extends Omit<
  TextareaHTMLAttributes<HTMLTextAreaElement>, "onSelect"
> {
  autocomplete?: boolean;
  minChars?: number;
  suggestions?: string[];
  value?: string;
  label?: string;
  title?: string;
  searchLabel?: string;
  className?: string;
  onSelect?: (value: string) => void;
  showFollowUpQuestion?: boolean;
  isFollowUpActive?: boolean;
  onAskFollowUp?: () => void;
}

export interface AutosuggestListProps {
  idBase: string;
  listboxId: string;
  suggestions: string[];
  activeIndex: number;
  query: string;
  title?: string;
  onSelect: (value: string) => void;
  loading?: boolean;
  skeletonCount?: number;
}

export interface LoaderProps {
  skeletonCount?: number;
  className?: string;
}

export interface SearchBarProps {
  id: string;
  query: string;
  onQueryChange: (value: string) => void;
  onFormSubmit?: (e: any) => void;
  searchField: SearchFieldProps;
  showFollowUpQuestion: boolean;
  isFollowUpActive?: boolean;
  onAskFollowUp?: () => void;
  question?: string;
}

export interface SearchResultProps {
  result: AiSearchResult;
}

export interface TextInputProps extends InputHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
}

export interface AutoSuggestHookParams {
  autocomplete: boolean;
  minChars: number;
  suggestions?: string[];
  value?: string;
}

export interface ERIconProps {
  name: string;
  colorClass?: string;
}

export type ERSearchAppContext = {
  searchField: SearchFieldProps;
  suggestedSearch?: SuggestedSearchProps;
  autocompleteUrl?: string;
  keywordSearchUrl?: string;
  answerUrl?: string;
  pdfUrl?: string;
  homeUrl?: string;
};
export type KeywordSearchProps = {
  query: string;
  keywordSearchUrl: string;
  sessionId?: string;
};


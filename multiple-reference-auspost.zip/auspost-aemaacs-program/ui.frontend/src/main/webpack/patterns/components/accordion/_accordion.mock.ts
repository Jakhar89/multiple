// accordionData.ts
import { Accordion } from './interfaces';

export const ACCORDION_DATA: Accordion = {
  id: 'accordion-123',
  items: [
    {
      id: 'item1',
      heading: 'Accordion Item 1',
      content: '<p>This is the content for item 1.</p>'
    },
    {
      id: 'item2',
      heading: 'Accordion Item 2',
      content: '<p>This is the content for item 2.</p>'
    }
  ]
};

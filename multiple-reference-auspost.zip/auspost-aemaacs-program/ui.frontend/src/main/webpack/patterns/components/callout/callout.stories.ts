import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './callout.liquid';
import { CalloutProps } from './interfaces';
import { heading, text, listContent } from './_callout.mock';

const meta = {
  title: 'Components/Callout',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    heading,
    text,
    listContent
  }
} satisfies Meta<CalloutProps>;

export default meta;
type Story = StoryObj<CalloutProps>;

export const Info: Story = {
  args: {
    cardType: 'info',
    icon: 'info'
  },
};

export const Success: Story = {
  args: {
    cardType: 'promo',
    icon: 'tag'
  },
};

export const Warning: Story = {
  args: {
    cardType: 'warning',
    icon: 'warning'
  },
};

export const Neutral: Story = {
  args: {
    cardType: 'neutral',
    icon: 'info'
  },
};

export const WithCtas: Story = {
  args: {
    cardType: 'neutral',
    icon: 'info',
    cta: true
  },
};

export const NoHeading: Story = {
  args: {
    cardType: 'neutral',
    icon: 'info',
    heading: ''
  },
};



import type { Meta, StoryObj } from '@storybook/html-vite';
import { HOMEPAGE_BANNER_DATA, sidebarCardsReverseAlignment, sidebarCardsWithSquareStamps, sidebarCardsWithUltrawideStamp, sidebarCardsWithPortraitStamp, HOMEPAGE_BANNER_DATA_WITHOUT_SPACES, OpenNewWindow } from './_hp.mock';
import component from './hp.liquid';
import { HPBannerProps } from './interface';
import initHpBanner from './hp';

const meta: Meta<HPBannerProps> = {
  title: 'Components/Banner/HP',
  component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {},
  args: {
    ...HOMEPAGE_BANNER_DATA
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    initHpBanner();
  }
};

export default meta;

type Story = StoryObj<HPBannerProps>;

export const Default: Story = {
  args: {
    ...HOMEPAGE_BANNER_DATA
  }
};

export const reverseOrder: Story = {
  args: {
    ...HOMEPAGE_BANNER_DATA,
    homepageSidebarCards: sidebarCardsReverseAlignment
  }
};

export const withSquareStamp: Story = {
  args: {
    ...HOMEPAGE_BANNER_DATA,
    homepageSidebarCards: [HOMEPAGE_BANNER_DATA.homepageSidebarCards[0], sidebarCardsWithSquareStamps[0]]
  }
};

export const withUltrawideStamp: Story = {
  args: {
    ...HOMEPAGE_BANNER_DATA,
    homepageSidebarCards: [HOMEPAGE_BANNER_DATA.homepageSidebarCards[0], sidebarCardsWithUltrawideStamp[0]]
  }
};


export const withPortraitStamp: Story = {
  args: {
    ...HOMEPAGE_BANNER_DATA,
    homepageSidebarCards: [HOMEPAGE_BANNER_DATA.homepageSidebarCards[0], sidebarCardsWithPortraitStamp[0]]
  }
};

export const LongTitleWithoutSpaces: Story = {
  args: {
    ...HOMEPAGE_BANNER_DATA_WITHOUT_SPACES
  }
};

export const newWindow: Story = {
  args: {
    ...OpenNewWindow
  }
};

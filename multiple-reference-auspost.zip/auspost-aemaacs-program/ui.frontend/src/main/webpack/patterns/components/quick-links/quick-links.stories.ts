import type { Meta, StoryObj } from '@storybook/html-vite';
import { QuickLinksProps } from './interfaces';
import { quickLinksMock, quickLinksIconOnlyMock, quickLinksExtendedMock } from './_quick-links.mock';
import quickLinks from './quick-links.liquid';

const meta = {
  title: 'Components/Quick Links',
  component: quickLinks,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: 'A flexible quick links component that supports multiple layout variations for different use cases and space constraints.'
      }
    }
  },
} satisfies Meta<QuickLinksProps>;

export default meta;
type Story = StoryObj<QuickLinksProps>;

export const Default: Story = {
  args: {
    quickLinks: quickLinksMock,
    variation: 'default'
  },
  parameters: {
    docs: {
      description: {
        story: 'Default layout with icons above labels in a horizontal row, suitable for main content areas.'
      }
    }
  }
};

export const IconOnly: Story = {
  args: {
    quickLinks: quickLinksIconOnlyMock,
    variation: 'icon-only'
  },
  parameters: {
    docs: {
      description: {
        story: 'Icon-only layout displaying only the icons without text labels, perfect for space-constrained areas where visual recognition is sufficient.'
      }
    }
  }
};

export const Extended: Story = {
  args: {
    quickLinks: quickLinksExtendedMock,
    variation: 'default'
  },
  parameters: {
    docs: {
      description: {
        story: 'Extended layout with 6 quick link items, demonstrating how the component handles more content and wider layouts.'
      }
    }
  }
};
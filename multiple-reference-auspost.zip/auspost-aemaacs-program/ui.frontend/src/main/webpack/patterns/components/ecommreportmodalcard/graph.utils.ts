import { VIEWPORT_THRESHOLD } from "./ecommreportmodalcard.constants";

export function getTransition(duration: number) {
  return `stroke-dashoffset ${duration * 0.9}ms ease-in-out`;
}

export function animateNumber(
  element: HTMLElement,
  start: number,
  end: number,
  duration: number,
  suffix: string = "",
) {
  let startTime = 0;

  function step(timestamp: number) {
    if (!startTime) startTime = timestamp;
    const progress = Math.min((timestamp - startTime) / duration, 1);

    // Ease-in-out calculation
    const ease =
      progress < 0.5
        ? 2 * progress * progress
        : 1 - Math.pow(-2 * progress + 2, 2) / 2;
    const current = Math.floor(ease * (end - start) + start);

    if (element)
      element.innerHTML = `${current.toString().padStart(2, "0")}${suffix}`;

    if (progress < 1) {
      setTimeout(() => window.requestAnimationFrame(step), 0);
    }
  }
  window.requestAnimationFrame(step);
}

export const handleIntersectionObserver = (
  callBack: (entry: IntersectionObserverEntry) => void,
  container: any,
  options: any = {
    threshold: VIEWPORT_THRESHOLD,
  },
) => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(callBack);
  }, options);

  observer.observe(container);

  return observer;
};

export const handleViewportIntersectionObserverAnimation = (
  container: HTMLElement,
  animationCallback: () => void,
  removeAnimationCallBack: () => void,
) => {
  if (!("IntersectionObserver" in window)) {
    animationCallback();
  } else {
    handleIntersectionObserver((entry) => {
      if (entry.isIntersecting) {
        animationCallback();
      } else {
        removeAnimationCallBack();
      }
    }, container);
  }
};

export enum ModalCardMediaEnum {
  IMAGE= 'image',
  GRAPH= 'graph'
}

export enum ModalCardBgVariantEnum {
  DEFAULT= 'default',
  GREY= 'grey'
}

export enum ModalCardGraphTypeEnum {
  BAR= 'bar',
  PIE= 'pie'
}
export enum ModalCardMediaAlignmentEnum {
  LEFT= 'left',
  RIGHT= 'right'
}

export interface ModalCardGraphItemDataProps {
  prefix?: string;
  suffix?: string;
  value: number;
  label?: string;
}

export interface ModalCardMediaProps {
  url: string;
  alt: string;
}

export interface ModalCardProps {
  title: string;
  description: string;
  mediaType: ModalCardMediaEnum;
  mediaAlignment: ModalCardMediaAlignmentEnum;
  variant: ModalCardBgVariantEnum;
  graphType?: ModalCardGraphTypeEnum;
  graphData?: ModalCardGraphItemDataProps[];
  image?: ModalCardMediaProps;
  maxValue?: number;
}
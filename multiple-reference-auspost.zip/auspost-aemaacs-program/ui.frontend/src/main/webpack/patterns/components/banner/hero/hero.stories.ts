import type { Meta, StoryObj } from '@storybook/html-vite';
import { HERO_BANNER_DATA as BANNER_DATA } from './_hero.mock';
import { BannerProps } from '../interfaces';
import { faker } from '@faker-js/faker';
import component from './hero.liquid';

const meta: Meta<BannerProps> = {
  title: 'Components/Banner/Hero',
  component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {},
  args: {
    ...BANNER_DATA
  }
};

export default meta;

type Story = StoryObj<BannerProps>;

export const Default: Story = {
  args: {
    ...BANNER_DATA
  }
};

export const WithBackLink: Story = {
  args: {
    ...BANNER_DATA,
    backLink: faker.word.words(3)
  }
};

export const WithoutImage: Story = {
  args: {
    ...BANNER_DATA,
    backgroundImage: {
      src: '',
      alt: ''
    }
  }
};

import { getIconPath } from '../../../scripts/utils/utils';

export default function initText(): void {
  const externaLinks = document.querySelectorAll<HTMLElement>('.rich-text a .external-link, .rich-text a[target="_blank"]');

  for (const link of externaLinks) {
    const wrapperClasses = 'd-inline-flex align-items-center justify-content-center';
    const svgClasses = 'd-inline-flex align-items-center justify-content-center icon--fill-brand';
    const icon = 'new-window';

    const svg =
      `<span class='icon icon--sm m-l-100 underline-none mx-auto ${wrapperClasses}'>
        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 24 24" class="${svgClasses}">
          <use href="${getIconPath()}/${icon}.svg#${icon}"></use>
      </svg>
    </span>`;

    link.innerHTML = link.innerHTML.trim() + svg;
  }
}

initText();

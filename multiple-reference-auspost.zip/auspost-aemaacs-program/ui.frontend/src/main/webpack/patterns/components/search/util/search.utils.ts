export function getQueryFromLocation(): string {
  try {
    if (typeof window === 'undefined') {
      return '';
    }
    const { search } = window.location;
    const searchParams = new URLSearchParams(search);
    return searchParams.get('q') ?? '';
  } catch (e) {
    return '';
  }
}

export function formatLinkDisplay(url: string): string {
  return url.replace(/^https?:\/\//i, '');
}
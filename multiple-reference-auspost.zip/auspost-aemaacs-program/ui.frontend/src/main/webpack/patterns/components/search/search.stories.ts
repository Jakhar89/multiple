import type { Meta, StoryObj } from '@storybook/html-vite';
import initReactTest from "./search.js";
import component from './search.liquid';
import { popularSearch, searchFieldData, searchAutocompleteUrl, searchApiUrl, errorMessage } from './search.mock';

const meta = {
  title: 'Components/React Search',
  component: component,
  parameters: {},
  args: {
    searchFieldJson: JSON.stringify(searchFieldData),
    popularSearchJson: JSON.stringify(popularSearch),
    searchAutocompleteUrl: searchAutocompleteUrl,
    searchApiUrl: searchApiUrl
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initReactTest();
  }
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const Default: Story = {};

// Story variant where popularSearch is undefined (no data attribute).
export const PopularUndefined: Story = {
  args: {
    popularSearchJson: undefined,
  },
};

// Results page variation
export const ResultsView: Story = {
  args: {
    searchVariant: 'results',
    popularSearchJson: undefined,
    errorMessage: errorMessage,
  },
};

export const ResultsErrorView: Story = {
  args: {
    searchVariant: 'results',
    popularSearchJson: undefined,
    errorMessage: errorMessage,
    searchApiUrl: undefined
  },
};

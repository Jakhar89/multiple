import type { Meta, StoryObj } from '@storybook/html-vite';
import { mockTabsData } from './_tabs.mock';
import component from './tabs.liquid';
import { initTabs } from './tabs';

const meta = {
  title: 'Components/Tabs',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  args: mockTabsData.default,
  argTypes: {
    activeItem: {
      control: { type: 'number' },
      description: 'Index of the initially active tab (0-based)',
      defaultValue: 0
    },
    tabs: {
      control: { type: 'object' },
      description: 'Array of tab items containing title and content'
    }
  }
} satisfies Meta<typeof mockTabsData.default>;

export default meta;
type Story = StoryObj<typeof meta.args>;

// Default story with 3 tabs
export const Default: Story = {
  args: mockTabsData.default,
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initTabs();
  }
};

// Story with minimal tabs (2 tabs)
export const Minimal: Story = {
  args: mockTabsData.minimal,
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initTabs();
  }
};

// Story with extended tabs (5 tabs)
export const Extended: Story = {
  args: mockTabsData.extended,
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initTabs();
  }
};

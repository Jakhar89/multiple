import React from "react";
import '@testing-library/jest-dom';
import { render } from "@testing-library/react";
import ERIcon from "./ERIcon";

jest.mock("../../../../scripts/utils/utils", () => ({
  getIconPath: () => "/mock-icons",
}));

describe("ERIcon", () => {
  test("renders svg with default colorClass and correct attributes/href", () => {
    const { container } = render(<ERIcon name="search" />);
    const svg = container.querySelector("svg");
    const useEl = container.querySelector("use");

    expect(svg).not.toBeNull();
    expect(svg?.getAttribute("class")).toBe("search-icon icon--fill-white");
    expect(svg?.getAttribute("width")).toBe("16");
    expect(svg?.getAttribute("height")).toBe("16");
    expect(svg?.getAttribute("viewBox")).toBe("0 0 16 16");
    expect(svg?.getAttribute("fill")).toBe("none");

    expect(useEl).not.toBeNull();
    expect(useEl?.getAttribute("href")).toBe("/mock-icons/search.svg#search");
  });

  test("uses provided colorClass and builds href from name", () => {
    const { container } = render(
      <ERIcon name="iconName" colorClass="custom-class" />,
    );
    const svg = container.querySelector("svg");
    const useEl = container.querySelector("use");

    expect(svg).not.toBeNull();
    expect(svg?.getAttribute("class")).toBe("iconName-icon custom-class");
    expect(useEl?.getAttribute("href")).toBe(
      "/mock-icons/iconName.svg#iconName",
    );
  });
});

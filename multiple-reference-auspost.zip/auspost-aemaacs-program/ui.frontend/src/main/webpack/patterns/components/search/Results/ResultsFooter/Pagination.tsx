import React, { useEffect, useState } from 'react';
import Icon from '../../../../foundations/iconset/Icon';
import type { PaginationProps } from '../../SearchUtils/interface';

export default function Pagination({ performSearch, lastSearchedQuery = '', nextPageToken = null, loading = false }: PaginationProps) {
    const [pagesTokens, setPagesTokens] = useState<(string | null)[]>([null]);
    const [currentPageIndex, setCurrentPageIndex] = useState(0);

    const focusFirstResult = (triggerElement?: HTMLElement | null) => {
        try {
            const container = triggerElement?.closest('.search-results') || document.querySelector('.search-results');
            if (!container) return;

            const firstAnchor = container.querySelector('.search-result-item a') as HTMLElement | null;
            if (!firstAnchor) return;
            if (typeof firstAnchor.focus === 'function') {
                requestAnimationFrame(() => firstAnchor.focus());
            }
        } catch {
            // ignore focus errors
        }
    };

    useEffect(() => {
        setPagesTokens([null]);
        setCurrentPageIndex(0);
    }, [lastSearchedQuery]);

    const canGoPrev = currentPageIndex > 0;
    const canGoNext = !!nextPageToken;

    const handlePrev = async (e?: React.MouseEvent<HTMLButtonElement>) => {
        if (!canGoPrev || loading) return;
        const trigger = e?.currentTarget as HTMLElement | null;
        const prevIndex = currentPageIndex - 1;
        const token = pagesTokens[prevIndex];
        setCurrentPageIndex(prevIndex);
        try {
            await (performSearch ? performSearch(lastSearchedQuery, token, prevIndex) : Promise.resolve());
            setPagesTokens(prev => {
                const next = prev.slice(0, prevIndex + 1);
                next[prevIndex] = token ?? null;
                return next;
            });
            requestAnimationFrame(() => focusFirstResult(trigger));
        } catch {
            console.error('Error fetching previous page');
        }
    };

    const handleNext = async (e?: React.MouseEvent<HTMLButtonElement>) => {
        if (!canGoNext || loading) return;
        const trigger = e?.currentTarget as HTMLElement | null;
        const token = nextPageToken;
        const nextIndex = currentPageIndex + 1;
        setCurrentPageIndex(nextIndex);
        try {
            await (performSearch ? performSearch(lastSearchedQuery, token, nextIndex) : Promise.resolve());
            setPagesTokens(prev => {
                const next = prev.slice(0, nextIndex + 1);
                next[nextIndex] = token ?? null;
                return next;
            });
            requestAnimationFrame(() => focusFirstResult(trigger));
        } catch {
            console.error('Error fetching next page');
        }
    };

    return (
        <nav className='search-pagination d-flex align-items-center m-l-sm-auto' aria-label='Search results pagination'>
            <button
                type='button'
                className='btn btn-secondary d-flex align-items-center btn-prev cursor-pointer position-relative'
                onClick={(e) => handlePrev(e)}
                disabled={!canGoPrev || loading}>
                <Icon name="arrow-left" className=' d-flex m-r-150' size='sm' />
                Previous
            </button>
            <button
                type='button'
                className='btn btn-secondary d-flex align-items-center btn-next cursor-pointer'
                onClick={(e) => handleNext(e)}
                disabled={!canGoNext || loading}>
                Next
                <Icon name="arrow-right-lg" className=' d-flex m-l-150' size='sm' />
            </button>
        </nav>
    );
}

import type { Meta, StoryObj } from '@storybook/html-vite';
import component from './key-benefits.liquid';
import type { KeyBenefitsProps } from './interfaces';
import { Key_Benefits_DATA } from './_key-benefits.mock';


const meta = {
  title: 'Components/Key Benefits',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {
    description: { control: 'text' },
    imagePosition: {
      control: { type: 'select' },
      options: ['image-left', 'image-right', 'image-top']
    },
    listBackgroundColor: {
      control: { type: 'select' },
      options: ['bg-white', 'bg-grey']
    },
    iconColor: {
      control: { type: 'select' },
      options: ['default', 'brand', 'green']
    }
  },
  args: {
    ...Key_Benefits_DATA
  }
} satisfies Meta<KeyBenefitsProps>;

export default meta;
type Story = StoryObj<KeyBenefitsProps>;

export const Default: Story = {
  args: {
  }
};

export const ImageRight: Story = {
  args: {
    imagePosition: 'image-right'
  }
};

export const ImageTop: Story = {
  args: {
    imagePosition: 'image-top'
  }
};

export const ListWithGreyBackground: Story = {
  args: {
    listBackgroundColor: 'bg-grey'
  }
};

export const ListWithBrandIcon: Story = {
  args: {
    iconColor: 'brand'
  }
};

export const ListWithGreenIcon: Story = {
  args: {
    iconColor: 'green'
  }
};

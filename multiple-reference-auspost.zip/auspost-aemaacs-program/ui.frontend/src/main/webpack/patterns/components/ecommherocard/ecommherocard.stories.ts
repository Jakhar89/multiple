import type { Meta, StoryObj } from "@storybook/html-vite";
import type { EcommHeroCardProps } from "./interfaces";
import component from "./ecommherocard.liquid";
import { ECOMM_HERO_CARD_MOCK } from "./_ecommherocard.mock";

const meta = {
    title: "Components/Ecommerce Report/Hero Card",
    component,
    args: ECOMM_HERO_CARD_MOCK,
} satisfies Meta<EcommHeroCardProps>;

export default meta;

type Story = StoryObj<EcommHeroCardProps>;

export const Default: Story = {};

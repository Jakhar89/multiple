import '@testing-library/jest-dom';
import { fireEvent, render, screen } from '@testing-library/react';
import ERAutosuggestList from './ERAutosuggestList';

describe('ERAutosuggestList', () => {
  const baseProps = {
    idBase: 'test',
    listboxId: 'listbox',
    suggestions: ['Apple Pie', 'Banana Split'],
    activeIndex: 0,
    query: 'Pie',
    title: 'Results',
    onSelect: jest.fn(),
    loading: false,
  } as any;

  it('renders title and suggestions and highlights match', () => {
    const { container } = render(<ERAutosuggestList {...baseProps} />);
    expect(screen.getByText('Results')).toBeTruthy();

    const list = container.querySelector('#listbox');
    expect(list).toBeTruthy();

    // should render suggestions
    const items = container.querySelectorAll('.autosuggest-item');
    expect(items.length).toBe(2);

    // highlighted match should be wrapped in <strong> within the list
    const strong = container.querySelector('#listbox li strong');
    expect(strong).toBeTruthy();
    expect(strong?.textContent).toBe('Pie');
  });

  it('calls onSelect when an item is clicked', () => {
    const onSelect = jest.fn();
    const { container } = render(<ERAutosuggestList {...baseProps} onSelect={onSelect} />);
    const firstLi = container.querySelector('.autosuggest-item') as HTMLElement;
    expect(firstLi).toBeTruthy();
    fireEvent.click(firstLi);
    expect(onSelect).toHaveBeenCalledWith('Apple Pie');
  });

  it('shows loader when loading is true', () => {
    const { container } = render(<ERAutosuggestList {...baseProps} loading={true} />);
    const loader = container.querySelector('.search-loader');
    expect(loader).toBeTruthy();
  });
});

import { FormInputFieldItem } from '~/patterns/atoms/form-controls/input/interfaces';

export interface FormInfo {
    name: string;
    details: string;
    id: string;
    stage: string;
    step: string;
    status?: string;
    error?: string[];
    referenceId: string;
    options?: Record<string, string | string[]> | undefined;
}

export interface AnalticsFormData {
    event: string;
    eventCategory: string;
    eventDescription: string;
    formInfo: FormInfo;
}

export interface ErrorInfo {
    fieldId: string;
    message: string;
    fieldElement?: HTMLElement;
}

export interface FormGroup {
    id?: string;
    title: string;
    description?: string;
    fields: FormInputFieldItem[];
}

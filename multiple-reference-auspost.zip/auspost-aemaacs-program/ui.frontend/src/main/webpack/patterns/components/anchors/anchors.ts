import { scrollTo } from '../../../scripts/utils/scroll';

const scroll_amount = 150;

export default async function initAnchors(): Promise<void> {

  const anchorComponent = document.querySelector<HTMLElement>('.anchor-component');
  const anchorListContainer = document.querySelector<HTMLElement>('.anchor-list-wrapper');
  const anchorLinks = document.querySelectorAll<HTMLAnchorElement>('.anchor-item');
  const anchorPrevious = document.querySelector<HTMLButtonElement>('.anchor-previous-btn')!;
  const anchorNext = document.querySelector<HTMLButtonElement>('.anchor-next-btn')!;

  const mapIdToLink = new Map<string, HTMLAnchorElement>();

  anchorLinks.forEach((link) => {
    const href = link.getAttribute('href');
    if (!href) return;

    const anchorId = href?.substring(1);
    const target = document.getElementById(anchorId);

    if (!target) return;

    mapIdToLink.set(anchorId, link);

    // Handle scroll when anchor link is clicked
    link.addEventListener('click', (e: MouseEvent) => {
      e.preventDefault();
      const stickyHeaderHeight = anchorComponent?.offsetHeight ?? 0;
      const targetPositionY = target.getBoundingClientRect().top + window.scrollY - stickyHeaderHeight;
      slowScrollToElement(targetPositionY);
    });
  });

  // Handle smooth scrolling to the section
  function slowScrollToElement(targetPosition: number) {
    const currentPosition: number = window.scrollY;
    const diff: number = targetPosition - currentPosition;
    let startTime: number | null = null;

    function step(time: number): void {
      if (startTime === null) startTime = time;

      const progress = Math.min((time - startTime) / 1200, 1);
      window.scrollTo(0, currentPosition + diff * progress);

      if (progress < 1) {
        requestAnimationFrame(step);
      }
    }
    requestAnimationFrame(step);
  }

  // Handle highlighting active anchor link and autoscroll to the anchor link
  const observer = new IntersectionObserver(
    (entries: IntersectionObserverEntry[]) => {

      let hasActiveSection = false;
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;

        const section = entry.target as HTMLElement;
        const link = mapIdToLink.get(section.id);

        if (!link) return;
        hasActiveSection = true;
        anchorLinks.forEach(anchorItem => anchorItem.classList.remove('active'));
        link.classList.add('active');
        link.scrollIntoView({
          behavior: 'smooth',
          inline: 'center',
          block: 'nearest'
        });
      });

      if (!hasActiveSection) {
        anchorLinks.forEach(anchorItem => anchorItem.classList.remove('active'));
      }
    },
    {
      threshold: 0.9
    }
  );

  // Observe sections that have matched anchors Id
  mapIdToLink.forEach((_, anchorId) => {
    const el = document.getElementById(anchorId);
    if (el) { observer.observe(el); }
  });

  // Show/hide Next and previous arrow based on content overflow: When more content, toggle anchors to Center and left aligned
  function updateArrows() {
    if (!anchorListContainer) return;

    const isOverFlowing = anchorListContainer.scrollWidth > anchorListContainer.clientWidth;
    anchorListContainer.classList.toggle('centered', !isOverFlowing);
    anchorNext.classList.toggle('visible', isOverFlowing);
  }

  anchorNext?.addEventListener('click', () => {
    anchorListContainer?.scrollBy({ left: scroll_amount, behavior: 'smooth' });
  });

  anchorPrevious?.addEventListener('click', () => {
    anchorListContainer?.scrollBy({ left: -scroll_amount, behavior: 'smooth' });
  });

  // Show or hide. next and previous arrows while scrolling
  anchorListContainer?.addEventListener('scroll', () => {
    const maxScroll = anchorListContainer.scrollWidth - anchorListContainer.clientWidth;
    anchorPrevious.style.display = anchorListContainer.scrollLeft <= 0 ? 'none' : 'block';
    anchorNext.style.display = anchorListContainer.scrollLeft >= maxScroll - 1 ? 'none' : 'block';
  });

  window.addEventListener('resize', updateArrows);
  updateArrows();
}

document.addEventListener('DOMContentLoaded', initAnchors);


import React from "react";
import { SearchBarProps } from "../store/ERSearchInterface";
import AutoSuggest from "../ERAutoSuggest/ERAutoSuggest";
import { ASK_A_NEW_QUESTION, ASK_FOLLOW_UP_QUESTION, AUTOCOMPLETE_TITLE } from "../utils/constants";
import ERIcon from "../Icons/ERIcon";

export default function ERSearchForm({
  id,
  query,
  onQueryChange,
  onFormSubmit = (e: any) => {},
  searchField,
  showFollowUpQuestion,
  isFollowUpActive,
  onAskFollowUp,
  question
}: SearchBarProps) {
  const formClassName = `ecomm-search-form ${isFollowUpActive ? 'follow-up-mode' :''}`

  return (
    <div className="ecomm-search-form-wrapper">
      {!isFollowUpActive && !showFollowUpQuestion && <h4 className="search-title">{searchField.label}</h4>}

      <form
        method="get"
        action="#"
        className={formClassName}
        aria-label="Search Ecommerce reports insights"
        onSubmit={onFormSubmit}
      >
        {isFollowUpActive && (
          <div className="follow-up-question">
            <ERIcon
              name="search"
              colorClass="icon--fill-black"
            />
            <p>{question}</p>
          </div>
          )}

        <div className="ecomm-search-bar-wrapper">
          <AutoSuggest
            id={id}
            placeholder={searchField.placeholder || ""}
            value={query}
            searchLabel={searchField.buttonText}
            onChange={(e: any) => onQueryChange(e.currentTarget.value)}
            aria-label="Search input"
            title={
              searchField.autocomplete
                ? searchField.autocompleteTitle
                : AUTOCOMPLETE_TITLE
            }
            autocomplete={showFollowUpQuestion ? false : searchField.autocomplete}
            showFollowUpQuestion={showFollowUpQuestion}
            isFollowUpActive={isFollowUpActive}
            onAskFollowUp={onAskFollowUp}
          />
        </div>
      </form>

      {showFollowUpQuestion && (
        <div className="button secondary default">
          <button
            type="button"
            className="cmp-button ask-follow-up-btn"
            aria-label="Ask a follow up question"
            onClick={() => onAskFollowUp && onAskFollowUp()}
          >
            {isFollowUpActive ? (
              <span>{ASK_A_NEW_QUESTION}</span>
            ) : (
              <>
                <span className="icon-left">
                  <ERIcon
                    name="arrow-curve-right"
                    colorClass="icon--fill-black"
                  />
                </span>
                <span>{ASK_FOLLOW_UP_QUESTION}</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}

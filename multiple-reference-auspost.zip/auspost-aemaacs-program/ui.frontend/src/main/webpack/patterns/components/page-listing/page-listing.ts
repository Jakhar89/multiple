import { fetchApiGet, ResponseFormat } from '../../../scripts/utils/api';
import { decodeHtmlEntities } from '../../../scripts/utils/utils';
import { pushToAdobeDataLayer } from '../../../scripts/analytics/analytics';
import { handleCardClick } from '../../../scripts/utils/card-clickable';

export default function initPageListing(): void {
  const pageListingComponent = document.querySelector<HTMLElement>('.page-listing-wrapper');

  if (!pageListingComponent)
    return;

  // Global (scoped to component) variables used for logical operations
  let itemsPerPage: number;
  let totalFilteredResults: number;
  let totalFilteredResultsForDataLater: number;

  let resourcePath: string;
  let totalPageCount = 0;
  let currentPage = 0;

  // Global (scoped to component) DOM references
  let filtersWrapper: HTMLElement | null;
  let noResults: HTMLElement | null;
  let resultsWrapper: HTMLElement | null;
  let resultsList: HTMLElement | null;
  let pageControls: HTMLElement | null;
  let resultSummary: HTMLElement | null;
  let loadMoreButton: HTMLElement | null;


  let filterStr = '';
  const filterArrayForAdobe: string[] = [];

  // Reactive loading state
  // Set via: loadingContext.isLoading/isLoadingMore = true/false;
  const loadingState = { isLoading: false, isLoadingMore: false };
  const loadingContext = new Proxy(loadingState, {
    set: function (target: any, key: any, value: string) {
      // All loading actions go here
      if (key === 'isLoading') {
        resultsWrapper?.classList.toggle('is-loading');
      }

      if (key === 'isLoadingMore') {
        loadMoreButton?.querySelector('.spinner')?.classList.toggle('hide');
      }

      target[key] = value;
      return true;
    }
  });

  // Function declaration start
  function _updateScreenReaderMessage(message: string, delay = 200) {
    if (!resultSummary) return;
    setTimeout(() => {
      resultSummary!.textContent = message;
    }, delay);
  }

  function _updateFilterString() {
    if (!filtersWrapper)
      return;

    const filters = filtersWrapper.querySelectorAll<HTMLSelectElement>('.filter-dropdown');
    const filterArray: string[] = [];
    const filterArrayForAdobe: string[] = [];

    filters.forEach(filter => {
      if (filter.value.length > 0) {
        filterArrayForAdobe.push(filter.value);
        if (filter.value !== filter.options[0].text) {
          filterArray.push(filter.value);
        }
      }
    });

    filterStr = filterArray.length > 0 ? `.${filterArray.join('.')}` : '';
  }

  function _updateResultsSummary() {
    if (!pageListingComponent || !resultsWrapper || !resultSummary || !resultsList || !loadMoreButton)
      return;

    currentPage += 1;

    // Determine how many items to display
    const startItemNumber = 0; // If using pagination this would be: itemsPerPage * currentPage - itemsPerPage;
    let endItemNumber = itemsPerPage * currentPage;
    if (endItemNumber > totalFilteredResults) {
      endItemNumber = totalFilteredResults;
    }

    // Update the results summary text
    resultSummary.innerHTML = `${startItemNumber + 1} - ${endItemNumber} of ${totalFilteredResults} items`;
    if (loadMoreButton.classList.contains('hide')) {
      // Show load more button if there are more pages hidden
      if (currentPage < totalPageCount) {
        loadMoreButton.classList.remove('hide');
      }
    } else {
      // Hide load more button if we've reached the last page
      if (currentPage >= totalPageCount)
        loadMoreButton.classList.add('hide');
    }
  }

  function reloadDomReferences() {
    if (!pageListingComponent)
      return;

    filtersWrapper = pageListingComponent.querySelector<HTMLElement>('.filter-grid');
    noResults = pageListingComponent.querySelector<HTMLElement>('.no-results-wrapper');
    resultsWrapper = pageListingComponent.querySelector<HTMLElement>('.page-card-listing');
    resultsList = pageListingComponent.querySelector<HTMLElement>('.page-card-grid');
    pageControls = pageListingComponent.querySelector<HTMLElement>('.page-controls');
    resultSummary = pageListingComponent.querySelector<HTMLElement>('.item-count');
    loadMoreButton = pageListingComponent.querySelector<HTMLElement>('#loadMoreButton');

    if (resultsList && resultsList.children.length > 0) {
      noResults?.classList.add('hide');
      pageControls?.classList.remove('hide');
    } else {
      noResults?.classList.remove('hide');
      pageControls?.classList.add('hide');
      totalFilteredResultsForDataLater = 0;
    }

    if (!filtersWrapper || !resultsWrapper || !resultSummary || !loadMoreButton)
      return;

    reloadConfigurationVariables();
    _updateResultsSummary();

    const cards = document.querySelectorAll<HTMLElement>('.clickable-card');
    handleCardClick(cards);

    // Onclick needs to be inside reloadDomReferences as the button reference updates every filter change
    loadMoreButton!.onclick = async () => {
      if (loadingContext.isLoadingMore)
        return;

      loadingContext.isLoadingMore = true;
      _updateScreenReaderMessage('Loading more articles, please wait.', 100);


      const allCardsBeforeLoad = document.querySelectorAll<HTMLElement>('.page-card-grid .listing-card');
      const lastCardBeforeLoad = allCardsBeforeLoad[allCardsBeforeLoad.length - 1];

      _updateFilterString();
      const dataPageListing = await handleResultsFetch(`${filterStr}.offset${resultsList?.children.length}`);

      let newResultsWrapper: HTMLElement | null = null;

      // Empty results can be either pure whitespace (this is an AEM quirk of rendering empty pages)
      // or if there is HTML when the actual result list has nothign in it
      if (dataPageListing.trim().length > 0) {
        const parser = new DOMParser();
        const temporaryDocument = parser.parseFromString(dataPageListing, 'text/html');

        newResultsWrapper = temporaryDocument.querySelector<HTMLElement>('.page-card-listing');
        const newResultsList = newResultsWrapper?.querySelectorAll<HTMLElement>('.page-card-grid li');

        newResultsList?.forEach(article => {
          resultsList?.appendChild(article);
        });
      }

      // Fix the tab order after clicking load more to highlight the next card being made visible
      if (lastCardBeforeLoad) {
        const links = lastCardBeforeLoad?.querySelectorAll<HTMLElement>('a, button');

        if (links && links.length > 0) {
          links[links.length - 1].focus();
          links[links.length - 1].blur();
        }
      }

      reloadDomReferences();

      loadingContext.isLoadingMore = false;
    }; // End onclick
  }

  function reloadConfigurationVariables() {
    if (!resultsWrapper)
      return;

    // Read the data attributes supplied by the backend
    itemsPerPage = parseInt(resultsWrapper.dataset.itemsLoadInitial ?? '20');
    totalFilteredResults = parseInt(resultsWrapper.dataset.totalFilteredResult ?? '-1');
    totalFilteredResultsForDataLater = totalFilteredResults;
    // totalResults = parseInt(resultsWrapper.dataset.totalResult ?? '-1');=
    resourcePath = resultsWrapper.dataset.resourcePath ?? '';

    // Determine total number of pages we can show
    totalPageCount = Math.ceil(totalFilteredResults / itemsPerPage);
  }

  pageListingComponent.onchange = async (event: Event) => {
    if (!filtersWrapper || !resultsWrapper) return;

    // Track which filter was changed
    const changedFilter = event.target as HTMLSelectElement;

    // Generate URL based on filters selected
    _updateFilterString();

    // Accessibility: Announce filter change BEFORE API call
    const announcement = document.getElementById('filter-announcement');
    const label = document.querySelector(`label[for='${changedFilter.id}']`);
    if (announcement && label) {
      const labelText = label.textContent?.trim() || 'Filter';
      announcement.textContent = `${labelText} set to ${changedFilter.value}`;
    }

    const dataPageListing = await handleResultsFetch(filterStr);
    let hasResults = false;
    let newResultsWrapper: HTMLElement | null = null;

    // Empty results can be either pure whitespace (this is an AEM quirk of rendering empty pages)
    // or if there is HTML when the actual result list has nothign in it
    if (dataPageListing.trim().length > 0) {
      const decodedHtml = decodeHtmlEntities(dataPageListing);
      const parser = new DOMParser();
      const temporaryDocument = parser.parseFromString(decodedHtml, 'text/html');
      newResultsWrapper = temporaryDocument.querySelector<HTMLElement>('.page-card-listing');
      const newResultsList = newResultsWrapper?.querySelector<HTMLElement>('.page-card-grid');
      hasResults = (newResultsList && newResultsList.children.length > 0) ?? false;
    }

    loadingContext.isLoading = false;
    if (newResultsWrapper != null) {
      resultsWrapper.outerHTML = newResultsWrapper.outerHTML;
      if (hasResults) {
        currentPage = 0;
      } else {
        // No result returned
        resultsList?.remove();
      }
    } else {
      resultsList?.remove();
    }

    reloadDomReferences();

    if (changedFilter) {
      changedFilter.focus();
    }
    // Analytics - Push object to adobedatalayer
    const adobeDataObject = {
      'event': 'filtered-results',
      'eventCategory': `${filterArrayForAdobe.join('||')}`,
      'eventDescription': `${totalFilteredResultsForDataLater}`
    };
    pushToAdobeDataLayer(adobeDataObject);
  };

  async function handleResultsFetch(filterArugments: any) {
    const resourcePathWithoutExtension = resourcePath.substring(0, resourcePath.lastIndexOf('.'));
    const extension = resourcePath.substring(resourcePath.lastIndexOf('.') + 1, resourcePath.length);
    const urlWithFilters = `${resourcePathWithoutExtension}${filterArugments}`;

    // Update the browser URL so the user can see state change - keep the users query string (if available) and drop the resource path extension
    if (!resultsWrapper?.dataset.devMode) {
      const queryString = window.location.search;
      const authorModeExtension = window.location.pathname.indexOf('.html') > -1 ? `.${extension}` : '';
      const friendlyUrl = `${urlWithFilters}${authorModeExtension}${queryString}`;
      history.pushState(null, '', friendlyUrl);
    }

    // GET new result list - with resource path extension - ignore query string
    const apiUrl = `${urlWithFilters}.${extension}`;
    loadingContext.isLoading = true;
    const returnObj = await fetchApiGet(apiUrl, ResponseFormat.Html) as string;
    loadingContext.isLoading = false;

    return returnObj;
  }
  // Function declaration end

  //Initial page load
  reloadDomReferences();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPageListing);
} else {
  initPageListing();
}

import type { Meta, StoryObj } from '@storybook/html-vite';
//import { waitForUIToRenderInDOM } from '../../../scripts/utils/_story-utils';
import { AnchorsProps } from './interfaces';
import { ANCHORS_LIST } from './_anchors.mock';
import component from './anchors.liquid';
import initAnchors from './anchors';

const meta = {
  title: 'Components/Anchors',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  argTypes: {
  },
  args: {
    anchors: ANCHORS_LIST.anchors
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    initAnchors();
  }
} satisfies Meta<AnchorsProps>;

export default meta;
type Story = StoryObj<AnchorsProps>;

export const Anchors: Story = {
};

export const AnchorsWithLessContent: Story = {
  args: {
    anchors: Array.from(ANCHORS_LIST.anchors).slice(0, 3)
  }
};
import { Liquid } from 'liquidjs';
import { ACCORDION_DATA } from './_accordion.mock';
import fs from 'fs';
import path from 'path';
import { JSDOM } from 'jsdom';

describe('Accordion Component', () => {
  let engine: Liquid;
  let template: string;

  beforeAll(() => {
    engine = new Liquid();
    const templatePath = path.resolve(__dirname, './accordion.liquid');
    template = fs.readFileSync(templatePath, 'utf8');
  });

  it('renders all accordion items', async () => {
    const html = await engine.parseAndRender(template, { accordion: ACCORDION_DATA });
    const dom = new JSDOM(html);
    const items = dom.window.document.querySelectorAll('.cmp-accordion__item');
    expect(items.length).toBe(ACCORDION_DATA.items.length);
  });

  it('renders expanded class when item.expanded is true', async () => {
    const data = {
      ...ACCORDION_DATA,
      items: ACCORDION_DATA.items.map((item, index) => ({
        ...item,
        expanded: index === 0,
      })),
    };
    const html = await engine.parseAndRender(template, { accordion: data });
    const dom = new JSDOM(html);
    const firstButton = dom.window.document.querySelector('.cmp-accordion__button');
    expect(firstButton?.classList.contains('cmp-accordion__button--expanded')).toBe(true);
  });
});

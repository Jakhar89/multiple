import React, { useEffect, useState } from 'react';
import config from '../util/search.config';
import Icon from '../../../foundations/iconset/Icon';

type Props = {
  visible: boolean;
  systemError?: boolean;
};

export default function ErrorMessage({ visible, systemError = false }: Props) {
  const [content, setContent] = useState('');

  useEffect(() => {
    if (!visible || typeof document === 'undefined') {
      setContent('');
      return;
    }

    if (systemError) {
      const systemErrorContent = `
      <h3>${config.systemErrorTitle}</h3>
      <p>${config.systemErrorDescription}</p>
      `
      setContent(systemErrorContent);
    }
    else {
      const el = document.querySelector('.search-error');
      if (el) {
        const html = (el as HTMLElement).innerHTML || '';
        setContent((html || `<h3>${config.errorMessage}</h3>`).trim());
      } else {
        setContent(`<h3>${config.errorMessage}</h3>`);
      }
    }
  
  }, [visible, systemError]);

if (!visible) return null;

return (
  <div className='search-error-message m-y-1000 m-y-md-1000 m-x-400 m-x-sm-500 m-x-md-900'>
    <div>
      <span className='error-icon d-inline-flex align-items-center justify-content-center m-b-600'>
        <Icon name={systemError ? 'alert' : 'search'} className='p-100 search-icon' size='xl' />
      </span>
    </div>
    <div dangerouslySetInnerHTML={{ __html: content }} />
  </div>
);
}

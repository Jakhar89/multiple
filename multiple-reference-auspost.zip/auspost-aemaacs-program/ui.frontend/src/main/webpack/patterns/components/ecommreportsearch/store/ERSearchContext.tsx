import React, { createContext, useContext } from "react";
import type { ERSearchAppContext } from "./ERSearchInterface";

export const ERSearchContext = createContext<ERSearchAppContext | null>(null);

export function SearchProvider({
  value,
  children,
}: {
  value: ERSearchAppContext;
  children?: React.ReactNode;
}) {
  return (
    <ERSearchContext.Provider value={value}>
      {children}
    </ERSearchContext.Provider>
  );
}

export function useERSearchContext() {
  const ctx = useContext(ERSearchContext);
  if (!ctx) {
    throw new Error("useSearchContext must be used within a SearchProvider");
  }
  return ctx;
}

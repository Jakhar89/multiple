import type { Meta, StoryObj } from '@storybook/html-vite';
import type { VideoProps } from './interfaces';

import component from './video.liquid';

export default {
  title: 'Components/Video',
  component: component,
  argTypes: {
    videoPlayer: {
      control: { type: 'select' },
      options: ['vudoo', 'youtube'],
    },
    showTranscript: { control: 'boolean' },
    transcriptStyle: {
      control: { type: 'select' },
      options: ['', 'floating', 'connected'],
    },
    transcriptBackground: {
      control: { type: 'select' },
      options: ['white', 'grey'],
    },
    transcriptText: { control: 'text' },
  },
  args: {
    videoPlayer: 'youtube',
    showTranscript: true,
    transcriptBackground: 'white',
    transcriptText: 'test transcript',
  },
} satisfies Meta<VideoProps>;

type Story = StoryObj<VideoProps>;

export const Vudoo: Story = {
  args: {
    videoPlayer: 'vudoo',
  }
};

export const Youtube: Story = {
  args: {
    videoPlayer: 'youtube',
  }
};

export const YoutubeGrey: Story = {
  args: {
    videoPlayer: 'youtube',
    transcriptBackground: 'grey',
  }
};


export const VudooWithoutTranscript: Story = {
  args: {
    videoPlayer: 'vudoo',
    transcriptText: '',
    showTranscript: false,
  }
};

export const YoutubeWithoutTranscript: Story = {
  args: {
    videoPlayer: 'youtube',
    transcriptText: '',
    showTranscript: false,
  }
}

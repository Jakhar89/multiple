export interface CalloutProps {
  heading: string;
  text: string;
  listContent?: string[];
  cardType: 'promo' | 'warning' | 'info' | 'neutral';
  icon: 'click-and-send' | 'coin' | 'help' | 'info' | 'parcel-locker' | 'pay-bill' | 'post-office' | 'redirect-mail' | 'tag' | 'track' | 'truck' | 'user' | 'warning';
  cta: boolean;
}

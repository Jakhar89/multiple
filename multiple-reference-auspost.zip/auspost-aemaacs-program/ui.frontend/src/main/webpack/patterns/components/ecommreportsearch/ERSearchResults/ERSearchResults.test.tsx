import React from "react";
import '@testing-library/jest-dom';
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import ERSearchResult from "./ERSearchResults";

jest.mock("react-markdown", () => (props: any) => (
    <div data-testid="markdown">{props.children}</div>
));

jest.mock("../ERSearchResultDownload/ERSearchResultDownload", () => () => (
    <div data-testid="download" />
));

jest.mock("../Icons/ERIcon", () => (props: any) => (
    <div data-testid="icon" data-name={props.name} />
));

describe("ERSearchResult", () => {
    const sampleResult = {
        question: "What is AI?",
        answer: { text: "AI is artificial intelligence." },
    };

    test("renders result contents when result is provided", () => {
        render(<ERSearchResult result={sampleResult as any} />);

        expect(screen.getByText(sampleResult.question)).toBeInTheDocument();
        expect(screen.getByTestId("icon")).toBeInTheDocument();
        expect(screen.getByTestId("icon")).toHaveAttribute(
            "data-name",
            "generative-ai"
        );
        expect(screen.getByTestId("markdown")).toHaveTextContent(
            sampleResult.answer.text
        );
        expect(screen.getByTestId("download")).toBeInTheDocument();
    });

    test("renders nothing inside when result is null", () => {
        render(<ERSearchResult result={null as any} />);

        expect(screen.queryByText(sampleResult.question)).not.toBeInTheDocument();
        expect(screen.queryByTestId("markdown")).not.toBeInTheDocument();
        expect(screen.queryByTestId("download")).not.toBeInTheDocument();
    });
});
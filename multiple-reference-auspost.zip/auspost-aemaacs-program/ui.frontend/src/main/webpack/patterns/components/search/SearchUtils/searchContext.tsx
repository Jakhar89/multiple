import React, { createContext, useContext } from 'react';
import type { PopularSearchProps, SearchFieldProps } from './interface';

export type SearchAppContext = {
  searchField: SearchFieldProps;
  popularSearch: PopularSearchProps;
  autocompleteUrl?: string;
  searchApiUrl?: string;
  resultPageSize: number;
};

const SearchContext = createContext<SearchAppContext | null>(null);

export function SearchProvider({ value, children }: { value: SearchAppContext; children?: React.ReactNode }) {
  return <SearchContext.Provider value={value}>{children}</SearchContext.Provider>;
}

export function useSearchContext() {
  const ctx = useContext(SearchContext);
  if (!ctx) {
    throw new Error('useSearchContext must be used within a SearchProvider');
  }
  return ctx;
}

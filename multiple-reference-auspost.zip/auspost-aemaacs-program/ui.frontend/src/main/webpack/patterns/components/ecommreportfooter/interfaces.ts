/**
 * Footer component interfaces matching Footer.json
 */

export interface EcommerceReportFooterProps {
  secondaryLinks: Array<{
    externalizedURL?: string;
    label: string;
    linkTarget?: string;
    linkURL?: string;
    mappedURL?: string;
    url: string;
  }>;
  socialLinks: Array<{
    externalizedURL?: string;
    icon: string;
    linkURL?: string;
    mappedURL?: string;
    url: string;
    label?: string;
  }>;
  footnoteLogo: {
    externalIconReference: string;
    iconReference: string;
  };
  footnoteLogoAlt?: string;
  footnote: string;
  data?: any;
  footer?: any;
}

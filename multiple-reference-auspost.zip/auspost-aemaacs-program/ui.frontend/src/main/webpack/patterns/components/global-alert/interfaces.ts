export interface GlobalAlertProps {
  alertType: 'information' | 'warning' | 'error' | 'success';
  message: string;
  dismissible: boolean;
  showIcon: boolean;
  renderMode?: boolean;
} 

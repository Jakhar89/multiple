import { CTASectionDataProps, CTASectionVariationEnum } from "./interfaces";

export const MockCTASectionDataDefault: CTASectionDataProps = {
  title: "Want the full story?",
  variant: CTASectionVariationEnum.FULL_PAGE,
  description:
    "There's so much more to unbox. Dive into more data, explore the categories and get the latest tips and takeaways from eCommerce leaders in the full report.",
  primaryCta: {
    label: "Download the 2026 report",
    iconLeft: "download",
    helpText: "No emai or details required",
  },
  secondaryCta: {
    label: "Listen to the podcase",
    iconLeft: "podcast",
    helpText: "Available on Spotify & iTunes",
    menuItems: [
      {
        label: "Spotify",
        icon: "spotify",
        url: "spotify.com",
      },
      {
        label: "Apple podcast",
        icon: "podcast",
        url: "itunes.com",
      },
    ],
  },
};

export const MockCTASectionDataModalVariant: CTASectionDataProps = {
  variant: CTASectionVariationEnum.INSIDE_MODAL,
  title: "Ready to unbox more?",
  description: "Get the full report covering all 4 major trends of 2026",
  primaryCta: {
    label: "Download the 2026 report",
    url: "/some.pdf",
    iconLeft: "download",
    helpText: "No emai or details required",
  },
  secondaryCta: {
    label: "Listen to the podcase",
    iconLeft: "music",
    helpText: "Available on Spotify & iTunes",
    menuItems: [
      {
        label: "Spotify",
        icon: "spotify",
        url: "spotify.com",
      },
      {
        label: "Apple podcast",
        icon: "podcast",
        url: "itunes.com",
      },
    ],
  },
  footer: {
    label: "Up next:",
    title: "Spending",
    imageUrl: "/src/main/webpack/patterns/assets/images/spending.png",
    imageAlt: "Spending",
    nextModalId: "002",
  },
};

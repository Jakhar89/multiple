export function normalizeSuggestions(data: unknown): string[] {
  if (Array.isArray(data)) {
    return data.map(String).filter(Boolean);
  }

  if (data && typeof data === 'object') {
    const list =
      (data as any).suggestions ||
      (data as any).querySuggestions ||
      (data as any).items ||
      [];

    if (Array.isArray(list)) {
      return list
        .map((item: any) =>
          typeof item === 'string'
            ? item
            : item?.suggestion ??
              item?.text ??
              item?.label ??
              item?.value ??
              ''
        )
        .filter(Boolean);
    }
  }

  return [];
}

export function getHighlightParts(text: string, query: string) {
  if (!query) {
    return { before: text, match: '', after: '' };
  }

  const lowerText = text.toLowerCase();
  const lowerQuery = query.toLowerCase();
  const index = lowerText.indexOf(lowerQuery);

  if (index === -1) {
    return { before: text, match: '', after: '' };
  }

  return {
    before: text.slice(0, index),
    match: text.slice(index, index + query.length),
    after: text.slice(index + query.length),
  };
}

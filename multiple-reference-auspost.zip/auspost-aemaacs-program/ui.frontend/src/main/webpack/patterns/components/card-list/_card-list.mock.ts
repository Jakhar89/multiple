import { faker } from '@faker-js/faker';
import { CardProps } from './interfaces';

export const MOCK_CARD: CardProps = {
  backgroundStyle: "white",
  imageUrl: '/src/main/webpack/patterns/assets/images/card-image.jpg',
  category: {
    label: '',
    bgColor: '',
    textColor: ''
  },
  title: faker.lorem.sentence(),
  description: faker.lorem.paragraph(),
  cardCtaText: faker.helpers.arrayElement(['Contact Mailorder', 'View Collection', 'Read Guide', 'Book Tickets']),
  cardCtaType: 'tertiary',
  cardCtaUrl: '#'
}
export const MOCK_POSTMARK_CARD: CardProps = {
  backgroundStyle: "white",
  imageUrl: '/src/main/webpack/patterns/assets/images/postmark.png',
  category: {
    label: '',
    bgColor: '',
    textColor: ''
  },
  title: faker.lorem.sentence(),
  description: '',
  cardCtaText: '',
  cardCtaType: '',
}

export const MOCK_STAMP_CARD_1: CardProps = {
  backgroundStyle: "white",
  imageUrl: '/src/main/webpack/patterns/assets/images/stamp-landscape.png',
  category: {
    label: '',
    bgColor: '',
    textColor: ''
  },
  title: faker.lorem.sentence(),
  description: faker.lorem.paragraph(),
  cardCtaText: '',
  cardCtaType: '',
}

export const MOCK_STAMP_CARD_2: CardProps = {
  backgroundStyle: "white",
  imageUrl: '/src/main/webpack/patterns/assets/images/stamp-portrait.png',
  category: {
    label: '',
    bgColor: '',
    textColor: ''
  },
  title: faker.lorem.sentence(),
  description: faker.lorem.paragraph(),
  cardCtaText: '',
  cardCtaType: '',
}

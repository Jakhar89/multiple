import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import ERAutoSuggest from './ERAutoSuggest';
import { SearchProvider } from '../store/ERSearchContext';

function renderWithProvider(ui: React.ReactElement) {
  const value = {
    searchField: {
      label: 'Search',
      buttonText: 'Search',
      placeholder: 'Type here',
      redirectUrl: '/search',
    },
    suggestedSearch: { title: '', items: [] },
    autocompleteUrl: '',
    keywordSearchUrl: '',
    answerUrl: ''
  };

  return render(<SearchProvider value={value}>{ui}</SearchProvider>);
}

describe('ERAutosuggest', () => {
  const baseSuggestions = [
    'auspost',
    'Australia Post',
    'passport',
    'package',
    'address',
    'postal service',
    'australia day',
    'post office',
    'bus',
  ];

  it('renders input with combobox role and a11y attributes', () => {
    renderWithProvider(
      <ERAutoSuggest label="Search" suggestions={baseSuggestions} />
    );

    const input = screen.getByRole('combobox');
    expect(input).toBeInTheDocument();
    expect(input).toHaveAttribute('aria-autocomplete', 'list');
    expect(input).toHaveAttribute('aria-expanded', 'false');
  });

});

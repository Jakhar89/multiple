import React from 'react';
import type { ResultsCountProps } from '../SearchUtils/interface';

export default function ResultsCount({
  start,
  end,
  total,
  loading = false,
  hasItems = true,
  className = ''
}: ResultsCountProps) {
  

  const classes = ['results-count', className].filter(Boolean).join(' ');

  return (
    <div className={classes}>
      {start} - {end} of {total} items
    </div>
  );
}

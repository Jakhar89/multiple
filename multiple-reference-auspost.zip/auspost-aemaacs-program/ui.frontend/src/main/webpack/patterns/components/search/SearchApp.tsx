import React, { useId, useState } from 'react';
import SearchBar from './SearchBar/SearchBar';
import PopularSearches from './PopularSearch/PopularSearch';
import { useSearchContext } from './SearchUtils/searchContext';
import Results from './Results/Results';
import Icon from '../../foundations/iconset/Icon';

type Props = { isResultsView?: boolean };

export default function SearchApp({ isResultsView }: Props) {

  if (isResultsView) {
    return <Results />;
  }

  const [query, setQuery] = useState('');
  const inputId = useId();
  const { popularSearch, searchField } = useSearchContext();

  const handleClose = () => {
    const modal = document.querySelector('.search-modal') as HTMLElement | null;
    const searchButton = document.querySelector('.header-search-btn') as HTMLElement | null;
    if (modal) {
      modal.classList.remove('active');
      document.body.classList.remove('no-scroll');
    }
    if (searchButton) {
      searchButton.setAttribute('aria-expanded', 'false');
      
      // Restore focus capability to header elements
      if (typeof (window as any).restoreHeaderElements === 'function') {
        (window as any).restoreHeaderElements();
      }
      
      // Return focus to the search button when modal closes
      searchButton.focus();
    }
  };

  return (
    <div className="standalone-search position-relative" role="dialog" aria-modal="true" aria-labelledby="search-dialog-label">
      <div className='search-overlay' onClick={handleClose}></div>
      <div className='search-wpr'>
        <form className='search-form d-flex p-x-400 p-y-1000 p-x-md-500 p-t-md-800 p-b-md-600' action={searchField.redirectUrl} role="search">

          <label id="search-dialog-label" className="search-label h4 m-r-400 m-t-sm-150" htmlFor={inputId}>{searchField.label}</label>
          <div className="w-100">
            <SearchBar
              id={inputId}
              query={query}
              onQueryChange={(value) => setQuery(value)}
              searchField={searchField}
            />
            {popularSearch.items.length > 0 && 
              query.trim().length < 3 && (
                <PopularSearches title={popularSearch.title} items={popularSearch.items} />
              )
            }
          </div>
        </form>
        <button
          type="button"
          className="search-close btn btn-link m-l-auto"
          aria-label="Close search"
          onClick={handleClose}
        >
          <Icon name="cross" size="sm" svgClassName='icon--fill-default' />
        </button>
      </div>
    </div>
  );
}

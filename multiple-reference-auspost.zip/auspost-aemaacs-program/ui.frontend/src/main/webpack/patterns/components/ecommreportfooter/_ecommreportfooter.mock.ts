import { EcommerceReportFooterProps } from './interfaces';
import { faker } from '@faker-js/faker';

export const FOOTER_DATA: EcommerceReportFooterProps = {
  secondaryLinks: [
    {
      externalizedURL: faker.internet.url(),
      label: 'auspost.com.au',
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    {
      externalizedURL: faker.internet.url(),
      label: 'Privacy Statement',
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    {
      externalizedURL: faker.internet.url(),
      label: 'Terms & Conditions',
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
    {
      externalizedURL: faker.internet.url(),
      label: 'Accessibility',
      linkTarget: '_self',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
    },
  ],
  socialLinks: [
    {
      externalizedURL: faker.internet.url(),
      icon: 'facebook',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'Facebook'
    },
    {
      externalizedURL: faker.internet.url(),
      icon: 'instagram',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'Instagram'
    },
    {
      externalizedURL: faker.internet.url(),
      icon: 'twitter',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'twitter'
    },
    {
      externalizedURL: faker.internet.url(),
      icon: 'linkedin',
      linkURL: faker.internet.url(),
      mappedURL: faker.internet.url(),
      url: faker.internet.url(),
      label: 'linkedin'
    },
  ],
  footnoteLogo: {
    externalIconReference: "http://localhost:4503/content/dam/collectables/ap-acknowledgement-logos.svg",
    iconReference: "/src/main/webpack/patterns/assets/images/acknowledgement.png",
  },
  footnoteLogoAlt: faker.company.name(),
  footnote: `<p>Australia Post acknowledges the Traditional Custodians of the land on which we operate, live and gather as employees, and recognise their continuing connection to land, water and community. We pay respect to Elders past, present and emerging.</p>`,
};


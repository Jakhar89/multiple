import { fetchApiGet, ResponseFormat } from '../../../scripts/utils/api';
import { decodeHtmlEntities } from '../../../scripts/utils/utils';
import initPageListing from './page-listing';

afterAll(() => {
  jest.clearAllMocks();
});

// Mock API and Decode HTML Entities
jest.mock('../../../scripts/utils/api', () => ({
  fetchApiGet: jest.fn(),
  ResponseFormat: { Html: 'html' }
}));

jest.mock('../../../scripts/utils/utils', () => ({
  decodeHtmlEntities: jest.fn()
}));

describe('DOM element assignments from pageListingComponent', () => {
  let pageListingComponent: HTMLElement;

  beforeEach(() => {
    // Set up the DOM structure
    document.body.innerHTML = `
      <div id="pageListingComponent">
        <div class="filter-grid"></div>
        <div class="no-results-wrapper"></div>
        <div class="page-card-listing"></div>
        <div class="page-card-grid"></div>
        <div class="page-controls"></div>
        <div class="item-count"></div>
        <button id="loadMoreButton"><div class="spinner hide"></div></button>
      </div>
    `;

    pageListingComponent = document.getElementById('pageListingComponent')!;
    (global as any).pageListingComponent = pageListingComponent;
  });

  it('should assign filtersWrapper, noResults, resultsWrapper, load more correctly', () => {
    const filtersWrapper = pageListingComponent.querySelector<HTMLElement>('.filter-grid');
    expect(filtersWrapper).not.toBeNull();
    expect(filtersWrapper?.className).toBe('filter-grid');
    const noResults = pageListingComponent.querySelector<HTMLElement>('.no-results-wrapper');
    expect(noResults).not.toBeNull();
    expect(noResults?.className).toBe('no-results-wrapper');
    const resultsWrapper = pageListingComponent.querySelector<HTMLElement>('.page-card-listing');
    expect(resultsWrapper).not.toBeNull();
    expect(resultsWrapper?.className).toBe('page-card-listing');
    const resultsList = pageListingComponent.querySelector<HTMLElement>('.page-card-grid');
    expect(resultsList).not.toBeNull();
    expect(resultsList?.className).toBe('page-card-grid');
    const pageControls = pageListingComponent.querySelector<HTMLElement>('.page-controls');
    expect(pageControls).not.toBeNull();
    expect(pageControls?.className).toBe('page-controls');
    const resultSummary = pageListingComponent.querySelector<HTMLElement>('.item-count');
    expect(resultSummary).not.toBeNull();
    expect(resultSummary?.className).toBe('item-count');
    const loadMoreButton = pageListingComponent.querySelector<HTMLElement>('#loadMoreButton');
    expect(loadMoreButton).not.toBeNull();
    expect(loadMoreButton?.id).toBe('loadMoreButton');
  });
});

describe('loadingContext Proxy', () => {
  let resultsWrapper: HTMLElement;
  let loadMoreButton: HTMLElement;
  let spinner: HTMLElement;
  let loadingState: any;
  let loadingContext: any;

  beforeEach(() => {
    // Set up DOM
    document.body.innerHTML = `
      <div class="page-card-listing"></div>
      <button id="loadMoreButton">
        <div class="spinner hide"></div>
      </button>
    `;

    resultsWrapper = document.querySelector('.page-card-listing')!;
    loadMoreButton = document.getElementById('loadMoreButton')!;
    spinner = loadMoreButton.querySelector('.spinner')!;

    // Assign globals
    (global as any).resultsWrapper = resultsWrapper;
    (global as any).loadMoreButton = loadMoreButton;

    // Initial loading state
    loadingState = {
      isLoading: false,
      isLoadingMore: false
    };

    // Create proxy
    loadingContext = new Proxy(loadingState, {
      set: function (target: any, key: any, value: string) {
        if (key === 'isLoading') {
          resultsWrapper?.classList.toggle('is-loading');
        }

        if (key === 'isLoadingMore') {
          loadMoreButton?.querySelector('.spinner')?.classList.toggle('hide');
        }

        target[key] = value;
        return true;
      }
    });
  });

  it('should toggle is-loading class on resultsWrapper when isLoading is set', () => {
    expect(resultsWrapper.classList.contains('is-loading')).toBe(false);
    loadingContext.isLoading = true;
    expect(resultsWrapper.classList.contains('is-loading')).toBe(true);
    loadingContext.isLoading = false;
    expect(resultsWrapper.classList.contains('is-loading')).toBe(false);
  });

  it('should toggle hide class on spinner when isLoadingMore is set', () => {
    expect(spinner.classList.contains('hide')).toBe(true);
    loadingContext.isLoadingMore = true;
    expect(spinner.classList.contains('hide')).toBe(false);
    loadingContext.isLoadingMore = false;
    expect(spinner.classList.contains('hide')).toBe(true);
  });

  it('should update the target object correctly', () => {
    loadingContext.isLoading = true;
    expect(loadingState.isLoading).toBe(true);
    loadingContext.isLoadingMore = true;
    expect(loadingState.isLoadingMore).toBe(true);
  });
});

describe('reloadDomReferences - early return', () => {
  it('should return early if pageListingComponent is not defined', () => {
    // Remove or unset global reference
    (global as any).pageListingComponent = null;
    expect((global as any).filtersWrapper).toBeUndefined();
    expect((global as any).resultsList).toBeUndefined();
  });
});

describe('initPageListing', () => {
  let container: HTMLElement;

  beforeEach(() => {
    document.body.innerHTML = `
      <div id="page-listing" class="page-listing-wrapper">
        <div class="filter-grid">
          <select class="filter-dropdown">
            <option>All</option>
            <option value="test">Test</option>
          </select>
        </div>
        <div class="no-results-wrapper hide"></div>
        <div class="page-card-listing" data-items-load-initial="20" data-total-filtered-result="28">
          <div class="page-card-grid">
            <div class="listing-card card"></div>
            <div class="listing-card card"></div>
            <div class="listing-card card"></div>
            <div class="listing-card card"></div>
            <div class="listing-card card"></div>
            <div class="listing-card card"></div>
            <div class="listing-card card"></div>
            <div class="listing-card card"></div>
          </div>
        </div>
        <div class="page-controls hide"></div>
        <div class="item-count"></div>
        <button id="loadMoreButton"><span class="spinner hide"></span></button>
      </div>
    `;
    container = document.querySelector('#page-listing')!;
  });

  it('should initialize and show first page of results', () => {
    initPageListing();

    const cards = container.querySelectorAll('.listing-card');
    const resultSummary = container.querySelector('.item-count')!;
    const loadMoreButton = container.querySelector('#loadMoreButton')!;

    expect(cards[0].classList.contains('hide')).toBe(false);
    expect(cards[1].classList.contains('hide')).toBe(false);
    expect(resultSummary.textContent).toBe('1 - 20 of 28 items');
    expect(loadMoreButton.classList.contains('hide')).toBe(false);
  });

  it('should hide loadMoreButton when all pages are loaded', () => {
    initPageListing();

    const loadMoreButton = container.querySelector('#loadMoreButton')!;

    setTimeout(() => {
      expect(loadMoreButton.classList.contains('hide')).toBe(true);
    }, 250);
  });

  it('should update results on filter change', async () => {
    const mockHtml = `
      <div class="filter-grid"></div>
      <div class="page-card-listing" data-items-load-initial="2" data-total-filtered-result="2" data-resource-path="test.html">
        <div class="page-card-grid">
          <div class="listing-card card hide"></div>
          <div class="listing-card card hide"></div>
        </div>
        <section class="page-controls">
          <div class="page-controls-wrapper">
            <div class="item-count"></div>
          </div>
        </section>
      </div>
    `;
    (fetchApiGet as jest.Mock).mockResolvedValue(mockHtml);
    (decodeHtmlEntities as jest.Mock).mockReturnValue(mockHtml);

    initPageListing();

    const select = container.querySelector('.filter-dropdown')!;
    select.dispatchEvent(new Event('change'));
    const resultSummary = container.querySelector('.item-count')!;
    expect(resultSummary.textContent).toBe('1 - 20 of 28 items');
  });
});

describe('loadLogicParameters', () => {
  let resultsWrapper: HTMLElement;

  beforeEach(() => {
    // Create a mock resultsWrapper element
    resultsWrapper = document.createElement('div');
    resultsWrapper.dataset.itemsLoadInitial = '20';
    resultsWrapper.dataset.totalFilteredResult = '28';
    resultsWrapper.dataset.resourcePath = '/resources';

    // Add 20 mock .listing-card elements
    for (let i = 0; i < 20; i++) {
      const card = document.createElement('div');
      card.classList.add('card');
      resultsWrapper.appendChild(card);
    }

    // Attach to document for querySelector to work
    document.body.appendChild(resultsWrapper);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('should correctly initialize parameters and calculate totalPageCount', () => {
    // Variables to be set by the function
    let itemsPerPage, totalFilteredResults, initialResultsArray, resourcePath, totalPageCount;

    function loadLogicParameters() {
      if (!resultsWrapper) {return;}

      itemsPerPage = parseInt(resultsWrapper.dataset.itemsLoadInitial ?? '20');
      totalFilteredResults = parseInt(resultsWrapper.dataset.totalFilteredResult ?? '-1');
      initialResultsArray = Array.from(resultsWrapper.querySelectorAll('.listing-card'));
      resourcePath = resultsWrapper.dataset.resourcePath ?? '';
      totalPageCount = Math.ceil(initialResultsArray.length / itemsPerPage);
    }

    loadLogicParameters();

    expect(itemsPerPage).toBe(20);
    expect(totalFilteredResults).toBe(28);
    expect(resourcePath).toBe('/resources');
  });
});

describe('loadNextPage', () => {
  let pageListingComponent: HTMLElement;
  let resultsWrapper: HTMLElement;
  let resultSummary: HTMLElement;
  let resultsList: HTMLElement;
  let loadMoreButton: HTMLElement;
  let initialResultsArray: HTMLElement[];

  beforeEach(() => {
    // Set up DOM elements
    document.body.innerHTML = `
      <div id="pageListingComponent">
        <div class="page-card-listing"></div>
        <div class="page-card-grid"></div>
        <div class="item-count"></div>
        <button id="loadMoreButton" class="hide"></button>
      </div>
    `;

    pageListingComponent = document.getElementById('pageListingComponent')!;
    resultsWrapper = pageListingComponent.querySelector('.page-card-listing')!;
    resultSummary = pageListingComponent.querySelector('.item-count')!;
    resultsList = pageListingComponent.querySelector('.page-card-grid')!;
    loadMoreButton = pageListingComponent.querySelector('#loadMoreButton')!;

    // Assign globals
    (global as any).pageListingComponent = pageListingComponent;
    (global as any).resultsWrapper = resultsWrapper;
    (global as any).resultSummary = resultSummary;
    (global as any).resultsList = resultsList;
    (global as any).loadMoreButton = loadMoreButton;

    // Create mock result items
    initialResultsArray = Array.from({ length: 20 }, (_, i) => {
      const el = document.createElement('div');
      el.classList.add('hide');
      el.textContent = `Item ${i + 1}`;
      resultsList.appendChild(el);
      return el;
    });

    (global as any).initialResultsArray = initialResultsArray;
    (global as any).itemsPerPage = 20;
    (global as any).totalFilteredResults = 28;
    (global as any).totalPageCount = 2;
    (global as any).currentPage = 0;

    // Mock dependencies
    (global as any).reloadDomReferences = jest.fn();
    (global as any).loadLogicParameters = jest.fn();
  });

  it('should load the first page of results and update summary', () => {
    const visibleItems = initialResultsArray.filter(el => !el.classList.contains('hide'));
    expect(visibleItems.length).toBe(0);
    expect(loadMoreButton.classList.contains('hide')).toBe(true);
  });

  it('should load the second page and hide loadMoreButton at last page', () => {
    (global as any).currentPage = 1;
    const visibleItems = initialResultsArray.filter(el => !el.classList.contains('hide'));
    expect(visibleItems.length).toBe(0);
    expect(loadMoreButton.classList.contains('hide')).toBe(true);
  });

});

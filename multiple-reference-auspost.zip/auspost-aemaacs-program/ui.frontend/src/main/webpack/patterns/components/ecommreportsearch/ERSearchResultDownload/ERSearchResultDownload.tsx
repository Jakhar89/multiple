import React from "react";
import ERIcon from "../Icons/ERIcon";
import { useERSearchContext } from "../store/ERSearchContext";

export default function ERSearchResultDownload() {
  const {pdfUrl} = useERSearchContext();

  return (
    <div className="search-result-download-wrapper">
      <p className="label">
        This insight is a summary - download the full report for details.
      </p>
      <div className="button default primary">
        <a
          href={pdfUrl}
          className="cmp-button"
          target="_blank"
          aria-label="Download ecommerce report"
        >
          <span className="button-icon icon-left">
            <ERIcon name="download" />
          </span>

          <span className="cmp-button__text">Download full PDF</span>
        </a>
      </div>
    </div>
  );
}

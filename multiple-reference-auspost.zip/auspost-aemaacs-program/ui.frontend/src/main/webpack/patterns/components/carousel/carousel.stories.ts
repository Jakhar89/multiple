import type { Meta, StoryObj } from '@storybook/html-vite';
import type { Carousel } from './interfaces';
import { CAROUSEL_DATA } from './_carousel.mock';


import carousel from './carousel.liquid';

const meta = {
  title: 'Components/Carousel',
  component: carousel,
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    carousel: CAROUSEL_DATA,
  },
} satisfies Meta<{ carousel: Carousel }>;

export default meta;
type Story = StoryObj<{ carousel: Carousel }>;

export const Default: Story = {
  args: {}
};

export const WithGradient: Story = {
  args: {
    carousel: {
      ...CAROUSEL_DATA,
      gradientBackground: true,
    }
  },

}; export const WithoutCta: Story = {
  args: {
    carousel: {
      ...CAROUSEL_DATA,
      cta: false
    },
  },
};

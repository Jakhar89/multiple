export interface CreatorBlockProps {
  authorName: string;
  authorTitle: string;
  fileReference?: string;
  articleLink: string;
  facebookLink: string;
  xLink: string;
  linkedinLink?: string;
  socialShareTitle: string;
  authorDescription?: string;
}

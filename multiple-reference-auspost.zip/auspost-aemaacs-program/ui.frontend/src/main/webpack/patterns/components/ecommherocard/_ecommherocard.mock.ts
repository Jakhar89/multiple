import type { EcommHeroCardProps } from "./interfaces";

export const ECOMM_HERO_CARD_MOCK: EcommHeroCardProps = {
  cards: [
    {
      title: "Your shoppers",
      description: "Meet the year's top shoppers",
      imageUrl: "/src/main/webpack/patterns/assets/images/shoppers.png",
      imageAlt: "Your shoppers",
      href: "#",
      titleIcon: "arrow-diagonal-right-thin",
    },
    {
      title: "Spending",
      description: "Where and how much they spent",
      imageUrl: "/src/main/webpack/patterns/assets/images/spending.png",
      imageAlt: "Spending",
      href: "#",
      titleIcon: "arrow-diagonal-right-thin",
    },
    {
      title: "Delivering big",
      description: "Top locations unboxed",
      imageUrl:
        "/src/main/webpack/patterns/assets/images/delivery.png",
      imageAlt: "Delivering big",
      href: "#",
      titleIcon: "arrow-diagonal-right-thin",
    },
    {
      title: "The future",
      description: "What's next for eCommerce",
      imageUrl: "/src/main/webpack/patterns/assets/images/future.png",
      imageAlt: "The future",
      href: "#",
      titleIcon: "arrow-diagonal-right-thin",
    },
  ],
  searchTile: {
    label: "AI Search",
    title: "Explore the data your way",
    placeholder: "Ask about eCommerce trends",
    description: "Search insights or explore categories in detail",
    labelIcon: "arrow-diagonal-right-thin",
    searchIcon: "search",
    searchBgImageUrl: "/src/main/webpack/patterns/assets/images/ecommreport-box.png",
    searchBgImageAlt: ""
  },
};

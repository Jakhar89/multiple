import type { Meta, StoryObj } from "@storybook/html-vite";
import type { PageListProps } from "./interfaces";
import PageList from "./page-listing.liquid";
import initPageListing from "./page-listing";
import { pageListDefaultMock, pageListExtendedMock } from "./_page-listing.mock";
import { MOCK_ASSET_ITEM } from "./asset-item/_asset-listing.mock";
import { MOCK_STAMP_ITEM } from './stamp-item/_stamp-item.mock';
import { MOCK_ARTICLE_ITEM } from './article-item/_article-item.mock';

const meta = {
  title: "Components/Page Listing",
  component: PageList,
  argTypes: {},
  args: {
    ...pageListDefaultMock,
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    initPageListing();
  }
} satisfies Meta<PageListProps>;

export default meta;

type Story = StoryObj<PageListProps>;

export const Default: StoryObj<PageListProps> = {};

export const ExtraFilters: StoryObj<PageListProps> = {
  args: {
    pageListHeading: "Explore extended pages",
    filterList: pageListExtendedMock,
  }
};

export const NoFilters: StoryObj<PageListProps> = {
  args: {
    pageListHeading: "Explore extended pages",
    filterList: [],
  }
};

export const NoResults: Story = {
  parameters: { layout: "centered" },
  args: {
    results: []
  }
};

export const AssetItemList: Story = {
  parameters: { layout: "centered" },
  args: {
    resultType: 'AssetItem',
    results: Array.from({ length: 4 }, (_, index) => (MOCK_ASSET_ITEM))
  }
};

export const StampItemList: Story = {
  parameters: { layout: "centered" },
  args: {
    resultType: 'StampItem',
    results: Array.from({ length: 4 }, (_, index) => (MOCK_STAMP_ITEM))
  }
};

export const ArticleItemList: Story = {
  parameters: { layout: "centered" },
  args: {
    resultType: 'ArticleItem',
    results: Array.from({ length: 4 }, (_, index) => (MOCK_ARTICLE_ITEM))
  }
};


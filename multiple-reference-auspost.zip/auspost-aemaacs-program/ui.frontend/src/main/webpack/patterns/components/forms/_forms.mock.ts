import { FormInputFieldItem } from '../../atoms/form-controls/input/interfaces';
import { FormOptionsGroup } from '~/patterns/atoms/form-controls/checkbox/interfaces';
import { FormGroup } from './interfaces';
import { abnLookupFieldWithErrorMock } from '../../atoms/form-controls/abn-lookup/_abn-lookup.mock';
import { searchAddressField } from '../../atoms/form-controls/location-lookup/address/_address.mock';
import { postcodeOrSuburbField } from '../../atoms/form-controls/location-lookup/postcode-suburb-lookup/_postcode-suburb-lookup.mock';

export const formFields: FormInputFieldItem[] = [
    {
        label: 'First Name',
        id: 'form-text-firstname',
        name: 'First Name',
        type: 'text',
        placeholder: 'Enter your first name',
        optional: true,
    },
    {
        label: 'Last Name',
        id: 'form-text-lastname',
        name: 'Last Name',
        type: 'text',
        placeholder: 'Enter your last name'
    },
    {
        label: 'Email',
        id: 'form-text-email',
        name: 'Email',
        type: 'email',
        placeholder: 'Enter your email',
        optional: true,
    },
    {
        label: 'Phone number',
        id: 'form-text-phone',
        name: 'Phone',
        type: 'tel',
        placeholder: 'Enter your phone number',
        optional: true,
    },
];

export const formFieldsWithErrors: FormInputFieldItem[] = [
    {
        label: 'First Name',
        id: 'form-text-firstname',
        name: 'First Name',
        type: 'text',
        placeholder: 'Enter your first name',
        optional: false,
        error: 'First Name is required',
        charLimit: 10,
    },
    {
        label: 'Last Name',
        id: 'form-text-lastname',
        name: 'Last Name',
        type: 'text',
        placeholder: 'Enter your last name',
        optional: false,
        error: 'Last Name is required',
        charLimit: 10,
    },
    {
        label: 'Email',
        id: 'form-text-email',
        name: 'Email',
        type: 'email',
        placeholder: 'Enter your email',
        optional: false,
        error: 'Email is required',
        charLimit: 10,
    },
    {
        label: 'Phone number',
        id: 'form-text-phone',
        name: 'Phone',
        type: 'tel',
        placeholder: 'Enter your phone number',
        optional: false,
        error: 'Phone number is required',
        charLimit: 10,
    }
];

export const formCheckboxField: FormOptionsGroup = {
    id: 'checkbox-id',
    type: 'checkbox',
    name: 'checbox-name',
    required: false,
    error: 'This field is required',
    options: [{
        text: 'I acknowledge that I have read and accept the Australia Post <a href="#" >privacy policy.</a>',
        value: 'option1',
        selected: false,
        disabled: false,
    }]
};

export const formWithMultipleOption: FormOptionsGroup = {
    type: 'checkbox',
    id: 'checkbox-id',
    name: 'servicesInterested',
    title: 'What service(s) are you interested in? ',
    helpMessage: 'You may select more than one option',
    required: false,
    error: 'This field is required',
    options: [
        {
            value: 'domestic_parcels',
            text: 'Domestic parcels',
            selected: false,
            disabled: false,
        },
        {
            value: 'international_parcels',
            text: 'International parcels',
            selected: false,
            disabled: false,
        },
        {
            value: 'lettetr_service',
            text: 'Letter service',
            selected: false,
            disabled: false,
        },
        {
            value: 'payment_service',
            text: 'Payment Service',
            selected: false,
            disabled: false,
        },
        {
            value: 'other',
            text: 'others',
            selected: false,
            disabled: false,
        }
    ]
};

export const formDropdown: FormOptionsGroup = {
    id: 'dropdown-id',
    type: 'drop-down',
    name: 'dropdown-name',
    required: false,
    title: 'Input label',
    error: 'Select field is required',
    options: [{
        text: 'Default',
        value: '',
        selected: false,
        disabled: false,
    }, {
        text: 'Option1',
        value: 'option1',
        selected: false,
        disabled: false,
    }, {
        text: 'Option2',
        value: 'option2',
        selected: false,
        disabled: false,
    }]
};

export const formRadioButton: FormOptionsGroup = {
    id: 'radio-id',
    type: 'radio',
    name: 'radio-name',
    required: false,
    title: 'Size of Business',
    error: 'Select radio button is required',
    options: [{
        text: 'Option1',
        value: 'Option1',
        selected: false,
        disabled: false
    }, {
        text: 'Option2',
        value: 'option2',
        selected: false,
        disabled: false
    }, {
        text: 'Option3',
        value: 'option3',
        selected: false,
        disabled: false
    }]
};

export const allFormFieldsWithErrors = [
    ...formFieldsWithErrors,
    { ...formDropdown, required: true },
    { ...formWithMultipleOption, required: true },
    { ...formRadioButton, required: true },
    { ...abnLookupFieldWithErrorMock, required: true },
    { ...searchAddressField, optional: false, error: 'Address field is required' },
    { ...postcodeOrSuburbField, error: 'Please select an option or enter an address manually' }
];

export const formFieldsGrouped: FormGroup[] = [
    {
        id: 'personal-details',
        title: 'Personal details',
        description: 'Tell us a bit about yourself',
        fields: [
            formFields[0],
            formFields[1]
        ]
    },
    {
        id: 'contact-details',
        title: 'Contact details',
        description: 'How can we reach you?',
        fields: [
            formFields[2],
            formFields[3]
        ]
    }
];

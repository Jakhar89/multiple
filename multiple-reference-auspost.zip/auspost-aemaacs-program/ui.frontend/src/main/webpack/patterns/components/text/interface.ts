export interface TextProps {
  textContent?: string;
  quote?: string;
  name?: string;
  designation?: string;
  listContent?: string[];
}

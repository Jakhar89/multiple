import type { Meta, StoryObj } from '@storybook/html-vite';
import type { EcommerceReportFooterProps } from './interfaces';
import { FOOTER_DATA } from './_ecommreportfooter.mock';


import ecommreportfooter from './ecommreportfooter.liquid';

const meta = {
  title: 'Components/Ecommerce Report/Footer',
  component: ecommreportfooter,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: 'Footer component with collapsible navigation sections for mobile devices.'
      }
    }
  },
  args: {
    footer: FOOTER_DATA
  },
  argTypes: {
    footer: {}
  }
} satisfies Meta<EcommerceReportFooterProps>;

export default meta;
type Story = StoryObj<EcommerceReportFooterProps>;

export const Default: Story = {
  args: {
    footer: FOOTER_DATA

  },
  play: async () => {}
};




/**
 * @jest-environment jsdom
 */

describe("initCTASection", () => {
    const modulePath = "./ecommreportctasection";

    beforeEach(() => {
        jest.resetModules();
        document.body.innerHTML = `
            <div class="ecomm-cta-section">
                <div class="ecomm-cta-section__dropdown">
                    <button class="button" id="btn1">Btn1</button>
                </div>
                <div class="ecomm-cta-section__dropdown-content" id="menu1">Menu1</div>

                <div class="ecomm-cta-section__dropdown">
                    <button class="button" id="btn2">Btn2</button>
                </div>
                <div class="ecomm-cta-section__dropdown-content" id="menu2">Menu2</div>

                <!-- button without a corresponding menu -->
                <div class="ecomm-cta-section__dropdown">
                    <button class="button" id="btn-no-menu">BtnNoMenu</button>
                </div>
            </div>
        `;
        // Import after DOM setup so the module's init runs against this DOM
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        require(modulePath);
    });

    test("clicking a dropdown button toggles its menu's show-menu class", () => {
        const btn1 = document.getElementById("btn1") as HTMLButtonElement;
        const menu1 = document.getElementById("menu1") as HTMLElement;

        btn1.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
        expect(menu1.classList.contains("show-menu")).toBe(true);

        btn1.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
        expect(menu1.classList.contains("show-menu")).toBe(false);
    });

    test("clicking outside closes any open menus", () => {
        const btn2 = document.getElementById("btn2") as HTMLButtonElement;
        const menu2 = document.getElementById("menu2") as HTMLElement;

        // open menu
        btn2.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
        expect(menu2.classList.contains("show-menu")).toBe(true);

        // click outside (on body)
        document.body.dispatchEvent(new MouseEvent("click", { bubbles: true }));
        expect(menu2.classList.contains("show-menu")).toBe(false);
    });

    test("clicking inside a menu does not close it", () => {
        const btn1 = document.getElementById("btn1") as HTMLButtonElement;
        const menu1 = document.getElementById("menu1") as HTMLElement;

        // open menu
        btn1.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
        expect(menu1.classList.contains("show-menu")).toBe(true);

        // click inside the menu
        menu1.dispatchEvent(new MouseEvent("click", { bubbles: true }));
        expect(menu1.classList.contains("show-menu")).toBe(true);
    });

    test("button without a corresponding menu does not affect menus when clicked", () => {
        const btnNoMenu = document.getElementById("btn-no-menu") as HTMLButtonElement;
        const menu1 = document.getElementById("menu1") as HTMLElement;
        const menu2 = document.getElementById("menu2") as HTMLElement;

        // ensure menus are closed
        expect(menu1.classList.contains("show-menu")).toBe(false);
        expect(menu2.classList.contains("show-menu")).toBe(false);

        // clicking the button without a menu should not throw and should not open other menus
        btnNoMenu.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));

        expect(menu1.classList.contains("show-menu")).toBe(false);
        expect(menu2.classList.contains("show-menu")).toBe(false);
    });
});
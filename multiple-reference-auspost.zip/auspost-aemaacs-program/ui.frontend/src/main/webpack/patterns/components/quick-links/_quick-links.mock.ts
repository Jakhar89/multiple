import { faker } from '@faker-js/faker';
import { QuickLinkItem } from './interfaces';

const icons = [
  'stamp',
  'sticker-circle',
  'shopping-cart',
  'users',
  'stamp', // Reusing icons for 6 items
  'sticker-circle', // Reusing icons for 6 items
];

// Generate full quick links with labels (4 items)
export const quickLinksMock: QuickLinkItem[] = icons.slice(0, 4).map((icon) => ({
  icon,
  label: faker.lorem.words(3),
  url: '#',
}));

// Generate icon-only quick links (empty labels) - 4 items
export const quickLinksIconOnlyMock: QuickLinkItem[] = icons.slice(0, 4).map((icon) => ({
  icon,
  label: '',
  url: '#',
}));

// Generate extended quick links with 6 items
export const quickLinksExtendedMock: QuickLinkItem[] = icons.map((icon) => ({
  icon,
  label: faker.lorem.words(3),
  url: '#',
}));

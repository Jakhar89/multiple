import type { Meta, StoryObj } from '@storybook/html-vite';
import { faker } from '@faker-js/faker';

import component from './promo-card.liquid';
import { PromoCardProps } from './interfaces';
import { initLightbox } from '../../atoms/lightbox/lightbox';
import { PROMO_CARD_MOCK } from './_promo-card.mock';

const meta = {
  title: 'Components/Promo Card',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  argTypes: {
    description: { control: 'text' },
    imageHref: {
      control: { type: 'select' },
      options: ['', 
        '/src/main/webpack/patterns/assets/images/stamp-portrait.png', 
        '/src/main/webpack/patterns/assets/images/stamp-square.png',
        '/src/main/webpack/patterns/assets/images/photo-father-son-sending-parcels.jpeg'
      ]
    },
    info: { control: 'text' },
    price: { control: 'text' },
    categoryBgColor: {
      control: { type: 'select' },
      options: ['red', 'black', 'grey']
    },
    categoryTextColor: {
      control: { type: 'select' },
      options: ['white', 'black']
    }
  },
  args: {
    bgGrey: false,
    blockQuote: '',
    categoryBgColor: 'red',
    categoryLabel: PROMO_CARD_MOCK.categoryLabel,
    categoryTextColor: 'white',
    ctas: [{ type: 'primary', label: 'Buy now' }],
    description: PROMO_CARD_MOCK.description,
    enableLightbox: true,
    imageCaption: PROMO_CARD_MOCK.imageCaption,
    imageHref: '/src/main/webpack/patterns/assets/images/stamp-portrait.png',
    imageRight: false,
    info: PROMO_CARD_MOCK.info,
    price: PROMO_CARD_MOCK.price,
    roundedImage: false,
    title: PROMO_CARD_MOCK.title
  }
} satisfies Meta<PromoCardProps>;

export default meta;
type Story = StoryObj<PromoCardProps>;

export const Default: Story = {
  args: {
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const ImageRight: Story = {
  args: {
    imageRight: true
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const SquareImage: Story = {
  args: {
    imageHref: '/src/main/webpack/patterns/assets/images/stamp-square.png'
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const TwoButtons: Story = {
  args: {
    ctas: [{ type: 'primary', label: 'Buy now' }, { type: 'secondary', label: 'Join the community' }]
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const RoundedImage: Story = {
  args: {
    imageHref: '/src/main/webpack/patterns/assets/images/photo-father-son-sending-parcels.jpeg',
    roundedImage: true
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const NoLightbox: Story = {
  args: {
    enableLightbox: false
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const NoLightboxRoundedImage: Story = {
  args: {
    imageHref: '/src/main/webpack/patterns/assets/images/photo-father-son-sending-parcels.jpeg',
    enableLightbox: false,
    roundedImage: true
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const NoImage: Story = {
  args: {
    imageHref: ''
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const BlackTag: Story = {
  args: {
    categoryBgColor: 'black'
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const GreyBackground: Story = {
  args: {
    bgGrey: true
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const NoTag: Story = {
  args: {
    categoryLabel: ''
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};

export const WithBlockQoute: Story = {
  args: {
    info: '',
    title: '',
    description: '',
    categoryLabel: '',
    price: '',
    blockQuote: faker.lorem.sentences(2),
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    initLightbox();
  }
};


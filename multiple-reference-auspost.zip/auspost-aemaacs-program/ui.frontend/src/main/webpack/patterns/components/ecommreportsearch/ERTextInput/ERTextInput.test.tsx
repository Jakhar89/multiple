import React from 'react';
import '@testing-library/jest-dom';
import ERTextInput from './ERTextInput';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { MAX_ROWS } from '../utils/constants';

describe('ERTextInput', () => {
  afterEach(() => {
    jest.restoreAllMocks();
    cleanup();
  });

  test('renders label and textarea with correct attributes', () => {
    const onKeyDown = jest.fn();
    render(<ERTextInput label="Search label" placeholder="Type here" onKeyDown={onKeyDown} />);

    expect(screen.getByText('Search label')).toBeInTheDocument();

    const textarea = screen.getByLabelText('Search input') as HTMLTextAreaElement;
    expect(textarea).toBeInTheDocument();
    expect(textarea.placeholder).toBe('Type here');
    expect(textarea.getAttribute('rows')).toBe('1');
  });

  test('adds and removes resize event listener on mount/unmount', () => {
    const addSpy = jest.spyOn(window, 'addEventListener');
    const removeSpy = jest.spyOn(window, 'removeEventListener');

    const { unmount } = render(<ERTextInput label="L" />);

    expect(addSpy).toHaveBeenCalledWith('resize', expect.any(Function));
    unmount();
    expect(removeSpy).toHaveBeenCalledWith('resize', expect.any(Function));
  });

  test('calls provided onKeyDown and requests form submit on Enter without Shift', () => {
    const onKeyDown = jest.fn();

    const form = document.createElement('form');
    const requestSubmitSpy = jest.fn();
    // @ts-ignore
    form.requestSubmit = requestSubmitSpy;
    document.body.appendChild(form);

    render(<ERTextInput label="L" onKeyDown={onKeyDown} />, { container: form });

    const textarea = screen.getByLabelText('Search input');
    fireEvent.keyDown(textarea, { key: 'Enter', code: 'Enter', shiftKey: false });

    expect(onKeyDown).toHaveBeenCalled();
    expect(requestSubmitSpy).toHaveBeenCalled();

    document.body.removeChild(form);
  });

  test('onInput adjusts height immediately and onPaste schedules adjustment', () => {
    jest.useFakeTimers();

    // mock computed style to provide a predictable lineHeight
    const getComputedStyleSpy = jest
      .spyOn(window, 'getComputedStyle')
      .mockReturnValue({ lineHeight: '20px' } as any);

    render(<ERTextInput label="L" />);

    const textarea = screen.getByLabelText('Search input') as HTMLTextAreaElement;

    // simulate small content -> hidden overflow after adjust
    Object.defineProperty(textarea, 'scrollHeight', { value: 10, configurable: true });
    fireEvent.input(textarea);
    expect(textarea.style.overflowY).toBe('hidden');

    // simulate large content for paste -> overflow auto after timeout
    Object.defineProperty(textarea, 'scrollHeight', {
      value: (MAX_ROWS + 5) * 20,
      configurable: true,
    });
    fireEvent.paste(textarea);
    // run the scheduled timeout from onPaste
    jest.runAllTimers();

    expect(textarea.style.overflowY).toBe('auto');

    getComputedStyleSpy.mockRestore();
    jest.useRealTimers();
  });
});

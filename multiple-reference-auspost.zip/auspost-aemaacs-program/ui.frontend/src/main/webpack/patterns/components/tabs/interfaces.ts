export interface TabElements {
    outer: HTMLElement | null;
    list: HTMLElement | null;
    btnNext: HTMLButtonElement | null;
    btnPrev: HTMLButtonElement | null;
    select: HTMLSelectElement | null;
    tabs: HTMLElement[];
    tabpanels: HTMLElement[];
}
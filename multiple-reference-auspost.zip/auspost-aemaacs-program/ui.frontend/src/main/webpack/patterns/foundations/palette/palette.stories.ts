import type { Meta, StoryObj } from '@storybook/html-vite';
import './palette.scss';

import component from './palette.liquid';

const meta = {
  title: 'Foundations/Colour Palette',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {}
} satisfies Meta;

export default meta;

export const BrandAndProductPalette: StoryObj = {
  args: {
    brandPalette: true
  }
};

export const ExtendedPalette: StoryObj = {
  args: {
    brandPalette: false
  }
};

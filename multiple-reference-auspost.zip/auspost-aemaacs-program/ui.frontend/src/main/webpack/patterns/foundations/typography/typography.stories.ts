import type { Meta, StoryObj } from '@storybook/html-vite';

import component from './typography.liquid';

const meta = {
  title: 'Foundations/Typography',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {}
} satisfies Meta;

export default meta;

export const Default: StoryObj = {}

export const HeadingSizes: StoryObj = {
  args: {
    headingScale: true
  }
};
export const BodyContentSizes: StoryObj = {
  args: {
    bodyScale: true
  }
};

import type { Meta, StoryObj } from '@storybook/html-vite';
import { getIconList } from '../../../scripts/utils/_story-utils';

import component from './iconset.liquid';

const meta = {
  title: 'Foundations/Iconset',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    iconSet: getIconList(),
    size: "",
    fill: "",
    background: "",
    className: ""
  }
} satisfies Meta;

export default meta;

export const Default: StoryObj = {};

export const ExtraSmall: StoryObj = {
  args: {
    size: 'xs'
  }
};

export const Small: StoryObj = {
  args: {
    size: 'sm'
  }
};

export const Medium: StoryObj = {
  args: {
    size: 'md'
  }
};

export const Large: StoryObj = {
  args: {
    size: 'lg'
  }
};

export const Enormous: StoryObj = {
  args: {
    size: 'enormous'
  }
};

export const FillDefault: StoryObj = {
  args: {
    fill: 'default'
  }
};

export const FillBrand: StoryObj = {
  args: {
    fill: 'brand'
  }
};

export const BackgroundBrand: StoryObj = {
  args: {
    background: 'brand'
  }
};

export const OptionalClass: StoryObj = {
  args: {
    className: 'm-x-200'
  }
};

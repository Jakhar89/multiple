import React from 'react';
import { getIconPath } from '../../../scripts/utils/utils';

type IconProps = {
    name: string;
    width?: number | string;
    height?: number | string;
    viewBox?: string;
    className?: string;
    size?: 'sm' | 'md' | 'lg' | 'xl';
    svgClassName?: string;
};

export default function Icon({
    name,
    viewBox = '0 0 16 16',
    className = '',
    size,
    svgClassName,
}: IconProps) {
    return (
        <span className={`icon ${size ? `icon--${size}` : ''} ${className}`} aria-hidden="true">
            <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox={viewBox}
                className={svgClassName}
            >
                <use href={getIconPath() + `/${name}.svg#${name}`}></use>
            </svg>
        </span>
    );
}

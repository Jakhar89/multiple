import type { Meta, StoryObj } from '@storybook/html-vite';
import './spacing.scss';

import component from './spacing.liquid';

const meta = {
  title: 'Foundations/Spacing',
  component: component,
  parameters: {
    layout: 'fullscreen'
  },
  args: {}
} satisfies Meta;

export default meta;

export const Default: StoryObj = {};

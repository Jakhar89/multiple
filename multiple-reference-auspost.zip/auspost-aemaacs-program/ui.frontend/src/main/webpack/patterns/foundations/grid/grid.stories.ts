import type { Meta, StoryObj } from '@storybook/html-vite';
import './grid.scss';

import component from './grid.liquid';

const meta = {
  title: 'Foundations/Grid',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {}
} satisfies Meta;

export default meta;

export const Default: StoryObj = {};

import type { Meta, StoryObj } from '@storybook/html-vite';

import './page-listing-page.scss';

import { HEADER_MOCK } from '../../components/header/_header.mock';
import { mockBreadcrumbs } from '../../components/breadcrumb/_breadcrumb.mock';
import { FOOTER_DATA } from '../../components/footer/_footer.mock';
import { pageListDefaultMock } from "../../components/page-listing/_page-listing.mock";

import initHeader from '../../components/header/header';
import initFooter from '../../components/footer/footer';
import initPageListing from '../../components/page-listing/page-listing';
import component from './page-listing-page.liquid';

const meta = {
  title: 'Pages/Page Listing Page',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    header: HEADER_MOCK,
    breadcrumbs: mockBreadcrumbs,
    footer: FOOTER_DATA,

    ...pageListDefaultMock
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    initHeader();
    initFooter();
    initPageListing();
  }
} satisfies Meta;

export default meta;

export const Default: StoryObj = {};

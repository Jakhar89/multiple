import type { Meta, StoryObj } from '@storybook/html-vite';

import './home-page.scss';

import { HEADER_MOCK } from '../../components/header/_header.mock';
import { mockBreadcrumbs } from '../../components/breadcrumb/_breadcrumb.mock';
import { FOOTER_DATA } from '../../components/footer/_footer.mock';
import { HOMEPAGE_BANNER_DATA } from "../../components/banner/hp/_hp.mock";
import { quickLinksMock } from '../../components/quick-links/_quick-links.mock';
import initHeader from '../../components/header/header';
import { initGlobalAlertClose } from '../../components/global-alert/global-alert';
import initFooter from '../../components/footer/footer';

import component from './home-page.liquid';

const meta = {
  title: 'Pages/Home Page',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    header: HEADER_MOCK,
    breadcrumbs: mockBreadcrumbs,
    footer: FOOTER_DATA,

    showGlobalAlert: true,
    ...HOMEPAGE_BANNER_DATA,
    'quick-links': quickLinksMock,
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    initGlobalAlertClose();
    initHeader();
    initFooter();
  }
} satisfies Meta;

export default meta;

export const Default: StoryObj = {};

export const WithoutGlobalAlert: StoryObj = {
  args: {
    showGlobalAlert: false,
  }
};

import type { Meta, StoryObj } from '@storybook/html-vite';

import './content-page.scss';

import { HEADER_MOCK } from '../../components/header/_header.mock';
import { mockBreadcrumbs } from '../../components/breadcrumb/_breadcrumb.mock';
import { HERO_BANNER_DATA as BANNER_DATA } from '../../components/banner/hero/_hero.mock';
import { heading, text } from '../../components/callout/_callout.mock';
import { ACCORDION_DATA } from '../../components/accordion/_accordion.mock';
import { PROMO_CARD_MOCK } from '../../components/promo-card/_promo-card.mock';
import { FOOTER_DATA } from '../../components/footer/_footer.mock';
import initHeader from '../../components/header/header';
import initFooter from '../../components/footer/footer';
import { initGlobalAlertClose } from '../../components/global-alert/global-alert';
import { initLightbox } from '../../atoms/lightbox/lightbox';
import { CAROUSEL_DATA } from '../../components/carousel/_carousel.mock';
import { ANCHORS_LIST } from '../../components/anchors/_anchors.mock';
import initAnchors from '../../components/anchors/anchors';

import component from './content-page.liquid';

const meta = {
  title: 'Pages/Content Page',
  component: component,
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    header: HEADER_MOCK,
    breadcrumbs: mockBreadcrumbs,
    banner: {
      ...BANNER_DATA,
      foreground: {
        src: 'src/main/webpack/patterns/assets/images/stamp-portrait.png',
        alt: 'Stamp image',
      },
      background: {
        src: "",
        alt: "",
      },
    },
    callout: {
      heading: heading,
      text: text,
    },
    accordion: {
      ...ACCORDION_DATA,
      items: ACCORDION_DATA.items.map(item => ({
        ...item,
        expanded: true,
      })),
    },
    promoCard: PROMO_CARD_MOCK,
    carousel: {
      ...CAROUSEL_DATA,
      gradientBackground: true,
    },
    anchors: ANCHORS_LIST.anchors,
    footer: FOOTER_DATA
  },
  play: async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    initHeader();
    initFooter();
    initGlobalAlertClose();
    initLightbox();
    await new Promise(resolve => setTimeout(resolve, 3000));
    initAnchors();
  }
} satisfies Meta;

export default meta;

export const Default: StoryObj = {};

export const WithCarousel: StoryObj = {
  args: {
    showCarousel: true,
  }
}

module.exports = {
    root: true, // This makes sure ESLint looks for this file in the root directory
    parser: '@typescript-eslint/parser', // Specifies the ESLint parser
    extends: [
        'plugin:@typescript-eslint/recommended', // Uses the recommended rules from the @typescript-eslint/eslint-plugin,
        'plugin:react/recommended'
    ],
    parserOptions: {
        ecmaVersion: 2018, // Allows for the parsing of modern ECMAScript features
        sourceType: 'module' // Allows for the use of imports
    },
    settings: { react: { version: 'detect ' } },
    // If you want to define variables that are available across various processed JavaScript
    // files, define them here. More details: http://eslint.org/docs/user-guide/configuring#specifying-globals
    globals: {
        window: true,
        localStorage: true,
        document: true,
        typeof: true
    },
    plugins: [
        'import'
    ],
    rules: {
        curly: 1,
        '@typescript-eslint/explicit-function-return-type': [0],
        '@typescript-eslint/no-explicit-any': [0],
        'ordered-imports': [0],
        'object-literal-sort-keys': [0],
        'new-parens': 1,
        'no-bitwise': 1,
        'no-cond-assign': 1,
        'no-trailing-spaces': 0,
        'eol-last': 1,
        'func-style': ['error', 'declaration', { allowArrowFunctions: true }],
        'no-var': 0,
        'no-new': 0,
        'global-require': 0,
        'no-plusplus': [2, { allowForLoopAfterthoughts: true }],
        'max-len': ['error', { code: 150 }],
        'prefer-destructuring': ['error', { object: true, array: false }],
        semi: 'error',
        strict: 'error',
        'no-console': 0,
        'import/prefer-default-export': 0,
        'no-unused-vars': 'warn',
        'linebreak-style': 0,
        'class-methods-use-this': 0,
        quotes: ['error', 'single'],
        'import/no-extraneous-dependencies': [
            'error',
            {
                devDependencies: true,
                optionalDependencies: false,
                peerDependencies: false,
                packageDir: './',
                devDependencies: [
                    '**/*.stories.ts',
                    '**/*.mock.ts',
                    '**/*.test.ts',
                    '**/*.spec.ts',
                    '**/tests/**',
                    '**/__tests__/**'
                ]
            }
        ],
        'no-param-reassign': ['error', { props: false }],
        'comma-dangle': ['error', 'never'],
        'no-use-before-define': [
            'error',
            {
                'functions': false,
                'classes': false,
                'variables': true,
                'allowNamedExports': false
            }
        ],
        'consistent-return': ['error', { treatUndefinedAsUnspecified: true }],
        'no-unused-expressions': ['error', { allowShortCircuit: true }]
    }
};

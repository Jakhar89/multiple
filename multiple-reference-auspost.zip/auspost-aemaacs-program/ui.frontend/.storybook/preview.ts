import type { Preview } from '@storybook/html-vite';
import { initialize, mswLoader } from 'msw-storybook-addon';
import { handlers } from '../.storybook/mocks/handlers';

// main.ts component import
import '../src/main/webpack/site/main';

// We want these components to run in Storybook but not AEM
import '../src/main/webpack/patterns/demos/api-demo/api-demo';
import '../src/main/webpack/patterns/demos/react-demo/react-demo';

// Initialize MSW
initialize({
  onUnhandledRequest: (req) => {
    const url = new URL(req.url);

    // Ignore static asset requests
    const isStaticAsset = /\.(svg|png|jpg|jpeg|gif|ico|css|js|woff|woff2|ttf)$/i.test(url.pathname);
    if (isStaticAsset) {
      return;
    }

    // Default MSW warning for all other requests, handle here if required
  }
});

const preview: Preview = {
  parameters: {
    a11y: {
      options: {
        /*
         * See https://github.com/dequelabs/axe-core/blob/develop/doc/API.md#options-parameter-examples for more info
         */
        runOnly: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'],
      },
    },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
    darkMode: {
      stylePreview: true
    },
    options: {
      storySort: {
        order: ['Foundations', 'Atoms', '*', 'Pages'],
        method: 'alphabetical'
      }
    },
    msw: {
      handlers
    },
  },
  loaders: [mswLoader], // Provide the MSW addon loader globally
};

export default preview;

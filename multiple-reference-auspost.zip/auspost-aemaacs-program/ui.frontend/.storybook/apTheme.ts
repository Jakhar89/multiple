import { create } from 'storybook/theming';
 
export default create({
  base: 'light',
  brandTitle: 'Australia Post FWP Frontend',
  brandUrl: 'https://example.com',
  brandImage: '../src/main/webpack/patterns/assets/images/logo.svg',
  brandTarget: '_self',
});

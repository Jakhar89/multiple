import { addons } from 'storybook/manager-api';
import apTheme from './apTheme';
 
addons.setConfig({
  theme: apTheme,
});

import type { StorybookConfig } from '@storybook/html-vite';

const config: StorybookConfig = {
  "stories": [
    "../src/**/*.mdx",
    "../src/**/*.stories.@(js|jsx|mjs|ts|tsx)"
  ],
  "addons": [
    "@storybook/addon-docs",
    "@storybook/addon-a11y",
    "@vueless/storybook-dark-mode",
    "msw-storybook-addon"
  ],
  "core": {
    "builder": '@storybook/builder-vite',
  },
  "framework": {
    "name": "@deptdk/liquidjs-framework-vite",
    "options": {}
  },
  "staticDirs": [{ from: "../src/main/webpack/patterns", to: "/patterns" }]
};

export default config;

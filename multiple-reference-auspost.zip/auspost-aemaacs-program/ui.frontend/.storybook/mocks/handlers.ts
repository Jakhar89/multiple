import { delay, http, HttpResponse } from 'msw';
import { AssetListing_FilterResponseHtml, PageListing_FilterResponseHtml, PageListing_FilterNoResultsResponseHtml } from '../../src/main/webpack/patterns/components/page-listing/_page-listing.mock';
import { abnLookupApiResponseErrorMock, abnLookupServiceDownApiResponse, abnLookupApiResponseMock } from '../../src/main/webpack/patterns/atoms/form-controls/abn-lookup/_abn-lookup.mock';
import { Address_Success_Response, Address_Failure_Response } from '../../src/main/webpack/patterns/atoms/form-controls/location-lookup/address/_address-response.mock';
import { Postcode_Suburb_Success_Response, Postcode_Suburb_Failure_Response } from '../../src/main/webpack/patterns/atoms/form-controls/location-lookup/postcode-suburb-lookup/_postcode-suburb-response.mock';


/*
 * API Mocks - handlers can be separated out into individual files if needed
 */

// Health check API handlers for testing API mocking functionality.
export const healthSuccess = [
  http.get('/api/health', () => {
    return HttpResponse.json({
      status: 'ok',
      timestamp: new Date().toISOString()
    });
  }),
];

export const healthDegraded = [
  http.get('/api/health', () => {
    return HttpResponse.json(
      {
        status: 'degraded',
        timestamp: new Date().toISOString(),
        message: 'Some services experiencing issues'
      },
      { status: 200 }
    );
  })
];

export const healthError = [
  http.get('/api/health', () => {
    return HttpResponse.json(
      {
        status: 'error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }),
];

export const healthMaintenance = [
  http.get('/api/health', () => {
    return HttpResponse.json(
      {
        status: 'maintenance',
        timestamp: new Date().toISOString(),
        message: 'System maintenance in progress'
      },
      { status: 503 }
    );
  })
];

export const handlers = [
  http.get('/api/assetlisting*', async ({ request }) => {
    await delay(500);

    if (request.url.indexOf('no-result') > -1)
      return HttpResponse.text(PageListing_FilterNoResultsResponseHtml);

    return HttpResponse.text(AssetListing_FilterResponseHtml);
  }),

  http.get('/api/pagelisting*', async ({ request }) => {
    await delay(500);

    if (request.url.indexOf('no-result') > -1)
      return HttpResponse.text(PageListing_FilterNoResultsResponseHtml);

    return HttpResponse.text(PageListing_FilterResponseHtml);
  }),

  http.get('/api/abnlookup*', async ({ request }) => {
    await delay(500);

    const url = new URL(request.url);
    const abn = url.searchParams.get('abn');

    // Test ABN: ABN not found
    if (abn === '88888888888') {
      return HttpResponse.json(abnLookupApiResponseErrorMock);
    }

    // Test ABN: API error
    if (abn === '99999999999') {
      return HttpResponse.json(abnLookupServiceDownApiResponse, { status: 500 });
    }

    return HttpResponse.json(abnLookupApiResponseMock);
  }),

  http.get('/addresslookup.model.json?*', async ({ request }) => {
    await delay(500);

    return await HttpResponse.json(Address_Success_Response, { status: 200 });
  }),

  http.get('/addresslookup.model.json?*', async ({ request }) => {
    await delay(500);

    return HttpResponse.json(Address_Failure_Response, { status: 500 });
  }),

  // postcode or suburb lookup
  http.get('/postcodeorsuburblook.model.json?*', async ({ request }) => {
    await delay(500);
    return await HttpResponse.json(Postcode_Suburb_Success_Response, { status: 200 });
  }),

  http.get('/postcodeorsuburblook.model.json?*', async ({ request }) => {
    await delay(500);

    return HttpResponse.json(Postcode_Suburb_Failure_Response, { status: 500 });
  }),

];

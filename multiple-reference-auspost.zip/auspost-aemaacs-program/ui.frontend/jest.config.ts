import type { Config } from 'jest';
import { Liquid } from "liquidjs";

export const liquidEngine = new Liquid({
  root: [
    './',
  ],
  extname: '.liquid'
});

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'json'],
  transform: {
    '^.+\\.ts(ts|tsx)$': 'ts-jest'
  },
  moduleNameMapper: {
    '\\.(scss|css)$': 'identity-obj-proxy',
    '^~/(.*)$': '<rootDir>/src/main/webpack/$1',
    '^~/components/(.*)$': '<rootDir>/src/main/webpack/patterns/components/$1',
    '^@root/(.*)$': '<rootDir>/$1'
  },
  roots: ['<rootDir>/src'],
  setupFiles: ['<rootDir>/jest.setup.ts'],
  globals: {
    'ts-jest': {
      tsconfig: 'tsconfig.jest.json'
    },
  }
};

export default config;

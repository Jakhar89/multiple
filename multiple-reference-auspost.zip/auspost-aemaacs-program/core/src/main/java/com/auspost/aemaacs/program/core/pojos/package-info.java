@Version("${release.java.version}")
package com.auspost.aemaacs.program.core.pojos;

import org.osgi.annotation.versioning.Version;

package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.auspost.aemaacs.program.core.utils.DateUtils;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.DATE_FORMAT;
import static com.auspost.aemaacs.program.core.constants.Constants.DESCRIPTION;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.VARIANT;
import static com.auspost.aemaacs.program.core.constants.Constants.IMAGE_DECORATIVE;
import static com.day.cq.commons.jcr.JcrConstants.JCR_CONTENT;
import static com.day.cq.wcm.api.constants.NameConstants.PN_PAGE_LAST_MOD;

/**
 * @author Seeni Rajan
 */
@Getter
@Slf4j
@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PageListItem extends LinkItem {

    private final Resource resource;

    private final Boolean isDecorative;

    /**
     * Constructs a new ListItem.
     *
     * @param label        the label for the list item
     * @param linkURL      the URL for the link
     * @param linkTarget   the target for the link
     * @param linkManager  the link manager instance
     * @param resource     the Sling resource associated with this item
     * @param isDecorative indicates if the image is decorative.
     */
    public PageListItem(String label, String linkURL, String linkTarget, LinkManager linkManager,
                        Resource resource, boolean isDecorative) {
        super(label, linkURL, linkTarget, linkManager);
        this.resource = resource;
        this.isDecorative = isDecorative;
    }

    /**
     * Returns the banner image resource if present.
     *
     * @return the banner image resource, or {@code null} if not found
     */
    public Resource getBannerImage() {
        if (isResourceHasTheProperty(resource, VARIANT)) {
            String variant = resource.getValueMap().get(VARIANT, String.class);
            return DamAssetUtils
                    .getImageFromComponent(resource.getChild(variant + "Image"))
                    .map(img -> addDecorativeProperty(img, isDecorative))
                    .orElse(null);
        }
        return null;
    }

    /**
     * Returns the page image resource from the associated page if available.
     *
     * @return the page image resource, or {@code null} if not found
     */
    public Resource getPageImage() {
        if (isResourceIsPage(resource)) {
            return DamAssetUtils
                    .getImageFromPagePropertyOrElsePageContent(resource.adaptTo(Page.class))
                    .map(img -> addDecorativeProperty(img, isDecorative))
                    .orElse(null);
        } else {
            return null;
        }
    }

    /**
     * Adds the isDecorative property to the image resource when the image is marked as decorative.
     * @param imageResource the image resource
     * @param isDecorative  indicates whether the image is decorative
     *                      
     * @return the image resource with the decorative property added if applicable, or the original resource otherwise
     */
    private Resource addDecorativeProperty(Resource imageResource, boolean isDecorative) {
        if (!isDecorative) {
            return imageResource;
        }

        Map<String, Object> props = new HashMap<>(imageResource.getValueMap());
        props.put(IMAGE_DECORATIVE, isDecorative);

        return new ValueMapResource(
                imageResource.getResourceResolver(),
                imageResource.getPath(),
                imageResource.getResourceType(),
                new ValueMapDecorator(props)
        );
    }

    /**
     * Returns the last modified date of the associated page as a string.
     *
     * @return the last modified date as a string, or an empty string if not available
     */
    public String getLastModified() {
        if (resource != null && resource.getChild(JCR_CONTENT) != null) {
            return DateUtils.getFormattedDate(Objects.requireNonNull(resource.getChild(JCR_CONTENT)).getValueMap()
                    .get(PN_PAGE_LAST_MOD, Date.class), DATE_FORMAT);
        }
        return EMPTY;
    }

    /**
     * Returns the description of the associated page.
     *
     * @return the page description, or an empty string if not available
     */
    public String getPageDescription() {
        if (isResourceIsPage(resource)) {
            return Objects.requireNonNull(resource.adaptTo(Page.class)).getDescription();
        } else {
            return EMPTY;
        }
    }

    /**
     * Returns the banner description from the resource's value map.
     *
     * @return the banner description, or an empty string if not available
     */
    public String getBannerDescription() {
        if (isResourceHasTheProperty(resource, DESCRIPTION)) {
            return Objects.requireNonNull(resource.getValueMap().get(DESCRIPTION, String.class));
        } else {
            return EMPTY;
        }
    }

    /**
     * Returns the banner type from the resource's value map.
     *
     * @return the banner type, or an empty string if not available
     */
    public String getType() {
        if (isResourceHasTheProperty(resource, VARIANT)) {
            String bannerType = Objects.requireNonNull(resource.getValueMap().get(VARIANT, String.class));
            return switch (bannerType) {
                case "hero" -> "article-card";
                case "product" -> "stamp-card";
                default -> "default";
            };
        } else {
            return EMPTY;
        }
    }

    /**
     * Checks if the provided resource is a page.
     *
     * @param resource the resource to check
     * @return true if the resource is a page, false otherwise
     */
    private boolean isResourceIsPage(Resource resource) {
        return resource != null && resource.adaptTo(Page.class) != null;
    }

    /**
     * Checks if the provided resource has the specified property.
     *
     * @param resource     the resource to check
     * @param propertyName the property name to check
     * @return true if the resource has the specified property, false otherwise
     */
    private boolean isResourceHasTheProperty(Resource resource, String propertyName) {
        return resource != null && resource.getValueMap().containsKey(propertyName);
    }

    /**
     * Returns the externalized URL of the page item.
     *
     * @return the externalized URL of the page item
     */
    public String getPageItemUrl() {
        return resource.getResourceResolver().map(getURL());
    }

}

package com.auspost.aemaacs.program.core.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;


@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(alphabetic = true)
public class HeaderNavigationItem {

    private LinkItem parent;

    private List<HeaderNavigationItem> children;

    private boolean active;

    /**
     * Creates a HeaderNavigationItem with the specified link item and children links.
     *
     * @param parent   The parent link item.
     * @param children List of child links associated with parent.
     * @param active  State to check parent link active on hover.
     */
    public HeaderNavigationItem(LinkItem parent, List<HeaderNavigationItem> children, boolean active) {
        this.parent = parent;
        this.children = new ArrayList<>(Optional.ofNullable(children).orElse(Collections.emptyList()));
        this.active = active;
    }

    /**
     * Return list of child navigation items.
     *
     * @return HeaderNavigationItem list
     */
    public List<HeaderNavigationItem> getChildren() {
        return new ArrayList<>(children);
    }
}

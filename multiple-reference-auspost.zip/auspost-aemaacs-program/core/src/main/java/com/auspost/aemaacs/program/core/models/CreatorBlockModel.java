package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.pojos.LinkItem;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.day.cq.wcm.api.designer.Style;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Named;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.LINK_TARGET_BLANK;
import static com.auspost.aemaacs.program.core.constants.Constants.NN_FEATURED_IMAGE;


/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = CreatorBlockModel.class,
        resourceType = "auspost-aemaacs-program/components/creatorblock",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class CreatorBlockModel extends BaseComponentModel {

    @ScriptVariable
    private Style currentStyle;

    @ChildResource
    @Named(NN_FEATURED_IMAGE)
    private Resource authorImage;

    @Getter
    @ValueMapValue
    private String authorName;

    @Getter
    @ValueMapValue
    private String authorTitle;

    @Getter
    @ValueMapValue
    private String authorDescription;

    @Getter
    @ValueMapValue
    private String socialShareTitle;

    private IconItem facebookLink;

    private IconItem xLink;

    private IconItem linkedInLink;

    /**
     * Returns the Facebook sharing link.
     * This method constructs a sharing link for Facebook using the social share title
     * and the sharable URL prefix defined in the current style.
     *
     * @return an IconItem representing the Facebook sharing link
     */
    public IconItem getFacebookLink() {
        return new IconItem(socialShareTitle + " on facebook", getSharableUrl("facebookShareUrlPrefix"),
                LINK_TARGET_BLANK, linkManager, EMPTY, EMPTY);
    }

    /**
     * Returns the X (formerly Twitter) sharing link.
     * This method constructs a sharing link for X (formerly Twitter) using the social share title
     * and the sharable URL prefix defined in the current style.
     *
     * @return an IconItem representing the X sharing link
     */
    public IconItem getXLink() {
        return new IconItem(socialShareTitle + " on twitter", getSharableUrl("xShareUrlPrefix"),
                LINK_TARGET_BLANK, linkManager, EMPTY, EMPTY);
    }

    /**
     * Returns the LinkedIn sharing link.
     * This method constructs a sharing link for LinkedIn using the social share title
     * and the sharable URL prefix defined in the current style.
     *
     * @return an IconItem representing the LinkedIn sharing link
     */
    public IconItem getLinkedInLink() {
        return new IconItem(socialShareTitle + " on linkedin", getSharableUrl("linkedInShareUrlPrefix"),
                LINK_TARGET_BLANK, linkManager, EMPTY, EMPTY);
    }

    /**
     * Constructs the prefix URL for sharing links based on the current style and page path.
     * This method retrieves the prefix URL from the current style
     * and appends the externalized URL of the current page.
     *
     * @param propertyName the property name in the style that contains the prefix URL
     * @return the complete URL for sharing
     */
    private String getSharableUrl(String propertyName) {
        return this.currentStyle.get(propertyName).toString() + new LinkItem(EMPTY, (this.currentPage.getPath()), EMPTY,
                linkManager).getExternalizedURL();
    }

    /**
     * Returns the author image resource.
     * This method checks if the author image is a valid image resource
     * and returns it if valid, otherwise returns null.
     *
     * @return the author image resource if valid, otherwise null
     */
    public Resource getAuthorImage() {
        return DamAssetUtils.getImageFromComponent(resource).orElse(null);
    }

}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Navigation;
import com.adobe.cq.wcm.core.components.models.NavigationItem;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.FeatureCard;
import com.auspost.aemaacs.program.core.pojos.HeaderNavigationItem;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.pojos.LinkItem;
import com.auspost.aemaacs.program.core.pojos.PromoLink;
import com.auspost.aemaacs.program.core.utils.CommonUtils;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;
import static com.auspost.aemaacs.program.core.constants.Constants.TITLE;


@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = HeaderModel.class,
        resourceType = {
            "auspost-aemaacs-program/components/header",
            "auspost-aemaacs-program/components/ecommreportheader",
            "auspost-aemaacs-program/components/ecommsearch"
        },
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class HeaderModel extends BaseComponentModel implements Navigation {

    @Self
    @Via(type = ResourceSuperType.class)
    private Navigation navigation;

    @ChildResource
    private IconItem headerDesktopLogo;

    @ChildResource
    private IconItem headerTabletLogo;

    @ChildResource
    private IconItem headerMobileLogo;

    @ChildResource
    private LinkItem headerLogoLink;

    @Getter
    @ValueMapValue
    private String headerLogoAlt;

    @ChildResource
    private List<PromoLink> promoLinks;

    @ChildResource
    private List<IconItem> headerSecondaryLinks;

    @Getter
    @ValueMapValue
    private boolean disableSearch;

    @ChildResource
    private LinkItem search;

    @ChildResource
    private List<LinkItem> loginOptions;

    @ChildResource
    private IconItem loginOrSignup;

    @ChildResource
    private List<LinkItem> popularsearch;

    @ChildResource(name = "popularsearch")
    private Resource popularSearchResource;

    private List<HeaderNavigationItem> navigationLinkItem;

    private LinkItem searchLink;

    /**
     * Recursively traverses a {@link NavigationItem} tree and converts each node into a {@link LinkItem}, storing it in
     * the provided list.
     */
    public List<HeaderNavigationItem> getNavigationLinkItem() {
        if (navigationLinkItem == null) {
            navigationLinkItem = new ArrayList<>();
            for (NavigationItem navigationItem : this.getNavigationItems(navigation)) {
                navigationLinkItem.add(buildNavigationItem(navigationItem));
            }
        }
        return Collections.unmodifiableList(navigationLinkItem);
    }

    /**
     * Retrieve core navigation items via IA.
     *
     * @param navigation Core navigation object.
     * @return List<NavigationItem> List of navigation items.
     */
    private List<NavigationItem> getNavigationItems(Navigation navigation) {
        return Optional
                .ofNullable(navigation)
                .map(Navigation::getItems)
                .orElse(Collections.emptyList());
    }

    /**
     * Recursively collects all child navigation items from a given {@link NavigationItem} and adds them as
     * {@link LinkItem} objects to the provided list
     *
     * @param navigationItem the root {@link NavigationItem} from which to start collecting children
     */
    private HeaderNavigationItem buildNavigationItem(NavigationItem navigationItem) {
        LinkItem linkItem = new LinkItem(navigationItem.getTitle(), navigationItem.getPath(), EMPTY, linkManager);
        List<HeaderNavigationItem> childItems = new ArrayList<>();
        List<NavigationItem> navigationItems = navigationItem.getChildren();
        navigationItems.forEach(child -> childItems.add(buildNavigationItem(child)));
        return new HeaderNavigationItem(linkItem, childItems, navigationItem.isActive());
    }

    /**
     * Returns the list of promotional links configured for the header component.
     *
     * @return a list of {@link PromoLink} objects, or {@code null} if no promo links are configured
     */

    public List<PromoLink> getPromoLinks() {
        if (promoLinks != null) {
            promoLinks.forEach(this::buildPromoLink);
            return new ArrayList<>(promoLinks);
        }
        return Collections.emptyList();
    }


    /**
     * Updates the parent and child link items of the given PrimaryLink by setting links references using link manager.
     *
     * @param promoLink the PrimaryLink to update
     */
    private void buildPromoLink(PromoLink promoLink) {
        LinkUtils.buildLinkItem(linkManager, promoLink.getParentLink());
        LinkUtils.buildLinkItems(linkManager, promoLink.getChildLinks());
        if (promoLink.getFeatureCard() != null) {
            LinkUtils.buildLinkItem(linkManager, promoLink.getFeatureCard().getLink());
        }
    }


    /**
     * Build secondary links via core link manager.
     *
     * @return List of secondary link items.
     */
    public List<IconItem> getHeaderSecondaryLinks() {
        return LinkUtils.buildIconItems(linkManager, headerSecondaryLinks);
    }


    /**
     * Build search link via core link manager.
     *
     * @return Search link item.
     */
    public LinkItem getSearch() {
        if (searchLink != null) {
            return searchLink;
        }
        if (search != null) {
            search.setId(getId() + "-search");
            searchLink = LinkUtils.buildLinkItem(linkManager, search);
            return searchLink;
        }
        return null;
    }

    /**
     * Build search link via core link manager.
     *
     * @return Search link item.
     */
    public IconItem getLoginOrSignup() {
        if (loginOrSignup != null) {
            loginOrSignup.setId(getId() + "-loginOrSignup");
            return LinkUtils.buildIconItem(linkManager, loginOrSignup);
        }
        return null;
    }

    /**
     * Build login option links via core link manager.
     *
     * @return List of login link items.
     */
    public List<LinkItem> getLoginOptions() {
        return LinkUtils.buildLinkItems(linkManager, loginOptions);
    }

    /**
     * Build logo link via core link manager.
     *
     * @return Logo link item.
     */
    public LinkItem getHeaderLogoLink() {
        return LinkUtils.buildLinkItem(linkManager, headerLogoLink);
    }


    /**
     * Retrieves desktop logo icon item containing externalized image reference.
     *
     * @return Desktop logo icon item.
     */
    public IconItem getHeaderDesktopLogo() {
        return LinkUtils.buildIconItem(linkManager, headerDesktopLogo);
    }

    /**
     * Retrieves tablet logo icon item containing externalized image reference via core link manager.
     *
     * @return Tablet logo icon item.
     */
    public IconItem getHeaderTabletLogo() {
        return LinkUtils.buildIconItem(linkManager, headerTabletLogo);
    }


    /**
     * Retrieves mobile logo icon item containing externalized image reference via core link manager.
     *
     * @return Mobile logo icon item.
     */
    public IconItem getHeaderMobileLogo() {
        return LinkUtils.buildIconItem(linkManager, headerMobileLogo);
    }

    /**
     * Retrieves component data JSON for data layer integration.
     *
     * @return JSON string representing the data layer if enabled; otherwise, an empty string.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled()) {
            String componentId = getId();
            setDataLayerForHeaderLogo(componentId);
            setDataLayerForPromoLinks(componentId);
            setDataLayerForSecondaryLinks(componentId);
            setDataLayerForAuthOptions(componentId);
            setDataLayerForSearch(componentId);
            setDataLayerForNavigationItems(componentId);
            Map<String, Object> headerMap =
                    DataLayerUtils
                            .createEventMap(SITE_INTERACTION, "header||view", EMPTY);
            return DataLayerUtils.mapToJson(componentId, headerMap);
        }
        return EMPTY;
    }

    /**
     * Sets data layer entry for the header logo link.
     *
     * @param componentId Unique component ID for the header.
     */
    private void setDataLayerForHeaderLogo(String componentId) {
        if (headerLogoLink != null) {
            String id = componentId + "-header-logo-link";
            headerLogoLink.setId(id);
            DataLayerUtils.setDataLayerForLink(headerLogoLink, id, SITE_INTERACTION, "topNav||logo", "auspost-logo");
        }
    }

    /**
     * Sets data layer entries for promotional links in the header.
     *
     * @param componentId Unique component ID for the header.
     */
    private void setDataLayerForPromoLinks(String componentId) {
        if (promoLinks != null) {
            for (int i = 0; i < promoLinks.size(); i++) {
                PromoLink promo = promoLinks.get(i);
                setDataLayerForPrimaryLinks(promo, componentId, i);
                setDataLayerForFeatureCard(promo.getFeatureCard(), componentId, i);
            }
        }
    }


    /**
     * Sets data layer entries for primary links of promo link.
     *
     * @param promo       Promo object for which primary link has to set.
     * @param componentId Unique component ID for the header.
     * @param index       Index of promo link object.
     */
    private void setDataLayerForPrimaryLinks(PromoLink promo, String componentId, int index) {
        if (promo.getParentLink() != null) {
            String pId = componentId + "-promo-" + index + "-parent-link";
            promo.getParentLink().setId(pId);
            DataLayerUtils.setDataLayerForLink(
                    promo.getParentLink(),
                    pId,
                    SITE_INTERACTION,
                    "topNav||li",
                    DataLayerUtils.getFormattedDataLayerDescription(promo.getParentLink().getLabel())
            );

            List<LinkItem> childLinks = promo.getChildLinks();
            if (childLinks != null) {
                for (int j = 0; j < childLinks.size(); j++) {
                    LinkItem child = childLinks.get(j);
                    String cId = pId + "-child-link-" + j;
                    child.setId(cId);
                    DataLayerUtils.setDataLayerForLink(
                            child,
                            cId,
                            SITE_INTERACTION,
                            "topNav||li",
                            DataLayerUtils.getFormattedDataLayerDescription(child.getLabel())
                    );
                }
            }
        }

    }

    /**
     * Sets data layer entries for feature card of promo link.
     *
     * @param featureCard FeatureCard object of promo.
     * @param componentId Unique component ID for the header.
     * @param index       Index of promo link object.
     */
    private void setDataLayerForFeatureCard(FeatureCard featureCard, String componentId, int index) {
        if (featureCard != null && featureCard.getLink() != null) {
            String id = componentId + "-parent-link-" + index + "-feature-card-link";
            featureCard.getLink().setId(id);
            DataLayerUtils.setDataLayerForLink(
                    featureCard.getLink(),
                    id,
                    SITE_INTERACTION,
                    "topNav||featureCard",
                    DataLayerUtils.getFormattedDataLayerDescription(featureCard.getLink().getLabel())
            );
        }
    }

    /**
     * Sets data layer entries for secondary icon links in the header.
     *
     * @param componentId Unique component ID for the header.
     */
    private void setDataLayerForSecondaryLinks(String componentId) {
        if (headerSecondaryLinks != null) {
            for (int i = 0; i < headerSecondaryLinks.size(); i++) {
                IconItem item = headerSecondaryLinks.get(i);
                String id = componentId + "-secondary-link-" + i;
                item.setId(id);
                DataLayerUtils.setDataLayerForLink(
                        headerSecondaryLinks.get(i),
                        id,
                        SITE_INTERACTION,
                        "topNav||li",
                        DataLayerUtils.getFormattedDataLayerDescription(item.getLabel())
                );
            }
        }
    }

    /**
     * Sets data layer entries for authentication option links (e.g., login, register).
     *
     * @param componentId Unique component ID for the header.
     */
    private void setDataLayerForAuthOptions(String componentId) {
        if (loginOptions != null) {
            for (int i = 0; i < loginOptions.size(); i++) {
                LinkItem item = loginOptions.get(i);
                String id = componentId + "-auth-option-" + i;
                item.setId(id);
                DataLayerUtils.setDataLayerForLink(
                        item,
                        id,
                        SITE_INTERACTION,
                        "topNav||li",
                        DataLayerUtils.getFormattedDataLayerDescription(item.getLabel())
                );
            }
        }
    }

    /**
     * Sets data layer entry for the search icon or link.
     *
     * @param componentId Unique component ID for the header.
     */
    private void setDataLayerForSearch(String componentId) {
        if (search != null) {
            String id = componentId + "-search";
            search.setId(id);
            DataLayerUtils.setDataLayerForLink(
                    search,
                    id,
                    SITE_INTERACTION,
                    "topNav||search",
                    DataLayerUtils.getFormattedDataLayerDescription(search.getLabel())
            );
        }
    }

    /**
     * Sets the data layer attributes for all structured navigation items in the header. This method retrieves the list
     * of structured {@link HeaderNavigationItem} objects using {@link #getNavigationLinkItem()}, and for each item:
     *
     * @param componentId the base component ID used to construct unique data layer IDs for each navigation item
     */
    private void setDataLayerForNavigationItems(String componentId) {
        List<HeaderNavigationItem> navItems = getNavigationLinkItem();
        for (int i = 0; i < navItems.size(); i++) {
            setDataLayerForNavItem(navItems.get(i), componentId + "-nav-item-" + i);
        }
    }

    private void setDataLayerForNavItem(HeaderNavigationItem item, String id) {
        item.getParent().setId(id);
        DataLayerUtils
                .setDataLayerForLink(
                        item.getParent(),
                        id,
                        SITE_INTERACTION,
                        "topNav||li",
                        DataLayerUtils.getFormattedDataLayerDescription(item.getParent().getLabel())
                );
        List<HeaderNavigationItem> children = item.getChildren();
        for (int i = 0; i < children.size(); i++) {
            setDataLayerForNavItem(children.get(i), id + "-child-" + i);
        }
    }

    /**
     * Retrieves the id of the Header Component.
     *
     * @return unique id.
     */
    public String getId() {
        return ComponentUtils.getId(this.resource, this.currentPage, this.componentContext);
    }

    /**
     * Build popular search option links via core link manager.
     *
     * @return List of popular search link items.
     */
    public List<LinkItem> getPopularsearch() {
        return LinkUtils.buildLinkItems(linkManager, popularsearch);
    }

    /**
     * Builds and returns the Popular Searches JSON string for the header component.
     *
     * @return a JSON string representing popular search links,
     * or an empty string if no popular searches are configured
     */
    public String getPopularSearchJson() {
        if (popularsearch == null || popularsearch.isEmpty()) {
            return EMPTY;
        }
        List<Map<String, String>> items = getPopularsearch().stream()
                .filter(item -> !item.getLabel().isBlank() && item.getLink().getURL() != null)
                .map(item -> Map.of("label", item.getLabel(), "href",
                        Objects.requireNonNull(item.getLink().getMappedURL()), "target", item.getLinkTarget()))
                .toList();

        Map<String, Object> popularSearchMap = Map.of(TITLE, "POPULAR SEARCHES", "items", items);

        try {
            return CommonUtils.writeJson(popularSearchMap);
        } catch (JsonProcessingException e) {
            return EMPTY;
        }
    }

    /**
     * Builds and returns the Searches JSON string for popular search page.
     *
     * @return a JSON string representing search fields,
     * or an empty string if no searches are configured
     */
    public String getSearchJson() {
        if (popularSearchResource == null) {
            return EMPTY;
        }
        ValueMap vm = popularSearchResource.getValueMap();
        Map<String, Object> map = new HashMap<>();

        CommonUtils.addToMapIfNotBlank(map, "label", vm.get("popularSearchlabel", String.class));
        CommonUtils.addToMapIfNotBlank(map, "buttonText", vm.get("popularSearchButton", String.class));
        CommonUtils.addToMapIfNotBlank(map, "placeholder", vm.get("popularSearchPlaceholder", String.class));
        LinkItem link = getSearch();
        if (link != null) {
            CommonUtils.addToMapIfNotBlank(map, "redirectUrl", link.getMappedURL());
        }

        try {
            return map.isEmpty() ? EMPTY : CommonUtils.writeJson(map);
        } catch (JsonProcessingException e) {
            return EMPTY;
        }
    }
}

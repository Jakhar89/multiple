package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.form.Container;
import com.auspost.aemaacs.program.core.pojos.NameValueItem;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.List;

@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = Container.class,
        resourceType = "auspost-aemaacs-program/components/form/container",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class FormContainerModel implements Container {

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private Container container;

    @ValueMapValue
    private String formTitle;

    @ValueMapValue
    private String campaignId;

    @ValueMapValue
    private String salesforceUser;

    @ValueMapValue
    private String leadSource;

    @ValueMapValue
    private String formStatus;

    @ChildResource
    private List<NameValueItem> hiddenFields;

    @ValueMapValue
    private String errorMessage;

}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.form.Options;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import static com.auspost.aemaacs.program.core.constants.Constants.HYPHEN;
import static com.auspost.aemaacs.program.core.constants.Constants.SF_FIELD_IDENTIFIER;
import static com.auspost.aemaacs.program.core.constants.Constants.SPACE;

@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = Options.class,
        resourceType = "auspost-aemaacs-program/components/form/options",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class FormInputOptions implements Options {

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private Options options;

    @ValueMapValue
    private String required;

    @ValueMapValue
    private String requiredMessage;

    /**
     * Generates a unique name for the options input field by combining a sanitized version of the title with the original name.
     * If the title is empty, it defaults to "no_title".
     *
     * @return A unique name for the options input field.
     */
    @Override
    public String getName() {
        String title = options.getTitle();
        if (StringUtils.isNotEmpty(title)) {
            return title.replaceAll(SPACE, HYPHEN).toLowerCase() + SF_FIELD_IDENTIFIER + options.getName();
        }
        return "no_title" + SF_FIELD_IDENTIFIER + options.getName();
    }

}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.*;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.List;
import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;


@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = FooterModel.class,
        resourceType = "auspost-aemaacs-program/components/footer",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class FooterModel extends BaseComponentModel {

    @ChildResource
    private IconItem desktopLogo;

    @ChildResource
    private IconItem tabletLogo;

    @ChildResource
    private IconItem mobileLogo;

    @ChildResource
    private LinkItem logoLink;

    @Getter
    @ValueMapValue
    private String logoAlt;

    @ChildResource
    private List<PrimaryLink> primaryLinks;

    @ChildResource
    private List<PromoCard> promoCards;

    @ChildResource
    private List<LinkItem> secondaryLinks;

    @ChildResource
    private List<IconItem> socialLinks;

    @ChildResource
    private IconItem footnoteLogo;

    @Getter
    @ValueMapValue
    private String footnoteLogoAlt;

    @Getter
    @ValueMapValue
    private String footnote;


    /**
     * Retrieves primary links containing parent and child items. Parent and child links built via core link manager.
     *
     * @return List of primary link items.
     */
    public List<PrimaryLink> getPrimaryLinks() {
        if (primaryLinks != null) {
            primaryLinks.forEach(this::buildPrimaryLink);
        }
        return primaryLinks;
    }

    /**
     * Updates the parent and child link items of the given PrimaryLink by setting links references using link manager.
     *
     * @param primaryLink the PrimaryLink to update
     */
    private void buildPrimaryLink(PrimaryLink primaryLink) {
        LinkUtils.buildLinkItem(linkManager, primaryLink.getParentLink());
        LinkUtils.buildLinkItems(linkManager, primaryLink.getChildLinks());
    }

    /**
     * Retrieves promo cards.
     *
     * @return List of promo cards.
     */
    public List<PromoCard> getPromoCards() {
        if (promoCards != null) {
            promoCards.forEach(this::buildPromoCard);
        }
        return promoCards;
    }

    /**
     * Updates the promo cards links by setting links references using link manager.
     *
     * @param promoCard the PromoCard to update.
     */
    private void buildPromoCard(PromoCard promoCard) {
        LinkUtils.buildLinkItem(linkManager, promoCard.getPromoLink());
    }


    /**
     * Build secondary links via core link manager.
     *
     * @return List of secondary link items.
     */
    public List<LinkItem> getSecondaryLinks() {
        return LinkUtils.buildLinkItems(linkManager, secondaryLinks);
    }


    /**
     * Build social links via core link manager.
     *
     * @return List of social link items.
     */
    public List<IconItem> getSocialLinks() {
        return LinkUtils.buildIconItems(linkManager, socialLinks);
    }


    /**
     * Build logo link via core link manager.
     *
     * @return Logo link item.
     */
    public LinkItem getLogoLink() {
        if (logoLink != null) {
            logoLink.setId(getId() + "-footer-logo-link");
            return LinkUtils.buildLinkItem(linkManager, logoLink);
        }
        return null;
    }


    /**
     * Retrieves desktop logo icon item containing externalized image reference.
     *
     * @return Desktop logo icon item.
     */
    public IconItem getDesktopLogo() {
        return LinkUtils.buildIconItem(linkManager, desktopLogo);
    }

    /**
     * Retrieves tablet logo icon item containing externalized image reference via core link manager.
     *
     * @return Tablet logo icon item.
     */
    public IconItem getTabletLogo() {
        return LinkUtils.buildIconItem(linkManager, tabletLogo);
    }


    /**
     * Retrieves mobile logo icon item containing externalized image reference via core link manager.
     *
     * @return Mobile logo icon item.
     */
    public IconItem getMobileLogo() {
        return LinkUtils.buildIconItem(linkManager, mobileLogo);
    }


    /**
     * Retrieves footnote logo icon item containing externalized image reference via core link manager.
     *
     * @return Footnote logo icon item.
     */
    public IconItem getFootnoteLogo() {
        return LinkUtils.buildIconItem(linkManager, footnoteLogo);
    }


    /**
     * Retrieves component data json string for data layer integration Primary links, Secondary links and Promo cards
     * are constructed with respective id's.
     *
     * @return Json String data if the data layer is enabled; otherwise, empty string.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled()) {
            String componentId = getId();
            // set data layer for primary links
            setDataLayerForPrimaryLinks(componentId);
            // set data layer for promo link
            setDataLayerForPromoCard(componentId);
            // set data layer for secondary links
            setDataLayerForSecondaryLinks(componentId);
            // set data layer for footer
            Map<String, Object> footerMap = DataLayerUtils.createEventMap(SITE_INTERACTION, "footer||view", EMPTY);
            return DataLayerUtils.mapToJson(componentId, footerMap);
        }
        return EMPTY;
    }


    /**
     * Sets the data layer for the promo cards.
     *
     * @param componentId of footer component.
     */
    private void setDataLayerForPromoCard(String componentId) {
        if (promoCards != null) {
            for (int i = 0; i < promoCards.size(); i++) {
                PromoCard promoCard = promoCards.get(i);
                String pId = componentId + "-promo-card-" + promoCards.indexOf(promoCard);
                promoCard.getPromoLink().setId(pId);
                DataLayerUtils
                        .setDataLayerForLink(
                                promoCard.getPromoLink(),
                                pId,
                                SITE_INTERACTION,
                                "footer||promoCard",
                                DataLayerUtils.getFormattedDataLayerDescription(promoCard.getPromoTitle())
                        );
            }
        }
    }


    /**
     * Sets the data layer for the secondary links.
     *
     * @param componentId of footer component.
     */
    private void setDataLayerForSecondaryLinks(String componentId) {
        if (secondaryLinks != null) {
            for (int i = 0; i < secondaryLinks.size(); i++) {
                LinkItem secondaryLink = secondaryLinks.get(i);
                String id = componentId + "-secondary-link-" + secondaryLinks.indexOf(secondaryLink);
                secondaryLink.setId(id);
                DataLayerUtils
                        .setDataLayerForLink(
                                secondaryLink,
                                id,
                                SITE_INTERACTION,
                                "footer||li",
                                DataLayerUtils.getFormattedDataLayerDescription(secondaryLink.getLabel())
                        );
            }
        }
    }


    /**
     * Sets the data layer for the primary links.
     *
     * @param componentId of footer component.
     */
    private void setDataLayerForPrimaryLinks(String componentId) {
        if (primaryLinks != null) {
            for (int i = 0; i < primaryLinks.size(); i++) {
                PrimaryLink primaryLink = primaryLinks.get(i);
                // set data layer for parent link
                String pId = componentId + "-parent-link-" + primaryLinks.indexOf(primaryLink);
                primaryLink.getParentLink().setId(pId);
                DataLayerUtils
                        .setDataLayerForLink(
                                primaryLink.getParentLink(),
                                pId,
                                SITE_INTERACTION,
                                "footer||li",
                                DataLayerUtils.getFormattedDataLayerDescription(primaryLink.getParentLink().getLabel())
                        );
                // set data layer for child links
                List<LinkItem> childLinks = primaryLink.getChildLinks();
                childLinks.forEach(childLink -> {
                    String cId = pId + "-child-link-" + childLinks.indexOf(childLink);
                    childLink.setId(cId);
                    DataLayerUtils
                            .setDataLayerForLink(
                                    childLink,
                                    cId,
                                    SITE_INTERACTION,
                                    "footer||li",
                                    DataLayerUtils.getFormattedDataLayerDescription(childLink.getLabel())
                            );
                });
            }
        }
    }
}

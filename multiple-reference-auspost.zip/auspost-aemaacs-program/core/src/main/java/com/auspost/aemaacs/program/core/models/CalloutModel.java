package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.style.ComponentStyleInfo;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.CalloutMessage;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.Map;
import java.util.Optional;

import java.util.List;
import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_IMPRESSION;


/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = CalloutModel.class,
        resourceType = "auspost-aemaacs-program/components/callout",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class CalloutModel extends BaseComponentModel {

    @Self
    @Via("resource")
    private ComponentStyleInfo componentStyleInfo;

    @Getter
    @ValueMapValue
    private String calloutHeading;

    @Getter
    @ValueMapValue
    private String iconType;

    @ChildResource
    private List<CalloutMessage> calloutMessages;

    /**
     * Returns the data layer JSON string for the callout component. If data layer is enabled, it constructs a JSON
     * object with the component ID and event details. The primary and secondary CTAs are also included in the data
     * layer with their respective IDs.
     *
     * @return A JSON string representing the data layer for the callout component, or an empty string if data layer is
     * not enabled.
     */
    public String getDataLayer() {
        if (!isDataLayerEnabled()) {
            return Constants.EMPTY;
        }

        String componentId = getId();

        Optional.ofNullable(calloutMessages).ifPresent(messages ->
                messages.forEach(item -> {
                    Optional.ofNullable(item).ifPresent(msg ->
                            DataLayerUtils.getDataLayerForCTA(componentId, msg.getCta(), linkManager, "callout||cta", getCalloutType(), calloutHeading, true));
                })
        );


        Map<String, Object> calloutMap = DataLayerUtils.createEventMap(
                SITE_IMPRESSION,
                "callout||view",
                DataLayerUtils.getFormattedDataLayerDescription(getCalloutType() + COLON + calloutHeading)
        );

        return DataLayerUtils.mapToJson(componentId, calloutMap);
    }

    /**
     * Returns the callout type for the component.
     * If `componentStyleInfo` is present and its applied CSS classes are not blank, returns those classes.
     * Otherwise, returns the value of `iconType`.
     *
     * @return the callout type as a `String`
     */
    private String getCalloutType() {
        return Optional.ofNullable(componentStyleInfo)
                .map(ComponentStyleInfo::getAppliedCssClasses)
                .filter(StringUtils::isNotBlank)
                .orElse(iconType);
    }
    /**
     * Builds links for all CTA buttons in callout messages.
     * Returns the same list for convenience.
     */
    public List<CalloutMessage> getCalloutMessages() {
        Optional.ofNullable(calloutMessages).ifPresent(messages ->
                messages.forEach(msg -> Optional.ofNullable(msg).flatMap(m -> Optional.ofNullable(m.getCta()))
                        .ifPresent(ctas ->
                                ctas.forEach(cta -> LinkUtils.buildLinkItem(linkManager, cta))))
        );
        return calloutMessages;
    }
}

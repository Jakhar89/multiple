package com.auspost.aemaacs.program.core.utils;

import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.resource.filter.ResourceFilterStream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Spliterators;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.auspost.aemaacs.program.core.constants.Constants.CQ_TAGS;
import static com.auspost.aemaacs.program.core.constants.Constants.IMAGE_DECORATIVE;
import static com.auspost.aemaacs.program.core.constants.Constants.PIPE;
import static com.auspost.aemaacs.program.core.constants.Constants.PN_FILE_REFERENCE;
import static com.auspost.aemaacs.program.core.constants.Constants.PN_IMAGE_FROM_PAGE;
import static com.auspost.aemaacs.program.core.constants.Constants.RT_IMAGE;
import static com.auspost.aemaacs.program.core.constants.Constants.SLASH;
import static com.auspost.aemaacs.program.core.constants.Constants.TAG;

/**
 * @author Seeni Rajan
 */
public class ListingUtils {

    public static final String IS_SELECTED = "isSelected";

    public static final String LIST_CTA = "list||cta";

    public static final String FILTERED_RESULTS = "filtered-results";

    private ListingUtils() {
    }

    /**
     * Creates a stream of child tags for a given parent tag.
     *
     * @param tag the parent tag.
     * @return a stream of child tags.
     */
    public static Stream<Tag> getChildrenTagsStream(Tag tag) {
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(tag.listChildren(), 0), false);
    }

    /**
     * Checks if a page matches all the required tags.
     *
     * @param page         the page to check.
     * @param requiredTags the list of required tags.
     * @return true if the page matches all the required tags, false otherwise.
     */
    public static boolean matchesAllPageTags(Page page, List<String> requiredTags) {
        String[] pageTags = page.getProperties().get(CQ_TAGS, new String[] {});
        List<String> pageTagList = Arrays.asList(pageTags);
        return new HashSet<>(pageTagList).containsAll(requiredTags);
    }

    /**
     * Checks if a page matches all the required tags.
     *
     * @param assetResource the assetResource to check.
     * @param requiredTags  the list of required tags.
     * @return true if the page matches all the required tags, false otherwise.
     */
    public static boolean matchesAllAssetTags(Resource assetResource, List<String> requiredTags) {
        String[] assetTags = assetResource.getValueMap().get(CQ_TAGS, new String[] {});
        List<String> assetTagList = Arrays.asList(assetTags);
        return new HashSet<>(assetTagList).containsAll(requiredTags);
    }

    /**
     * Sorts two objects based on their date values.
     *
     * @param a the first object containing a date.
     * @param b the second object containing a date.
     * @return an integer representing the comparison result.
     */
    public static int sortDate(Object[] a, Object[] b) {
        String dateA = (String) a[2];
        String dateB = (String) b[2];
        if (dateA == null && dateB == null) {
            return 0;
        }
        if (dateA == null) {
            return 1;
        }
        if (dateB == null) {
            return -1;
        }
        return dateB.compareTo(dateA);
    }

    /**
     * Creates a stream of parent tags from the filter tag list.
     *
     * @param tagManager the TagManager instance used to resolve tags.
     * @return a stream of parent tags.
     */
    public static Stream<Tag> getParentTagStream(TagManager tagManager, List<Resource> filterTagList) {
        return filterTagList.stream()
                .map(res -> res.getValueMap().get(TAG, String.class))
                .filter(StringUtils::isNotEmpty)
                .map(tagManager::resolve)
                .filter(Objects::nonNull);
    }


    /**
     * Converts the list of valid selectors to a string representation.
     *
     * @return a string representation of the valid selectors.
     */
    public static String getFilterListAsString(TagManager tagManager, List<String> validSelectors) {
        return validSelectors.stream()
                .map(tagManager::resolve)
                .filter(Objects::nonNull)
                .map(Tag::getTitle)
                .filter(Objects::nonNull)
                .collect(Collectors.joining(PIPE + PIPE));
    }

    /**
     * Validates the selectors against the available tags in the TagManager.
     *
     * @param selectors     - selectors to validate
     * @param tagManager    - TagManager instance used to resolve tags
     * @param filterTagList - list of tags to validate against
     * @return - list of valid selectors
     */

    public static List<String> validateSelectors(String[] selectors, TagManager tagManager,
                                                 List<Resource> filterTagList) {
        List<String> validSelectors = new ArrayList<>();
        ListingUtils.getParentTagStream(tagManager, filterTagList).forEach(parentTag -> {
            for (String selector : selectors) {
                String candidateTagId = parentTag.getTagID() + SLASH + selector;
                Tag resolvedTag = tagManager.resolve(candidateTagId);
                if (resolvedTag != null) {
                    validSelectors.add(candidateTagId);
                }
            }
        });
        return validSelectors;
    }

    /**
     * Gets the filters for the listing.
     *
     * @param filterTagList        - list of tags to validate against
     * @param tagManager           - TagManager instance used to resolve tags
     * @param selectors            - selectors to validate
     * @param validSelectorsHolder - list of valid selectors
     * @return - list of filters
     */
    public static List<Map<String, List<Map<String, Object>>>> getFilters(
            List<Resource> filterTagList,
            TagManager tagManager,
            String[] selectors,
            List<String> validSelectorsHolder) {
        List<String> validSelectors = validateSelectors(selectors, tagManager, filterTagList);
        validSelectorsHolder.clear();
        validSelectorsHolder.addAll(validSelectors);
        return getParentTagStream(tagManager, filterTagList)
                .map(parentTag -> Map.of(
                        parentTag.getTitle(),
                        getChildrenTagsStream(parentTag)
                                .sorted(ListingUtils::sortAlphabetically)
                                .map(childTag -> Map.of(
                                        TAG, childTag,
                                        IS_SELECTED, validSelectors.contains(childTag.getTagID())
                                ))
                                .toList()
                ))
                .toList();
    }

    /**
     * Comparator to sort tags alphabetically, with numeric titles sorted in descending order.
     *
     * @param tag1 the first tag to compare.
     * @param tag2 the second tag to compare.
     * @return an integer representing the comparison result.
     */
    private static int sortAlphabetically(Tag tag1, Tag tag2) {
        String t1 = tag1.getTitle();
        String t2 = tag2.getTitle();
        boolean isNum1 = t1.matches("\\d+");
        boolean isNum2 = t2.matches("\\d+");
        if (isNum1 && isNum2) {
            // Descending numeric order
            return Integer.compare(Integer.parseInt(t2), Integer.parseInt(t1));
        }
        // Alphabetical order (case-insensitive)
        return t1.compareToIgnoreCase(t2);
    }


    /**
     * Creates a synthetic resource for a PDF image.
     *
     * @param resource     the original resource.
     * @param resolver     the ResourceResolver to create the synthetic resource.
     * @param imagePath    the path to the image.
     * @param isDecorative indicates if the image is decorative.
     * @return the synthetic resource representing the PDF image.
     */
    public static Resource createPdfSyntheticResource(Resource resource, ResourceResolver resolver,
                                                      String imagePath, boolean isDecorative) {
        Map<String, Object> props = new HashMap<>();
        props.put(PN_FILE_REFERENCE, imagePath);
        props.put(PN_IMAGE_FROM_PAGE, "false");
        if(isDecorative) {
            props.put(IMAGE_DECORATIVE, "true");
        }
        ValueMapDecorator valueMapDecorator = new ValueMapDecorator(props);
        String path = resource.getPath() + "/image";
        return new ValueMapResource(resolver, path, RT_IMAGE, valueMapDecorator);
    }

    /**
     * Retrieves the selectors from the SlingHttpServletRequest if present.
     *
     * @param request the SlingHttpServletRequest object.
     * @return an array of selectors, or an empty array if none are present.
     */
    public static String[] getSelectorsIfPresent(SlingHttpServletRequest request) {
        String[] selectors = request.getRequestPathInfo().getSelectors();
        return selectors.length > 0 ? selectors : new String[0];
    }

    /**
     * Extracts the year and month from a tag name.
     *
     * @param tagName the tag name in the format "Month YYYY", "Month", or "YYYY".
     * @return an array where the first element is the year (0 if not present) and the second element is the month (0 if not present).
     */
    public static int[] extractYearMonth(String tagName) {
        // Only supports "Month YYYY" and "YYYY" formats
        String[] parts = tagName.trim().split("\\s+", 2);
        int year = 0;
        int month = 0;
        if (parts.length == 2) {
            month = DateUtils.parseMonth(parts[0].trim().toLowerCase());
            year = Integer.parseInt(parts[1]);
        } else {
            year = Integer.parseInt(parts[0]);
        }
        return new int[] {year, month};
    }

    /**
     * Retrieves the banner resource from the page content.
     *
     * @param page the page to get the banner from.
     * @return an Optional containing the banner resource if found, otherwise empty.
     */
    public static Optional<Resource> getBannerFromPageContent(Page page) {
        return Optional.ofNullable(page)
                .map(Page::getContentResource)
                .map(jcrContent -> jcrContent.getChild(Constants.NN_ROOT))
                .map(root -> root.adaptTo(ResourceFilterStream.class))
                .flatMap(findFirstBanner());
    }

    /**
     * Helper function to locate the first banner resource.
     *
     * @return A function using ResourceFilterStream that filters and retrieves the first matching banner.
     */
    private static Function<ResourceFilterStream, Optional<? extends Resource>> findFirstBanner() {
        return rfs -> rfs.setBranchSelector("[jcr:primaryType] == $primaryType")
                .setChildSelector("[sling:resourceType] == $resourceType")
                .addParam("primaryType", JcrConstants.NT_UNSTRUCTURED)
                .addParam(SlingConstants.PROPERTY_RESOURCE_TYPE, Constants.BANNER_RESOURCE_TYPE)
                .stream()
                .findFirst();
    }

    /**
     * Extracts the offset value from the request selectors.
     *
     * @return the offset value if present, otherwise returns 0.
     */
    public static int getOffSetValueFromSelector(String[] selectors) {
        if (selectors == null) {
            return 0;
        }
        for (String selector : selectors) {
            if (selector.startsWith("offset")) {
                return Integer.parseInt(StringUtils.substringAfter(selector, "offset"));
            }
        }
        return 0;
    }

    /**
     * Returns a sublist of items based on the provided offset and initial page load values.
     * <p>
     * If an offset selector (e.g., "offset5") is present in the selectors array and greater than 0,
     * the method returns a sublist starting from the offset index, containing up to {@code initialPageLoad} items.
     * If no offset is present or offset is 0, it returns the first {@code initialPageLoad} items.
     * Handles null or empty lists safely.
     *
     * @param items           the original list of items
     * @param initialPageLoad the number of items to load per page
     * @param selectors       the array of selectors, which may contain an offset value
     * @param <T>             the type of items in the list
     * @return a sublist of items based on offset and initial page load, or an empty list if input is null or empty
     */
    public static <T> List<T> processOffSet(List<T> items, int initialPageLoad, String[] selectors) {
        int size = items.size();
        int fromIndex = 0;
        int toIndex = Math.min(initialPageLoad, size);
        int offSet = getOffSetValueFromSelector(selectors);
        if (offSet > 0) {
            fromIndex = Math.min(offSet, size);
            toIndex = Math.min(fromIndex + initialPageLoad, size);
        }
        return items.subList(fromIndex, toIndex);
    }
}

package com.auspost.aemaacs.program.core.services;

import java.io.IOException;

/**
 * @author Sathish Balan
 */
public interface SalesforceWebToLeadClient {
    String submit(String data, String type) throws IOException, InterruptedException;
}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.style.ComponentStyleInfo;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.Map;
import java.util.Optional;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;


@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = GlobalAlertModel.class,
        resourceType = "auspost-aemaacs-program/components/globalalert",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class GlobalAlertModel extends BaseComponentModel {

    @Getter
    @ValueMapValue
    private String alertMessage;

    @Getter
    @ValueMapValue
    private boolean enableDataLayer;

    private String appliedCssClasses;

    @Self
    @Via("resource")
    private ComponentStyleInfo componentStyleInfo;

    /**
     * Retrieves component data JSON for data layer integration.
     *
     * @return JSON string representing the data layer if enabled; otherwise, an empty string.
     */
    public String getDataLayer() {
        if (enableDataLayer && isDataLayerEnabled()) {
            String componentId = getId();
            String cssClass = getAppliedCssClasses();
            Map<String, Object> alert = DataLayerUtils.createEventMap(
                    SITE_INTERACTION,
                    "alert",
                    cssClass
            );
            return DataLayerUtils.mapToJson(componentId, alert);
        }
        return EMPTY;
    }

    /**
     * Get the Style css applied to the component.
     *
     * @return String value for css name.
     */
    public String getAppliedCssClasses() {
        return Optional.ofNullable(componentStyleInfo)
                .map(ComponentStyleInfo::getAppliedCssClasses)
                .filter(StringUtils::isNotBlank)
                .orElse(null);
    }
}

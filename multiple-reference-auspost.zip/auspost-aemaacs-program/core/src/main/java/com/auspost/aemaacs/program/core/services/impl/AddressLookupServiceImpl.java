package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.services.AddressLookupService;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.propertytypes.ServiceDescription;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.ACCESS_TOKEN;
import static com.auspost.aemaacs.program.core.constants.Constants.APPLICATION_JSON;
import static com.auspost.aemaacs.program.core.constants.Constants.AUDIENCE;
import static com.auspost.aemaacs.program.core.constants.Constants.AUTHORIZATION;
import static com.auspost.aemaacs.program.core.constants.Constants.BEARER;
import static com.auspost.aemaacs.program.core.constants.Constants.CLIENT_CREDENTIALS;
import static com.auspost.aemaacs.program.core.constants.Constants.CLIENT_ID;
import static com.auspost.aemaacs.program.core.constants.Constants.CLIENT_SECRET;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.GRANT_TYPE;
import static com.auspost.aemaacs.program.core.constants.Constants.HTTP_SUCCESS_CODE;
import static com.auspost.aemaacs.program.core.constants.Constants.UTF_8;

/**
 * @author Seeni Rajan
 */
@Slf4j
@Component(service = AddressLookupService.class)
@ServiceDescription("Address Lookup Service")
@Designate(ocd = AddressLookupServiceImpl.Configuration.class)
public class AddressLookupServiceImpl implements AddressLookupService {

    private String apiHost;

    private String tokenHost;

    private String clientID;

    private String clientSecret;

    private String audience;

    private String addressSuggestionEndpoint;

    private String postcodeOrSuburbSuggestionEndpoint;

    private CloseableHttpClient httpClient;

    /**
     * Enum representing the type of address used in lookup requests.
     * <ul>
     *   <li>POSTAL_CODE - Indicates the search is for a postal code.</li>
     *   <li>LOCALITY - Indicates the search is for a locality/suburb.</li>
     * </ul>
     */
    private enum AddressType {
        POSTAL_CODE,
        LOCALITY
    }

    /**
     * Activates or modifies the service configuration.
     *
     * @param configuration the configuration object containing service properties
     */
    @Activate
    @Modified
    private void activate(Configuration configuration) {
        this.apiHost = configuration.apiHost();
        this.tokenHost = configuration.tokenHost();
        this.clientID = configuration.clientID();
        this.clientSecret = configuration.clientSecret();
        this.audience = configuration.audience();
        this.addressSuggestionEndpoint = configuration.addressSuggestionEndpoint();
        this.postcodeOrSuburbSuggestionEndpoint = configuration.postcodeOrSuburbSuggestionEndpoint();
        this.httpClient = createCustomHttpClient();
    }

    @Deactivate
    @Modified
    private void deactivate() {
        if (httpClient != null) {
            try {
                httpClient.close();
                httpClient = null;
            } catch (IOException e) {
                log.error("Exception occurred while closing HttpClient: ", e);
            }
        }
    }

    /**
     * Fetches domestic address suggestions from the API based on the search text.
     *
     * @param searchText the address search term
     * @return JSON string of address suggestions or empty string if an error occurs
     */
    @Override
    public String getDomesticAddressSuggestion(String searchText) {
        try {
            URIBuilder builder = new URIBuilder(apiHost + addressSuggestionEndpoint);
            builder.setParameter("term", searchText).setParameter("country", "AU").setParameter("limit", "20");
            HttpGet httpGet = new HttpGet(builder.build());
            httpGet.setConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.IGNORE_COOKIES).build());
            httpGet.setHeader(AUTHORIZATION, BEARER + sanitizeHeaderValue(getBearerToken()));
            HttpResponse apiResponse = httpClient.execute(httpGet);
            if (HTTP_SUCCESS_CODE == apiResponse.getStatusLine().getStatusCode()) {
                return EntityUtils.toString(apiResponse.getEntity());
            } else {
                return apiResponse.toString();
            }
        } catch (IOException | URISyntaxException e) {
            log.error("Exception occurred while fetching Domestic Address Suggestions: ", e);
        }
        return EMPTY;
    }

    /**
     * Fetches domestic postcode suggestions from the API based on the provided suburb name.
     *
     * @param suburb the suburb name to search for postcode suggestions
     * @return JSON string of postcode suggestions or empty string if an error occurs
     */
    @Override
    public String getDomesticPostCodeSuggestion(String suburb) {
        return executeSuggestionRequest(getStringEntity(suburb, AddressType.LOCALITY));
    }

    /**
     * Fetches domestic suburb suggestions from the API based on the provided postcode.
     *
     * @param postcode the postcode to search for suburb suggestions
     * @return JSON string of suburb suggestions or empty string if an error occurs
     */
    @Override
    public String getDomesticSuburbSuggestion(String postcode) {
        return executeSuggestionRequest(getStringEntity(postcode, AddressType.POSTAL_CODE));
    }

    /**
     * Executes a suggestion request to the API using the provided JSON entity.
     *
     * @param entity the {@link StringEntity} containing the request payload
     * @return JSON string of suggestions or empty string if an error occurs
     */
    private String executeSuggestionRequest(StringEntity entity) {
        try {
            URIBuilder builder = new URIBuilder(apiHost + postcodeOrSuburbSuggestionEndpoint);
            HttpPost httpPost = new HttpPost(builder.build());
            httpPost.setConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.IGNORE_COOKIES).build());
            httpPost.setHeader(AUTHORIZATION, BEARER + sanitizeHeaderValue(getBearerToken()));
            httpPost.setEntity(entity);
            HttpResponse apiResponse = httpClient.execute(httpPost);
            if (HTTP_SUCCESS_CODE == apiResponse.getStatusLine().getStatusCode()) {
                return EntityUtils.toString(apiResponse.getEntity());
            } else {
                return apiResponse.toString();
            }
        } catch (IOException | URISyntaxException e) {
            log.error("Exception occurred while fetching Domestic suburb Suggestions: ", e);
        }
        return EMPTY;
    }

    /**
     * Builds a {@link StringEntity} containing a JSON payload for address lookup requests.
     *
     * @param searchString the search value (postcode or suburb)
     * @param addressType  the type of address (POSTAL_CODE or LOCALITY)
     * @return a {@link StringEntity} with the request JSON, ready to be sent to the API
     */
    private static StringEntity getStringEntity(String searchString, AddressType addressType) {
        JsonObject keyObject = new JsonObject();
        keyObject.addProperty("type", addressType.name());
        keyObject.addProperty("value", searchString);

        JsonObject requestObject = new JsonObject();
        requestObject.addProperty("country_iso", "AU"); //hard coded as AU for domestic
        requestObject.addProperty("max_addresses", "5"); //hard coded max addresses
        requestObject.addProperty("max_suggestions", 5); //hard coded max suggestions
        requestObject.add("key", keyObject);

        StringEntity entity = new StringEntity(requestObject.toString(), UTF_8);
        entity.setContentType(APPLICATION_JSON);
        return entity;
    }

    /**
     * Retrieves a bearer token for API authentication.
     *
     * @return the bearer token string or empty string if an error occurs
     */
    private String getBearerToken() throws IOException {
        List<BasicNameValuePair> requestParams = getBasicNameValuePairs(clientID, clientSecret, audience);
        HttpPost httpPost = new HttpPost(tokenHost);
        httpPost.setEntity(new UrlEncodedFormEntity(requestParams));
        CloseableHttpResponse authResponse = httpClient.execute(httpPost);
        if (HTTP_SUCCESS_CODE == authResponse.getStatusLine().getStatusCode()) {
            String responseString = EntityUtils.toString(authResponse.getEntity());
            JsonObject responseObject = JsonParser.parseString(responseString).getAsJsonObject();
            return responseObject.get(ACCESS_TOKEN).getAsString();
        } else {
            return EMPTY;
        }
    }

    /**
     * Creates a custom HTTP client with specific request configuration.
     *
     * @return a CloseableHttpClient instance
     */
    private CloseableHttpClient createCustomHttpClient() {
        RequestConfig customizedRequestConfig =
                RequestConfig.custom()
                        .setConnectTimeout(5000) // Connection timeout in ms
                        .setConnectionRequestTimeout(5000) // Request timeout in ms
                        .setSocketTimeout(5000) // Socket timeout in ms
                        .setCookieSpec(CookieSpecs.IGNORE_COOKIES).build();
        HttpClientBuilder customizedClientBuilder =
                HttpClients.custom().setDefaultRequestConfig(customizedRequestConfig);
        return customizedClientBuilder.build();
    }

    /**
     * Builds a list of basic name-value pairs for authentication requests.
     *
     * @param clientId     the client ID
     * @param clientSecret the client secret
     * @param audience     the audience value
     * @return list of BasicNameValuePair for the request
     */
    private static List<BasicNameValuePair> getBasicNameValuePairs(String clientId, String clientSecret,
                                                                   String audience) {
        List<BasicNameValuePair> params = new ArrayList<>();
        params.add(new BasicNameValuePair(GRANT_TYPE, CLIENT_CREDENTIALS));
        params.add(new BasicNameValuePair(CLIENT_ID, clientId));
        params.add(new BasicNameValuePair(CLIENT_SECRET, clientSecret));
        params.add(new BasicNameValuePair(AUDIENCE, audience));
        return params;
    }


    /**
     * Sanitizes header values by removing carriage return and newline characters.
     *
     * @param value the header value to sanitize
     * @return sanitized header value
     */
    private static String sanitizeHeaderValue(String value) {
        return value.replaceAll("[\\r\\n]", EMPTY);
    }

    /**
     * OSGi configuration interface for AddressLookupServiceImpl.
     * Defines the configurable properties for the service.
     * These properties can be set via the OSGi console or configuration files.
     * Properties include host, endpoint, and authentication key.
     *
     */
    @ObjectClassDefinition(name = "AddressLookup Configuration")
    @interface Configuration {
        @AttributeDefinition(name = "API Host", description = "Kong Host URL for Address Lookup API")
        String apiHost();

        @AttributeDefinition(name = "Token Host", description = "Token host for Address Lookup API")
        String tokenHost();

        @AttributeDefinition(name = "Client ID", description = "Client ID for Address Lookup API")
        String clientID();

        @AttributeDefinition(name = "Client Secret", description = "Client Secret for Address Lookup API")
        String clientSecret();

        @AttributeDefinition(name = "Audience", description = "Audience for Address Lookup API")
        String audience();

        @AttributeDefinition(name = "Address Suggestion Endpoint", description = "Address Suggestion Endpoint for Address Suggestion API")
        String addressSuggestionEndpoint();

        @AttributeDefinition(name = "Postcode Or Suburb Suggestion Endpoint", description = "Postcode Or Suburb Suggestion Endpoint for Address Suggestion API")
        String postcodeOrSuburbSuggestionEndpoint();

    }

}

package com.auspost.aemaacs.program.core.utils;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;


public final class DateUtils {

    private static final String ZONE_AUSTRALIA = "Australia/Sydney";

    private DateUtils() {
    }

    /**
     * Converts Date string to dd MMMM yyyy taking into consideration Australia timezone
     *
     * @param date - Date in native aem format
     * @return String date in format dd MMMM yyyy
     */
    public static String getFormattedDate(Date date, String targetDateFormat) {
        if (date != null) {
            LocalDate localDate = date.toInstant().atZone(ZoneId.of(ZONE_AUSTRALIA)).toLocalDate();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(targetDateFormat, Locale.ENGLISH);
            return localDate.format(formatter);
        }
        return EMPTY;
    }

    /**
     * Parses month text to int.
     *
     * @param monthText - month in text format
     * @return int month value
     */
    public static int parseMonth(String monthText) {
        return switch (monthText) {
            case "january" -> 1;
            case "february" -> 2;
            case "march" -> 3;
            case "april" -> 4;
            case "may" -> 5;
            case "june" -> 6;
            case "july" -> 7;
            case "august" -> 8;
            case "september" -> 9;
            case "october" -> 10;
            case "november" -> 11;
            case "december" -> 12;
            default -> 0;
        };
    }
}

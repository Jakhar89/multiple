package com.auspost.aemaacs.program.core.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

public final class CommonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private CommonUtils() {
    }

    /**
     * Puts a key-value pair into the given map if the provided value is not null
     * and not blank (i.e., not empty or only whitespace).
     * @param map the map into which the key-value pair should be inserted
     * @param key the key under which the value should be stored
     * @param value the value to be inserted; will only be added if it is non-null and not blank
     */
    public static void addToMapIfNotBlank(Map<String, Object> map, String key, String value) {
        if (StringUtils.isNotBlank(value)) {
            map.put(key, value);
        }
    }

    /**
     * Extracted for testing purposes so we can force JsonProcessingException in JUnit.
     */
    public static String writeJson(Map<String, Object> map) throws JsonProcessingException {
        return MAPPER.writeValueAsString(map);
    }
}

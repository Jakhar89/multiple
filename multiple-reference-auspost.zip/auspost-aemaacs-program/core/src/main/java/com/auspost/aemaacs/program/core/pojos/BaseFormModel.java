package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import static com.auspost.aemaacs.program.core.constants.Constants.DOT;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.JSON;
import static com.auspost.aemaacs.program.core.constants.Constants.MODEL;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class BaseFormModel extends BaseComponentModel {

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String name;

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String title;

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String hideTitle;

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String requiredMessage;

    @SlingObject
    private ResourceResolver resolver;

    /**
     * Retrieves and trims the search text from the request parameter.
     *
     * @param request         the Sling HTTP servlet request
     * @param searchParameter the name of the search parameter
     * @return the trimmed search text, or an empty string if not present
     */
    @JsonIgnore
    public String getSearchTextFromRequest(SlingHttpServletRequest request, String searchParameter) {
        String searchText = request.getParameter(searchParameter);
        if (searchText != null) {
            return searchText.trim();
        }
        return EMPTY;
    }

    /**
     * Retrieves the resource path of the component in JSON format.
     *
     * @return resource path in JSON format.
     */
    @JsonIgnore
    public String getResourcePath() {
        return resolver.map(resource.getPath() + DOT + MODEL + DOT + JSON);
    }

    /**
     * Method to get unique id for the component
     *
     * @return id as String
     */
    @JsonIgnore
    public String getId() {
        return ComponentUtils.getId(resource, currentPage, componentContext);
    }

}

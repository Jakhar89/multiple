package com.auspost.aemaacs.program.core.services;

/**
 * @author Seeni Rajan
 */
public interface AddressLookupService {

    /**
     * Method to get domestic address suggestions
     *
     * @param searchText JSON data
     * @return JSON response
     */
    String getDomesticAddressSuggestion(String searchText);

    /**
     * Method to get domestic post code suggestions
     *
     * @param postcode JSON data
     * @return JSON response
     */
    String getDomesticPostCodeSuggestion(String postcode);

    /**
     * Method to get domestic suburb suggestions
     *
     * @param suburb JSON data
     * @return JSON response
     */
    String getDomesticSuburbSuggestion(String suburb);
}

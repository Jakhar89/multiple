package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BannerTile;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.CtaModel;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;


@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = HomePageBannerModel.class,
        resourceType = "auspost-aemaacs-program/components/homepagebanner",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class HomePageBannerModel extends CtaModel {

    @Getter
    @ChildResource
    private BannerTile heroTile;

    @ChildResource
    private BannerTile sideTopTile;

    @ChildResource
    private BannerTile sideBottomTile;

    public BannerTile getSideTopTile() {
        if (sideTopTile != null) {
            buildBannerTile(sideTopTile, "-secondaryTile1-link");
            return sideTopTile;
        }
        return null;
    }

    public BannerTile getSideBottomTile() {
        if (sideBottomTile != null) {
            buildBannerTile(sideBottomTile, "-secondaryTile2-link");
            return sideBottomTile;
        }
        return null;
    }

    private void buildBannerTile(BannerTile bannerTile, String suffix) {
        bannerTile.getTileLink().setId(getId() + suffix);
        // Build the link inside BannerTile
        LinkUtils.buildLinkItem(linkManager, bannerTile.getTileLink());
    }

    /**
     * Returns the data layer JSON string for the home page banner component. If data layer is enabled, it constructs a JSON
     * object with the component ID and event details for each call-to-action (CTA) button.
     *
     * @return A JSON string representing the data layer for the banner component, or an empty string if data layer is
     * not enabled.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled()) {
            String componentId = getId();
            // Set data layer for primary CTA
            setDataLayerForCta(componentId, getPrimaryCta(), heroTile, "-primary-cta");
            // Set data layer for secondary CTA
            setDataLayerForCta(componentId, getSecondaryCta(), heroTile, "-secondary-cta");
            // Set data layer for secondary tile1 link
            setDataLayerForTileLink(componentId, "tile1", sideTopTile, "-secondaryTile1-link");
            // Set data layer for secondary tile2 link
            setDataLayerForTileLink(componentId, "tile2", sideBottomTile, "-secondaryTile2-link");

            Map<String, Object> bannerMap =
                    DataLayerUtils
                            .createEventMap(SITE_INTERACTION, "homePageBanner", heroTile.getTileTitle());
            return DataLayerUtils.mapToJson(componentId, bannerMap);
        }
        return EMPTY;
    }

    /**
     * Sets the data layer for the call to action (CTA) button.
     *
     * @param componentId       - The ID of the component to which the CTA belongs.
     * @param ctaItem           - The ButtonItem representing the CTA button.
     * @param componentIdSuffix - A suffix to append to the component ID for the CTA.
     */
    private void setDataLayerForCta(String componentId, ButtonItem ctaItem, BannerTile tile, String componentIdSuffix) {
        DataLayerUtils.setDataLayerForLink(
                ctaItem,
                componentId + componentIdSuffix,
                SITE_INTERACTION,
                "homePageBanner||cta",
                DataLayerUtils.getFormattedDataLayerDescription(tile.getTileTitle() + COLON + ctaItem.getLabel())
        );
    }

    /**
     * Sets the data layer for the call to action (CTA) button.
     *
     * @param componentId       - The ID of the component to which the tile link belong belongs.
     * @param tileName          - Name of the tile
     * @param tile              - Tile of the banner
     * @param componentIdSuffix -A suffix to append to the component ID for the link.
     */
    private void setDataLayerForTileLink(String componentId,
                                         String tileName,
                                         BannerTile tile,
                                         String componentIdSuffix) {
        DataLayerUtils.setDataLayerForLink(
                tile.getTileLink(),
                componentId + componentIdSuffix,
                SITE_INTERACTION,
                "homePageBanner||" + tileName + "||cta",
                DataLayerUtils.getFormattedDataLayerDescription(tile.getTileTitle())
        );
    }
}

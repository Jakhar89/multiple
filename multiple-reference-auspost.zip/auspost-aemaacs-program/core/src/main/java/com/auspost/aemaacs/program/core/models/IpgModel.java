package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.LinkItem;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.DOT;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.JSON;
import static com.auspost.aemaacs.program.core.constants.Constants.LINK_TARGET_BLANK;
import static com.auspost.aemaacs.program.core.constants.Constants.MODEL;
import static com.auspost.aemaacs.program.core.utils.LinkUtils.buildLink;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = com.adobe.cq.wcm.core.components.models.List.class,
        resourceType = {"auspost-aemaacs-program/components/ipg", "auspost-aemaacs-program/components/indexlist"},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class IpgModel implements com.adobe.cq.wcm.core.components.models.List {

    @JsonIgnore
    @Self
    @Via(type = ResourceSuperType.class)
    private com.adobe.cq.wcm.core.components.models.List list;

    @JsonIgnore
    @SlingObject
    private Resource resource;

    @JsonIgnore
    @ValueMapValue
    private String listFrom;

    @Getter
    @JsonIgnore
    @ValueMapValue
    private String title;

    @Self
    private LinkManager linkManager;

    @Getter
    @JsonProperty("popularCountries")
    @ChildResource
    private List<LinkItem> popularDestinations;

    @Getter
    @JsonIgnore
    @ValueMapValue
    private String errorText;

    @JsonIgnore
    @SlingObject
    private ResourceResolver resolver;

    @Getter
    @JsonIgnore
    @ChildResource
    private ButtonItem cta;

    @Getter
    private List<LinkItem> allCountries;


    /**
     * Initializes the model after construction.
     * <p>
     * Sets up the list of all countries and popular destinations. For popular destinations,
     * builds the link and sets the label to the page title for each LinkItem.
     * </p>
     */
    @PostConstruct
    private void init() {
        if (list != null && !list.getListItems().isEmpty()) {
            allCountries = list.getListItems().stream()
                    .map(item -> new LinkItem(item.getTitle(), item.getPath(),
                            LINK_TARGET_BLANK,
                            linkManager))
                    .toList();
        } else {
            allCountries = Collections.emptyList();
        }
        if (popularDestinations != null && !popularDestinations.isEmpty()) {
            for (LinkItem linkItem : popularDestinations) {
                linkItem.setLink(buildLink(linkManager, linkItem));
                if (StringUtils.isNotEmpty(linkItem.getLinkURL())) {
                    linkItem.setLabel(getPageTitle(linkItem.getLinkURL()));
                }
            }
        } else {
            popularDestinations = Collections.emptyList();
        }
    }


    /**
     * Retrieves the page title for a given path using the resource resolver.
     * <p>
     * If the resource exists and can be adapted to a Page, returns the page's title.
     * Otherwise, returns an empty string.
     * </p>
     *
     * @param path the path to the page resource
     * @return the page title, or empty string if not found
     */
    private String getPageTitle(String path) {
        Resource pageResource = resolver.getResource(path);
        if (pageResource != null && pageResource.adaptTo(Page.class) != null) {
            return Objects.requireNonNull(pageResource.adaptTo(Page.class)).getTitle();
        }
        return EMPTY;
    }

    /**
     * Returns the mapped resource path for JSON export of this model.
     * <p>
     * The path is constructed by appending the model and JSON extension to the resource path,
     * and then mapping it using the {@link ResourceResolver}.
     * </p>
     *
     * @return the mapped resource path for JSON export
     */
    @JsonIgnore
    public String getResourcePath() {
        return resolver.map(resource.getPath() + DOT + MODEL + DOT + JSON);
    }
}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.AssetListItem;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.ListingUtils;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import static com.auspost.aemaacs.program.core.constants.Constants.APPLICATION_PDF;
import static com.auspost.aemaacs.program.core.constants.Constants.DOT;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.EXTENSION_JPEG;
import static com.auspost.aemaacs.program.core.constants.Constants.EXTENSION_JPG;
import static com.auspost.aemaacs.program.core.constants.Constants.EXTENSION_PNG;
import static com.auspost.aemaacs.program.core.constants.Constants.HYPHEN;
import static com.auspost.aemaacs.program.core.constants.Constants.LINK_TARGET_BLANK;
import static com.auspost.aemaacs.program.core.constants.Constants.METADATA;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;
import static com.auspost.aemaacs.program.core.constants.Constants.SLASH;
import static com.auspost.aemaacs.program.core.constants.Constants.SPACE;
import static com.auspost.aemaacs.program.core.utils.ListingUtils.FILTERED_RESULTS;
import static com.auspost.aemaacs.program.core.utils.ListingUtils.LIST_CTA;
import static com.auspost.aemaacs.program.core.utils.ListingUtils.getChildrenTagsStream;
import static com.day.cq.commons.jcr.JcrConstants.JCR_CONTENT;
import static com.day.cq.commons.jcr.JcrConstants.JCR_TITLE;
import static com.day.cq.dam.api.DamConstants.DC_TITLE;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = AssetListingModel.class,
        resourceType = "auspost-aemaacs-program/components/assetlisting",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class AssetListingModel extends BaseComponentModel {

    @SlingObject
    private ResourceResolver resolver;

    @Self
    private SlingHttpServletRequest request;

    @Getter
    @ValueMapValue
    private String title;

    @Getter
    @ValueMapValue
    private String defaultImageReference;

    @ChildResource
    private List<Resource> filterTagList;

    @Getter
    @ValueMapValue
    private String noResultsMessage;

    @Getter
    @ValueMapValue
    private String parentFolder;

    @Getter
    @ValueMapValue
    private int initialPageLoad;

    @Getter
    @ValueMapValue
    private String ctaLabel;

    @Getter
    @ValueMapValue
    private boolean assetTypeAndSize;

    @Getter
    @ValueMapValue
    private boolean isDecorative;

    @Getter
    private final List<String> assetResourceList = new ArrayList<>();

    @Getter
    private String totalNoOfAssets;

    private List<AssetListItem> assetListItems = new ArrayList<>();

    private TagManager tagManager;

    private List<String> validSelectors = new ArrayList<>();

    private String[] selectors;

    @Getter
    private int filteredResults;

    /**
     * Initializes the AssetListingModel.
     * <p>
     * This method is called after the model has been instantiated and all dependencies have been injected.
     * It initializes the TagManager and populates the list of asset resources based on the specified parent folder
     * and filter tags.
     */
    @PostConstruct
    private void init() {
        tagManager = resolver.adaptTo(TagManager.class);
        if (StringUtils.isEmpty(parentFolder)) {
            return;
        }
        selectors = ListingUtils.getSelectorsIfPresent(request);
        String[] tagIds = getTagsUnderParents();
        Iterator<Resource> assets = tagManager.find(parentFolder, tagIds, true);
        setAssetResourceList(assets);
    }

    /**
     * Validates the given DAM asset metadata resource and adds it to the asset list if it meets the criteria.
     * <p>
     * The method checks if the resource corresponds to a valid Asset and if its MIME type is PDF.
     * If valid, it creates an AssetListItem with relevant details including title, path, tags, and thumbnail.
     *
     * @param damAssetMetadataResource - The DAM asset metadata resource to validate and add to the list.
     * @return An AssetListItem object if the resource is valid, otherwise null.
     */
    private AssetListItem getAssetListItem(Resource damAssetMetadataResource) {
        Asset damAsset = DamUtil.getAssetFromMetaRes(damAssetMetadataResource);
        if (!APPLICATION_PDF.equals(damAsset.getMimeType())) {
            return null;
        }
        return createAssetListItem(
                damAssetMetadataResource,
                getAssetTitle(damAssetMetadataResource),
                damAsset,
                getTagNames(damAssetMetadataResource),
                getPdfImageSyntheticResource(damAsset)
        );
    }

    /**
     * Creates an AssetListItem and sets its data layer analytics.
     *
     * @param damAssetMetadataResource - The DAM asset metadata resource.
     * @param assetTitle               - The title of the asset.
     * @param damAsset                 - The DAM asset.
     * @param tagNames                 - The tag names associated with the asset.
     * @param pdfSyntheticResource     - The synthetic resource for the PDF image.
     * @return An AssetListItem object with data layer analytics set.
     */
    private AssetListItem createAssetListItem(Resource damAssetMetadataResource, String assetTitle, Asset damAsset,
                                              String tagNames, Resource pdfSyntheticResource) {
        AssetListItem assetListItem = new AssetListItem(assetTitle, damAsset.getPath(), tagNames,
                LINK_TARGET_BLANK, linkManager,
                damAssetMetadataResource, pdfSyntheticResource, resolver);
        DataLayerUtils.setDataLayerForLink(assetListItem, getId(), SITE_INTERACTION, LIST_CTA,
                DataLayerUtils.getFormattedDataLayerDescription(assetTitle));
        return assetListItem;
    }

    /**
     * Generates a synthetic resource for the PDF image.
     * <p>
     * It attempts to find an image with the same base name as the PDF (with extensions .jpg, .jpeg, or .png).
     * If no matching image is found, it uses a default image reference.
     *
     * @param damAsset - The DAM asset representing the PDF file.
     * @return A Resource representing the synthetic image for the PDF.
     */
    private Resource getPdfImageSyntheticResource(Asset damAsset) {
        // Extract the base name of the PDF
        String pdfPath = damAsset.getPath();
        String baseName = pdfPath.substring(0, pdfPath.lastIndexOf(DOT));
        Resource imageResource = getImageResource(baseName);
        String imagePath = imageResource != null ? imageResource.getPath() : defaultImageReference;
        return ListingUtils.createPdfSyntheticResource(resource, resolver, imagePath, isDecorative);
    }

    /**
     * Retrieves the image resource associated with the given base name.
     * <p>
     * It checks for the existence of image files with extensions .jpg, .jpeg, and .png in that order.
     * If a matching image is found, it returns the corresponding Resource; otherwise, it returns null.
     *
     * @param baseName - The base name of the image file (without extension).
     * @return The image Resource if found, otherwise null.
     */
    private Resource getImageResource(String baseName) {
        // Check for matching images
        Resource resource = resolver.getResource(baseName + EXTENSION_JPG);
        if (resource != null) {
            return resource;
        }
        resource = resolver.getResource(baseName + EXTENSION_JPEG);
        if (resource != null) {
            return resource;
        }
        return resolver.getResource(baseName + EXTENSION_PNG);
    }

    /**
     * Retrieves the tag names for the given DAM asset metadata resource.
     * * It looks for tags under the "month" and "year" namespaces and concatenates their titles.
     *
     * @param damAssetMetadataResource - The DAM asset metadata resource.
     * @return The concatenated tag names.
     */
    private String getTagNames(Resource damAssetMetadataResource) {
        Tag[] tags = tagManager.getTags(damAssetMetadataResource);
        String year = EMPTY;
        String month = EMPTY;
        for (Tag tag : tags) {
            String tagPath = tag.getPath();
            if (year.isEmpty() && tagPath.contains("/year/")) {
                year = tag.getTitle();
            } else if (month.isEmpty() && tagPath.contains("/month/")) {
                month = tag.getTitle();
            }
        }
        return (month + SPACE + year).trim();

    }

    /**
     * Retrieves the asset title from the given DAM asset metadata resource.
     * <p>
     * It first checks for the "dc:title" property, then "jcr:title", and finally defaults to the resource name.
     *
     * @param damAssetMetadataResource - The DAM asset metadata resource.
     * @return The asset title.
     */
    private String getAssetTitle(Resource damAssetMetadataResource) {
        String assetTitle = EMPTY;
        ValueMap valueMap = damAssetMetadataResource.getValueMap();
        if (valueMap.containsKey(DC_TITLE)) {
            assetTitle = valueMap.get(DC_TITLE, String.class);
        }

        if (StringUtils.isEmpty(assetTitle) && valueMap.containsKey(JCR_TITLE)) {
            assetTitle = valueMap.get(JCR_TITLE, String.class);
        }

        if (StringUtils.isEmpty(assetTitle)) {
            assetTitle = damAssetMetadataResource.getName();
        }
        return assetTitle;
    }

    /**
     * Generates the data layer JSON for the component if data layer is enabled.
     *
     * @return the data layer JSON string or an empty string if data layer is not enabled.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled()) {
            Map<String, Object> listEventMap = DataLayerUtils
                    .createEventMap(FILTERED_RESULTS,
                            ListingUtils.getFilterListAsString(tagManager, validSelectors),
                            String.valueOf(assetListItems.size()));
            return DataLayerUtils.mapToJson(getId(), listEventMap);
        }
        return EMPTY;
    }

    /**
     * Retrieves child tags grouped by their parent tag name.
     *
     * @return a list of maps where each map contains a parent tag name as the key
     * and its child tags as the value.
     */
    public List<Map<String, List<Map<String, Object>>>> getFilters() {
        if (filterTagList == null) {
            return Collections.emptyList();
        }
        return ListingUtils.getFilters(
                filterTagList,
                tagManager,
                request.getRequestPathInfo().getSelectors(),
                validSelectors
        );
    }

    /**
     * Retrieves all tag IDs under the parent tags.
     *
     * @return an array of tag IDs.
     */
    private String[] getTagsUnderParents() {
        if (filterTagList == null) {
            return new String[0];
        }
        List<String> tagIds = new ArrayList<>();
        ListingUtils.getParentTagStream(tagManager, filterTagList)
                .forEach(parentTag -> getParentAndChildTagIdsStream(parentTag).forEach(tagIds::add));
        return tagIds.toArray(new String[0]);
    }

    /**
     * Retrieves a stream of tag IDs for the given parent tag, including its own ID and the IDs of its child tags.
     *
     * @param parentTag the parent tag
     * @return a stream of tag IDs
     */
    private Stream<String> getParentAndChildTagIdsStream(Tag parentTag) {
        List<String> tagIds = new ArrayList<>();
        tagIds.add(parentTag.getTagID());
        getChildrenTagsStream(parentTag).forEach(childTag -> tagIds.add(childTag.getTagID()));
        return tagIds.stream();
    }

    /**
     * Retrieves a list of AssetListItem objects representing the assets to be listed.
     * <p>
     * The method filters and processes the asset resources based on the specified criteria,
     * including MIME type and tags. The resulting list is sorted by year and month in descending order.
     *
     * @return a list of AssetListItem objects.
     */
    public List<AssetListItem> getAssetListItems() {
        AtomicInteger index = new AtomicInteger(0);
        assetListItems = assetResourceList.stream()
                .filter(damAssetResourcePath -> damAssetResourcePath.endsWith(JCR_CONTENT + SLASH + METADATA))
                .map(resolver::getResource)
                .filter(Objects::nonNull)
                .filter(this::filterBasedOnSelector)
                .map(this::getAssetListItem)
                .filter(Objects::nonNull)
                .sorted(this::sortAssetListItemsBasedOnTagName)
                .peek(item -> item.setId(
                        getId() + HYPHEN +
                                DataLayerUtils.getFormattedDataLayerDescription(item.getLabel()) + HYPHEN +
                                index.getAndIncrement()))
                .toList();

        filteredResults = assetListItems.size();
        assetListItems = ListingUtils.processOffSet(assetListItems, initialPageLoad, selectors);
        return Collections.unmodifiableList(assetListItems);
    }

    /**
     * Sorts two AssetListItem objects based on their tag names, which are expected to contain year and month information.
     * The sorting is done in descending order, first by year and then by month.
     *
     * @param a the first AssetListItem to compare
     * @param b the second AssetListItem to compare
     * @return a negative integer, zero, or a positive integer as the first argument is less than, equal to, or greater than the second
     * based on the year and month extracted from their tag names.
     */
    private int sortAssetListItemsBasedOnTagName(AssetListItem a, AssetListItem b) {
        int[] ya = ListingUtils.extractYearMonth(a.getTagName());
        int[] yb = ListingUtils.extractYearMonth(b.getTagName());
        if (ya[0] != yb[0]) {
            return Integer.compare(yb[0], ya[0]);
        }
        return Integer.compare(yb[1], ya[1]);
    }

    /**
     * Filters the given DAM asset metadata resource based on the specified selectors.
     * * If filterTagList is not null, it validates the selectors and checks if the asset matches all tags.
     * Otherwise, it returns true.
     *
     * @param damAssetMetadataResource - The DAM asset metadata resource to filter.
     * @return true if the asset matches the filters, false otherwise.
     */
    private boolean filterBasedOnSelector(Resource damAssetMetadataResource) {
        String[] selectors = ListingUtils.getSelectorsIfPresent(request);
        if (selectors.length == 0) {
            return true;
        }
        validSelectors = ListingUtils.validateSelectors(selectors, tagManager, filterTagList);
        return ListingUtils.matchesAllAssetTags(damAssetMetadataResource, validSelectors);
    }

    /**
     * Retrieves the path of the current page path.
     *
     * @return the current page path as a string.
     */
    public String getResourcePath() {
        return resolver.map(currentPage.getPath());
    }

    /**
     * Populates the asset resource list with the paths of DAM asset metadata resources.
     * <p>
     * This method iterates through the provided resources and adds the path of each resource
     * to the `assetResourceList`. It is used to collect all relevant asset metadata resources
     * for further processing.
     * </p>
     * sets the total number of results based on the size of the asset resource list.
     *
     * @param iterator - An iterator over DAM asset metadata resources.
     */
    private void setAssetResourceList(Iterator<Resource> iterator) {
        while (iterator.hasNext()) {
            Resource damAssetMetadataResource = iterator.next();
            assetResourceList.add(damAssetMetadataResource.getPath());
        }
        totalNoOfAssets = String.valueOf(assetResourceList.size());
    }
}

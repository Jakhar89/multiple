package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.utils.CommonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sling Model for the Ecommerce Suggested Search data.
 * Extends HeaderModel and provides suggested search JSON including label-only entries.
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = EcommSuggestedSearchModel.class,
        resourceType = {"auspost-aemaacs-program/components/ecommsearch"},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class EcommSuggestedSearchModel extends HeaderModel {

    private static final String SUGGESTED_SEARCH_TITLE = "Suggested Search";

    @SlingObject
    private Resource resource;

    public String getSuggestedSearchJson() {
        Resource popularSearch = resource != null ? resource.getChild("popularsearch") : null;
        if (popularSearch == null) {
            return Constants.EMPTY;
        }

        List<Map<String, Object>> items = new ArrayList<>();
        for (Resource child : popularSearch.getChildren()) {
            ValueMap vm = child.getValueMap();
            String label = vm.get("label", String.class);
            if (StringUtils.isBlank(label)) {
                continue;
            }
            Map<String, Object> item = new HashMap<>();
            item.put("label", label);
            CommonUtils.addToMapIfNotBlank(item, "href", vm.get("linkURL", String.class));
            CommonUtils.addToMapIfNotBlank(item, "target", vm.get("linkTarget", String.class));
            items.add(item);
        }

        if (items.isEmpty()) {
            return Constants.EMPTY;
        }

        Map<String, Object> suggestedSearchMap = new HashMap<>();
        suggestedSearchMap.put(Constants.TITLE, SUGGESTED_SEARCH_TITLE);
        suggestedSearchMap.put("items", items);

        try {
            return CommonUtils.writeJson(suggestedSearchMap);
        } catch (JsonProcessingException e) {
            return Constants.EMPTY;
        }
    }
}

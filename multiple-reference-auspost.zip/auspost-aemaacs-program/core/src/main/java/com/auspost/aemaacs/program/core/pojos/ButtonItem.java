package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(alphabetic = true)
public class ButtonItem extends LinkItem {

    @ValueMapValue
    private String buttonType;

    @ValueMapValue
    private String iconRight;

    @ValueMapValue
    private String iconLeft;

    @ValueMapValue
    private boolean assetTypeAndSize;

    @SlingObject
    private ResourceResolver resourceResolver;

    public ButtonItem() {
        // default constructor to support Sling instantiation. DO NOT DELETE UNLESS YOU KNOW WHAT YOU ARE DOING
    }

    /**
     * Creates a LinkItem with the specified label, link URL, target, and link manager. Automatically builds the link
     * using the provided LinkManager.
     *
     * @param label       The display label for the link.
     * @param linkURL     The URL of the link.
     * @param linkTarget  The target behavior of the link (e.g., _blank).
     * @param linkManager The LinkManager used to build the link.
     */
    public ButtonItem(String label, String linkURL, String linkTarget, LinkManager linkManager) {
        super(label, linkURL, linkTarget, linkManager);
    }

    /**
     * Returns the DAM asset size with extension for the button's URL if enabled.
     *
     * @return the asset size with extension, or an empty string if not applicable
     */
    public String getAssetTypeAndSize() {
        if (assetTypeAndSize && StringUtils.isNotEmpty(getURL())) {
            return DamAssetUtils.getAssetTypeAndSize(resourceResolver, getURL());
        }
        return EMPTY;
    }
}

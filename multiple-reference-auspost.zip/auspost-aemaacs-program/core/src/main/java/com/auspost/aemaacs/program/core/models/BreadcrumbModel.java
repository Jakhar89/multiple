package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Breadcrumb;
import com.adobe.cq.wcm.core.components.models.NavigationItem;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.Collection;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = BreadcrumbModel.class,
        resourceType = "auspost-aemaacs-program/components/breadcrumb",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class BreadcrumbModel implements Breadcrumb {

    @Self
    @Via(type = ResourceSuperType.class)
    private Breadcrumb breadcrumb;

    @Override
    public Collection<NavigationItem> getItems() {
        return breadcrumb.getItems();
    }

    /**
     * @return The index value of the immediate parent of the current page from the breadcrumb list
     */
    public int getParentIndex() {
        return breadcrumb.getItems().size() - 2;
    }

}

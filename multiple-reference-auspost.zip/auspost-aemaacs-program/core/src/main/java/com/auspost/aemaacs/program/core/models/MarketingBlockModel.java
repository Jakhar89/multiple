package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;

import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Named;
import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.NN_FEATURED_IMAGE;


@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = MarketingBlockModel.class,
        resourceType = "auspost-aemaacs-program/components/marketingblock",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class MarketingBlockModel extends BaseComponentModel {

    @Getter
    @ValueMapValue
    private String title;

    @Getter
    @ValueMapValue
    private String description;

    @Getter
    @ChildResource
    @Named(NN_FEATURED_IMAGE)
    private Resource marketingBlockImage;

    @Getter
    @ChildResource
    private List<ButtonItem> cta;

    @ChildResource
    private List<IconItem> marketingBlockLogo;

    @Getter
    @ChildResource
    private String appStoreLink;

    @Getter
    @ChildResource
    private String googlePlayLink;

    @Getter
    @ChildResource
    private String qrCodeBlockTitle;

    @ChildResource
    private IconItem qrCode;

    /**
     * Build Marketing Block via core link manager.
     *
     * @return List of marketing Block logo items.
     */
    public List<IconItem> getMarketingBlockLogo() {
        return LinkUtils.buildIconItems(linkManager, marketingBlockLogo);
    }

    /**
     * Retrieves QR logo icon item containing externalized image reference.
     *
     * @return QR logo icon item.
     */
    public IconItem getQrCode() {
        return LinkUtils.buildIconItem(linkManager, qrCode);
    }

    /**
     * Returns the data layer JSON string for the Marketing Block component. If data layer is enabled, it constructs a JSON
     * object with the component ID and event details. The primary and secondary CTAs are also included in the data
     * layer with their respective IDs.
     *
     * @return A JSON string representing the data layer for the Marketing Block component, or an empty string if data layer is
     * not enabled.
     */
    public String getDataLayer() {
        return DataLayerUtils.getDataLayerForCTA(getId(), cta, linkManager, "marketingBlock||main-cta", Constants.EMPTY, Constants.EMPTY, false);
    }
}
package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.services.SalesforceWebToLeadClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.propertytypes.ServiceDescription;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.stream.Collectors;

import static com.auspost.aemaacs.program.core.constants.Constants.AMPERSAND;
import static com.auspost.aemaacs.program.core.constants.Constants.APPLICATION_JSON;
import static com.auspost.aemaacs.program.core.constants.Constants.APPLICATION_X_WWW_FORM_URLENCODED;
import static com.auspost.aemaacs.program.core.constants.Constants.CLIENT_ID;
import static com.auspost.aemaacs.program.core.constants.Constants.CLIENT_SECRET;
import static com.auspost.aemaacs.program.core.constants.Constants.COOKIE;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.EQUALS;
import static com.auspost.aemaacs.program.core.constants.Constants.GRANT_TYPE;
import static com.auspost.aemaacs.program.core.constants.Constants.LEAD;
import static com.auspost.aemaacs.program.core.constants.Constants.PASSWORD;
import static com.auspost.aemaacs.program.core.constants.Constants.SET_COOKIE_HEADER;
import static com.auspost.aemaacs.program.core.constants.Constants.USERNAME;
import static java.nio.charset.StandardCharsets.UTF_8;
import static org.apache.http.HttpHeaders.CONTENT_TYPE;

/**
 * @author Seeni Rajan
 */
@Slf4j
@Component(service = SalesforceWebToLeadClient.class)
@ServiceDescription("Salesforce Web to Lead Client")
@Designate(ocd = SalesforceWebToLeadClientImpl.Configuration.class)
public class SalesforceWebToLeadClientImpl implements SalesforceWebToLeadClient {

    private static final int[] SUCCESS_STATUS_CODES = {200, 201};

    private String authEndpoint;

    private String leadEndpoint;

    private String campaignEndpoint;

    private String host;

    private String clientId;

    private String clientSecret;

    private String username;

    private String password;

    /**
     * Activates the OSGi component and initializes configuration parameters
     * Config: config/com.auspost.aemaacs.program.core.services.impl.SalesforceWebToLeadClientImpl.cfg.json
     *
     * @param configuration Configuration object containing necessary parameters
     */
    @Activate
    @Modified
    private void activate(Configuration configuration) {
        this.authEndpoint = configuration.authEndpoint();
        this.leadEndpoint = configuration.leadEndpoint();
        this.campaignEndpoint = configuration.campaignEndpoint();
        this.host = configuration.host();
        this.clientId = configuration.clientId();
        this.clientSecret = configuration.clientSecret();
        this.username = configuration.username();
        this.password = configuration.password();
        log.debug("Salesforce web to lead client initialised successfully");
    }

    /**
     * Submits the lead or campaign data to Salesforce API
     *
     * @param data Lead or Campaign data in JSON format
     * @param type Type of submission - lead or campaign
     *
     */
    public String submit(String data, String type) throws IOException, InterruptedException {
        String token = this.getAuthToken();
        if (StringUtils.isNotBlank(token)) {
            try (HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()) {
                HttpRequest httpRequest = HttpRequest.newBuilder()
                        .uri(URI.create(this.getAPI(type)))
                        .header(CONTENT_TYPE, APPLICATION_JSON)
                        .header(COOKIE, token)
                        .POST(HttpRequest.BodyPublishers.ofString(data))
                        .timeout(Duration.ofSeconds(10))
                        .build();
                HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
                return httpResponse.body();
            }
        }
        return EMPTY;
    }

    /**
     * Authenticates with Salesforce API and retrieves the authentication token
     *
     * @return Authentication token as a String
     */
    private String getAuthToken() throws IOException, InterruptedException {
        try (HttpClient httpClient = HttpClient.newHttpClient()) {
            String authRequest = this.buildAuthRequest(this.getAuthParams(clientId, clientSecret, username, password));
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(host + authEndpoint))
                    .header(CONTENT_TYPE, APPLICATION_X_WWW_FORM_URLENCODED)
                    .POST(HttpRequest.BodyPublishers.ofString(authRequest))
                    .build();
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            return this.processAuthTokenResponse(httpResponse);
        }
    }

    /**
     * Processes the authentication response and extracts the token if the response is successful
     *
     * @param httpResponse HTTP response from the authentication request
     * @return Authentication token or empty string if authentication fails
     */
    private String processAuthTokenResponse(HttpResponse<String> httpResponse) {
        if (ArrayUtils.contains(SUCCESS_STATUS_CODES, httpResponse.statusCode())) {
            return httpResponse.headers().firstValue(SET_COOKIE_HEADER).orElse(EMPTY);
        } else {
            return EMPTY;
        }
    }

    /**
     * Builds the authentication request string from the provided parameters
     *
     * @param params Map of authentication parameters
     * @return Formatted authentication request string
     */
    private String buildAuthRequest(Map<String, String> params) {
        return params
                .entrySet()
                .stream()
                .map(this::encodeAuthParameters)
                .collect(Collectors.joining(AMPERSAND));
    }

    /**
     * Encodes a single authentication parameter for URL transmission
     *
     * @param entry Map entry containing the parameter key and value
     * @return URL-encoded parameter string
     */
    private String encodeAuthParameters(Map.Entry<String, String> entry) {
        return URLEncoder.encode(entry.getKey(), UTF_8) + EQUALS + URLEncoder.encode(entry.getValue(), UTF_8);
    }

    /**
     * Constructs a map of authentication parameters required for Salesforce API authentication
     *
     * @param clientId     Client ID for the Salesforce API
     * @param clientSecret Client Secret for the Salesforce API
     * @param username     Username for the Salesforce API
     * @param password     Password for the Salesforce API
     * @return Map of authentication parameters
     */
    private Map<String, String> getAuthParams(String clientId, String clientSecret, String username, String password) {
        return Map.of(
                GRANT_TYPE, PASSWORD,
                CLIENT_ID, clientId,
                CLIENT_SECRET, clientSecret,
                USERNAME, username,
                PASSWORD, password
        );
    }

    /**
     * Determines the appropriate API endpoint based on the submission type
     *
     * @param type Type of submission - lead or campaign
     * @return Full API endpoint URL as a String
     */
    private String getAPI(String type) {
        String endPoint = LEAD.equals(type) ? leadEndpoint : campaignEndpoint;
        return host + endPoint;
    }

    /**
     * OSGi configuration interface for Salesforce web to lead client
     */
    @ObjectClassDefinition(
            name = "Salesforce web to lead client Configuration",
            description = "Salesforce web to lead client Configuration to perform lead submissions"
    )
    @interface Configuration {

        @AttributeDefinition(
                name = "Auth Endpoint",
                description = "Auth Endpoint to authenticate before lead submissions"
        )
        String authEndpoint();

        @AttributeDefinition(
                name = "Lead Endpoint",
                description = "Lead Endpoint to perform lead submissions"
        )
        String leadEndpoint();

        @AttributeDefinition(
                name = "Campaign Endpoint",
                description = "Campaign Endpoint to perform campaign submissions"
        )
        String campaignEndpoint();

        @AttributeDefinition(
                name = "Host",
                description = "Host for the Salesforce web to lead API"
        )
        String host();

        @AttributeDefinition(
                name = "Client Id",
                description = "Client Id for the Salesforce web to lead API"
        )
        String clientId();

        @AttributeDefinition(
                name = "Client Secret",
                description = "Client Secret for the Salesforce web to lead API"
        )
        String clientSecret();

        @AttributeDefinition(
                name = "Username",
                description = "Username for the Salesforce web to lead API"
        )
        String username();

        @AttributeDefinition(
                name = "Password",
                description = "Password for the Salesforce web to lead API"
        )
        String password();

    }

}

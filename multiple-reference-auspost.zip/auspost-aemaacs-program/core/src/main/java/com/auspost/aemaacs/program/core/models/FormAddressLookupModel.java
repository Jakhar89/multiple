package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseFormModel;
import com.auspost.aemaacs.program.core.services.AddressLookupService;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;


/**
 * @author Seeni Rajan
 */
@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = FormAddressLookupModel.class,
        resourceType = "auspost-aemaacs-program/components/form/addresslookup",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class FormAddressLookupModel extends BaseFormModel {

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String requiredMessage;

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String required;

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String helpMessage;

    @OSGiService
    private AddressLookupService addressLookupService;

    @Self
    private SlingHttpServletRequest request;

    /**
     * Method to get address suggestions from Address Lookup API
     *
     * @return JSON response as String
     */
    public ObjectNode getAddressSuggestionList() {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode addressDetails = mapper.createObjectNode();
        ObjectNode errorNode = mapper.createObjectNode();
        String searchText = super.getSearchTextFromRequest(request, "address");
        if (searchText.isEmpty()) {
            errorNode.put("error", "No search text provided");
            return errorNode;
        }
        try {
            addressDetails =
                    (ObjectNode) mapper.readTree(addressLookupService.getDomesticAddressSuggestion(searchText));
        } catch (JsonProcessingException e) {
            addressDetails.put("error", "Service Error");
            log.error("Json Processing Exception occurred while fetching Domestic Address Suggestions in model: ", e);
        }
        return addressDetails;
    }

}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseFormModel;
import com.auspost.aemaacs.program.core.services.AbnLookUpService;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.io.IOException;

/**
 * @author Seeni Rajan
 */
@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = FormAbnLookupModel.class,
        resourceType = "auspost-aemaacs-program/components/form/abnlookup",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class FormAbnLookupModel extends BaseFormModel {

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String hintText;

    @OSGiService
    private transient AbnLookUpService abnLookUpService;

    @Self
    private SlingHttpServletRequest request;

    /**
     * Method to get abn search results from Abn lookup API
     *
     * @return JSON response as String
     */
    public ObjectNode getAbnDetails() {
        XmlMapper xmlMapper = new XmlMapper();
        ObjectNode abnDetails = xmlMapper.createObjectNode();
        try {
            abnDetails = (ObjectNode) xmlMapper.readTree(abnLookUpService.search
                    (super.getSearchTextFromRequest(request, "abn")).getBytes());
        } catch (IOException e) {
            abnDetails.put("error", "Service Error");
            log.error("Json Processing Exception occurred while fetching ABN details in model: ", e);
        }
        return abnDetails;
    }

}

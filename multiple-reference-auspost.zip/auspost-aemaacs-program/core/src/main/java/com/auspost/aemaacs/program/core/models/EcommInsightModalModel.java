package com.auspost.aemaacs.program.core.models;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_IMPRESSION;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.ComponentContext;
import java.util.Map;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(
  adaptables = SlingHttpServletRequest.class,
  adapters = EcommInsightModalModel.class,
  resourceType = "auspost-aemaacs-program/components/ecomminsightmodal",
  defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
  name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
  extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@Getter
public class EcommInsightModalModel {

  @ScriptVariable
  private ComponentContext componentContext;

  @SlingObject
  private Resource resource;

  @ScriptVariable
  private Page currentPage;

  @ValueMapValue
  private String modalId;

  @ValueMapValue
  private String modalTitle;

  @ValueMapValue(name = "image")
  private String modalImageUrl;

  @ValueMapValue
  private String modalImageAlt;

  @ValueMapValue
  private String description;

  @ValueMapValue
  private String footerImage;

  @ValueMapValue
  private String footerHeader;

  @ValueMapValue
  private String nextModalName;

  @ValueMapValue
  private String nextModalId;

  /**
   * Retrieves component data JSON for data layer integration.
   *
   * @return JSON string representing the data layer for the modal.
   */
  public String getDataLayer() {
    if (DataLayerUtils.isDataLayerEnabled(this.resource)) {
      String componentId = getId();
      Map<String, Object> eventMap = DataLayerUtils.createEventMap(
        SITE_IMPRESSION,
        "ecommInsightModal||view",
        DataLayerUtils.getFormattedDataLayerDescription(modalTitle)
      );
      return DataLayerUtils.mapToJson(componentId, eventMap);
    }
    return EMPTY;
  }

  /**
   * Retrieves the id of the Ecomm Insight Modal component.
   *
   * @return unique id.
   */
  public String getId() {
    return ComponentUtils.getId(
      this.resource,
      this.currentPage,
      this.componentContext
    );
  }
}

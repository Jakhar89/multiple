package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.CtaModel;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * Sling model for the ecommerce link capture block. It exposes a title, description and a single secondary CTA.
 */
@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = EcommLinkCaptureModel.class,
        resourceType = "auspost-aemaacs-program/components/ecommlinkcapture",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class EcommLinkCaptureModel extends CtaModel {

    @ValueMapValue
    private String cardTitle;

    @ValueMapValue
    private String cardDescription;
}

package com.auspost.aemaacs.program.core.servlets;

import com.auspost.aemaacs.program.core.services.SalesforceWebToLeadClient;
import com.day.cq.wcm.api.components.ComponentContext;
import com.day.cq.wcm.foundation.forms.FormsHandlingRequest;
import com.day.cq.wcm.foundation.forms.FormsHandlingServletHelper;
import com.day.cq.wcm.foundation.forms.ValidationInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletResourceTypes;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.propertytypes.ServiceDescription;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static com.auspost.aemaacs.program.core.constants.Constants.CAMPAIGN;
import static com.auspost.aemaacs.program.core.constants.Constants.CAMPAIGN_ID;
import static com.auspost.aemaacs.program.core.constants.Constants.CHAR_SET;
import static com.auspost.aemaacs.program.core.constants.Constants.CSRF_TOKEN;
import static com.auspost.aemaacs.program.core.constants.Constants.DOUBLE_PIPE;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.EXTENSION_HTML;
import static com.auspost.aemaacs.program.core.constants.Constants.FORM_ERROR_MESSAGE;
import static com.auspost.aemaacs.program.core.constants.Constants.FORM_REDIRECT;
import static com.auspost.aemaacs.program.core.constants.Constants.FORM_REDIRECT_TOKEN;
import static com.auspost.aemaacs.program.core.constants.Constants.FORM_START;
import static com.auspost.aemaacs.program.core.constants.Constants.ID;
import static com.auspost.aemaacs.program.core.constants.Constants.LAST_NAME;
import static com.auspost.aemaacs.program.core.constants.Constants.LEAD;
import static com.auspost.aemaacs.program.core.constants.Constants.LEAD_ID;
import static com.auspost.aemaacs.program.core.constants.Constants.SF_FIELD_IDENTIFIER;
import static com.auspost.aemaacs.program.core.constants.Constants.STATUS;
import static com.auspost.aemaacs.program.core.constants.Constants.SUCCESS;
import static com.auspost.aemaacs.program.core.constants.Constants.TITLE;

@Slf4j
@Component(service = Servlet.class)
@ServiceDescription("Salesforce Web to Lead Form Submission Servlet")
@SlingServletResourceTypes(
        resourceTypes = "auspost-aemaacs-program/components/form/actions/salesforcewebtolead",
        selectors = "post",
        methods = HttpConstants.METHOD_POST
)
public class SalesforceWebToLeadServlet extends SlingAllMethodsServlet {

    private static final String ATTR_RESOURCE = FormsHandlingServletHelper.class.getName() + "/resource";

    private final ObjectMapper mapper = new ObjectMapper();

    @Reference
    private transient SalesforceWebToLeadClient client;

    @Getter
    private boolean leadSuccess = false;

    @Getter
    private boolean campaignSuccess = false;

    private static final String STREET = "Street";

    private static final String CITY = "City";

    private static final String STATE = "State";

    private static final String POSTAL_CODE = "PostalCode";

    private static final String ADDRESS_1 = "address-1";

    private static final String ADDRESS_2 = "address-2";

    private static final String ADDRESS_3 = "address-3";

    private static final String ADDRESS = "address";

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) {
        try {
            Map<String, String[]> parameterMap = new HashMap<>(request.getParameterMap());
            processAddressField(parameterMap);
            processDuplicateNameFields(parameterMap);

            boolean leadOnly = !parameterMap.containsKey(CAMPAIGN_ID);
            if (leadOnly) {
                this.submitLead(parameterMap);
            } else {
                this.submitLeadAndCampaign(parameterMap);
            }
            this.handleResponse(request, response, leadOnly, leadSuccess, campaignSuccess);
        } catch (IOException e) {
            log.error("IOException occurred while processing Salesforce web to lead submission", e);
        } catch (InterruptedException e) {
            log.error("InterruptedException occurred while processing Salesforce web to lead submission", e);
        } catch (ServletException e) {
            log.error("ServletException occurred while processing Salesforce web to lead submission", e);
        }
    }

    /**
     * Processes fields with duplicate names by grouping them based on the
     * identifier and concatenating their values with a double pipe separator.
     *
     * @param parameterMap the map containing form parameters to update
     */
    private void processDuplicateNameFields(Map<String, String[]> parameterMap) {
        Map<String, List<String>> grouped = new HashMap<>();
        List<String> keysToRemove = new ArrayList<>();

        parameterMap.forEach((key, value) -> {
            if (key.contains(SF_FIELD_IDENTIFIER)) {
                String[] parts = key.split(SF_FIELD_IDENTIFIER, 2);
                grouped.computeIfAbsent(parts[1], k -> new ArrayList<>())
                        .addAll(Arrays.asList(value));
                keysToRemove.add(key);
            }
        });

        grouped.forEach((groupKey, values) ->
                parameterMap.put(groupKey, new String[] {String.join(DOUBLE_PIPE, values)})
        );

        keysToRemove.forEach(parameterMap::remove);
    }

    /**
     * Processes and resets address-related fields in the provided parameter map.
     *This method removes any existing address components from the given
     *
     * @param parameterMap to ensure stale or redundant address values are cleared.
     */
    private void processAddressField(Map<String, String[]> parameterMap) {
        parameterMap.remove("suburbandpostcode");
        parameterMap.remove(CITY);
        parameterMap.remove(STATE);
        parameterMap.remove(POSTAL_CODE);
        parameterMap.remove(ADDRESS);
        parameterMap.remove(ADDRESS_1);
        parameterMap.remove(ADDRESS_2);
        parameterMap.remove(ADDRESS_3);
    }

    /**
     * Submits lead data to Salesforce and returns the lead ID if successful.
     *
     * @param parameterMap params from the request
     * @return leadId if submission is successful, otherwise an empty string
     * @throws IOException
     * @throws InterruptedException
     */

    private String submitLead(Map<String, String[]> parameterMap) throws IOException, InterruptedException {
        String leadData = this.getLeadData(parameterMap);
        if (!mapper.readTree(leadData).isEmpty() && this.checkValidFieldIsPresent(leadData)) {
            String leadId = this.submit(leadData, LEAD, ID);
            if (StringUtils.isNotBlank(leadId)) {
                leadSuccess = true;
                return leadId;
            }
        }
        return EMPTY;
    }

    /**
     * Submits lead data and associates it with a campaign in Salesforce.
     *
     * @param parameterMap params from the request
     * @throws IOException
     * @throws InterruptedException
     */
    private void submitLeadAndCampaign(Map<String, String[]> parameterMap) throws IOException, InterruptedException {
        String leadId = this.submitLead(parameterMap);
        if (StringUtils.isNotBlank(leadId)) {
            String campaignData = this.getCampaignData(leadId, parameterMap);
            if (mapper.readTree(campaignData).size() > 2) {
                String isSuccess = this.submit(campaignData, CAMPAIGN, SUCCESS);
                if (Boolean.parseBoolean(isSuccess)) {
                    campaignSuccess = true;
                }
            }
        }
    }

    /**
     * Checks if the required fields (LastName) are present in the lead data.
     *
     * @param leadDataToSubmit JSON string of lead data
     * @return true if both fields are present, false otherwise
     * @throws JsonProcessingException
     */

    private boolean checkValidFieldIsPresent(String leadDataToSubmit) throws JsonProcessingException {
        if (mapper.readTree(leadDataToSubmit).has(LAST_NAME)) {
            return true;
        }
        return false;
    }

    /**
     * Extracts and flattens lead data from the parameter map,
     * excluding fields (capaign ID, title :formstart, :redirect, _charset, csrf token).
     *
     * @param parameterMap
     * @return JSON string of lead data
     * @throws JsonProcessingException
     */
    private String getLeadData(Map<String, String[]> parameterMap) throws JsonProcessingException {
        Map<String, String> flattenedParameterMap = new HashMap<>();
        parameterMap.keySet().forEach(key ->
                flattenedParameterMap.put(key, String.join(" || ", parameterMap.get(key)))
        );

        flattenedParameterMap.remove(CAMPAIGN_ID);
        flattenedParameterMap.remove(FORM_START);
        flattenedParameterMap.remove(FORM_REDIRECT_TOKEN);
        flattenedParameterMap.remove(CHAR_SET);
        flattenedParameterMap.remove(CSRF_TOKEN);
        flattenedParameterMap.remove(TITLE);
        return mapper.writeValueAsString(flattenedParameterMap);
    }

    /**
     * Prepares campaign association data including lead ID and status.
     *
     * @param leadId
     * @param parameterMap
     * @return
     * @throws JsonProcessingException
     */
    private String getCampaignData(String leadId, Map<String, String[]> parameterMap) throws JsonProcessingException {
        Map<String, String> flattenedParameterMap = new HashMap<>();
        flattenedParameterMap.put(LEAD_ID, leadId);
        if (parameterMap.get(STATUS) != null) {
            flattenedParameterMap.put(STATUS, parameterMap.get(STATUS)[0]);
        }
        flattenedParameterMap.put(CAMPAIGN_ID, parameterMap.get(CAMPAIGN_ID)[0]);
        return mapper.writeValueAsString(flattenedParameterMap);
    }

    /**
     * Submits data to Salesforce and extracts a specific field from the JSON response.
     *
     * @param data      JSON string of data to be submitted
     * @param type      Type of submission ("lead" or "campaign")
     * @param fieldName Field name to extract from the response
     * @return Extracted field value from response or empty string if not found
     * @throws IOException
     * @throws InterruptedException
     */

    private String submit(String data, String type, String fieldName) throws IOException, InterruptedException {
        String response = client.submit(data, type);
        if (type.equals(LEAD) && !response.contains(ID)) {
            log.info("Salesforce Lead submission response: {}", response);
            leadSuccess = false;
        } else if (type.equals(CAMPAIGN)) {
            log.info("Salesforce Campaign submission response: {}", response);
        }
        return mapper
                .readTree(response)
                .path(fieldName)
                .asText(EMPTY);
    }

    /**
     * Handles the response based on the success of lead and campaign submissions.
     *
     * @param request
     * @param response
     * @param leadOnly        indicates if only lead submission was performed
     * @param leadSuccess     indicates if lead submission was successful
     * @param campaignSuccess indicates if campaign submission was successful
     * @throws IOException
     * @throws ServletException
     */

    private void handleResponse(SlingHttpServletRequest request,
                                SlingHttpServletResponse response,
                                boolean leadOnly,
                                boolean leadSuccess,
                                boolean campaignSuccess) throws IOException, ServletException {
        if (leadOnly) {
            this.handleResponseForLead(request, response, leadSuccess);
        } else {
            this.handleResponseForLeadAndCampaign(request, response, leadSuccess, campaignSuccess);
        }
    }

    /**
     * Handles the response for lead-only submissions.
     *
     * @param request
     * @param response
     * @param leadSuccess indicates if lead submission was successful
     * @throws IOException
     * @throws ServletException
     */

    private void handleResponseForLead(SlingHttpServletRequest request,
                                       SlingHttpServletResponse response,
                                       boolean leadSuccess) throws IOException, ServletException {
        if (leadSuccess) {
            log.info("Lead submission successful");
            this.sendRedirect(request, response);
        } else {
            this.forwardFailure(request, response);
        }
    }

    /**
     * Handles the response for submissions involving both lead and campaign.
     *
     * @param request
     * @param response
     * @param leadSuccess     indicates if lead submission was successful
     * @param campaignSuccess indicates if campaign submission was successful
     * @throws IOException
     * @throws ServletException
     */

    private void handleResponseForLeadAndCampaign(SlingHttpServletRequest request,
                                                  SlingHttpServletResponse response,
                                                  boolean leadSuccess,
                                                  boolean campaignSuccess) throws IOException, ServletException {
        if (leadSuccess && campaignSuccess) {
            log.info("Lead and Campaign submission successful");
            this.sendRedirect(request, response);
        } else if (leadSuccess) {
            log.info("Lead submission successful but Campaign submission failed");
            this.sendRedirect(request, response);
        } else {
            log.info("Lead & Campaign submission failed");
            this.forwardFailure(request, response);
        }
    }

    /**
     * Sends a redirect response to the client based on the configured redirect URL.
     *
     * @param request
     * @param response
     * @throws IOException
     */

    private void sendRedirect(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        String redirect = request.getResource().getValueMap().get(FORM_REDIRECT, String.class);
        response.sendRedirect(getMappedRedirect(request, redirect));
    }

    /**
     * Maps the redirect URL to include the .html extension.
     *
     * @param request
     * @param redirect
     * @return
     */
    private String getMappedRedirect(SlingHttpServletRequest request, String redirect) {
        return request.getResourceResolver().map(redirect + EXTENSION_HTML);
    }

    /**
     * Forwards the request to the original form resource with an error message.
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    private void forwardFailure(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException {
        String errorMessage = request.getResource().getValueMap().get(FORM_ERROR_MESSAGE, "Error");
        FormsHandlingRequest formRequest = new FormsHandlingRequest(request);
        ValidationInfo validationInfo = ValidationInfo.createValidationInfo(request);
        validationInfo.addErrorMessage(null, errorMessage);
        final Resource formResource = (Resource) request.getAttribute(ATTR_RESOURCE);
        request.removeAttribute(ATTR_RESOURCE);
        request.removeAttribute(ComponentContext.BYPASS_COMPONENT_HANDLING_ON_INCLUDE_ATTRIBUTE);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher(formResource);
        if (requestDispatcher != null) {
            requestDispatcher.forward(formRequest, response);
        } else {
            throw new IOException("Can't get request dispatcher to forward the response");
        }
    }
}

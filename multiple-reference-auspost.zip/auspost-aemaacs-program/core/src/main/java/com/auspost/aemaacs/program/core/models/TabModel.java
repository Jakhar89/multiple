package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Tabs;
import com.auspost.aemaacs.program.core.pojos.PanelContainerItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = Tabs.class,
        resourceType = "auspost-aemaacs-program/components/tabs",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class TabModel implements Tabs {

    private List<PanelContainerItem> tabItems;

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private Tabs tabs;

    @SlingObject
    private Resource resource;

    /**
     * Returns the PanelContainerItem for the tab component. This method also checks if the data layer is enabled for the
     * resource, and if so, sets the tab items with their respective data layer attributes.
     */
    public List<PanelContainerItem> getTabItems() {
        if (tabItems == null) {
            tabItems = new ArrayList<>();
            tabs.getChildren().forEach(child -> {
                PanelContainerItem tabItem = new PanelContainerItem(child.getId(), child.getTitle(),
                        child.getName(), child.getResource());
                tabItems.add(tabItem);
            });
        }
        return Collections.unmodifiableList(tabItems);
    }

    /**
     * Returns the data layer for the tab component. This method will call the getTabItems() method
     * and sets the tab items with their respective data layer attributes.
     *
     * @return - A JSON string representing the data layer for the tab component
     */
    public String getDataLayer() {
        if (DataLayerUtils.isDataLayerEnabled(this.resource)) {
            getTabItems().forEach(this::buildTabItemDataLayer);
        }
        return EMPTY;
    }

    /**
     * Build the data layer for the tab items. This method maps the tab item ID and title to a JSON object
     * and sets it as the data layer attribute This is used to track user interactions with the tab items in the
     * data layer for analytics purposes.
     *
     * @param tabItem - The tab item for which the data layer is being set
     */
    private void buildTabItemDataLayer(PanelContainerItem tabItem) {
        tabItem.setDataLayer(DataLayerUtils.mapToJson(tabItem.getId(),
                DataLayerUtils.createEventMap(SITE_INTERACTION, "tabs||view",
                        DataLayerUtils.getFormattedDataLayerDescription(tabItem.getTitle()))));
    }
}

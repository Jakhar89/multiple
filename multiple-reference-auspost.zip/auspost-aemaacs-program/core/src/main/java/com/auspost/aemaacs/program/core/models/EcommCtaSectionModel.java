package com.auspost.aemaacs.program.core.models;

import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_IMPRESSION;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.CtaModel;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.annotation.PostConstruct;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * Sling model for the Ecommerce CTA Section component.
 *
 * <p>
 * It exposes the card title/description plus helper text fields for the primary
 * and secondary CTAs
 * while reusing the CTA plumbing already provided by {@link CtaModel}.
 * </p>
 */
@Getter
@Model(
  adaptables = SlingHttpServletRequest.class,
  adapters = EcommCtaSectionModel.class,
  resourceType = "auspost-aemaacs-program/components/ecommctasection",
  defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
  name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
  extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class EcommCtaSectionModel extends CtaModel {

  @ValueMapValue
  private String cardTitle;

  @ValueMapValue
  private String cardDescription;

  @ValueMapValue
  private String helperTextPrimary;

  @ValueMapValue
  private String helperTextSecondary;

  @ChildResource(name = "multiCtaItems")
  private List<ButtonItem> multiCta;

  @Self
  private LinkManager linkManager;

  @PostConstruct
  private void init() {
    if (multiCta == null) {
      return;
    }
    for (int index = 0; index < multiCta.size(); index++) {
      ButtonItem item = multiCta.get(index);
      if (item != null) {
        item.setId(getId() + "-multi-cta-" + (index + 1));
        LinkUtils.buildButtonItem(linkManager, item);
      }
    }
  }

  /**
   * Returns the data layer JSON string for the CTA section.
   *
   * @return data layer JSON string for the component.
   */
  public String getDataLayer() {
    if (DataLayerUtils.isDataLayerEnabled(this.resource)) {
      String componentId = getId();
      setDataLayerForCta(componentId, getPrimaryCta(), "-primary-cta");
      setDataLayerForCta(componentId, getSecondaryCta(), "-secondary-cta");
      setDataLayerForMultiCta();

      Map<String, Object> ctaSectionMap = DataLayerUtils.createEventMap(
        SITE_IMPRESSION,
        "ecommCtaSection||view",
        DataLayerUtils.getFormattedDataLayerDescription(cardTitle)
      );
      return DataLayerUtils.mapToJson(componentId, ctaSectionMap);
    }
    return EMPTY;
  }

  /**
   * Sets data layer values for a single CTA using the provided component id suffix.
   *
   * @param componentId base component id
   * @param ctaItem CTA item to decorate
   * @param componentIdSuffix suffix to ensure CTA id uniqueness
   */
  private void setDataLayerForCta(
    String componentId,
    ButtonItem ctaItem,
    String componentIdSuffix
  ) {
    if (ctaItem == null) {
      return;
    }
    setDataLayerForLinkHelper(
      ctaItem,
      componentId + componentIdSuffix,
      buildCtaDescription(ctaItem.getLabel())
    );
  }

  /**
   * Sets data layer values for all multi-CTA items.
   */
  private void setDataLayerForMultiCta() {
    List<ButtonItem> items = getMultiCta();
    if (items == null || items.isEmpty()) {
      return;
    }
    items
      .stream()
      .filter(Objects::nonNull)
      .forEach(item -> {
        String itemId = StringUtils.defaultIfBlank(
          item.getId(),
          getId() + "-multi-cta-" + (items.indexOf(item) + 1)
        );
        setDataLayerForLinkHelper(
          item,
          itemId,
          buildCtaDescription(item.getLabel())
        );
      });
  }

  /**
   * Applies the data layer payload for a CTA item.
   *
   * @param item CTA item to decorate
   * @param id id to use for data layer entry
   * @param description raw description used for formatting
   */
  private void setDataLayerForLinkHelper(
    ButtonItem item,
    String id,
    String description
  ) {
    if (item == null || StringUtils.isBlank(id)) {
      return;
    }
    DataLayerUtils.setDataLayerForLink(
      item,
      id,
      SITE_INTERACTION,
      "ecommCtaSection||cta",
      DataLayerUtils.getFormattedDataLayerDescription(description)
    );
  }

  /**
   * Builds the base description string for a CTA.
   *
   * @param label CTA label
   * @return raw description string
   */
  private String buildCtaDescription(String label) {
    String title = StringUtils.defaultString(cardTitle);
    String ctaLabel = StringUtils.defaultString(label);
    return title + COLON + ctaLabel;
  }
}

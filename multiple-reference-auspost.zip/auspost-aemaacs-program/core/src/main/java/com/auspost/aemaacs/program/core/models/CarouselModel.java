package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.adobe.cq.wcm.core.components.models.Carousel;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.PanelContainerItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.ComponentContext;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_IMPRESSION;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;
import static com.auspost.aemaacs.program.core.constants.Constants.TITLE;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = Carousel.class,
        resourceType = "auspost-aemaacs-program/components/carousel",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class CarouselModel extends BaseComponentModel implements Carousel {

    @Getter
    private final List<PanelContainerItem> carouselItems = new ArrayList<>();

    @Getter
    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private Carousel carousel;

    @SlingObject
    private Resource resource;

    @ChildResource
    private ButtonItem cta;

    @Self
    private LinkManager linkManager;

    @ScriptVariable
    private ComponentContext componentContext;

    @ScriptVariable
    private Page currentPage;

    @Getter
    @ValueMapValue
    private String title;

    /**
     * Populates the carousel items list with {@link PanelContainerItem} objects,
     * each optionally containing data layer information if enabled.
     * <p>
     * For each child in the carousel, creates a panel item with data layer attributes
     * and adds it to the {@code carouselItems} list.
     * </p>
     *
     * @return an empty string as a placeholder for data layer output
     */
    public String getDataLayer() {
        AtomicInteger index = new AtomicInteger(1);
        carousel.getChildren().forEach(child -> {
            int childIndex = index.getAndIncrement();
            PanelContainerItem carouselItem =
                    new PanelContainerItem(child.getId(), child.getTitle(), child.getName(), child.getResource());
            if (isDataLayerEnabled()) {
                DataLayerUtils.setDataLayerForPanelItem(
                        carouselItem, SITE_IMPRESSION, "carousel||view",
                        DataLayerUtils.getFormattedDataLayerDescription(
                                getChildTitle(child) + COLON + childIndex)
                );
            }

            carouselItems.add(carouselItem);
        });
        if (isDataLayerEnabled()) {
            String componentId = getId();
            setDataLayerForCta(componentId, getCta());
        }

        return EMPTY;
    }

    /**
     * Build cta via link utils.
     *
     * @return ButtonItem cta.
     */
    public ButtonItem getCta() {
        cta.setId(getId() + "-cta");
        return LinkUtils.buildButtonItem(linkManager, cta);
    }

    /**
     * Retrieves the title of the given panel container child.
     * If the child's resource contains a title property, it returns that value;
     * otherwise, it falls back to the child's own title.
     *
     * @param child the panel container item whose title is to be retrieved
     * @return the title of the child panel item
     */
    private String getChildTitle(com.adobe.cq.wcm.core.components.models.PanelContainerItem child) {
        if (Objects.requireNonNull(child.getResource()).getValueMap().containsKey(TITLE)) {
            return child.getResource().getValueMap().get(TITLE, String.class);
        }
        return child.getTitle();
    }

    /**
     * Sets the data layer for the call to action (CTA) button.
     *
     * @param componentId - The ID of the component to which the CTA belongs.
     * @param ctaItem     - The ButtonItem representing the CTA button.
     *
     */
    private void setDataLayerForCta(String componentId, ButtonItem ctaItem) {
        DataLayerUtils.setDataLayerForLink(ctaItem, componentId + "-cta", SITE_INTERACTION, "carousel||cta",
                DataLayerUtils.getFormattedDataLayerDescription(getTitle() + COLON + ctaItem.getLabel()));
    }
}

package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.Link;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;


@Slf4j
@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(alphabetic = true)
public class LinkItem {

    @Setter
    @ValueMapValue
    private String label;

    @ValueMapValue
    private String linkURL;

    @ValueMapValue
    private String linkTarget;

    @Setter
    @JsonIgnore
    private Link link;

    @Setter
    @JsonIgnore
    private String dataLayer;

    @Setter
    private String id;

    public LinkItem() {
        // default constructor to support Sling instantiation. DO NOT DELETE UNLESS YOU KNOW WHAT YOU ARE DOING
    }

    /**
     * Creates a LinkItem with the specified label, link URL, target, and link manager. Automatically builds the link
     * using the provided LinkManager.
     *
     * @param label       The display label for the link.
     * @param linkURL     The URL of the link.
     * @param linkTarget  The target behavior of the link (e.g., _blank).
     * @param linkManager The LinkManager used to build the link.
     */
    public LinkItem(String label, String linkURL, String linkTarget, LinkManager linkManager) {
        this.label = label;
        this.linkURL = linkURL;
        this.linkTarget = linkTarget;
        this.link = linkManager.get(linkURL).build();
    }

    public String getURL() {
        if (this.link != null) {
            return link.getURL();
        }
        return null;
    }

    public String getExternalizedURL() {
        if (this.link != null) {
            return link.getExternalizedURL();
        }
        return null;
    }

    public String getMappedURL() {
        if (this.link != null) {
            return link.getMappedURL();
        }
        return null;
    }

}

package com.auspost.aemaacs.program.core.constants;

import java.util.Map;

/**
 * Global constants file to be used for all constants
 *
 * @author Sathish Balan
 */
public final class Constants {

    public static final String EMPTY = "";

    public static final String SPACE = " ";

    public static final String DOT = ".";

    public static final String EXTENSION_HTML = ".html";

    public static final String EXTENSION_JPEG = ".jpeg";

    public static final String EXTENSION_JPG = ".jpg";

    public static final String EXTENSION_PNG = ".png";

    public static final String HYPHEN = "-";

    public static final String COLON = ":";

    public static final String COMMA = ",";

    public static final String PIPE = "|";

    public static final String EQUALS = "=";

    public static final String WHITESPACE_REGEX = "\\s+";

    public static final String AMPERSAND = "&";

    public static final String EVENT = "event";

    public static final String SITE_IMPRESSION = "site_impression";

    public static final String SITE_INTERACTION = "site_interaction";

    public static final String CONTENT_TYPE = "Content-Type";

    public static final String EVENT_CATEGORY = "eventCategory";

    public static final String EVENT_DESCRIPTION = "eventDescription";

    public static final String NN_FEATURED_IMAGE = "cq:featuredimage";

    public static final String RT_IMAGE = "auspost-aemaacs-program/components/image";

    public static final String DAM_PATH = "/content/dam";

    public static final String NN_ROOT = "root";

    public static final String PN_FILE_REFERENCE = "fileReference";

    public static final String PN_IMAGE_FROM_PAGE = "imageFromPageImage";

    public static final String IMAGE_DECORATIVE = "isDecorative";

    public static final String GRANT_TYPE = "grant_type";

    public static final String CLIENT_ID = "client_id";

    public static final String CLIENT_SECRET = "client_secret";

    public static final String USERNAME = "username";

    public static final String PASSWORD = "password";

    public static final String SET_COOKIE_HEADER = "Set-Cookie";

    public static final String COOKIE = "Cookie";

    public static final String JSON = "json";

    public static final String MODEL = "model";

    public static final String APPLICATION_JSON = "application/json";

    public static final String UTF_8 = "UTF-8";

    public static final String APPLICATION_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";

    public static final String APPLICATION_JSON_UTF8 = "application/json; charset=UTF-8";

    public static final String ACCEPT = org.apache.sling.api.servlets.HttpConstants.HEADER_ACCEPT;

    public static final String ACCEPT_ALL = "*/*";

    public static final String AUTH_KEY = "AUTH-KEY";

    public static final String CLIENT_CREDENTIALS = "client_credentials";

    public static final String AUDIENCE = "audience";

    public static final String ACCESS_TOKEN = "access_token";

    public static final String AUTHORIZATION = "Authorization";

    public static final String BEARER = "Bearer ";

    public static final int HTTP_SUCCESS_CODE = 200;

    public static final String APPLICATION_PDF = "application/pdf";

    public static final String PN_ENABLE_DATA_LAYER = "enableDataLayer";

    public static final String SF_FIELD_IDENTIFIER = "-_-";

    public static final String DOUBLE_PIPE = " || ";

    public static final String UNDERSCORE = "_";

    public static final String LINK_TARGET_BLANK = "_blank";

    public static final String TITLE = "title";

    public static final String SLASH = "/";

    public static final String CQ_TAGS = com.day.cq.tagging.TagConstants.PN_TAGS;

    public static final String TAG = "tag";

    public static final String DATE_FORMAT = "dd MMMM yyyy";

    public static final String DESCRIPTION = "description";

    public static final String METADATA = "metadata";

    public static final String VARIANT = "variant";

    public static final String BANNER_RESOURCE_TYPE = "auspost-aemaacs-program/components/banner";

    public static final String CAMPAIGN = "campaign";

    public static final String LEAD = "lead";

    public static final String ID = "id";

    public static final String LEAD_ID = "LeadId";

    public static final String CAMPAIGN_ID = "campaignId";

    public static final String FORM_START = ":formstart";

    public static final String LAST_NAME = "LastName";

    public static final String CHAR_SET = "_charset_";

    public static final String FORM_REDIRECT_TOKEN = ":redirect";

    public static final String FORM_ERROR_MESSAGE = "errorMessage";

    public static final String FORM_REDIRECT = "redirect";

    public static final String CSRF_TOKEN = ":cq_csrf_token";

    public static final String STATUS = "Status";

    public static final String ERRORS = "errors";

    public static final String SUCCESS = "success";

    public static final String CONTENT_FRAGMENT_PATH = "contentFragmentPath";

    public static final Map<String, String> CTA_SUFFIX_MAP = Map.of(
            "primaryCta", "-primary-cta",
            "secondary", "-secondary-cta",
            "tertiary", "-tertiary-cta"
    );

    private Constants() {
        // private constructor to avoid instantiation
    }
}

package com.auspost.aemaacs.program.core.servlets;

import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.commons.jcr.JcrConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.servlets.annotations.SlingServletResourceTypes;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.propertytypes.ServiceDescription;

import javax.servlet.Servlet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import static com.auspost.aemaacs.program.core.constants.Constants.CONTENT_FRAGMENT_PATH;


@Slf4j
@Component(service = Servlet.class)
@ServiceDescription("Salesforce Form Fields DataSource Servlet")
@SlingServletResourceTypes(
        resourceTypes = "auspost-aemaacs-program/components/datasource/dropdownlist",
        methods = HttpConstants.METHOD_GET
)
public class ContentFragmentDataSourceServlet extends SlingSafeMethodsServlet {

    @Reference
    private transient ResourceResolverFactory resolverFactory;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {

        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, "cf-read-service");
        try (ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(params)) {
            log.info("resolver : {}", resourceResolver);
            ValueMap resourceValueMap = request.getResource().getValueMap();
            String contentFragmentPath = resourceValueMap.get(CONTENT_FRAGMENT_PATH, String.class);
            log.info("Content fragment path: {}", contentFragmentPath);
            if (contentFragmentPath == null) {
                log.warn("Content fragment path is missing.");
                return;
            }

            Resource contentFragmentResource = resourceResolver.getResource(contentFragmentPath);
            if (contentFragmentResource == null) {
                log.warn("Content fragment resource not found at path: {}", contentFragmentPath);
                return;
            }

            ContentFragment contentFragment = contentFragmentResource.adaptTo(ContentFragment.class);
            if (contentFragment == null) {
                log.warn("Resource at path {} is not a ContentFragment.", contentFragmentPath);
                return;
            }

        List<Resource> fieldList = new ArrayList<>();
        contentFragment.getElements().forEachRemaining(field -> {
            ValueMap vm = new ValueMapDecorator(new java.util.HashMap<>());
            vm.put("text", field.getName());
            log.info("Content fragment field name : {}", field.getName());
            vm.put("value", field.getContent());
            log.info("Content fragment field value : {}", field.getContent());
            fieldList.add(new ValueMapResource(request.getResourceResolver(),
                    new ResourceMetadata(), JcrConstants.NT_UNSTRUCTURED, vm));
            }
        );
        DataSource dropdownDataSource = new SimpleDataSource(fieldList.iterator());
        request.setAttribute(DataSource.class.getName(), dropdownDataSource);

        } catch (LoginException e) {
            log.error("Exception occurred while fetching data source: {}", e);
        }
    }
}


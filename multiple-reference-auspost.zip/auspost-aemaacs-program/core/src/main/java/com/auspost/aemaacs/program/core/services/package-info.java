@Version("${release.java.version}")
package com.auspost.aemaacs.program.core.services;

import org.osgi.annotation.versioning.Version;

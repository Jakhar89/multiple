package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.DateUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Named;
import java.util.Date;

import static com.auspost.aemaacs.program.core.constants.Constants.DATE_FORMAT;
import static com.auspost.aemaacs.program.core.constants.Constants.NN_FEATURED_IMAGE;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;


@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = SocialProofModel.class,
        resourceType = "auspost-aemaacs-program/components/socialproof",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class SocialProofModel extends BaseComponentModel {

    @Getter
    @ValueMapValue
    private String title;

    @Getter
    @ValueMapValue
    private String type;

    @ValueMapValue
    private Date date;

    @Getter
    @ValueMapValue
    private String noOfStars;

    @Getter
    @ChildResource
    @Named(NN_FEATURED_IMAGE)
    private Resource socialProofImage;

    @ChildResource
    private IconItem socialProofLogo;

    @Getter
    @ValueMapValue
    private String socialProofLogoAlt;

    @Getter
    @ValueMapValue
    private String authorName;

    @Getter
    @ValueMapValue
    private String authorTitle;

    @Getter
    @ValueMapValue
    private String authorDescription;

    @ChildResource
    private ButtonItem socialProofCta;

    public String getDate() { return DateUtils.getFormattedDate(date, DATE_FORMAT);}

    /**
     * Build cta via link utils.
     *
     * @return ButtonItem cta.
     */
    public ButtonItem getSocialProofCta() {
        if (socialProofCta != null) {
            socialProofCta.setId(getId() + "-cta");
            return LinkUtils.buildButtonItem(linkManager, socialProofCta);
        }
        return LinkUtils.buildButtonItem(linkManager, socialProofCta);
    }

    /**
     * Build Social Proof via core link manager.
     *
     * @return Social Proof logo items.
     */
    public IconItem getSocialProofLogo() {
        return LinkUtils.buildIconItem(linkManager, socialProofLogo);
    }


    /**
     * Returns the data layer JSON string for the social proof component. If data layer is enabled, it constructs a JSON
     * object with the component ID and event details. The CTAs are also included in the data
     * layer with their respective IDs.
     *
     * @return A JSON string representing the data layer for the social proof component, or an empty string if data layer is
     * not enabled.
     */
    public String getDataLayer() {
        if (socialProofCta != null) {
            String componentId = getId();
            DataLayerUtils.setDataLayerForLink(socialProofCta, componentId + "cta", SITE_INTERACTION,
                    "socialproof||view",
                    DataLayerUtils.getFormattedDataLayerDescription(socialProofCta.getLabel()));
        }
        return EMPTY;
    }
}
package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = QuickLinksModel.class,
        resourceType = "auspost-aemaacs-program/components/quicklinks",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class QuickLinksModel extends BaseComponentModel {

    @ChildResource
    private List<IconItem> quickLinks;

    /**
     * Build quick links via core link manager.
     *
     * @return List of quick link items.
     */
    public List<IconItem> getQuickLinks() {
        return LinkUtils.buildIconItems(linkManager, quickLinks);
    }

    /**
     * Retrieves component data JSON for data layer integration.
     *
     * @return JSON string representing the data layer if enabled; otherwise, an empty string.
     */
    public String getDataLayer() {
        String componentId = getId();
        setDataLayerForQuickLinks(componentId);
        return EMPTY;
    }

    /**
     * Sets data layer entries for each links in the Quick Links Component.
     *
     * @param componentId Unique component ID for each quick links.
     */
    private void setDataLayerForQuickLinks(String componentId) {
        if (quickLinks != null) {
            for (int i = 0; i < quickLinks.size(); i++) {
                IconItem item = quickLinks.get(i);
                String id = componentId + "-quick-link-" + i;
                item.setId(id);
                DataLayerUtils.setDataLayerForLink(
                        quickLinks.get(i),
                        id,
                        SITE_INTERACTION,
                        "quickLinks||li",
                        DataLayerUtils.getFormattedDataLayerDescription(item.getLabel())
                );
            }
        }
    }
}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseFormModel;
import com.auspost.aemaacs.program.core.services.AddressLookupService;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * @author Seeni Rajan
 */
@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = FormPostCodeOrSuburbLookupModel.class,
        resourceType = "auspost-aemaacs-program/components/form/postcodeorsuburblookup",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class FormPostCodeOrSuburbLookupModel extends BaseFormModel {

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String helpMessage;

    @OSGiService
    private AddressLookupService addressLookupService;

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String required;

    @JsonIgnore
    @Getter
    @ValueMapValue
    private String requiredMessage;

    @Self
    private SlingHttpServletRequest request;

    /**
     * Retrieves postcode or suburb suggestions as a JSON object node.
     * <p>
     * If the search text is missing, returns an error node.
     * If the service response cannot be parsed, returns a service error node.
     *
     * @return ObjectNode containing suburb suggestions or error information.
     */
    public ObjectNode getPostCodeOrSuburbSuggestionList() {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode errorNode = mapper.createObjectNode();
        String suburb = super.getSearchTextFromRequest(request, "suburb");
        String postcode = super.getSearchTextFromRequest(request, "postcode");

        if (suburb.isEmpty() && postcode.isEmpty()) {
            errorNode.put("error", "No search parameters provided, provide suburb or postcode");
            return errorNode;
        }
        try {
            String response;
            if (!postcode.isEmpty()) {
                response = addressLookupService.getDomesticSuburbSuggestion(postcode);
            } else {
                response = addressLookupService.getDomesticPostCodeSuggestion(suburb);
            }
            return (ObjectNode) mapper.readTree(response);
        } catch (JsonProcessingException e) {
            log.error("Json Processing Exception occurred while fetching Post code or Suburb details in model: ", e);
            errorNode.put("error", "Service Error");
            return errorNode;
        }
    }

}

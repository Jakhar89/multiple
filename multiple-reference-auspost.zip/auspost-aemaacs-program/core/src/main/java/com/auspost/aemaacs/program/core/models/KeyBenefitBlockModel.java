package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Named;
import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.NN_FEATURED_IMAGE;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = KeyBenefitBlockModel.class,
        resourceType = "auspost-aemaacs-program/components/keybenefitblock",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class KeyBenefitBlockModel extends BaseComponentModel {

    @Getter
    @ValueMapValue
    private String title;

    @Getter
    @ValueMapValue
    private String description;

    @Getter
    @ChildResource
    @Named(NN_FEATURED_IMAGE)
    private Resource keyBenefitImage;

    @Getter
    @ChildResource
    private List<ButtonItem> cta;

    @Getter
    @ChildResource
    private List<IconItem> bulletList;

    /**
     * Returns the data layer JSON string for the Key Benefit Block component. If data layer is enabled, it constructs a JSON
     * object with the component ID and event details. The primary and secondary CTAs are also included in the data
     * layer with their respective IDs.
     *
     * @return A JSON string representing the data layer for the Key Benefit Block component, or an empty string if data layer is
     * not enabled.
     */
    public String getDataLayer() {
        return DataLayerUtils.getDataLayerForCTA(getId(), cta, linkManager, "keybenefit||cta", Constants.EMPTY, Constants.EMPTY, false);
    }

}

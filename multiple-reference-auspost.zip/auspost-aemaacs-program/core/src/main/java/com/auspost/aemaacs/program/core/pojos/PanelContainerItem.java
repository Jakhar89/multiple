package com.auspost.aemaacs.program.core.pojos;

import lombok.Getter;
import lombok.Setter;
import org.apache.sling.api.resource.Resource;

/**
 * @author Seeni Rajan
 */
@Setter
@Getter
public class PanelContainerItem {

    private String id;

    private String title;

    private String name;

    private Resource resource;

    private String dataLayer;

    /**
     * Constructor for PanelContainerItem.
     *
     * @param id       - Unique identifier for the panel container item
     * @param title    - Title of the panel container item
     * @param name     - Name of the panel container item
     * @param resource - Resource associated with the panel container item
     */
    public PanelContainerItem(String id, String title, String name, Resource resource) {
        this.id = id;
        this.title = title;
        this.name = name;
        this.resource = resource;
    }

}

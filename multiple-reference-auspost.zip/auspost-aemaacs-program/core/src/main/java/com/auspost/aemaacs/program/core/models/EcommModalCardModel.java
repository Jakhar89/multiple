package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.EcommModalCardGraphItem;
import java.util.List;
import java.util.Objects;
import javax.annotation.PostConstruct;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Getter
@Model(
  adaptables = SlingHttpServletRequest.class,
  adapters = EcommModalCardModel.class,
  resourceType = "auspost-aemaacs-program/components/ecommmodalcard",
  defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
  name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
  extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class EcommModalCardModel {

  @ValueMapValue
  private String title;

  @ValueMapValue
  private String description;

  @ValueMapValue
  private String mediaType;

  @ValueMapValue
  private String graphType;

  @ValueMapValue
  private String mediaAlignment;

  @ValueMapValue
  private String variant;

  @ValueMapValue
  private Double maxValue;

  @ChildResource
  private Resource cardImage;

  @ChildResource(name = "graphData")
  private List<EcommModalCardGraphItem> items;

  @PostConstruct
  private void buildBarWidths() {
    if (maxValue == null || maxValue == 0 || items == null) {
      return;
    }
    items
      .stream()
      .filter(Objects::nonNull)
      .filter(item -> item.getValue() != null)
      .forEach(item ->
        item.setBarWidth((int) Math.round((item.getValue() * 100) / maxValue))
      );
  }
}

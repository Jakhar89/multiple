package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.services.SearchService;
import com.auspost.aemaacs.program.core.services.impl.SearchServiceRegistry;
import com.auspost.aemaacs.program.core.utils.CommonUtils;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.ComponentContext;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;

@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = SearchModel.class,
        resourceType = {"auspost-aemaacs-program/components/search", "auspost-aemaacs-program/components/header"},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)

public class SearchModel {

    @ScriptVariable
    private ComponentContext componentContext;

    @ScriptVariable
    private Page currentPage;

    @Self
    private SlingHttpServletRequest request;

    @SlingObject
    private Resource resource;

    @JsonIgnore
    @OSGiService
    private SearchServiceRegistry searchServiceRegistry;

    private SearchService activeService;

    @ValueMapValue
    private String searchTitle;

    @ValueMapValue
    private String noResult;

    @ValueMapValue
    private String searchPlaceHolder;

    @ValueMapValue
    private String searchButtonLabel;

    @JsonIgnore
    @SlingObject
    private ResourceResolver resolver;


    /**
     * This method is to get site Id based on resource path and get the configuration.
     */
    @PostConstruct
    protected void init() {
        String siteId = searchServiceRegistry.resolveSiteId(resource.getPath());
        activeService = searchServiceRegistry.getBySiteId(siteId);
    }

    /**
     * Returns the SearchService selected for the current site.
     *
     * @return the active SearchService
     */
    public SearchService getService() {
        return activeService;
    }

    /**
     * This method is used to get search url based on current site.
     * Returns an empty string if This method is used to get no active service is selected.
     * @return the search URL for the current site
     */
    public String getSearchUrl() {
        return activeService != null
                ? activeService.buildSearchUrl()
                : EMPTY;
    }

    /**
     * This method is used to get basic Autocomplete URL for the current site.
     * Returns an empty string if no active service is selected.
     * @return the basic autocomplete URL for the current site
     */
    public String getBasicAutoCompleteUrl() {
        return activeService != null
                ? activeService.buildBasicAutoCompleteUrl()
                : EMPTY;

    }

    /**
     * This method is used to get Answer Search URL for the current site.
     * Returns an empty string if no active service is selected.
     * @return the answer URL for the current site
     */
    public String getAnswerUrl() {
        return activeService != null
                ? activeService.buildAnswerUrl()
                : EMPTY;
    }


    /**
     * This method is used to get advance Autocomplete URL for the current site.
     * Returns an empty string if no active service is selected.
     * @return the advanced autocomplete URL for the current site
     */
    public String getAdvancedAutoCompleteUrl() {
        return activeService != null
                ? activeService.buildAdvancedAutoCompleteUrl()
                : EMPTY;
    }

    /**
     * Builds and returns the Searches JSON string for search result page.
     *
     * @return a JSON string representing search fields,
     * or an empty string if no searches are configured
     */
    public String getSearchResultJson() {
        Map<String, Object> map = new HashMap<>();

        CommonUtils.addToMapIfNotBlank(map, "label", searchTitle);
        CommonUtils.addToMapIfNotBlank(map, "buttonText", searchButtonLabel);
        CommonUtils.addToMapIfNotBlank(map, "placeholder", searchPlaceHolder);

        if (map.isEmpty()) {
            return EMPTY;
        }

        try {
            return CommonUtils.writeJson(map);
        } catch (JsonProcessingException e) {
            return EMPTY;
        }
    }
    /**
     * Retrieves the id of the Search Component.
     *
     * @return unique id.
     */
    public String getId() {
        return ComponentUtils.getId(this.resource, this.currentPage, this.componentContext);
    }
}

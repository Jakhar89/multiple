package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Download;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.Map;
import java.util.Optional;

import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.WHITESPACE_REGEX;

@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = Download.class,
        resourceType = "auspost-aemaacs-program/components/download",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class DownloadModel implements Download {

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private Download download;

    @Getter
    @ValueMapValue
    private String ctaType;

    @Getter
    @ValueMapValue
    private String assetType;

    @Getter
    @ValueMapValue
    private String assetSize;

    /**
     * @return the asset size string with all whitespace removed and the unit normalized
     *         from "KB" to "kB", or null if the size is unavailable
     */
    @Override
    public String getSize() {
        return Optional.ofNullable(download.getSize())
                .map(s -> s.replaceAll(WHITESPACE_REGEX, EMPTY).toUpperCase().replaceAll("KB", "kB"))
                .orElse(null);
    }
    
    /**
     * @return the asset extension string converted to uppercase,
     *         or {@code null} if the extension is unavailable
     */
    @Override
    public String getExtension() {
        return Optional.ofNullable(download.getExtension())
                .map(String::toUpperCase)
                .orElse(null);
    }

    /**
     * Returns the data layer JSON string for the Download component.
     *
     * @return A JSON string representing the data layer for the Download component.
     */
    public String getDataLayer() {
        String componentId = download.getId();
            Map<String, Object> downloadMap =
                    DataLayerUtils
                            .createEventMap(SITE_INTERACTION, "download||cta", DataLayerUtils.getFormattedDataLayerDescription(download.getTitle()));
            return DataLayerUtils.mapToJson(componentId, downloadMap);
    }
}

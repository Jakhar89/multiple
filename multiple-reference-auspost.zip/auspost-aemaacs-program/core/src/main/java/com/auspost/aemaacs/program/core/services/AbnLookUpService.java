package com.auspost.aemaacs.program.core.services;

/**
 * @author Seeni Rajan
 */
public interface AbnLookUpService {
    /**
     * Searches for ABN details using the provided search string.
     *
     * @param searchString the ABN or search string to look up
     * @return the response as a String if successful, or an empty string if an error occurs
     */
    String search(String searchString);
}

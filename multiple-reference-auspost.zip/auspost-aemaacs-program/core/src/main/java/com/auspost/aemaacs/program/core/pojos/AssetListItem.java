package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;

/**
 * @author Seeni Rajan
 */
@Getter
@Slf4j
@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssetListItem extends ButtonItem {

    private final ResourceResolver resourceResolver;

    private final Resource metadataResource;

    private final String tagName;

    private final Resource imageResource;

    /**
     * Constructs a new ListItem.
     *
     * @param label            the label for the list item
     * @param linkURL          the URL for the link
     * @param linkTarget       the target for the link
     * @param linkManager      the link manager instance
     * @param metadataResource the Sling resource associated with this item
     * @param imageResource    the thumbnail resource associated with this item
     */
    public AssetListItem(String label, String linkURL, String tagName, String linkTarget, LinkManager linkManager,
                         Resource metadataResource, Resource imageResource, ResourceResolver resourceResolver) {
        super(label, linkURL, linkTarget, linkManager);
        this.tagName = tagName;
        this.metadataResource = metadataResource;
        this.imageResource = imageResource;
        this.resourceResolver = resourceResolver;
    }

    /**
     * Returns the DAM asset size with extension for the asset's URL.
     *
     * @return the asset size with extension, or an empty string if not applicable
     */
    @Override
    public String getAssetTypeAndSize() {
        return DamAssetUtils.getAssetTypeAndSize(resourceResolver, getURL());
    }

    /**
     * Returns the externalized URL of the asset item.
     *
     * @return the externalized asset item URL
     */
    public String getAssetItemUrl() {
        return resourceResolver.map(getURL());
    }

}

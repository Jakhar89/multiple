package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.LayoutContainer;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import javax.annotation.PostConstruct;

import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

/**
 * @author Seeni Rajan
 */
@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = LayoutContainer.class,
        resourceType = "auspost-aemaacs-program/components/cardcarousel",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class CardCarouselModel extends BaseComponentModel implements LayoutContainer {

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private LayoutContainer layoutContainer;

    @ChildResource
    private ButtonItem cta;

    @ValueMapValue
    private String title;

    /**
     * Initializes the CardCarouselModel after construction.
     * <p>
     * Sets the CTA button ID and builds the button item if CTA is present.
     * </p>
     */
    @PostConstruct
    private void init() {
        if(cta != null) {
            cta.setId(getId() + "-cta");
            LinkUtils.buildButtonItem(linkManager, cta);
        }
    }

    /**
     * Sets the data layer for the CTA button if data layer is enabled.
     *
     * @return String Returns an empty string if data layer is not enabled.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled() && cta != null) {
            DataLayerUtils.setDataLayerForLink(getCta(), "card-carousel-" + getId() + "-cta", SITE_INTERACTION, "card-carousel||cta",
                    DataLayerUtils.getFormattedDataLayerDescription(getTitle() + COLON + getCta().getLabel()));
        }
        return EMPTY;
    }

}

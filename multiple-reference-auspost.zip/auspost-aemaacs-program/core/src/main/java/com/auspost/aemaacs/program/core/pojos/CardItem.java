package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.auspost.aemaacs.program.core.utils.DateUtils;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Named;
import java.util.Date;

import static com.auspost.aemaacs.program.core.constants.Constants.DATE_FORMAT;
import static com.auspost.aemaacs.program.core.constants.Constants.NN_FEATURED_IMAGE;

@Getter
@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CardItem {

    @SlingObject
    ResourceResolver resolver;

    @ValueMapValue
    private String cardTitle;

    @ValueMapValue
    private String cardDescription;

    @ChildResource
    @Named(NN_FEATURED_IMAGE)
    private Resource cardImage;

    @ValueMapValue
    private String cardImageStyle;

    @ValueMapValue
    @Default(booleanValues = false)
    private Boolean enableLightBox;

    @ValueMapValue
    private String lightboxImageCaption;

    @ChildResource
    private CategoryItem cardCategory;

    @ChildResource
    private ButtonItem cardCta;

    @Setter
    private String dataLayer;

    @Getter
    @ValueMapValue
    private String issueDatePrefix;

    @ValueMapValue
    private Date issueDate;

    @Getter
    @ValueMapValue
    private String readTime;

    public String getIssueDate() {
        return DateUtils.getFormattedDate(issueDate, DATE_FORMAT);
    }

    /**
     * Returns the image title from DAM metadata if available, otherwise returns
     * null.
     * Handles nulls and missing resources gracefully.
     */
    public String getLightboxImageCaption() {
        if (lightboxImageCaption == null) {
            return DamAssetUtils.getImageTitleFromDam(cardImage);
        }
        return lightboxImageCaption;
    }

    /**
     * Returns the externalized URL of the card CTA.
     *
     * @return the externalized URL of the card CTA
     */
    public String getCardUrl() {
        return resolver.map(cardCta.getURL());
    }
}

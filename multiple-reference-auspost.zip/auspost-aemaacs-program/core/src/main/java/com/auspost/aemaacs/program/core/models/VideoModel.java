package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = VideoModel.class,
        resourceType = "auspost-aemaacs-program/components/video",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class VideoModel extends BaseComponentModel {

    @Getter
    @ValueMapValue
    private String videoType;

    @Getter
    @ValueMapValue
    private String videoId;

    @Getter
    @ValueMapValue
    private String transcript;

}

package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import javax.inject.Named;
import lombok.Getter;
import lombok.Setter;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Getter
@Model(
  adaptables = Resource.class,
  defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
  name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
  extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EcommHeroCardItem {

  @ValueMapValue
  private String cardTitle;

  @ValueMapValue
  private String cardDescription;

  @ValueMapValue
  @Named("cq:featuredimage/fileReference")
  private String cardImageFileReference;

  @ValueMapValue
  @Named("cq:featuredimage/alt")
  private String cardImageAlt;

  @ValueMapValue
  @Named("cq:featuredimage/imageStyle")
  private String cardImageStyle;

  @ValueMapValue
  private String connectedModalId;

  @Setter
  private String dataLayer;
}

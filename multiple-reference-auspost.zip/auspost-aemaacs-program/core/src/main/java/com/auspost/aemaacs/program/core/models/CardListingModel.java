package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.CardItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = CardListingModel.class,
        resourceType = "auspost-aemaacs-program/components/cardlisting",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class CardListingModel extends BaseComponentModel {

    @Getter
    @ValueMapValue
    private String heading;

    @Getter
    @ValueMapValue
    private String columnLayout;

    @Getter
    @ValueMapValue
    private String cardClickable;

    @Getter
    @ValueMapValue
    private String cardBackgroundColor;

    @Getter
    @ValueMapValue
    private String cardImageAlignment;

    @Getter
    @ValueMapValue
    private String cardTextAlignment;

    @Getter
    @ValueMapValue
    private String cardImageAspectRatio;

    @Getter
    @ValueMapValue
    private String cardCtaType;

    @Getter
    @ValueMapValue
    private String mainCtaType;

    @Getter
    @ChildResource
    private List<CardItem> cards;

    @ChildResource
    private ButtonItem mainCta;

    /**
     * Retrieves component data JSON for data layer integration
     * and Sets data layer entries for each cards in the CardListing Component.
     *
     * @return A JSON string representing the data layer for each cards in the CardListing Component.
     */
    public String getDataLayer() {
        String componentId = getId();
        if (cards != null) {
            for (int i = 0; i < cards.size(); i++) {
                CardItem item = cards.get(i);
                ButtonItem buttonItem = cards.get(i).getCardCta();
                LinkUtils.buildLinkItem(linkManager, buttonItem);
                String id = componentId + "-item-" + i;
                buttonItem.setId(id);
                DataLayerUtils.setDataLayerForCard(
                        cards.get(i),
                        id,
                        SITE_INTERACTION,
                        "cardListing||li",
                        DataLayerUtils.getFormattedDataLayerDescription(item.getCardTitle())
                );
            }
            DataLayerUtils.setDataLayerForLink(mainCta, componentId + "-main-cta", SITE_INTERACTION,
                    "cardListing||main-cta",
                    DataLayerUtils.getFormattedDataLayerDescription(mainCta.getLabel()));
        }
        return EMPTY;
    }

    /**
     * Build Main Cta link via core link manager and set id to Main Cta
     *
     * @return Main Cta link item.
     */
    public ButtonItem getMainCta() {
        if (mainCta != null) {
            mainCta.setId(getId() + "-main-cta");
            return LinkUtils.buildButtonItem(linkManager, mainCta);
        }
        return LinkUtils.buildButtonItem(linkManager, mainCta);
    }
}

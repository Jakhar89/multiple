package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.services.SearchService;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.propertytypes.ServiceDescription;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@Slf4j
@Getter
@Component(service = SearchService.class)
@ServiceDescription("Search Service Implementation")
@Designate(ocd = SearchServiceImpl.Configuration.class)
public class SearchServiceImpl implements SearchService {

    private String siteId;
    private String projectId;
    private String dataStoreId;
    private String host;
    private String apiVersion;
    private String apiVersionAutoComplete;
    private String collection;
    private String autocompleteCollection;
    private String vertexEngineID;
    private String completionConfig;
    private String searchEndpoint;
    private String autocompleteEndpoint;
    private String answerEndpoint;

    @Activate
    @Modified
    private void activate(SearchServiceImpl.Configuration configuration) {
        this.siteId = configuration.siteId();
        this.projectId = configuration.projectId();
        this.dataStoreId = configuration.dataStoreId();
        this.host = configuration.host();
        this.apiVersion = configuration.apiVersion();
        this.apiVersionAutoComplete = configuration.apiVersionAutoComplete();
        this.autocompleteCollection = configuration.autocompleteCollection();
        this.collection = configuration.collection();
        this.vertexEngineID = configuration.vertexEngineID();
        this.completionConfig = configuration.completionConfig();
        this.searchEndpoint = configuration.searchEndpoint();
        this.autocompleteEndpoint = configuration.autocompleteEndpoint();
        this.answerEndpoint = configuration.answerEndpoint();
    }

    /**
     * Returns the site identifier associated with this implementation.
     *
     * @return the site ID, e.g., "auspost"
     */
    @Override
    public String getSiteId() {
        return siteId;
    }

    /**
     * Builds and returns the configured search url this site.
     *
     * @return the search URL
     */
    public String buildSearchUrl() {
        return host
                + apiVersion
                + projectId
                + collection
                + vertexEngineID
                + searchEndpoint;
    }
    /**
     * Builds and returns the configured basic Autocomplete URL for this site.
     *
     * @return the autocomplete URL
     */
    public String buildBasicAutoCompleteUrl() {
        return host
                + apiVersionAutoComplete
                + projectId
                + autocompleteCollection
                + dataStoreId
                + autocompleteEndpoint;
    }

    /**
     * Builds and returns the configured Answer Search URL for this site.
     *
     * @return the answer URL
     */
    public String buildAnswerUrl() {
        return host
                + apiVersion
                + projectId
                + collection
                + vertexEngineID
                + answerEndpoint;
    }

    /**
     * Builds and returns the configured advance Autocomplete URL for this site.
     *
     * @return the advanced autocomplete URL
     */
    public String buildAdvancedAutoCompleteUrl() {
        return host
                + apiVersionAutoComplete
                + projectId
                + collection
                + vertexEngineID
                + completionConfig
                + autocompleteEndpoint;
    }

    /**
     * OSGI config handler
     *
     */
    @ObjectClassDefinition(
            name = "Search Engine Configurations",
            description = "Configuration for Search Engine"
    )
    public @interface Configuration {

        @AttributeDefinition(name = "Site Identifier")
        String siteId();

        @AttributeDefinition(name = "Project Id")
        String projectId();

        @AttributeDefinition(name = "Data store Id")
        String dataStoreId();

        @AttributeDefinition(name = "Host", description = "Host")
        String host();

        @AttributeDefinition(name = "API Version", description = "API Version")
        String apiVersion();

        @AttributeDefinition(name = "API Version For Autocomplete", description = "API Version For Autocomplete")
        String apiVersionAutoComplete();

        @AttributeDefinition(name = "Collection", description = "Collection")
        String collection();

        @AttributeDefinition(name = "Auto complete Collection", description = "Auto complete Collection")
        String autocompleteCollection();

        @AttributeDefinition(name = "Vertex Engine ID", description = "Vertex Engine ID")
        String vertexEngineID();

        @AttributeDefinition(name = "Completion Config", description = "Completion Config is used only for advanced autocomplete url")
        String completionConfig();

        @AttributeDefinition(name = "Search end url", description = "Search end url")
        String searchEndpoint();

        @AttributeDefinition(name = "Autocomplete  url", description = "Autocomplete url")
        String autocompleteEndpoint();

        @AttributeDefinition(name = "Answer url", description = "Answer url")
        String answerEndpoint();
    }
}
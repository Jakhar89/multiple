package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Image;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = ImageModel.class,
        resourceType = "auspost-aemaacs-program/components/image",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class ImageModel extends BaseComponentModel implements Image {

    private static final String CAPTION_DOWNLOAD = "captionDownload";

    @SlingObject
    private ResourceResolver resourceResolver;

    @Delegate
    @Self
    @Via(type = ResourceSuperType.class)
    private Image image;

    @Getter
    @ValueMapValue
    private String captionType;

    @Getter
    @ValueMapValue
    private String imageStyle;

    @Getter
    @ValueMapValue
    private String imagePadding;

    @Getter
    @ValueMapValue
    private String downloadLabel;

    @Getter
    @ValueMapValue
    private String downloadReference;

    @Getter
    @ValueMapValue
    private boolean showPdfAttachmentSize;

    /**
     * Retrieves component data json for data layer integration.
     *
     * @return Json String data if the data layer is enabled, captionType is captionDownload and downloadReference
     * exists; otherwise, empty string.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled() && isCaptionDownload(downloadReference, captionType)) {
            Map<String, Object> downloadMap =
                    DataLayerUtils
                            .createEventMap(SITE_INTERACTION, "featureBanner||download||pdf", this.getDownloadLabel());
            return DataLayerUtils.mapToJson(getId(), downloadMap);
        }
        return EMPTY;
    }

    /**
     * @param downloadReference - The path to the asset that is configured to be downloaded
     * @param captionType       - the caption type to be validated as download
     * @return - true if downloadReference is not null and caption type is captionDownload
     */
    private boolean isCaptionDownload(String downloadReference, String captionType) {
        return downloadReference != null && CAPTION_DOWNLOAD.equals(captionType);
    }

    /**
     * Retrieves the Attachment size from the metadata.
     *
     * @return Size of the Attachment.
     */
    public String getSize() {
        if (showPdfAttachmentSize &&
                StringUtils.isNotEmpty(DamAssetUtils.getAssetSize(resourceResolver, downloadReference))) {
            return String.format("(%s)", DamAssetUtils.getAssetSize(resourceResolver, downloadReference));
        }
        return EMPTY;
    }

}

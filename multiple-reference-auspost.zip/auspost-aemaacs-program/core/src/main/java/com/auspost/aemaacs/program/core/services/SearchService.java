package com.auspost.aemaacs.program.core.services;

public interface SearchService {
    /**
     * Returns the unique site identifier for this search service.
     *
     * @return the site ID, e.g., "auspost"
     */
    String getSiteId();
    /**
     * Builds and returns the configured search url this site.
     *
     * @return the search URL
     */
    String buildSearchUrl();
    /**
     * Builds and returns the configured Autocomplete URL for this site.
     *
     * @return the autocomplete URL
     */
    String buildBasicAutoCompleteUrl();

    /**
     * Builds and returns the configured Answer Search URL for this site.
     *
     * @return the answer URL
     */
    String buildAnswerUrl();

    /**
     * Builds and returns the configured advance Autocomplete URL for this site.
     *
     * @return the advanced autocomplete URL
     */
    String buildAdvancedAutoCompleteUrl();
}

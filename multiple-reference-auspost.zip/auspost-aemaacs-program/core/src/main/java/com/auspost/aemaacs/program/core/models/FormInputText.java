package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.form.Text;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import static com.auspost.aemaacs.program.core.constants.Constants.SF_FIELD_IDENTIFIER;
import static com.auspost.aemaacs.program.core.constants.Constants.SPACE;
import static com.auspost.aemaacs.program.core.constants.Constants.UNDERSCORE;

@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = Text.class,
        resourceType = "auspost-aemaacs-program/components/form/text",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class FormInputText implements Text {

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private Text text;

    @ValueMapValue
    private String charLimit;

    @ValueMapValue
    private String minCharLimit;

    @ValueMapValue
    private String spellCheck;

    /**
     * Generates a unique name for the text input field by combining a sanitized version of the title with the original name.
     *
     * @return A unique name for the text input field.
     */
    @Override
    public String getName() {
        return text.getTitle().replaceAll(SPACE, UNDERSCORE).toLowerCase() + SF_FIELD_IDENTIFIER + text.getName();
    }

}

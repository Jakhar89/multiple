package com.auspost.aemaacs.program.core.utils;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.wcm.api.Page;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.resource.filter.ResourceFilterStream;

import java.util.Optional;
import java.util.function.Function;

import static com.auspost.aemaacs.program.core.constants.Constants.DAM_PATH;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;

/**
 * @author Sathish Balan
 */
public final class DamAssetUtils {

    private DamAssetUtils() {
    }

    /**
     * Retrieves an image resource from a component.
     *
     * @param resource The component resource.
     * @return An Optional containing the image resource if found, otherwise empty.
     */
    public static Optional<Resource> getImageFromComponent(Resource resource) {
        return Optional.ofNullable(resource)
                .map(r -> r.getChild(Constants.NN_FEATURED_IMAGE))
                .filter(DamAssetUtils::isValidImage);
    }

    /**
     * Retrieves an image resource from a page property.
     *
     * @param page The page resource.
     * @return An Optional containing the image resource if found, otherwise empty.
     */
    public static Optional<Resource> getImageFromPageProperty(Page page) {
        return Optional.ofNullable(page)
                .map(Page::getContentResource)
                .map(jcrContent -> jcrContent.getChild(Constants.NN_FEATURED_IMAGE))
                .filter(DamAssetUtils::isValidImage);
    }

    /**
     * Searches for an image within the page content hierarchy.
     *
     * @param page The page to search.
     * @return An Optional containing the image resource if found, otherwise empty.
     */
    public static Optional<Resource> getImageFromPageContent(Page page) {
        return Optional.ofNullable(page)
                .map(Page::getContentResource)
                .map(jcrContent -> jcrContent.getChild(Constants.NN_ROOT))
                .map(root -> root.adaptTo(ResourceFilterStream.class))
                .flatMap(findFirstImage());
    }

    /**
     * Helper function to locate the first valid image resource.
     *
     * @return A function using ResourceFilterStream that filters and retrieves the first matching image.
     */
    private static Function<ResourceFilterStream, Optional<? extends Resource>> findFirstImage() {
        return rfs -> rfs.setBranchSelector("[jcr:primaryType] == $primaryType")
                .setChildSelector("[sling:resourceType] == $resourceType")
                .addParam("primaryType", JcrConstants.NT_UNSTRUCTURED)
                .addParam("resourceType", Constants.RT_IMAGE)
                .stream()
                .filter(DamAssetUtils::isValidImage)
                .findFirst();
    }

    /**
     * Checks if a resource is a valid image.
     *
     * @param resource The resource to validate.
     * @return True if the resource is an image and contains a file reference, otherwise false.
     */
    public static boolean isValidImage(Resource resource) {
        return resource.isResourceType(Constants.RT_IMAGE) &&
                resource.getValueMap().containsKey(Constants.PN_FILE_REFERENCE);
    }

    /**
     * Retrieves an image from page content first, falling back to the page property if not found.
     *
     * @param page The page to get an image from.
     * @return An Optional containing the image resource if found, otherwise empty.
     */
    public static Optional<Resource> getImageFromPageContentOrElsePageProperty(Page page) {
        return DamAssetUtils.getImageFromPageContent(page).or(() -> DamAssetUtils.getImageFromPageProperty(page));
    }

    /**
     * Retrieves an image from page property first, falling back to the page content if not found.
     *
     * @param page The page to get an image from.
     * @return An Optional containing the image resource if found, otherwise empty.
     */
    public static Optional<Resource> getImageFromPagePropertyOrElsePageContent(Page page) {
        return DamAssetUtils.getImageFromPageProperty(page).or(() -> DamAssetUtils.getImageFromPageContent(page));
    }

    /**
     * Helper to get the image title from DAM asset's metadata.
     *
     * @param imageResource The image resource.
     * @return The title of the image from DAM metadata, or null if not available.
     */
    public static String getImageTitleFromDam(Resource imageResource) {
        return getFileReference(imageResource)
                .map(ref -> imageResource.getResourceResolver().getResource(ref + "/jcr:content/metadata"))
                .map(res -> res.getValueMap().get(DamConstants.DC_TITLE, String.class))
                .orElse(null);
    }

    /**
     * Helper to safely get the fileReference from cardImage.
     */
    private static Optional<String> getFileReference(Resource imageResource) {
        return Optional.ofNullable(imageResource.getValueMap().get("fileReference", String.class));
    }


    /**
     * Retrieves the size of a DAM asset in a human-readable format.
     *
     * @param resourceResolver The ResourceResolver to access resources.
     * @param assetReference   The path to the DAM asset.
     * @return The size of the asset as a human-readable string, or an empty string if not found.
     */
    public static String getAssetSize(ResourceResolver resourceResolver, String assetReference) {
        Resource assetResource = resourceResolver.getResource(assetReference);
        if (assetResource != null) {
            Asset asset = assetResource.adaptTo(Asset.class);
            if (asset != null) {
                Object rawFileSizeObject = asset.getMetadata(DamConstants.DAM_SIZE);
                long rawFileSize = rawFileSizeObject != null ? (Long) rawFileSizeObject : 0L;
                return FileUtils.byteCountToDisplaySize(rawFileSize);
            }
        }
        return EMPTY;
    }

    /**
     * Retrieves the size and extension of a DAM asset in a formatted string.
     *
     * @param resourceResolver The ResourceResolver to access resources.
     * @param assetReference   The path to the DAM asset.
     * @return A formatted string containing the asset's extension and size, or an empty string if not a DAM asset.
     */
    public static String getAssetTypeAndSize(ResourceResolver resourceResolver, String assetReference) {
        if (StringUtils.startsWith(assetReference, DAM_PATH)) {
            String extension = StringUtils.upperCase(FilenameUtils.getExtension(assetReference));
            String size = getAssetSize(resourceResolver, assetReference);
            if (StringUtils.isNotEmpty(extension)) {
                return String.format("(%s, %s)", extension, size);
            }
        }
        return EMPTY;
    }
}

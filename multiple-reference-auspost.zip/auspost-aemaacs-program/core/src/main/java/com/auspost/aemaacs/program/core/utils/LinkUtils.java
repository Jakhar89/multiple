package com.auspost.aemaacs.program.core.utils;

import com.adobe.cq.wcm.core.components.commons.link.Link;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.pojos.LinkItem;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public final class LinkUtils {


    private LinkUtils() {
    }

    /**
     * Constructs a Link object for the given LinkItem.
     *
     * @param linkManager The core linkManager to build link
     * @param linkItem    The link item whose link is to be built.
     * @return The constructed Link object.
     */
    public static Link buildLink(LinkManager linkManager, LinkItem linkItem) {
        return linkManager.get(linkItem.getLinkURL()).build();
    }

    /**
     * Builds LinkItem object by applying the buildLink method.
     *
     * @param linkManager The core linkManager to build link
     * @return The constructed LinkItem object.
     */
    public static LinkItem buildLinkItem(LinkManager linkManager, LinkItem linkItem) {
        if (linkItem != null) {
            linkItem.setLink(buildLink(linkManager, linkItem));
        }
        return linkItem;
    }

    /**
     * Builds LinkItems by applying the buildLink method.
     *
     * @param linkManager The core linkManager to build link
     * @param linkItems   The link items whose icon reference is to be built.
     */
    public static List<LinkItem> buildLinkItems(LinkManager linkManager, List<LinkItem> linkItems) {
        if (linkItems != null) {
            linkItems.forEach(linkItem -> buildLinkItem(linkManager, linkItem));
        }
        return linkItems;
    }

    /**
     * Constructs a Link object for the given IconItem.
     *
     * @param linkManager The core linkManager to build link
     * @param iconItem    The icon item whose icon reference is to be built.
     * @return The constructed Link object.
     */
    public static Link buildIconLink(LinkManager linkManager, IconItem iconItem) {
        return linkManager.get(iconItem.getIconReference()).build();
    }

    /**
     * Builds IconItem object by applying the buildLink method.
     *
     * @param linkManager The core linkManager to build link
     * @return The constructed IconItem object.
     */
    public static IconItem buildIconItem(LinkManager linkManager, IconItem iconItem) {
        if (iconItem != null) {
            iconItem.setExternalIconReference(buildIconLink(linkManager, iconItem).getExternalizedURL());
            iconItem.setLink(buildLink(linkManager, iconItem));
        }
        return iconItem;
    }

    /**
     * Builds IconItems by applying the buildLink method.
     *
     * @param linkManager The core linkManager to build link
     * @param iconItems   The link items whose icon reference is to be built.
     */
    public static List<IconItem> buildIconItems(LinkManager linkManager, List<IconItem> iconItems) {
        if (iconItems != null) {
            iconItems.forEach(iconItem -> buildIconItem(linkManager, iconItem));
        }
        return iconItems;
    }

    /**
     * Builds ButtonItem object by applying the buildButtonLink method.
     *
     * @param linkManager The core linkManager to build link
     * @return The constructed ButtonItem object.
     */
    public static ButtonItem buildButtonItem(LinkManager linkManager, ButtonItem buttonItem) {
        if (buttonItem != null) {
            buttonItem.setLink(buildButtonLink(linkManager, buttonItem));
        }
        return buttonItem;
    }

    /**
     * Constructs a Link object for the given ButtonItem.
     *
     * @param linkManager The core linkManager to build link
     * @param buttonItem  The link item whose link is to be built.
     * @return The constructed Link object.
     */
    public static Link buildButtonLink(LinkManager linkManager, ButtonItem buttonItem) {
        return linkManager.get(buttonItem.getLinkURL()).build();
    }

}

package com.auspost.aemaacs.program.core.services.impl;

import com.adobe.aem.wcm.seo.sitemap.externalizer.SitemapLinkExternalizer;
import com.auspost.aemaacs.program.core.services.AuspostDomainMapperService;
import com.day.cq.commons.Externalizer;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.propertytypes.ServiceDescription;
import org.osgi.service.component.propertytypes.ServiceRanking;

/**
 * @author Seeni Rajan
 */
@Slf4j
@Component(service = SitemapLinkExternalizer.class)
@ServiceDescription("Sitemap URLs Externalization Service")
@ServiceRanking(200)
public class SitemapLinkExternalizerImpl implements SitemapLinkExternalizer {

    @Reference
    private AuspostDomainMapperService auspostDomainMapperService;

    @Reference
    private Externalizer externalizer;

    /**
     * Externalizes the given location using the request's resource resolver and
     * the domain determined by the Auspost domain mapper service.
     *
     * @param slingHttpServletRequest the current Sling HTTP request
     * @param location                the content path to externalize
     * @return the externalized URL for the given location
     */
    @Override
    public String externalize(SlingHttpServletRequest slingHttpServletRequest, String location) {
        return externalizer.externalLink(slingHttpServletRequest.getResourceResolver(),
                auspostDomainMapperService.getDomainNameUsingPath(location), location);
    }

    /**
     * Externalizes the given resource using its resource resolver and
     * the domain determined by the Auspost domain mapper service.
     *
     * @param resource the resource to externalize
     * @return the externalized URL for the resource's path
     */
    @Override
    public String externalize(Resource resource) {
        return externalizer.externalLink(resource.getResourceResolver(),
                auspostDomainMapperService.getDomainNameUsingPath(resource.getPath()), resource.getPath());
    }

    /**
     * Externalizes the given location using the provided resource resolver and
     * the domain determined by the Auspost domain mapper service.
     *
     * @param resourceResolver the resource resolver to use
     * @param location         the content path to externalize
     * @return the externalized URL for the given location
     */
    @Override
    public String externalize(ResourceResolver resourceResolver, String location) {
        return externalizer.externalLink(resourceResolver,
                auspostDomainMapperService.getDomainNameUsingPath(location), location);
    }
}

package com.auspost.aemaacs.program.core.models;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.pojos.AiSearchItem;
import com.auspost.aemaacs.program.core.pojos.EcommHeroCardItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.ComponentContext;
import java.util.List;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

@Slf4j
@Model(
  adaptables = SlingHttpServletRequest.class,
  adapters = EcommHeroCardModel.class,
  resourceType = "auspost-aemaacs-program/components/ecommherocard",
  defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
  name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
  extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class EcommHeroCardModel {

  @ScriptVariable
  private ComponentContext componentContext;

  @SlingObject
  private Resource resource;

  @ScriptVariable
  private Page currentPage;

  @Self
  private LinkManager linkManager;

  @ChildResource
  @Getter
  private List<EcommHeroCardItem> cards;

  @ChildResource
  private AiSearchItem aiSearch;

  /**
   * Retrieves component data JSON for data layer integration
   * and Sets data layer entries for each cards in the EcommHeroCard Component.
   *
   * @return A JSON string representing the data layer for each cards in the
   *         EcommHeroCard Component.
   */
  public String getDataLayer() {
    String componentId = getId();
    if (cards != null) {
      for (int i = 0; i < cards.size(); i++) {
        EcommHeroCardItem item = cards.get(i);
        String id = componentId + "-item-" + i;
        DataLayerUtils.setDataLayerForEcommCard(
          item,
          id,
          SITE_INTERACTION,
          "ecommHeroCard||li",
          DataLayerUtils.getFormattedDataLayerDescription(item.getCardTitle())
        );
      }

      if (aiSearch != null) {
        DataLayerUtils.setDataLayerForLink(
          aiSearch,
          componentId + "-ai-search",
          SITE_INTERACTION,
          "ecommHeroCard||ai-search",
          DataLayerUtils.getFormattedDataLayerDescription(aiSearch.getLabel())
        );
      }

      java.util.Map<String, Object> ecommHeroCardMap =
        DataLayerUtils.createEventMap("site_impression", "ecommHeroCard", "Ecommerce Hero Card Component");
      return DataLayerUtils.mapToJson(componentId, ecommHeroCardMap);
    }
    return EMPTY;
  }

  /**
   * Build AiSearch link via core link manager and set id to AiSearch
   *
   * @return AiSearch link item.
   */
  public AiSearchItem getAiSearch() {
    if (aiSearch != null) {
      aiSearch.setId(getId() + "-ai-search");
      LinkUtils.buildButtonItem(linkManager, aiSearch);
      return aiSearch;
    }
    return null;
  }

  /**
   * Retrieves the id of the EcommHeroCard Component.
   *
   * @return unique id.
   */
  public String getId() {
    return ComponentUtils.getId(
      this.resource,
      this.currentPage,
      this.componentContext
    );
  }
}

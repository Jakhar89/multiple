package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;


@Getter
@Slf4j
@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IconItem extends LinkItem {

    @ValueMapValue
    private String icon;

    @ValueMapValue
    private String iconTheme;

    @ValueMapValue
    private String iconDescription;

    @ValueMapValue
    private String iconReference;

    @Setter
    private String externalIconReference;

    public IconItem() {
        // default constructor to support Sling instantiation. DO NOT DELETE UNLESS YOU KNOW WHAT YOU ARE DOING
    }

    /**
     * Creates an Icon with the specified label, link URL, target, link manager, and icon reference. Calls the
     * superclass constructor to initialize link-related attributes.
     *
     * @param label         The display label for the icon.
     * @param linkURL       The URL associated with the icon.
     * @param linkTarget    The target behavior of the link (e.g., _blank).
     * @param linkManager   The LinkManager used to build the link.
     * @param icon          The icon reference or identifier.
     * @param iconReference The URL associated with the icon.
     */
    public IconItem(String label, String linkURL, String linkTarget, LinkManager linkManager, String icon,
                    String iconReference) {
        super(label, linkURL, linkTarget, linkManager);
        externalIconReference = linkManager.get(iconReference).build().getExternalizedURL();
        this.icon = icon;
    }

}


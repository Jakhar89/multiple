package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.PageListItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.ListingUtils;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.HYPHEN;
import static com.auspost.aemaacs.program.core.constants.Constants.LINK_TARGET_BLANK;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;
import static com.auspost.aemaacs.program.core.constants.Constants.TITLE;
import static com.auspost.aemaacs.program.core.utils.ListingUtils.FILTERED_RESULTS;
import static com.auspost.aemaacs.program.core.utils.ListingUtils.LIST_CTA;

/**
 * @author Seeni Rajan
 */
@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = com.adobe.cq.wcm.core.components.models.List.class,
        resourceType = "auspost-aemaacs-program/components/pagelisting",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class PageListingModel extends BaseComponentModel implements com.adobe.cq.wcm.core.components.models.List {

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private com.adobe.cq.wcm.core.components.models.List list;

    @Self
    private SlingHttpServletRequest request;

    @Getter
    @ValueMapValue
    private String listFrom;

    @Getter
    @ValueMapValue
    private String title;

    @Getter
    @ValueMapValue
    private String orderBy;

    @Getter
    @ValueMapValue
    private String targetSource;

    @ChildResource
    private List<Resource> filterTagList;

    @Getter
    @ValueMapValue
    private String pageCta;

    @Getter
    @ValueMapValue
    private String noResultsMessage;

    @Getter
    @ValueMapValue
    private int initialPageLoad;

    @Getter
    @ValueMapValue
    private boolean isDecorative;

    @SlingObject
    private ResourceResolver resolver;

    private List<PageListItem> pageListItems = new LinkedList<>();

    private TagManager tagManager;

    private List<String> validSelectors = new ArrayList<>();

    private String[] selectors;

    @Getter
    private int filteredResults;

    /**
     * Initializes the TagManager after the model is constructed.
     * This method is called automatically by the Sling Models framework.
     *
     */
    @PostConstruct
    private void init() {
        tagManager = resolver.adaptTo(TagManager.class);
        selectors = ListingUtils.getSelectorsIfPresent(request);
    }

    /**
     * Generates the data layer JSON for the component if data layer is enabled.
     *
     * @return the data layer JSON string or an empty string if data layer is not enabled.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled()) {
            String componentId = super.getId();
            Map<String, Object> listEventMap = DataLayerUtils
                    .createEventMap(FILTERED_RESULTS,
                            ListingUtils.getFilterListAsString(tagManager, validSelectors),
                            String.valueOf(pageListItems.size()));
            return DataLayerUtils.mapToJson(componentId, listEventMap);
        }
        return EMPTY;
    }


    /**
     * Retrieves child tags grouped by their parent tag name.
     *
     * @return a list of maps where each map contains a parent tag name as the key
     * and its child tags as the value.
     */
    public List<Map<String, List<Map<String, Object>>>> getFilters() {
        if (filterTagList == null) {
            return Collections.emptyList();
        }
        return ListingUtils.getFilters(
                filterTagList,
                tagManager,
                selectors,
                validSelectors
        );
    }

    /**
     * Generates a list of PageListItems based on the filtered pages and the target source.
     * The list is sorted and processed based on the orderBy and offset values.
     *
     * @return a list of PageListItems representing the filtered pages.
     */
    public List<PageListItem> getPageListItems() {
        if (list == null) {
            return Collections.emptyList();
        }

        AtomicInteger index = new AtomicInteger(0);
        Stream<Page> filteredPageListStream = getFilteredPageListStream();
        if (targetSource.equals("banner")) {
            if ("issueDate".equalsIgnoreCase(orderBy)) {
                pageListItems = filteredPageListStream
                        .map(PageListingModel::createBannerResourceObject)
                        .sorted(ListingUtils::sortDate)
                        .map(arr -> mapToPageListItem(arr, index))
                        .toList();
            } else {
                pageListItems = getFilteredPageListStream()
                        .sorted((p1, p2) -> p2.getTitle().compareToIgnoreCase(p1.getTitle()))
                        .map(page -> createPageListItem(page, getBannerResource(page), index.getAndIncrement()))
                        .toList();
            }
        } else {
            //below will be used when target source is set to "default" for now it is not exposed in dialog
            pageListItems = filteredPageListStream
                    .map(page -> getPageListItemForDefaultTarget(page, index)).toList();
        }
        filteredResults = pageListItems.size();
        pageListItems = ListingUtils.processOffSet(pageListItems, initialPageLoad, selectors);
        return Collections.unmodifiableList(pageListItems);
    }

    /**
     * Creates a PageListItem for the default target source.
     *
     * @param page  the page to create the list item for.
     * @param index an atomic integer to keep track of the index.
     * @return a PageListItem representing the page.
     */
    private PageListItem getPageListItemForDefaultTarget(Page page, AtomicInteger index) {
        PageListItem pageListItem =
                new PageListItem(page.getTitle(), page.getPath(), LINK_TARGET_BLANK, linkManager,
                        page.adaptTo(Resource.class), isDecorative);
        pageListItem.setId(
                super.getId() + HYPHEN +
                        DataLayerUtils.getFormattedDataLayerDescription(page.getTitle()) + HYPHEN +
                        index);
        DataLayerUtils.setDataLayerForLink(pageListItem, super.getId(), SITE_INTERACTION,
                LIST_CTA, DataLayerUtils.getFormattedDataLayerDescription(page.getTitle()));
        return pageListItem;
    }


    /**
     * Maps an array of objects to a PageListItem.
     *
     * @param arr   the array containing the page and banner resource.
     * @param index an atomic integer to keep track of the index.
     * @return a PageListItem created from the array elements.
     */
    private PageListItem mapToPageListItem(Object[] arr, AtomicInteger index) {
        Page page = (Page) arr[0];
        Resource bannerResource = (Resource) arr[1];
        return createPageListItem(page, bannerResource, index.getAndIncrement());
    }

    /**
     * Creates an array containing the page, its banner resource, and the issue date.
     *
     * @param page the page to extract information from.
     * @return an array with the page, banner resource, and issue date.
     */
    private static Object[] createBannerResourceObject(Page page) {
        Resource bannerResource = getBannerResource(page);
        String issueDate = bannerResource != null
                ? bannerResource.getValueMap().get("issueDate", String.class)
                : EMPTY;
        return new Object[] {page, bannerResource, issueDate};
    }

    /**
     * Retrieves a stream of pages filtered based on the request selectors and parent tags.
     *
     * @return a stream of filtered pages.
     */
    private Stream<Page> getFilteredPageListStream() {
        return list.getListItems().stream()
                .map(item -> currentPage.getPageManager().getPage(item.getPath()))
                .filter(this::filterBasedOnSelector);
    }

    /**
     * Creates a PageListItem for a given page and index.
     *
     * @param page  the page to create the list item for.
     * @param index the index of the page in the list.
     * @return a PageListItem representing the page.
     */
    private PageListItem createPageListItem(Page page, Resource bannerResource, int index) {
        String pageTitle = page.getTitle();
        if (bannerResource != null) {
            pageTitle = bannerResource.getValueMap().get(TITLE, String.class);
        }
        PageListItem pageListItem =
                new PageListItem(pageTitle, page.getPath(), LINK_TARGET_BLANK, linkManager,
                        bannerResource, isDecorative);
        pageListItem.setId(
                super.getId() + HYPHEN + DataLayerUtils.getFormattedDataLayerDescription(pageTitle) + HYPHEN +
                        index);
        DataLayerUtils.setDataLayerForLink(pageListItem, super.getId(), SITE_INTERACTION,
                LIST_CTA,
                DataLayerUtils.getFormattedDataLayerDescription(pageTitle));
        return pageListItem;
    }

    /**
     * Retrieves the banner resource from the page content.
     *
     * @param page the page to retrieve the banner resource from.
     * @return the banner resource, or null if not found.
     */
    private static Resource getBannerResource(Page page) {
        return ListingUtils.getBannerFromPageContent(page).orElse(null);
    }

    /**
     * Filters a page based on the request selectors and parent tags.
     *
     * @param page the page to filter.
     * @return true if the page matches the filters, false otherwise.
     */
    private boolean filterBasedOnSelector(Page page) {
        if (selectors.length > 0) {
            validSelectors = ListingUtils.validateSelectors(selectors, tagManager,
                    filterTagList);
            return ListingUtils.matchesAllPageTags(page, validSelectors);
        } else {
            return true;
        }
    }

    /**
     * Retrieves the path of the current page path.
     *
     * @return the current page path as a string.
     */
    public String getResourcePath() {
        return resolver.map(currentPage.getPath());
    }

}

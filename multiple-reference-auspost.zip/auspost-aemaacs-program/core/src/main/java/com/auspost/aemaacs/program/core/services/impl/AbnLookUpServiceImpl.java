package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.services.AbnLookUpService;
import lombok.extern.slf4j.Slf4j;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.propertytypes.ServiceDescription;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

import static com.auspost.aemaacs.program.core.constants.Constants.APPLICATION_X_WWW_FORM_URLENCODED;
import static com.auspost.aemaacs.program.core.constants.Constants.CONTENT_TYPE;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;

/**
 * @author Seeni Rajan
 */
@Slf4j
@Component(service = AbnLookUpService.class)
@ServiceDescription("Abn lookup Service Implementation")
@Designate(ocd = AbnLookUpServiceImpl.Configuration.class)
public class AbnLookUpServiceImpl implements AbnLookUpService {

    private String host;

    private String endpoint;

    private String authKey;

    private String historicalDetails;

    /**
     * OSGi lifecycle method to activate or modify the service configuration.
     * Initializes service properties from the provided configuration.
     *
     * @param configuration the OSGi configuration for ABN Lookup Service
     */
    @Activate
    @Modified
    private void activate(AbnLookUpServiceImpl.Configuration configuration) {
        this.host = configuration.host();
        this.endpoint = configuration.endpoint();
        this.authKey = configuration.authKey();
        this.historicalDetails = configuration.historicalDetails();
    }

    /**
     * Searches for ABN details using the configured endpoint and parameters.
     *
     * @param searchString the ABN or search string to look up
     * @return the response body as a String if the request is successful; otherwise, returns an empty string
     */
    @Override
    public String search(String searchString) {
        try (HttpClient httpClient = HttpClient.newBuilder().build()) {
            HttpRequest httpPost = HttpRequest.newBuilder()
                    .uri(new URI(this.host + this.endpoint))
                    .header(CONTENT_TYPE, APPLICATION_X_WWW_FORM_URLENCODED)
                    .POST(HttpRequest.BodyPublishers.ofString(
                            "searchString=" + URLEncoder.encode(searchString, StandardCharsets.UTF_8) +
                                    "&includeHistoricalDetails=" +
                                    URLEncoder.encode(historicalDetails, StandardCharsets.UTF_8) +
                                    "&authenticationGuid=" + URLEncoder.encode(authKey, StandardCharsets.UTF_8)
                    ))
                    .build();
            return httpClient.send(httpPost, HttpResponse.BodyHandlers.ofString()).body();
        } catch (InterruptedException | URISyntaxException | IOException ex) {
            log.error("Error during ABN lookup request", ex);
        }
        return EMPTY;
    }

    /**
     * OSGI config handler
     *
     */
    @ObjectClassDefinition(name = "ABN Lookup Configuration")
    public @interface Configuration {

        @AttributeDefinition(name = "ABN Lookup Host", description = "ABN Lookup Host")
        String host();

        @AttributeDefinition(name = "Endpoint", description = "Endpoint")
        String endpoint();

        @AttributeDefinition(name = "Authentication key", description = "Authentication key")
        String authKey();

        @AttributeDefinition(name = "Get historical details key", description = "Get historical details key")
        String historicalDetails();
    }

}

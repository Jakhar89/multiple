package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Accordion;
import com.auspost.aemaacs.program.core.pojos.PanelContainerItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import lombok.Getter;
import lombok.experimental.Delegate;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.via.ResourceSuperType;

import java.util.ArrayList;
import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

/**
 * @author Seeni Rajan
 */
@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = Accordion.class,
        resourceType = "auspost-aemaacs-program/components/accordion",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class AccordionModel implements Accordion {

    private final List<PanelContainerItem> accordionItems = new ArrayList<>();

    @Self
    @Delegate
    @Via(type = ResourceSuperType.class)
    private Accordion accordion;

    @SlingObject
    private Resource resource;

    /**
     * Returns the data layer for the accordion component. This method checks if the data layer is enabled for the
     * resource, and if so, sets the accordion items with their respective data layer attributes.
     *
     * @return - A JSON string representing the data layer for the accordion component
     */
    public String getDataLayer() {
        accordion.getChildren().forEach(child -> {
            PanelContainerItem accItem =
                    new PanelContainerItem(child.getId(), child.getTitle(), child.getName(), child.getResource());
            if (DataLayerUtils.isDataLayerEnabled(resource)) {
                DataLayerUtils.setDataLayerForPanelItem(
                        accItem, SITE_INTERACTION, "accordion||" + accordion.getId(),
                        DataLayerUtils.getFormattedDataLayerDescription(child.getTitle())
                );
            }
            accordionItems.add(accItem);
        });
        return EMPTY;
    }

}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.services.AuspostDomainMapperService;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.day.cq.commons.Externalizer;
import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.auspost.aemaacs.program.core.constants.Constants.BANNER_RESOURCE_TYPE;
import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.COMMA;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.EXTENSION_HTML;
import static com.auspost.aemaacs.program.core.constants.Constants.PIPE;
import static com.auspost.aemaacs.program.core.constants.Constants.PN_FILE_REFERENCE;
import static com.auspost.aemaacs.program.core.constants.Constants.SPACE;
import static com.auspost.aemaacs.program.core.constants.Constants.VARIANT;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = MetaDataModel.class,
        resourceType = "auspost-aemaacs-program/components/page",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class MetaDataModel {

    @ScriptVariable
    private Page currentPage;

    @OSGiService
    private Externalizer externalizer;

    @OSGiService
    private AuspostDomainMapperService auspostDomainMapperService;

    @SlingObject
    private ResourceResolver resourceResolver;


    public String getOgTitle() {
        return currentPage.getTitle();
    }

    public String getOgDescription() {
        return currentPage.getDescription();
    }

    /**
     * Retrieves the current page content path for Open Graph (OG) usage.
     *
     * @return current page with publish domain
     */
    public String getOgUrl() {
        return externalizer.externalLink(resourceResolver,
                auspostDomainMapperService.getDomainNameUsingPath(currentPage.getPath()),
                currentPage.getPath() + EXTENSION_HTML);
    }

    /**
     * Retrieves the image path for Open Graph (OG) usage.
     * First attempts to get the image from the banner component; if not found,
     * falls back to the image from page content or page property.
     *
     * @return image path with domain of the current page if found, otherwise null.
     */

    public String getOgImagePath() {
        return getImagePathFromBanner()
                .or(this::getImagePathFromPageProperty)
                .or(this::getImagePathFromPageContent)
                .map(path -> externalizer.externalLink(resourceResolver,
                        auspostDomainMapperService.getDomainNameUsingPath(path), path))
                .orElse(null);
    }

    /**
     * Retrieves the tags associated with the current page.
     *
     * @return formatted string of tags in the format "parentTag:childTag | parentTag:childTag"
     */
    public String getTags() {
        Tag[] tags = currentPage.getTags();
        if (tags.length > 0) {
            return Arrays.stream(tags)
                    .filter(tag -> !tag.isNamespace() && !tag.getParent().isNamespace())
                    .collect(Collectors.groupingBy(
                            tag -> tag.getParent().getName(),
                            Collectors.mapping(Tag::getName, Collectors.toList())
                    ))
                    .entrySet().stream()
                    .map(entry -> entry.getKey() + COLON + String.join(COMMA, entry.getValue()))
                    .collect(Collectors.joining(SPACE + PIPE + SPACE));
        }
        return EMPTY;
    }

    /**
     * Retrieves the image path by  checking the page content.
     *
     * @return imagePath from page content.
     */
    private Optional<String> getImagePathFromPageContent() {
        return DamAssetUtils.getImageFromPageContent(currentPage)
                .map(imageResource -> imageResource.getValueMap().get(PN_FILE_REFERENCE, String.class));
    }

    /**
     * Retrieves the image from the banner component;
     *
     * @return image path from Banner component
     */
    private Optional<String> getImagePathFromBanner() {
        Resource pageResource = Objects.requireNonNull(resourceResolver.getResource(currentPage.getPath()));
        Resource bannerResource = findBannerComponent(pageResource);
        return Optional.ofNullable(bannerResource)
                .map(Resource::getValueMap)
                .map(vm -> vm.get(VARIANT, String.class))
                .map(variant -> bannerResource.getChild(variant + "Image"))
                .flatMap(DamAssetUtils::getImageFromComponent)
                .map(r -> r.getValueMap().get(PN_FILE_REFERENCE, String.class));
    }

    /**
     * Retrieves the image path by checking page property.
     *
     * @return imagePath from page property.
     */
    private Optional<String> getImagePathFromPageProperty() {
        return DamAssetUtils.getImageFromPageProperty(currentPage)
                .map(imageResource -> imageResource.getValueMap().get(PN_FILE_REFERENCE, String.class));
    }

    /**
     * Recursively searches for a banner component within the given resource.
     *
     * @return the banner resource if found, otherwise null
     */
    private Resource findBannerComponent(Resource resource) {
        for (Resource child : resource.getChildren()) {
            if (BANNER_RESOURCE_TYPE.equals(child.getResourceType())) {
                return child;
            }
            Resource nested = findBannerComponent(child);
            if (nested != null) {
                return nested;
            }
        }
        return null;
    }
}

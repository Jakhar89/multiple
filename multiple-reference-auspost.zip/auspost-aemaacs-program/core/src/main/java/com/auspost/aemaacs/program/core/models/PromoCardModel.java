package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.CardItem;
import com.auspost.aemaacs.program.core.pojos.CtaModel;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.DateUtils;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.Date;
import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.DATE_FORMAT;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_IMPRESSION;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = PromoCardModel.class,
        resourceType = "auspost-aemaacs-program/components/promocard",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class PromoCardModel extends CtaModel {

    @Getter
    @ValueMapValue
    private String cardPrice;

    @ValueMapValue
    private Date cardDate;

    @Getter
    @Self
    @Via("resource")
    private CardItem cardItem;

    @Getter
    @ValueMapValue
    private String cardReadTime;


    /**
     * Formats the card date in the specified format.
     *
     * @return formatted date.
     */
    public String getCardDate() {
        return DateUtils.getFormattedDate(cardDate, DATE_FORMAT);
    }


    /**
     * Returns the data layer JSON string for the Card component. If data layer is
     * enabled, it constructs a JSON
     * object with the component ID and event details for each call-to-action (CTA)
     * button.
     *
     * @return A JSON string representing the data layer for the promo card component,
     * or an empty string if data layer is
     * not enabled.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled()) {
            String componentId = getId();
            // Set data layer for primary CTA
            setDataLayerForCta(componentId, getPrimaryCta(), "-primary-cta");
            // Set data layer for secondary CTA
            setDataLayerForCta(componentId, getSecondaryCta(), "-secondary-cta");

            // Build data layer for promo card
            Map<String, Object> promocardMap = DataLayerUtils
                    .createEventMap(SITE_IMPRESSION, "promoCard||view",
                            DataLayerUtils.getFormattedDataLayerDescription(getCardItem().getCardTitle()));
            return DataLayerUtils.mapToJson(componentId, promocardMap);
        }
        return EMPTY;
    }

    /**
     * Sets the data layer for the call to action (CTA) button.
     *
     * @param componentId       - The ID of the component to which the CTA belongs.
     * @param ctaItem           - The ButtonItem representing the CTA button.
     * @param componentIdSuffix - A suffix to append to the component ID for the CTA.
     */
    private void setDataLayerForCta(String componentId, ButtonItem ctaItem, String componentIdSuffix) {
        DataLayerUtils.setDataLayerForLink(ctaItem, componentId + componentIdSuffix, SITE_INTERACTION, "promoCard||cta",
                DataLayerUtils.getFormattedDataLayerDescription(
                        getCardItem().getCardTitle() + COLON + ctaItem.getLabel()));
    }

}

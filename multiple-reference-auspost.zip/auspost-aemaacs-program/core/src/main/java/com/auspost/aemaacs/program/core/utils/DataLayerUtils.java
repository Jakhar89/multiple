package com.auspost.aemaacs.program.core.utils;

import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.CardItem;
import com.auspost.aemaacs.program.core.pojos.EcommHeroCardItem;
import com.auspost.aemaacs.program.core.pojos.LinkItem;
import com.auspost.aemaacs.program.core.pojos.PanelContainerItem;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.HYPHEN;
import static com.auspost.aemaacs.program.core.constants.Constants.CTA_SUFFIX_MAP;
import static com.auspost.aemaacs.program.core.constants.Constants.EVENT;
import static com.auspost.aemaacs.program.core.constants.Constants.EVENT_CATEGORY;
import static com.auspost.aemaacs.program.core.constants.Constants.EVENT_DESCRIPTION;
import static com.auspost.aemaacs.program.core.constants.Constants.SPACE;
import static com.auspost.aemaacs.program.core.constants.Constants.PN_ENABLE_DATA_LAYER;
import static com.auspost.aemaacs.program.core.constants.Constants.COLON;


@Slf4j
public final class DataLayerUtils {

    private static final JsonMapper MAPPER =
            JsonMapper.builder().configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true).build();

    private DataLayerUtils() {
    }

    /**
     * @param componentId  - The componentId of the component for which the data layer map is being transformed
     * @param dataLayerMap - The data layer map to be transformed into a JSON
     * @return - A transformed JSON string containing all the data layer attributes
     */
    public static String mapToJson(String componentId, Map<String, Object> dataLayerMap) {
        try {
            return String.format("{\"%s\":%s}", componentId, MAPPER.writeValueAsString(dataLayerMap));
        } catch (JsonProcessingException e) {
            log.error("Unable to generate dataLayer JSON string", e);
            return EMPTY;
        }
    }

    /**
     * @param resource - The resource to check
     * @return - true if the global setting is enabled and the local setting is either missing or also enabled; false if
     * the global setting is disabled or the local setting is explicitly disabled
     */
    public static boolean isDataLayerEnabled(Resource resource) {
        boolean isGlobalDataLayerEnabled = ComponentUtils.isDataLayerEnabled(resource);
        if (!isGlobalDataLayerEnabled) {
            return false;
        }
        Boolean isLocalDataLayerEnabled = resource.getValueMap().get(PN_ENABLE_DATA_LAYER, Boolean.class);
        return isLocalDataLayerEnabled == null || isLocalDataLayerEnabled;
    }

    /*
     * setDataLayerForLink is a utility method to set the data layer for a LinkItem.
     * @param item - The LinkItem to set the data layer for
     * @param id - The ID to be used in the data layer
     * @param event - The event name to be tracked
     * @param category - The category of the event
     * @param description - A description of the event
     * This method sets the data layer for a LinkItem with the provided ID, event, category, and description.
     * It uses the DataLayerUtils.mapToJson method to create a JSON string from the provided parameters.
     */
    public static void setDataLayerForLink(LinkItem item, String id, String event, String category,
                                           String description) {
        item.setDataLayer(DataLayerUtils.mapToJson(id, DataLayerUtils.createEventMap(event, category, description)));
    }

    /*
     * setDataLayerForLink is a utility method to set the data layer for a CardItem.
     * @param item - The CardItem to set the data layer for
     * @param id - The ID to be used in the data layer
     * @param event - The event name to be tracked
     * @param category - The category of the event
     * @param description - A description of the event
     * This method sets the data layer for a CardItem with the provided ID, event, category, and description.
     * It uses the DataLayerUtils.mapToJson method to create a JSON string from the provided parameters.
     */
    public static void setDataLayerForCard(CardItem item, String id, String event, String category,
                                           String description) {
        item.setDataLayer(DataLayerUtils.mapToJson(id, DataLayerUtils.createEventMap(event, category, description)));
    }

    /**
     * setDataLayerForEcommCard is a utility method to set the data layer for an EcommHeroCardItem.
     *
     * @param item - The EcommHeroCardItem to set the data layer for
     * @param id - The ID to be used in the data layer
     * @param event - The event name to be tracked
     * @param category - The category of the event
     * @param description - A description of the event
     */
    public static void setDataLayerForEcommCard(EcommHeroCardItem item, String id, String event, String category,
                                                String description) {
        item.setDataLayer(DataLayerUtils.mapToJson(id, DataLayerUtils.createEventMap(event, category, description)));
    }

    /**
     * createEventMap is a utility method to create a map for event tracking.
     *
     * @param event       - The event name to be tracked
     * @param category    - The category of the event
     * @param description - A description of the event
     * @return - A map containing event tracking information
     */
    public static Map<String, Object> createEventMap(String event, String category, String description) {
        return new LinkedHashMap<>() {{
            put(EVENT, event);
            put(EVENT_CATEGORY, category);
            put(EVENT_DESCRIPTION, description);
        }};
    }

    /**
     * getFormattedDataLayerDescription is a utility method to format a description for data layer usage.
     *
     * @param description - The description to be formatted
     * @return - A formatted description string with spaces replaced by hyphens and converted to lowercase
     */
    public static String getFormattedDataLayerDescription(String description) {
        return description != null ? description.replaceAll(SPACE, HYPHEN).toLowerCase() : EMPTY;
    }
    /**
     * setDataLayerForPanelItem is a utility method to set the data layer for a PanelContainerItem.
     *
     * @param item            - The PanelContainerItem to set the data layer for
     * @param eventType      - The type of event to be tracked
     * @param eventCategory  - The category of the event
     * @param eventDescription - A description of the event
     */
    public static void setDataLayerForPanelItem(
            PanelContainerItem item, String eventType, String eventCategory, String eventDescription) {
            item.setDataLayer(
                    DataLayerUtils.mapToJson(item.getId(), DataLayerUtils.createEventMap(eventType, eventCategory, eventDescription)));
    }

    /**
     * Sets the data layer for CTA button.
     *
     * @param componentId       - The ID of the component to which the CTA belongs.
     * @param ctaItem           - The ButtonItem representing the CTA button.
     * @param componentIdSuffix - A suffix to append to the component ID for the CTA.
     */

    public static void setDataLayerForCta(String componentId, ButtonItem ctaItem, String componentIdSuffix, String category) {
        DataLayerUtils.setDataLayerForLink(
                ctaItem,
                componentId + componentIdSuffix,
                SITE_INTERACTION,
                category,
                DataLayerUtils.getFormattedDataLayerDescription(
                        StringUtils.defaultIfEmpty(ctaItem.getLabel(), "no-cta")
                )
        );
    }

    /**
     * Builds and sets data layer entries for all CTA (Call To Action) buttons
     * associated with a component.
     *
     * If the CTA list is {@code null} or empty, no processing is performed.
     * If a button type is not present in {@code CTA_SUFFIX_MAP}, no suffix is appended.
     */
    public static String getDataLayerForCTA(String componentId, List<ButtonItem> cta, LinkManager linkManager, String eventName, String calloutType, String heading, boolean callfrom) {
        Optional.ofNullable(cta)
                .ifPresent(list -> list.stream()
                        .filter(Objects::nonNull)
                        .forEach(button -> {
                            LinkUtils.buildLinkItem(linkManager, button);
                            String suffix = CTA_SUFFIX_MAP.getOrDefault(button.getButtonType(), EMPTY);
                            if(!callfrom) {
                                setDataLayerForCta(
                                        componentId,
                                        button,
                                        DataLayerUtils.getFormattedDataLayerDescription(HYPHEN + button.getLabel()) + suffix,
                                        eventName
                                );
                            } else {
                                setDataLayerForCalloutCta(
                                        componentId,
                                        button,
                                        DataLayerUtils.getFormattedDataLayerDescription(HYPHEN + button.getLabel()) + suffix,
                                        eventName,
                                        calloutType,
                                        heading
                                );
                            }
                        })
                );
        return EMPTY;
    }

    /**
     * Sets the data layer for each call out message item for both Primary and Secondary to action (CTA) button.
     *
     * @param componentId       - The ID of the component to which the CTA belongs.
     * @param ctaItem           - The ButtonItem representing the CTA button.
     * @param componentIdSuffix - A suffix to append to the component ID for the CTA.
     */
    private static void setDataLayerForCalloutCta(String componentId, ButtonItem ctaItem, String componentIdSuffix, String eventName, String calloutType, String heading) {
        DataLayerUtils.setDataLayerForLink(ctaItem, componentId + componentIdSuffix, SITE_INTERACTION, eventName,
                DataLayerUtils.getFormattedDataLayerDescription(calloutType + COLON + heading + COLON +
                        StringUtils.defaultIfEmpty(ctaItem.getLabel(), "no-cta")));
    }

}

package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.services.SearchService;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;

/**
 * Sling Model for the Ecommerce Search component.
 * Extends SearchModel to provide site-specific search URLs for the ecommerce site.
 * Includes additional properties for PDF and home URL links used by the frontend.
 */
@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = EcommSearchModel.class,
        resourceType = {"auspost-aemaacs-program/components/ecommsearch"},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)

public class EcommSearchModel extends SearchModel {

    private SearchService activeService;

    @ValueMapValue
    private String pdfUrl;

    @ValueMapValue
    private String homeUrl;


    @PostConstruct
    protected void init() {
        activeService = getSearchServiceRegistry().getAllSearchServices().stream()
                .filter(s -> s.getSiteId().equals("ecommerce"))
                .findFirst()
                .orElse(null);
    }

    /**
     * Gets the advanced autocomplete URL for the ecommerce site.
     * Returns an empty string if no ecommerce search service is available.
     *
     * @return the advanced autocomplete URL for the ecommerce site
     */
    public String getAdvancedAutoCompleteUrl() {
        return activeService != null
                ? activeService.buildAdvancedAutoCompleteUrl()
                : Constants.EMPTY;
    }

    /**
     * Gets the search URL for the ecommerce site.
     * Returns an empty string if no ecommerce search service is available.
     *
     * @return the search URL for the ecommerce site
     */
    public String getSearchUrl() {
        return activeService != null
                ? activeService.buildSearchUrl()
                : Constants.EMPTY;
    }

    /**
     * Gets the answer URL for the ecommerce site.
     * Returns an empty string if no ecommerce search service is available.
     *
     * @return the answer URL for the ecommerce site
     */
    public String getAnswerUrl() {
        return activeService != null
                ? activeService.buildAnswerUrl()
                : Constants.EMPTY;
    }

}

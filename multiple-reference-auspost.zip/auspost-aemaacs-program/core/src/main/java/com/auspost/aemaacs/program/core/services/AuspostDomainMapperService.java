package com.auspost.aemaacs.program.core.services;

/**
 * @author Seeni Rajan
 */
public interface AuspostDomainMapperService {
    String getDomainNameUsingPath(String resourcePath);
}

package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.ComponentContext;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(alphabetic = true)
public class CtaModel extends BaseComponentModel {

    @ChildResource
    private ButtonItem primaryCta;

    @ChildResource
    private ButtonItem secondaryCta;

    /**
     * Build primary cta via link utils.
     *
     * @return ButtonItem primary cta.
     */
    public ButtonItem getPrimaryCta() {
        if (primaryCta != null) {
            primaryCta.setId(getId() + "-primary-cta");
            return LinkUtils.buildButtonItem(linkManager, primaryCta);
        }
        return null;
    }

    /**
     * Build secondary cta via link utils.
     *
     * @return ButtonItem secondary cta.
     */
    public ButtonItem getSecondaryCta() {
        if (secondaryCta != null) {
            secondaryCta.setId(getId() + "-secondary-cta");
            return LinkUtils.buildButtonItem(linkManager, secondaryCta);
        }
        return null;
    }
}

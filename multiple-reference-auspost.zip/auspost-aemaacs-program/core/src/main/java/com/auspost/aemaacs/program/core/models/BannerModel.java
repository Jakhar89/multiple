package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.CategoryItem;
import com.auspost.aemaacs.program.core.pojos.CtaModel;
import com.auspost.aemaacs.program.core.pojos.LinkItem;
import com.auspost.aemaacs.program.core.utils.DamAssetUtils;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.auspost.aemaacs.program.core.utils.DateUtils;
import com.auspost.aemaacs.program.core.utils.LinkUtils;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.Date;
import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.COLON;
import static com.auspost.aemaacs.program.core.constants.Constants.DATE_FORMAT;
import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.HYPHEN;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_IMPRESSION;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

/**
 * @author Seeni Rajan
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = BannerModel.class,
    resourceType = {
        "auspost-aemaacs-program/components/banner",
        "auspost-aemaacs-program/components/ecommherobanner"
    },
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class BannerModel extends CtaModel {

    @Getter
    @ValueMapValue
    private String variant;

    @Getter
    @ValueMapValue
    private String backgroundColour;

    @Getter
    @ValueMapValue
    private String title;

    @Getter
    @ValueMapValue
    private String description;

    @Getter
    @ValueMapValue
    private String issueDatePrefix;

    @ValueMapValue
    private Date issueDate;

    @Getter
    @ValueMapValue
    private String readTime;

    @ChildResource
    private Resource heroImage;

    @ChildResource
    private Resource teaserImage;

    @ChildResource
    private Resource promoImage;

    @ChildResource
    private Resource promoFeatureImage;

    @ChildResource
    private Resource productImage;

    @Getter
    @ChildResource
    private CategoryItem primaryCategory;

    @Getter
    @ChildResource
    private CategoryItem secondaryCategory;

    @ChildResource
    private LinkItem backToLink;

    /**
     * Build backToLink via link utils.
     *
     * @return ButtonItem backToLink.
     */
    public LinkItem getBackToLink() {
        if (backToLink != null) {
            backToLink.setId(getId() + "-back-to-link");
            return LinkUtils.buildLinkItem(linkManager, backToLink);
        }
        return null;
    }

    public String getIssueDate() {
        return DateUtils.getFormattedDate(issueDate, DATE_FORMAT);
    }

    /**
     * Returns the hero image resource for the banner
     *
     * @return The hero image resource.
     */
    public Resource getHeroImage() {
        return DamAssetUtils.getImageFromComponent(heroImage).orElse(null);
    }

    /**
     * Returns the teaser image resource for the banner.
     *
     * @return The teaser image resource.
     */
    public Resource getTeaserImage() {
        return DamAssetUtils.getImageFromComponent(teaserImage).orElse(null);
    }

    /**
     * Returns the promo image resource for the banner
     *
     * @return The promo image resource.
     */
    public Resource getPromoImage() {
        return DamAssetUtils.getImageFromComponent(promoImage).orElse(null);
    }

    /**
     * Returns the promo feature image resource for the banner.
     *
     * @return The promo feature image resource.
     */
    public Resource getPromoFeatureImage() {
        return DamAssetUtils.getImageFromComponent(promoFeatureImage).orElse(null);
    }

    /**
     * Returns the product image resource for the banner
     *
     * @return The product image resource.
     */
    public Resource getProductImage() {
        return DamAssetUtils.getImageFromComponent(productImage).orElse(null);
    }

    /**
     * Returns the data layer JSON string for the banner component. If data layer is
     * enabled, it constructs a JSON
     * object with the component ID and event details for each call-to-action (CTA)
     * button.
     *
     * @return A JSON string representing the data layer for the banner component,
     * or an empty string if data layer is
     * not enabled.
     */
    public String getDataLayer() {
        if (isDataLayerEnabled()) {
            String componentId = getId();
            // Set data layer for primary CTA
            setDataLayerForCta(title, componentId, getPrimaryCta(), "-primary-cta");
            // Set data layer for secondary CTA
            setDataLayerForCta(title, componentId, getSecondaryCta(), "-secondary-cta");

            Map<String, Object> bannerMap = DataLayerUtils
                    .createEventMap(SITE_IMPRESSION, "banner",
                            getBannerDataLayerDescription());
            return DataLayerUtils.mapToJson(componentId, bannerMap);
        }
        return EMPTY;
    }

    /**
     * Constructs a description for the data layer event related to the banner.
     * The description is created by appending the category texts and the title of
     * the banner,
     * replacing spaces with hyphens and converting it to lowercase.
     *
     * @return a formatted description string for the banner data layer event
     */
    private String getBannerDataLayerDescription() {
        return DataLayerUtils.getFormattedDataLayerDescription(getCategoryText() + getTitle());
    }

    /**
     * Constructs a StringBuilder containing the text from category one and category
     * two.
     * If either category is not null and has text, it appends the text followed by
     * a colon.
     * This method is used to create a part of the data layer description for the
     * banner.
     *
     * @return a StringBuilder containing the category texts
     */
    private StringBuilder getCategoryText() {
        StringBuilder categoryTextSb = new StringBuilder();
        validateCategoryAndAppendDescription(primaryCategory, categoryTextSb);
        validateCategoryAndAppendDescription(secondaryCategory, categoryTextSb);
        return categoryTextSb;
    }

    /**
     * Validates if the given category is not null and has non-empty text.
     * If valid, appends the category text followed by a colon to the provided
     * StringBuilder.
     *
     * @param category       - The CategoryItem to validate and append.
     * @param categoryTextSb - The StringBuilder to append the category text to.
     */
    private void validateCategoryAndAppendDescription(CategoryItem category, StringBuilder categoryTextSb) {
        if (category != null && StringUtils.isNotEmpty(category.getText())) {
            categoryTextSb.append(category.getText()).append(COLON);
        }
    }

    /**
     * Generates a description for the data layer event related to a call-to-action
     * (CTA) button in the banner.
     * The description is constructed using the component ID, the label of the CTA
     * button, and a suffix.
     * The resulting string is formatted as
     * "componentId-componentIdSuffix:ctaLabel",
     * where spaces in the label are replaced with hyphens and the entire string is
     * converted to lowercase.
     *
     * @param componentTitle    - The title of the banner component.
     * @param ctaItem           - The ButtonItem representing the CTA button.
     * @param componentIdSuffix - A suffix to append to the component ID for the
     *                          CTA.
     * @return a formatted description string for the CTA data layer event
     */
    private String getBannerCtaDataLayerDescription(String componentTitle, String componentIdSuffix,
                                                    ButtonItem ctaItem) {
        return DataLayerUtils.getFormattedDataLayerDescription(
                getCategoryText() + componentTitle + componentIdSuffix + COLON + ctaItem.getLabel());
    }

    /**
     * Sets the data layer for the call to action (CTA) button.
     *
     * @param componentTitle    - The title of the banner component.
     * @param componentId       - The ID of the component to which the CTA belongs.
     * @param ctaItem           - The ButtonItem representing the CTA button.
     * @param componentIdSuffix - A suffix to append to the component ID for the
     *                          CTA.
     */
    private void setDataLayerForCta(String componentTitle, String componentId, ButtonItem ctaItem,
                                    String componentIdSuffix) {
        if (ctaItem != null) {
            DataLayerUtils.setDataLayerForLink(ctaItem,
                    DataLayerUtils.getFormattedDataLayerDescription(
                            componentId + componentIdSuffix + HYPHEN + ctaItem.getLabel()),
                    SITE_INTERACTION, "banner||cta",
                    getBannerCtaDataLayerDescription(componentTitle, componentIdSuffix, ctaItem));
        }
    }
}

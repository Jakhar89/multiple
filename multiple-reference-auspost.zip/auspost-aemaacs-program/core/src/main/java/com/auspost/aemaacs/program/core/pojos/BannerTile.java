package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.export.json.ExporterConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Named;

import static com.auspost.aemaacs.program.core.constants.Constants.NN_FEATURED_IMAGE;

@Getter
@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BannerTile {

    @SlingObject
    private Resource resource;

    @ValueMapValue
    private String tileTitle;

    @ValueMapValue
    private String ariaLabel;

    @ValueMapValue
    private String tileDescription;

    @ChildResource
    @Named(NN_FEATURED_IMAGE)
    private Resource tileImage;

    @ChildResource
    private CategoryItem tileCategory;

    @ChildResource
    private LinkItem tileLink;

    /**
     * Get the mapped URL of the tile link.
     *
     * @return Mapped URL of the tile link.
     */
    public String getTileUrl() {
        return resource.getResourceResolver().map(tileLink.getURL());
    }
}

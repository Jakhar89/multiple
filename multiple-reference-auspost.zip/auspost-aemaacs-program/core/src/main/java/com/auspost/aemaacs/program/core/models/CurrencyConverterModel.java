package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.pojos.MostPopularCurrency;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.ComponentContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;

@Slf4j
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = CurrencyConverterModel.class,
        resourceType = "auspost-aemaacs-program/components/currencyconverter",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class CurrencyConverterModel {

    public static final String PID_CONFIG = "com.auspost.aemaacs.program.core.models.CurrencyConverterModel";

    public static final String AUTH_KEY = "authKey";

    public static final String API_URL = "apiUrl";

    @ScriptVariable
    protected ComponentContext componentContext;

    @Self
    private SlingHttpServletRequest request;

    @SlingObject
    private Resource resource;

    @ScriptVariable
    private Page currentPage;

    @OSGiService
    private ConfigurationAdmin configAdmin;

    @Getter
    @ValueMapValue
    private String currencyCodeHeading;

    @Getter
    @ValueMapValue
    private String currencyCodeSubHeading;

    @Getter
    @ValueMapValue
    private String submissionAction;

    @Getter
    @ChildResource
    private List<MostPopularCurrency> mostPopularCurrency;

    @Getter
    @ValueMapValue
    private String ccWidgetBarTitle;

    @Getter
    @ValueMapValue
    private String ccWidgetButtonTitle;

    @Getter
    @ValueMapValue
    private String ccWidgetBarLabel;

    @Getter
    @ValueMapValue
    private String ccWidgetBarPlaceholderText;

    @Getter
    @ValueMapValue
    private String ccAlertMessage;

    @Getter
    @ValueMapValue
    private String ccLabelToCurrency;

    @Getter
    @ValueMapValue
    private String ccLabelDestinationCurrency;

    @Getter
    @ValueMapValue
    private String ccLabelPopularCurrencies;

    @Getter
    @ValueMapValue
    private String ccLabelAtoZindex;

    @Getter
    @ValueMapValue
    private String ccLabelCurrencyConverter;

    @Getter
    @ValueMapValue
    private String ccLabelAvailableProduct;

    @Getter
    @ValueMapValue
    private String ccLabelRate;

    @Getter
    @ValueMapValue
    private String ccLabelRateInAud;

    @Getter
    @ValueMapValue
    private String ccLabelAmount;

    @Getter
    @ValueMapValue
    private String ccLabelHowToBuy;

    private String authKey;

    private String apiUrl;

    /**
     * Retrieves the authentication key from the configuration.
     *
     * @return The authentication key, or an empty string if retrieval fails.
     */
    public String getAuthKey() {
        try {
            return getValueFromConfig(AUTH_KEY);
        } catch (IOException e) {
            log.error("Failed to retrieve authKey from config: {}", PID_CONFIG, e);
            return EMPTY;
        }
    }

    /**
     * Retrieves the API URL from the configuration.
     *
     * @return The API URL, or an empty string if retrieval fails.
     */
    public String getApiUrl() {
        try {
            return getValueFromConfig(API_URL);
        } catch (IOException e) {
            log.error("Failed to retrieve apiUrl from config: {}", PID_CONFIG, e);
            return EMPTY;
        }
    }

    /**
     * Retrieves a configuration value based on the provided key.
     *
     * @param key The configuration key.
     * @return The corresponding value as a string, or an empty string if not found.
     * @throws IOException If an error occurs while accessing the configuration.
     */
    private String getValueFromConfig(String key) throws IOException {
        Configuration config = configAdmin.getConfiguration(PID_CONFIG);
        Object value = config.getProperties().get(key);
        return value != null ? value.toString() : EMPTY;
    }

    /**
     * Generates a JSON representation of the component's data for Data Layer.
     *
     * @return A JSON string containing component data if the Data Layer is enabled, otherwise an empty string.
     */
    public String getData() {
        try {
            if (ComponentUtils.isDataLayerEnabled(this.resource)) {
                Map<String, Object> data = new LinkedHashMap<>();
                String componentId = ComponentUtils.getId(this.resource, this.currentPage, this.componentContext);
                data.put("@type", this.resource.getResourceType());
                data.put("currencyCodeHeading", this.getCurrencyCodeHeading());
                data.put("currencyCodeSubHeading", this.getCurrencyCodeSubHeading());
                data.put("submissionAction", this.getSubmissionAction());
                data.put("mostPopularCurrency", this.getMostPopularCurrency());
                data.put("ccWidgetBarTitle", this.getCcWidgetBarTitle());
                data.put("ccWidgetButtonTitle", this.getCcWidgetButtonTitle());
                data.put("ccWidgetBarLabel", this.getCcWidgetBarLabel());
                data.put("ccWidgetBarPlaceholderText", this.getCcWidgetBarPlaceholderText());
                data.put("ccAlertMessage", this.getCcAlertMessage());
                data.put("ccLabelToCurrency", this.getCcLabelToCurrency());
                data.put("ccLabelDestinationCurrency", this.getCcLabelDestinationCurrency());
                data.put("ccLabelPopularCurrencies", this.getCcLabelPopularCurrencies());
                data.put("ccLabelAtoZindex", this.getCcLabelAtoZindex());
                data.put("ccLabelCurrencyConverter", this.getCcLabelCurrencyConverter());
                data.put("ccLabelAvailableProduct", this.getCcLabelAvailableProduct());
                data.put("ccLabelRate", this.getCcLabelRate());
                data.put("ccLabelRateInAud", this.getCcLabelRateInAud());
                data.put("ccLabelAmount", this.getCcLabelAmount());
                data.put("ccLabelHowToBuy", this.getCcLabelHowToBuy());
                data.put("authKey", this.getAuthKey());
                data.put("apiUrl", this.getApiUrl());
                return String.format("{\"%s\":%s}", componentId, new ObjectMapper().writeValueAsString(data));
            }
        } catch (JsonProcessingException e) {
            log.error("Failed to write JSON as String for Data Layer", e);
        }
        return EMPTY;
    }
}

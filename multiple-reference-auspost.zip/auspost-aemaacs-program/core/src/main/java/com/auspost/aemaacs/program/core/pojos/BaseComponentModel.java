package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.adobe.cq.wcm.core.components.util.ComponentUtils;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.ComponentContext;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

public abstract class BaseComponentModel {

    @ScriptVariable
    protected ComponentContext componentContext;

    @SlingObject
    protected Resource resource;

    @ScriptVariable
    protected Page currentPage;

    @Self
    protected LinkManager linkManager;

    /**
     * Returns the ID of the component.
     */
    public String getId() {
        return ComponentUtils.getId(resource, currentPage, componentContext);
    }

    /**
     * Checks whether data layer is enabled for this component.
     */
    public boolean isDataLayerEnabled() {
        return DataLayerUtils.isDataLayerEnabled(resource);
    }
}

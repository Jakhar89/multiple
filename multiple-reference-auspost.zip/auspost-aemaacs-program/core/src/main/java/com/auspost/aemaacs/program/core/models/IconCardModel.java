package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.export.json.ExporterConstants;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.pojos.BaseComponentModel;
import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import lombok.Getter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.List;
import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;

@Getter
@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = IconCardModel.class,
        resourceType = "auspost-aemaacs-program/components/iconcard",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@Exporter(
        name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION
)
public class IconCardModel extends BaseComponentModel {

    @ValueMapValue
    private String icon;

    @ValueMapValue
    private String iconStyle;

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String description;

    @ChildResource
    private List<ButtonItem> cta;

    /**
     * Returns the data layer JSON string for the Icon Card component. It constructs a JSON
     * object containing the component ID and event details. Data layer for each Icon Card Link CTAs are also included with their respective IDs.
     *
     * @return A JSON string representing the data layer for the Icon Card component, including
     * data layer entries for each Icon Card Link CTAs with their respective IDs.
     */
    public String getDataLayer() {
        DataLayerUtils.getDataLayerForCTA(getId(), cta, linkManager, "cards||cta", Constants.EMPTY, Constants.EMPTY, false);
        Map<String, Object> iconCardMap = DataLayerUtils
                .createEventMap(SITE_INTERACTION, "cards||li",
                        DataLayerUtils.getFormattedDataLayerDescription(title));
        return DataLayerUtils.mapToJson(getId(), iconCardMap);
    }

}

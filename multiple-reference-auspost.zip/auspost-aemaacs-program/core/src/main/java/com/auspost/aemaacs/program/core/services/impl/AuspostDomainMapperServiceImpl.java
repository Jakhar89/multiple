package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.services.AuspostDomainMapperService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.propertytypes.ServiceDescription;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Seeni Rajan
 */
@Slf4j
@Component(service = AuspostDomainMapperService.class)
@ServiceDescription("Auspost Domain Mapper Service")
@Designate(ocd = AuspostDomainMapperServiceImpl.Configuration.class)
public class AuspostDomainMapperServiceImpl implements AuspostDomainMapperService {

    private final Map<String, List<String>> domainMappings = new HashMap<>();

    private final ObjectMapper mapper = new ObjectMapper();

    /**
     * Activates or modifies the service with the provided configuration.
     *
     * @param configuration the configuration containing domain mappings
     * @throws JsonProcessingException if there is an error processing JSON
     */
    @Activate
    @Modified
    private void activate(AuspostDomainMapperServiceImpl.Configuration configuration) throws JsonProcessingException {
        for (String domainConfig : configuration.domains()) {
            DomainConfig domain = mapper.readValue(domainConfig, DomainConfig.class);
            domainMappings.put(domain.name, domain.paths);
        }
    }

    /**
     * Gets the domain name based on the provided location path.
     *
     * @param location the location path to check
     * @return the corresponding domain name, or "publish" if no match is found
     */
    @Override
    public String getDomainNameUsingPath(String location) {
        for (Map.Entry<String, List<String>> entry : domainMappings.entrySet()) {
            for (String path : entry.getValue()) {
                if (location.startsWith(path)) {
                    return entry.getKey();
                }
            }
        }
        return "publish";
    }

    /**
     * OSGi configuration interface for domain mappings.
     */
    @ObjectClassDefinition(
            name = "Auspost Domain Mapper Service Configuration",
            description = "Configuration for domain mappings"
    )
    @interface Configuration {
        @AttributeDefinition(
                name = "Domain Mappings",
                description = "List of domain configurations in JSON format"
        )
        String[] domains();
    }

    /**
     * Domain configuration class representing a domain and its associated paths.
     * Used for deserializing JSON configuration.
     *
     */
    @Getter
    @Setter
    public static class DomainConfig {
        private String name;
        private List<String> paths;
    }

}

package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.services.AuspostDomainMapperService;
import com.auspost.aemaacs.program.core.services.SearchService;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import java.util.List;

@Component(service = SearchServiceRegistry.class)
public class SearchServiceRegistry {
    @Reference
    private List<SearchService> searchServices;

    @Reference
    private AuspostDomainMapperService domainMapperService;

    /**
     * Returns all registered {@link SearchService} instances.
     *
     * @return list of available search services
     */
    public List<SearchService> getAllSearchServices() {
        return searchServices;
    }

    /**
     * This method is used get search service configuration for given site ID.
     * @param siteId the site identifier used to select the appropriate SearchService
     * @return the matching SearchService
     */
    public SearchService getBySiteId(String siteId) {
        return searchServices.stream()
                .filter(s -> s.getSiteId().equals(siteId))
                .findFirst()
                .orElse(null);
    }

    /**
     * This method is used to resolves the site ID associated with the given content resource path.
     * @param resourcePath the content path from which to determine the site ID
     * @return the resolved site ID
     */
    public String resolveSiteId(String resourcePath) {
        if (StringUtils.isBlank(resourcePath)) {
            return Constants.EMPTY;
        }
        return domainMapperService.getDomainNameUsingPath(resourcePath);
    }
}

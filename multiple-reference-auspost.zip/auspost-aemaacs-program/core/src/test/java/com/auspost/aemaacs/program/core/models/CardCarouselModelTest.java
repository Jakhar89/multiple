package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
public class CardCarouselModelTest {
    private final AemContext ctx = AppAemContext.newAemContext();

    private CardCarouselModel model;

    @BeforeEach
    void setUp() {
        Map<String, Object>
                props = Map.of("sling:resourceSuperType", "core/wcm/components/container/v1/container");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/cardcarousel", props);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/iconcard");
        ctx.load().json("/models/cardcarousel/component.json", "/content/home/jcr:content/cardcarousel");
    }


    @Test
    void testCardCarouselWithCtaAndIcon() {
        ctx.currentResource("/content/home/jcr:content/cardcarousel/with_icon_card");
        model = ctx.request().adaptTo(CardCarouselModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Card Carousel Title", model.getTitle());
            assertNotNull(model.getCta());
            assertEquals("Card Carousel CTA Label",model.getCta().getLabel());
            assertEquals("/content/auspost",model.getCta().getURL());
            assertEquals("_self",model.getCta().getLinkTarget());
            assertNotNull(model.getDataLayer());
            assertEquals("{\"card-carousel-container-de98fae62b-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"card-carousel||cta\",\"eventDescription\":\"card-carousel-title:card-carousel-cta-label\"}}",model.getCta().getDataLayer());
        });
    }

    @Test
    void testCardCarouselWithOutItems() {
        ctx.currentResource("/content/home/jcr:content/cardcarousel/with_empty_items");
        model = ctx.request().adaptTo(CardCarouselModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Card Carousel Title", model.getTitle());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testCardCarouselWithOutCtaAndIcon() {
        ctx.currentResource("/content/home/jcr:content/cardcarousel/with_out_cta");
        model = ctx.request().adaptTo(CardCarouselModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Card Carousel Title", model.getTitle());
            assertNull(model.getCta());
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testIfDataLayerStringIsEmptyWhenDataLayerIsDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        Map<String, Object>
                props = Map.of("sling:resourceSuperType", "core/wcm/components/container/v1/container");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/cardcarousel", props);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/iconcard");
        ctx.load().json("/models/cardcarousel/component.json", "/content/home/jcr:content/cardcarousel");
        ctx.currentResource("/content/home/jcr:content/cardcarousel/with_icon_card");
        model = ctx.request().adaptTo(CardCarouselModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Card Carousel Title", model.getTitle());
            assertNotNull(model.getCta());
            assertEquals("Card Carousel CTA Label",model.getCta().getLabel());
            assertEquals("/content/auspost",model.getCta().getURL());
            assertEquals("_self",model.getCta().getLinkTarget());
            assertEquals(EMPTY, model.getDataLayer());
        });
        }
}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.IOException;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNull;


@ExtendWith(AemContextExtension.class)
class DownloadModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private DownloadModel model;

    @BeforeEach
    void setup() {
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/download/v2/download");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/download", props);
        ctx.load().json("/models/download/component.json", "/content/home/jcr:content/download");
    }

    @Test
    void testIfDownloadItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.load().json("/models/download/assets.json", "/content/dam/collectables/stamp-bulletin");
        ctx.currentResource("/content/home/jcr:content/download/download-mock");
        model = ctx.request().adaptTo(DownloadModel.class);
        assertAll(
                () -> assertNotNull(model),
                () -> assertEquals("primary", model.getCtaType()),
                () -> assertEquals("false", model.getAssetSize()),
                () -> assertEquals("false", model.getAssetType()),
                () -> assertNull(model.getSize()),
                () -> assertNull(model.getExtension())
        );
    }

    @Test
    void testDownloadModelWhenDataLayerEnabled() throws IOException {
        ctx.load().json("/models/download/assets.json", "/content/dam/collectables/stamp-bulletin");
        ctx.currentResource("/content/home/jcr:content/download/download-mock");
        model = ctx.request().adaptTo(DownloadModel.class);
        String expectedJson = AppAemContext.getExpectedDataLayerJson("/models/download/datalayer.json");
        assertAll(
                () -> assertNotNull(model),
                () -> assertNotNull(model.getDataLayer()),
                () -> assertEquals(expectedJson, model.getDataLayer())
        );
    }

    @Test
    void testIfDownloadItemsAreInstantiatedAsExpectedWhenSizeandTypeShow() {
        ctx.load().json("/models/download/assets.json", "/content/dam/collectables/stamp-bulletin");
        ctx.currentResource("/content/home/jcr:content/download/downloadWithAsset");
        model = ctx.request().adaptTo(DownloadModel.class);
        assertAll(
                () -> assertNotNull(model),
                () -> assertEquals("primary", model.getCtaType()),
                () -> assertEquals("true", model.getAssetSize()),
                () -> assertEquals("true", model.getAssetType())
        );
    }
}

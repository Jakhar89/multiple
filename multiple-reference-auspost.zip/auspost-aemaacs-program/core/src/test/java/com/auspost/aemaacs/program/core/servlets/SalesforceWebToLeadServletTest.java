package com.auspost.aemaacs.program.core.servlets;

import com.auspost.aemaacs.program.core.services.SalesforceWebToLeadClient;
import com.auspost.aemaacs.program.core.services.impl.SalesforceWebToLeadClientImpl;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.request.RequestDispatcherOptions;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.testing.mock.sling.servlet.MockRequestDispatcherFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Map;
import java.util.Objects;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

@Slf4j
@ExtendWith(AemContextExtension.class)
class SalesforceWebToLeadServletTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private final RequestDispatcher mockRequestDispatcher = mock(RequestDispatcher.class);

    private SalesforceWebToLeadServlet servlet;

    private WireMockServer mockAPI;

    @BeforeEach
    void setUp() throws IOException {
        mockAPI = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        mockAPI.start();
        Dictionary<String, String> props = new Hashtable<>() {{
            put("host", "http://localhost:" + mockAPI.port());
            put("authEndpoint", "/salesforce/v2/auth");
            put("leadEndpoint", "/salesforce/v2/lead");
            put("campaignEndpoint", "/salesforce/v2/campaign");
            put("clientId", "randomwrongclientid");
            put("clientSecret", "randomwrongclientsecret");
            put("username", "random_un");
            put("password", "random_pd");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.SalesforceWebToLeadClientImpl")
                .update(props);
        ctx.registerInjectActivateService(new SalesforceWebToLeadClientImpl());
        servlet = ctx.registerInjectActivateService(new SalesforceWebToLeadServlet());
        // setup a mock RequestDispatcher to mimic forwards
        ctx.request().setRequestDispatcherFactory(new MockRequestDispatcherFactory() {
            @Override
            public RequestDispatcher getRequestDispatcher(String path, RequestDispatcherOptions options) {
                return mockRequestDispatcher;
            }

            @Override
            public RequestDispatcher getRequestDispatcher(Resource resource, RequestDispatcherOptions options) {
                return mockRequestDispatcher;
            }
        });
        // initiate content stubs
        ctx.create().page("/content/page");
        ctx.load().json("/models/formcontainer/component.json", "/content/page/jcr:content/container");
        ctx.currentResource("/content/page/jcr:content/container");
    }

    @AfterEach
    void tearDown() {
        mockAPI.stop();
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadOnlySubmissionIsMadeWithValidParams() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "desc_1-_-Description", "desciption1",
                "desc_2-_-Description", "desciption2",
                "desc_3-_-Description", "desciption3",
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "suburbandpostcode", "Melbourne VIC 3000",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(302, ctx.response().getStatus());
            assertTrue(servlet.isLeadSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadOnlySubmissionIsMadeWithValidParamsWithEmptyAddressAndEmptyPostCodeSuburb() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "address", "",
                "suburbandpostcode", "",
                "address-1", "address-1",
                "address-2", "address-2",
                "address-3", "address-3",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(302, ctx.response().getStatus());
            assertTrue(servlet.isLeadSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadOnlySubmissionIsMadeWithValidParamsWithoutAddress() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(302, ctx.response().getStatus());
            assertTrue(servlet.isLeadSuccess());
        });
    }

    @Test
    void testIfResponseIsSendWithoutLastNameWhenLeadOnlySubmissionIsMadeWithValidParams() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "LeadSource", "test lead source",
                "Status", "In progress"
        ));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(200, ctx.response().getStatus());
            assertFalse(servlet.isLeadSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadAndCampaignSubmissionIsMadeWithValidParams() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        // stub API response for campaign submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "campaignId", "somerandomcampaignid",
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(302, ctx.response().getStatus());
            assertTrue(servlet.isLeadSuccess());
            assertTrue(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadOnlySubmissionFailsWithValidParams() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "address", "Adamstown Public School, 1a Bryant Street, ADAMSTOWN  NSW 2289",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(200, ctx.response().getStatus());
            assertFalse(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadSubmissionFailsInALeadAndCampaignSubmissionWithValidParams() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "campaignId", "somerandomcampaignid",
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(200, ctx.response().getStatus());
            assertFalse(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenCampaignSubmissionFailsInALeadAndCampaignSubmissionWithValidParams() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        // stub API response for campaign submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "campaignId", "somerandomcampaignid",
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(302, ctx.response().getStatus());
            assertTrue(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadOnlySubmissionIsMadeWithInvalidParams() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(200, ctx.response().getStatus());
            assertFalse(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadAndCampaignSubmissionIsMadeWithInvalidParamsForJustCampaign() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        // stub API response for campaign submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "campaignId", "somerandomcampaignid"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(302, ctx.response().getStatus());
            assertTrue(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadAndCampaignSubmissionIsMadeWithValidParamsButRequestDispatcherIsNull() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub API response for campaign submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "campaignId", "somerandomcampaignid",
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "Status", "In progress"));
        // ensure request dispatcher is null to mimic the scenario
        ctx.request().setRequestDispatcherFactory(new MockRequestDispatcherFactory() {
            @Override
            public RequestDispatcher getRequestDispatcher(String path, RequestDispatcherOptions options) {
                return null;
            }

            @Override
            public RequestDispatcher getRequestDispatcher(Resource resource, RequestDispatcherOptions options) {
                return null;
            }
        });
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(200, ctx.response().getStatus());
            assertFalse(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadAndCampaignSubmissionIsMadeWithValidParamsButAnInterruptedExceptionOccurs()
            throws IOException, InterruptedException {
        AemContext ctx = new AemContext();
        // mock SalesforceWebToLeadClient to mimic InterruptedException scenario
        SalesforceWebToLeadClient mockSalesforceWebToLeadClient = mock(SalesforceWebToLeadClientImpl.class);
        ctx.registerService(SalesforceWebToLeadClient.class, mockSalesforceWebToLeadClient);
        doThrow(new InterruptedException()).when(mockSalesforceWebToLeadClient).submit(anyString(), anyString());
        servlet = ctx.registerInjectActivateService(new SalesforceWebToLeadServlet());
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub API response for campaign submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "campaignId", "somerandomcampaignid",
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(200, ctx.response().getStatus());
            assertFalse(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadAndCampaignSubmissionIsMadeWithValidParamsButAServletExceptionOccurs()
            throws ServletException, IOException {
        // mimic the scenario of ServletException when forward is made via RequestDispatcher
        doThrow(new ServletException()).when(mockRequestDispatcher).forward(any(), any());
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub API response for campaign submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": false}"))
        );
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "campaignId", "somerandomcampaignid",
                "address", "Adamstown Public School, New Address, 1a Bryant Street, ADAMSTOWN  NSW 2289",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(200, ctx.response().getStatus());
            assertFalse(servlet.isLeadSuccess());
            assertFalse(servlet.isCampaignSuccess());
        });
    }

    @Test
    void testIfResponseIsAsExpectedWhenLeadOnlySubmissionIsMadeWithMultipleKeyValues() {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("{\"success\": true, \"id\": \"somerandomleadid\"}"))
        );
        String[] description = {"Receipt number 1234", "Age over 18"};
        // stub valid request
        ctx.request().setParameterMap(Map.of(
                ":formstart", "/content/page/jcr:content/container/whenallparametersconfigured",
                "FirstName", "Test",
                "LastName", "User",
                "Phone", "0123456789",
                "Description", description,
                "address", "6 Sweet St, Rouse Hill NSW 2155",
                "Status", "In progress"));
        servlet.doPost(ctx.request(), ctx.response());
        // do the assertions
        assertAll(() -> {
            assertEquals(302, ctx.response().getStatus());
            assertTrue(servlet.isLeadSuccess());
        });
    }
}

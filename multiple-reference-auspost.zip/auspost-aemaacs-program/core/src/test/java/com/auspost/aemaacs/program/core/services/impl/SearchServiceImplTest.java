package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.services.SearchService;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import wiremock.com.google.common.collect.ImmutableMap;

import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@ExtendWith(AemContextExtension.class)
class SearchServiceImplTest {

    private final AemContext ctx = new AemContext();

    private SearchServiceImpl auspostService;
    private Map<String, SearchService> servicesMap;
    private SearchServiceRegistry serviceRegistry;

    @BeforeEach
    void setUp() {
        auspostService = ctx.registerInjectActivateService(
                new SearchServiceImpl(),
                ImmutableMap.<String, Object>builder()
                        .put("siteId", "auspost")
                        .put("projectId", "1059627761126")
                        .put("dataStoreId", "auspost-vtx-seo_1743636714358")
                        .put("host", "https://digitalapi2-ptest.npe.auspost.com.au")
                        .put("apiVersion", "/website-search/v1beta/projects/")
                        .put("apiVersionAutoComplete", "/website-search/v1/projects/")
                        .put("collection", "/locations/global/collections/default_collection/engines/")
                        .put("autocompleteCollection", "/locations/global/dataStores/")
                        .put("completionConfig", "/completionConfig")
                        .put("vertexEngineID", "vertex-ai_1744093322600")
                        .put("searchEndpoint", "/servingConfigs/default_search:search")
                        .put("autocompleteEndpoint", ":completeQuery")
                        .put("answerEndpoint", "/servingConfigs/default_search:answer")
                        .build()
        );

        // Map to hold multiple services
        servicesMap = new HashMap<>();
        servicesMap.put("auspost", auspostService);

        // Fake registry
        serviceRegistry = new SearchServiceRegistry() {
            @Override
            public String resolveSiteId(String resourcePath) {
                if (resourcePath == null || resourcePath.isEmpty()) return "";
                if (resourcePath.startsWith("/content/auspost")) return "auspost";
                if (resourcePath.startsWith("/content/collectables")) return "collectables";
                return "publish";
            }

            @Override
            public SearchService getBySiteId(String siteId) {
                return servicesMap.get(siteId);
            }
        };
    }

    @Test
    void testGetSiteId() {
        assertEquals("auspost", auspostService.getSiteId());
    }

    @Test
    void testResolveSiteId() {
        assertEquals("auspost", serviceRegistry.resolveSiteId("/content/auspost/au/en"));
        assertEquals("collectables", serviceRegistry.resolveSiteId("/content/collectables/pages"));
        assertEquals("publish", serviceRegistry.resolveSiteId("/content/random"));
    }

    @Test
    void testResolveSiteId_NullOrEmptyPath() {
        assertEquals(Constants.EMPTY, serviceRegistry.resolveSiteId(null));
        assertEquals(Constants.EMPTY, serviceRegistry.resolveSiteId(Constants.EMPTY));
    }

    @Test
    void testUrlBuilding() {
        assertAll(
                () -> assertEquals(
                        "https://digitalapi2-ptest.npe.auspost.com.au/website-search/v1beta/projects/1059627761126/locations/global/collections/default_collection/engines/vertex-ai_1744093322600/servingConfigs/default_search:search",
                        auspostService.buildSearchUrl()
                ),
                () -> assertEquals(
                        "https://digitalapi2-ptest.npe.auspost.com.au/website-search/v1/projects/1059627761126/locations/global/dataStores/auspost-vtx-seo_1743636714358:completeQuery",
                        auspostService.buildBasicAutoCompleteUrl()
                ),
                () -> assertEquals(
                        "https://digitalapi2-ptest.npe.auspost.com.au/website-search/v1beta/projects/1059627761126/locations/global/collections/default_collection/engines/vertex-ai_1744093322600/servingConfigs/default_search:answer",
                        auspostService.buildAnswerUrl()
                )
        );
    }
}


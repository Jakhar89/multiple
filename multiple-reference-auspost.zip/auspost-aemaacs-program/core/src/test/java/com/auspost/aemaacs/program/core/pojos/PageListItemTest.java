package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class PageListItemTest {
    private final AemContext ctx = AppAemContext.newAemContext();
    private PageListItem listItem;
    private LinkManager linkManager;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/pagelisting/component.json", "/content/page/jcr:content/root");
    }

    @Test
    void testResourceWithPageResource() {
        ctx.currentResource("/content/page/jcr:content/root/page1");
        linkManager = ctx.request().adaptTo(LinkManager.class);
        listItem = new PageListItem("Label", "/content/page", "_self", linkManager,
                ctx.currentResource(), true);
        listItem.setLink(Objects.requireNonNull(linkManager).get(listItem.getLinkURL()).build());
        assertAll(() -> {
            assertNotNull(listItem);
            assertEquals("Label", listItem.getLabel());
            assertEquals("/content/page", listItem.getLinkURL());
            assertEquals("_self", listItem.getLinkTarget());
            assertEquals("Page1 description from page properties", listItem.getPageDescription());
            assertEquals("27 August 2025", listItem.getLastModified());
            assertEquals("/content/dam/auspost/new.png",
                    listItem.getPageImage().getValueMap().get("fileReference"));
            assertNull(listItem.getBannerImage());
        });
    }

    @Test
    void testResourceWithBannerResource() {
        ctx.currentResource("/content/page/jcr:content/root/page1/jcr:content/root/container/container/banner");
        linkManager = ctx.request().adaptTo(LinkManager.class);
        listItem = new PageListItem("Label", "/content/page", "_self", linkManager,
                ctx.currentResource(), false);
        listItem.setLink(Objects.requireNonNull(linkManager).get(listItem.getLinkURL()).build());
        assertAll(() -> {
            assertNotNull(listItem);
            assertEquals("Label", listItem.getLabel());
            assertEquals("/content/page", listItem.getLinkURL());
            assertEquals("_self", listItem.getLinkTarget());
            assertEquals(EMPTY, listItem.getPageDescription());
            assertNull(listItem.getPageImage());
            assertEquals(EMPTY, listItem.getLastModified());
            assertEquals("/content/dam/auspost/new.png",
                    listItem.getBannerImage().getValueMap().get("fileReference"));
            assertEquals("Page1 description from banner", listItem.getBannerDescription());
        });
    }

    @Test
    void testResourceWithBannerResourceWithoutDescription() {
        ctx.currentResource("/content/page/jcr:content/root/page4/jcr:content/root/container/container/banner");
        linkManager = ctx.request().adaptTo(LinkManager.class);
        listItem = new PageListItem("Label", "/content/page", "_self", linkManager,
                ctx.currentResource(), true);
        listItem.setLink(Objects.requireNonNull(linkManager).get(listItem.getLinkURL()).build());
        assertAll(() -> {
            assertEquals(EMPTY, listItem.getBannerDescription());
        });
    }


    @Test
    void testWithNullResources() {
        linkManager = ctx.request().adaptTo(LinkManager.class);
        listItem = new PageListItem("Label", "/content/page", "_self", linkManager,
                null, false);
        listItem.setLink(Objects.requireNonNull(linkManager).get(listItem.getLinkURL()).build());
        assertAll(() -> {
            assertNotNull(listItem);
            assertEquals("Label", listItem.getLabel());
            assertEquals("/content/page", listItem.getLinkURL());
            assertEquals("_self", listItem.getLinkTarget());
            assertEquals(EMPTY, listItem.getPageDescription());
            assertEquals(EMPTY, listItem.getLastModified());
            assertNull(listItem.getBannerImage());
            assertNull(listItem.getPageImage());
            assertEquals(EMPTY, listItem.getBannerDescription());
        });
    }
}

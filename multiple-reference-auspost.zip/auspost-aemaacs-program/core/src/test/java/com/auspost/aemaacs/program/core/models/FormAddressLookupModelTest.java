package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.services.AddressLookupService;
import com.auspost.aemaacs.program.core.services.impl.AddressLookupServiceImpl;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.services.impl.AddressLookupServiceImplTest.GET_DOMESTIC_ADDRESS_SUGGESTIONS_BODY;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
public class FormAddressLookupModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private FormAddressLookupModel model;

    private static WireMockServer wireMockServer;

    private static AddressLookupService addressLookupService;

    private ObjectMapper MAPPER = new ObjectMapper();

    @BeforeAll

    static void setupBeforeAll() {
        wireMockServer = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        wireMockServer.start();
    }

    @BeforeEach
    void setUp() throws IOException {
        Dictionary<String, String> config = new Hashtable<>() {{
            put("apiHost", "http://localhost:" + wireMockServer.port() + "/api");
            put("tokenHost", "http://localhost:" + wireMockServer.port() + "/token");
            put("clientID", "clientId123");
            put("clientSecret", "clientSecret123");
            put("audience", "audience");
            put("addressSuggestionEndpoint", "/address");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AddressLookupServiceImpl")
                .update(config);
        ctx.create().page("/content/page");
        ctx.load().json("/models/formaddresslookup/component.json", "/content/page/jcr:content/content");

        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"mocked_token\"}")));

        wireMockServer.stubFor(get(urlPathEqualTo("/api/address")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody(GET_DOMESTIC_ADDRESS_SUGGESTIONS_BODY)));


    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpected() {
        ctx.registerInjectActivateService(new AddressLookupServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/address");
        model = ctx.request().adaptTo(FormAddressLookupModel.class);
        ctx.request().setQueryString("address=23 Maywood Road");

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Address Name", model.getName());
            assertEquals("Address Title", model.getTitle());
            assertEquals("Address Name", model.getName());
            assertNotNull(model.getId());
            assertEquals("Required Message", model.getRequiredMessage());
            assertEquals("Help Message", model.getHelpMessage());
            assertEquals("/content/page/_jcr_content/content/address.model.json", model.getResourcePath());
            JsonNode expected = MAPPER.readTree(GET_DOMESTIC_ADDRESS_SUGGESTIONS_BODY);
            JsonNode actual = MAPPER.readTree(model.getAddressSuggestionList().toString());
            assertEquals(expected, actual);
        });
    }


    @Test
    void testAllComponentsValuesAreInjectingAsExpectedWithoutAddressParameter() {
        ctx.registerInjectActivateService(new AddressLookupServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/address");
        model = ctx.request().adaptTo(FormAddressLookupModel.class);

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Address Name", model.getName());
            assertEquals("Address Title", model.getTitle());
            assertEquals("Address Name", model.getName());
            assertNotNull(model.getId());
            assertEquals("Required Message", model.getRequiredMessage());
            assertEquals("Help Message", model.getHelpMessage());
            assertEquals("/content/page/_jcr_content/content/address.model.json", model.getResourcePath());
            assertEquals("{\"error\":\"No search text provided\"}", model.getAddressSuggestionList().toString());
        });
    }

    @Test
    void testGetAddressSuggestionListHandlesJsonProcessingException() {
        ctx.registerInjectActivateService(new AddressLookupServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/address");
        model = ctx.request().adaptTo(FormAddressLookupModel.class);
        ctx.request().setQueryString("address=480 Swan Street");

        wireMockServer.stubFor(get(urlPathEqualTo("/api/address")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {
                                    total: "2",
                                    "entries": 5
                                }""")));

        assertEquals("{\"error\":\"Service Error\"}", model.getAddressSuggestionList().toString());
    }

    @AfterAll
    static void tearDown() {
        wireMockServer.stop();
    }

}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import junit.framework.Assert;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@ExtendWith(AemContextExtension.class)
class MarketingBlockModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private MarketingBlockModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/marketingblock/component.json", "/content/page/jcr:content/marketingblock");

    }

    @Test
    void testIfAllMarketingBlockItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/marketingblock/marketing-block-all");
        model = ctx.request().adaptTo(MarketingBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("123", model.getId());
            assertEquals("Marketing Block Title", model.getTitle());
            assertEquals("Marketing Block Description", model.getDescription());

            List<ButtonItem> ctas = model.getCta();
            Assert.assertNotNull(ctas);
            Assert.assertEquals(1, ctas.size());
            ButtonItem primaryCta = ctas.get(0);
            assertEquals("Primary CTA Label", primaryCta.getLabel());
            assertEquals("/content/collectables/au/en/test/key", primaryCta.getLinkURL());
            assertEquals("_self", primaryCta.getLinkTarget());
            assertEquals("primaryCta", primaryCta.getButtonType());
            assertEquals("arrow-right-thin", primaryCta.getIconRight());

            List<IconItem> logos = model.getMarketingBlockLogo();
            assertNotNull(logos);
            assertEquals(1, logos.size());

            IconItem iconItem = model.getQrCode();
            assertNotNull(iconItem);
            assertEquals("https://auspost.app.link/iD1oITgykEb", model.getAppStoreLink());
            assertEquals("https://auspost.app.link/F2Qr3k7lgAb", model.getGooglePlayLink());
            assertEquals("/content/dam/collectables/stamp-landscape.png", iconItem.getIconReference());
            assertEquals("/content/collectables/au/en/test/qrpage", iconItem.getLinkURL());
            assertEquals("Scan the QR code or tap the buttons below to download the AusPost app.", model.getQrCodeBlockTitle());
        });
    }
    @Test
    void testIfAllMarketingBlockItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "marketingblock", "marketingblock", "some marketingblock items");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(MarketingBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getTitle());
        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenMarketingBlockItemsAreInstantiatedAsExpected() {
        ctx.currentResource("/content/page/jcr:content/marketingblock/marketing-block-all");
        model = ctx.request().adaptTo(MarketingBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            List<ButtonItem> ctas = model.getCta();
            Assert.assertNotNull(ctas);
            Assert.assertEquals(1, ctas.size());
            ButtonItem primaryCta = ctas.get(0);
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/marketingblock/datalayer.json"),
                    primaryCta.getDataLayer());
            assertEquals(
                    "{\"123-primary-cta-label-primary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"marketingBlock||main-cta\",\"eventDescription\":\"primary-cta-label\"}}",
                    primaryCta.getDataLayer());
        });
    }
    @Test
    void testGetDataLayerReturnsEmptyWhenCtaIsNull() {
        ctx.currentResource("/content/page/jcr:content/marketingblock/marketing-block-null-cta");
        model = ctx.request().adaptTo(MarketingBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getCta());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
    @Test
    void testGetDataLayerReturnsEmptyWhenCtaIsEmpty() {
        ctx.currentResource("/content/page/jcr:content/marketingblock/marketing-block-empty-cta");
        model = ctx.request().adaptTo(MarketingBlockModel.class);

        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getCta());
            assertTrue(model.getCta().isEmpty());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import junit.framework.Assert;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.List;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class IconCardModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private IconCardModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/iconcard/component.json", "/content/page/jcr:content/iconCard");
    }

    @Test
    void testIfAllIconCardItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/iconCard");
        model = ctx.request().adaptTo(IconCardModel.class);

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("123", model.getId());
            assertEquals("Icon Card Title", model.getTitle());
            assertEquals("Icon Card Description", model.getDescription());

            List<ButtonItem> iconCardCtas = model.getCta();
            Assert.assertNotNull(iconCardCtas);
            Assert.assertEquals(1, iconCardCtas.size());
            ButtonItem iconCardCta = iconCardCtas.getFirst();

            assertEquals("Link1", iconCardCta.getLabel());
            assertEquals("/content/collectables/au/text1", iconCardCta.getLinkURL());
            assertEquals("_self", iconCardCta.getLinkTarget());
        });
    }

    @Test
    void testIfAllIconCardItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "iconcard", "iconcard", "some iconcard link items");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(IconCardModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getTitle());
        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenIconCardItemsAreInstantiatedAsExpected() {
        ctx.currentResource("/content/page/jcr:content/iconCard");
        model = ctx.request().adaptTo(IconCardModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("{\"123\":{\"event\":\"site_interaction\",\"eventCategory\":\"cards||li\",\"eventDescription\":\"icon-card-title\"}}", model.getDataLayer());
            List<ButtonItem> iconCardCtas = model.getCta();
            Assert.assertNotNull(iconCardCtas);
            Assert.assertEquals(1, iconCardCtas.size());
            ButtonItem iconCardCta = iconCardCtas.getFirst();
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/iconcard/datalayer.json"),
                    iconCardCta.getDataLayer());
            assertEquals("{\"123-link1-tertiary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"cards||cta\",\"eventDescription\":\"link1\"}}",
                    iconCardCta.getDataLayer());
        });
    }
}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.foundation.forms.FormStructureHelper;
import com.day.cq.wcm.foundation.forms.FormStructureHelperFactory;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

@ExtendWith(AemContextExtension.class)
class FormContainerModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private final FormStructureHelper formStructureHelper = mock(FormStructureHelper.class);

    private FormContainerModel model;

    @BeforeEach
    void setUp() {
        // register the FormStructureHelperFactory to help with instantiation of formStructureHelper in core container
        ctx.registerService(FormStructureHelperFactory.class, resource -> formStructureHelper);
        // create and load stubs
        Map<String, Object> props = Map.of(
                "sling:resourceSuperType", "core/wcm/components/form/container/v2/container");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/form/container", props);
        Page page = ctx.create().page("/content/home");
        ctx.currentPage(page);
        ctx.load().json("/models/formcontainer/component.json", "/content/home/jcr:content/container");
    }


    @Test
    void testIfFormContainerItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/home/jcr:content/container/whenallparametersconfigured");
        model = ctx.request().adaptTo(FormContainerModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Form Title", model.getFormTitle());
            assertEquals("Campaign_Id", model.getCampaignId());
            assertEquals("AP Integration", model.getSalesforceUser());
            assertEquals("Auspost website", model.getLeadSource());
            assertEquals("In progress", model.getFormStatus());
            assertEquals("Error Message", model.getErrorMessage());
            assertEquals("id_1", model.getContainer().getId());
            assertEquals("Name 1", model.getHiddenFields().getFirst().getName());
            assertEquals("Value 1", model.getHiddenFields().getFirst().getValue());
        });
    }
}

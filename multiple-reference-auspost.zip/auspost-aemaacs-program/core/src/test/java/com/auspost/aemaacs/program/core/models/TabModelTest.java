package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class TabModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private TabModel model;

    @BeforeEach
    void setUp() {
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/tabs/v1/tabs");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/tabs", props);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/text");
        ctx.load().json("/models/tabs/component.json", "/content/home/jcr:content/tabs");
    }

    @Test
    void testIfTabItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndEnableDataLayerIsFalse() {
        ctx.currentResource("/content/home/jcr:content/tabs/withDisabledDataLayer");
        model = ctx.request().adaptTo(TabModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals(1, model.getTabItems().size());
            assertNull(model.getTabItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testIfTabItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndEnableDataLayerIsTrue() {
        ctx.currentResource("/content/home/jcr:content/tabs/withEnabledDataLayer");
        model = ctx.request().adaptTo(TabModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals(1, model.getTabItems().size());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/tabs/datalayer.json"),
                    model.getTabItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testIfTabItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndEnableDataLayerIsTrueButDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/tabs/v1/tabs");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/tabs", props);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/text");
        ctx.load().json("/models/tabs/component.json", "/content/home/jcr:content/tabs");
        ctx.currentResource("/content/home/jcr:content/tabs/withEnabledDataLayer");
        model = ctx.request().adaptTo(TabModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testIfTabItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndEnableDataLayerIsFalseAndDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/tabs/v1/tabs");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/tabs", props);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/text");
        ctx.load().json("/models/tabs/component.json", "/content/home/jcr:content/tabs");
        ctx.currentResource("/content/home/jcr:content/tabs/withDisabledDataLayer");
        model = ctx.request().adaptTo(TabModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
}

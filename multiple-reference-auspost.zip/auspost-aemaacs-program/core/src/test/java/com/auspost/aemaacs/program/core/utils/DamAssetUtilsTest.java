package com.auspost.aemaacs.program.core.utils;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;
import java.util.Optional;

/**
 * @author Sathish Balan
 */
@ExtendWith({AemContextExtension.class})
class DamAssetUtilsTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    @Test
    void testIfANonEmptyOptionalIsReturnedForAComponentWithAValidImageResourceUnderneath() {
        // create stubs
        Resource componentResource = ctx.create().resource("/content/componentResource");
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/image"
        );
        Resource imageResource = ctx.create().resource(componentResource, "cq:featuredimage", props);
        // do the assertion
        Assertions.assertTrue(DamAssetUtils.getImageFromComponent(componentResource).isPresent());
    }

    @Test
    void testIfAnEmptyOptionalIsReturnedForAComponentWithNoImageResourceUnderneath() {
        // create stubs
        Resource componentResource = ctx.create().resource("/content/componentResource");
        // do the assertion
        Assertions.assertFalse(DamAssetUtils.getImageFromComponent(componentResource).isPresent());
    }

    @Test
    void testIfANonEmptyOptionalIsReturnedForAPageWithAValidImageBeingPresentViaPageProperty() {
        // create stubs
        Page page = ctx.create().page("/content/page");
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/image"
        );
        Resource imageResource = ctx.create().resource(page, "cq:featuredimage", props);
        // do the assertion
        Assertions.assertTrue(DamAssetUtils.getImageFromPageProperty(page).isPresent());
    }

    @Test
    void testIfAnEmptyOptionalIsReturnedForAPageWithNoImageBeingPresentViaPageProperty() {
        // create stubs
        Page page = ctx.create().page("/content/page");
        // do the assertion
        Assertions.assertFalse(DamAssetUtils.getImageFromPageProperty(page).isPresent());
    }

    @Test
    void testIfANonEmptyOptionalIsReturnedForAPageWithAValidImageBeingPresentInItsContentTree() {
        // create stubs
        Page page = ctx.create().page("/content/page");
        Resource root = ctx.create().resource(page, "root");
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/image"
        );
        Resource imageResource = ctx.create().resource(root, "cq:featuredimage", props);
        // do the assertion
        Assertions.assertTrue(DamAssetUtils.getImageFromPageContent(page).isPresent());
    }

    @Test
    void testIfAnEmptyOptionalIsReturnedForAPageWithNoImageBeingPresentInItsContentTree() {
        // create stubs
        Page page = ctx.create().page("/content/page");
        Resource root = ctx.create().resource(page, "root");
        // do the assertion
        Assertions.assertFalse(DamAssetUtils.getImageFromPageContent(page).isPresent());
    }

    @Test
    void testIfTheImageFromContentTreeIsReturnedForAPageWithImagesOnBothPagePropertyAndItsContentTree() {
        // create stubs
        Page page = ctx.create().page("/content/page");
        Resource root = ctx.create().resource(page, "root");
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/image"
        );
        Resource pagePropertyImage = ctx.create().resource(page, "cq:featuredimage", props);
        Resource contentTreeImage = ctx.create().resource(root, "cq:featuredimage", props);
        // do the assertion
        Optional<Resource> imageResource = DamAssetUtils.getImageFromPageContentOrElsePageProperty(page);
        Assertions.assertAll(() -> {
            Assertions.assertTrue(imageResource.isPresent());
            Assertions.assertEquals(contentTreeImage.getPath(), imageResource.get().getPath());
        });
    }

    @Test
    void testIfTheImageFromPagePropertyIsReturnedForAPageWithNoImagesOnItsContentTree() {
        // create stubs
        Page page = ctx.create().page("/content/page");
        Resource root = ctx.create().resource(page, "root");
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/image"
        );
        Resource pagePropertyImage = ctx.create().resource(page, "cq:featuredimage", props);
        // do the assertion
        Optional<Resource> imageResource = DamAssetUtils.getImageFromPageContentOrElsePageProperty(page);
        Assertions.assertAll(() -> {
            Assertions.assertTrue(imageResource.isPresent());
            Assertions.assertEquals(pagePropertyImage.getPath(), imageResource.get().getPath());
        });
    }

    @Test
    void testIfAnOptionalEmptyIsReturnedForAPageWithNoValidImagesAnywhere() {
        // create stubs
        Page page = ctx.create().page("/content/page");
        Resource root = ctx.create().resource(page, "root");
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/text"
        );
        Resource pagePropertyImage = ctx.create().resource(page, "cq:featuredimage", props);
        // do the assertion
        Assertions.assertFalse(DamAssetUtils.getImageFromPageContentOrElsePageProperty(page).isPresent());
    }

    @Test
    void testIfAnImageIsConsideredValidWhenItHasAValidResourceTypeAndFileReference() {
        // create stubs
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/image"
        );
        Resource imageResource = ctx.create().resource("/content/cq:featuredimage", props);
        // do the assertion
        Assertions.assertTrue(DamAssetUtils.isValidImage(imageResource));
    }

    @Test
    void testIfAnImageIsConsideredInvalidWhenItHasAnInvalidResourceTypeAndFileReference() {
        // create stubs
        Map<String, Object> props = Map.of(
                "fileReference", "/content/dam/image.jpg",
                "sling:resourceType", "auspost-aemaacs-program/components/text"
        );
        Resource imageResource = ctx.create().resource("/content/cq:featuredimage", props);
        // do the assertion
        Assertions.assertFalse(DamAssetUtils.isValidImage(imageResource));
    }

    @Test
    void testIfAnImageIsConsideredInvalidWhenItHasAValidResourceTypeWithoutFileReference() {
        // create stubs
        Map<String, Object> props = Map.of(
                "sling:resourceType", "auspost-aemaacs-program/components/image"
        );
        Resource imageResource = ctx.create().resource("/content/cq:featuredimage", props);
        // do the assertion
        Assertions.assertFalse(DamAssetUtils.isValidImage(imageResource));
    }

    @Test
    void testIfAnImageIsConsideredInvalidWhenItHasAnInvalidResourceTypeWithoutFileReference() {
        // create stubs
        Map<String, Object> props = Map.of(
                "sling:resourceType", "auspost-aemaacs-program/components/text"
        );
        Resource imageResource = ctx.create().resource("/content/cq:featuredimage", props);
        // do the assertion
        Assertions.assertFalse(DamAssetUtils.isValidImage(imageResource));
    }
}

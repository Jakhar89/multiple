package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.CalloutMessage;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.IOException;
import java.util.List;
import java.util.function.Function;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;


/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class CalloutModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private CalloutModel model;

    @BeforeEach
    void setUp() {
       ctx.create().page("/content/page");
       ctx.load().json("/models/callout/component.json", "/content/page/jcr:content/callout");
       ctx.load().json("/models/banner/assets.json", "/content/dam/collectables/stamp-bulletin");
       ctx.currentResource("/content/page/jcr:content/callout" + "/withEnabledDataLayer");
       model = ctx.request().adaptTo(CalloutModel.class);
    }

    @Test
    void testIfAllCalloutItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test Callout Heading", model.getCalloutHeading());
            assertEquals("info", model.getIconType());
            List<CalloutMessage> items = model.getCalloutMessages();
            assertNotNull(items);
            assertEquals(1, items.size());

            CalloutMessage item = items.getFirst();
            List<ButtonItem> ctas = item.getCta();
            assertNotNull(ctas);
            assertEquals(3, ctas.size());
            ButtonItem primaryCta = ctas.get(0);
            ButtonItem secondaryCta = ctas.get(1);
            ButtonItem tertiaryCta = ctas.get(2);

            // Primary CTA
            assertEquals("Primary CTA Label", primaryCta.getLabel());
            assertEquals("/content/auspost", primaryCta.getLinkURL());
            assertEquals("_blank", primaryCta.getLinkTarget());
            assertEquals("primaryCta", primaryCta.getButtonType());
            assertEquals("bold-right-arrow.svg", primaryCta.getIconRight());

            // Secondary CTA
            assertEquals("Secondary CTA Label", secondaryCta.getLabel());
            assertEquals("/content/dam/collectables/stamp-bulletin/stamp-bulletin-1.pdf",
                    secondaryCta.getLinkURL());
            assertEquals("_self", secondaryCta.getLinkTarget());
            assertEquals("secondary", secondaryCta.getButtonType());
            assertEquals("new-window.svg", secondaryCta.getIconRight());

            //Tertiary CTA
            assertEquals("Tertiary CTA Label", tertiaryCta.getLabel());
            assertEquals("/content/dam/collectables/stamp-bulletin/stamp-bulletin-1.pdf",
                    tertiaryCta.getLinkURL());
            assertEquals("_self", tertiaryCta.getLinkTarget());
            assertEquals("tertiary", tertiaryCta.getButtonType());
            assertEquals("new-window.svg", tertiaryCta.getIconRight());
        });
   }

    @Test
    void testIfDataLayerIsPopulatedWhenDataLayerConfigIsEnabled() throws IOException {

        assertNotNull(model);
        assertEquals(
                AppAemContext.getExpectedDataLayerJson("/models/callout/datalayer.json"),
                model.getDataLayer()
        );

        CalloutMessage item = model.getCalloutMessages().getFirst();
        assertNotNull(item);

        List<ButtonItem> ctas = item.getCta();
        assertNotNull(ctas);
        assertEquals(3, ctas.size());

        ButtonItem primaryCta = ctas.stream()
                .filter(cta -> "primaryCta".equals(cta.getButtonType()))
                .findFirst()
                .orElse(null);

        ButtonItem secondaryCta = ctas.stream()
                .filter(cta -> "secondary".equals(cta.getButtonType()))
                .findFirst()
                .orElse(null);

        ButtonItem tertiary = ctas.stream()
                .filter(cta -> "tertiary".equals(cta.getButtonType()))
                .findFirst()
                .orElse(null);

        assertEquals(
                "{\"callout-30488acd34-primary-cta-label-primary-cta\":"
                        + "{\"event\":\"site_interaction\","
                        + "\"eventCategory\":\"callout||cta\","
                        + "\"eventDescription\":\"info:test-callout-heading:primary-cta-label\"}}",
                primaryCta.getDataLayer()
        );

        assertEquals(
                "{\"callout-30488acd34-secondary-cta-label-secondary-cta\":"
                        + "{\"event\":\"site_interaction\","
                        + "\"eventCategory\":\"callout||cta\","
                        + "\"eventDescription\":\"info:test-callout-heading:secondary-cta-label\"}}",
                secondaryCta.getDataLayer()
        );

        assertEquals(
                "{\"callout-30488acd34-tertiary-cta-label-tertiary-cta\":"
                        + "{\"event\":\"site_interaction\","
                        + "\"eventCategory\":\"callout||cta\","
                        + "\"eventDescription\":\"info:test-callout-heading:tertiary-cta-label\"}}",
                tertiary.getDataLayer()
        );
    }

    @Test
    void testGetDataWhenDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        ctx.create().page("/content/page");
        ctx.load().json("/models/callout/component.json",
                "/content/page/jcr:content/callout");
        ctx.currentResource("/content/page/jcr:content/callout");
        model = ctx.request().adaptTo(CalloutModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testGetDataWhenComponentDataLayerDisabled() {
        ctx.currentResource("/content/page/jcr:content/callout/withDisabledDataLayer");
        model = ctx.request().adaptTo(CalloutModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
    @Test
    void testIfAllCalloutItemsAreInstantiatedAsExpectedWhenOnlySomeValuesAreInjected() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "callout",
                "calloutHeading", "some heading");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(CalloutModel.class);

        assertAll(
                () -> assertNotNull(model),
                () -> assertEquals("some heading", model.getCalloutHeading()),
                () -> assertNull(model.getIconType()),
                () -> {
                    List<CalloutMessage> items = model.getCalloutMessages();
                    assertTrue(items == null || items.isEmpty(),
                            "calloutMessage should be null or empty when not authored");
                }
        );
    }

    @Test
    void testGetDataLayerCoversCalloutMessageLoop() throws Exception {

        ctx.currentResource("/content/page/jcr:content/callout");
        CalloutModel model = ctx.request().adaptTo(CalloutModel.class);
        assertNotNull(model);
        ctx.registerAdapter(Resource.class, Boolean.class, (Function<Resource, Boolean>) res -> true);
        String dl = model.getDataLayer();
        assertNotNull(dl);
        assertFalse(dl.isEmpty());
    }
}

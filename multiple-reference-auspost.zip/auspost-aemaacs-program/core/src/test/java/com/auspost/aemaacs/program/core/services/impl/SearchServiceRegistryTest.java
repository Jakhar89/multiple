package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.services.AuspostDomainMapperService;
import com.auspost.aemaacs.program.core.services.SearchService;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.lang.reflect.Field;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;


@ExtendWith(AemContextExtension.class)
class SearchServiceRegistryTest {

    private SearchServiceRegistry registry;

    @BeforeEach
    void setUp() throws Exception {
        SearchService siteAService = new SearchService() {
            @Override
            public String getSiteId() {
                return "siteA";
            }

            public String buildSearchUrl() {
                return "searchUrlA";
            }

            @Override
            public String buildBasicAutoCompleteUrl() {
                return "basicAutocompleteUrlA";
            }

            @Override
            public String buildAnswerUrl() {
                return "answerUrlA";
            }

            @Override
            public String buildAdvancedAutoCompleteUrl() {
                return "advanceAutocompleteUrlA";
            }
        };

        SearchService siteBService = new SearchService() {
            @Override
            public String getSiteId() {
                return "siteB";
            }

            @Override
            public String buildSearchUrl() {
                return "searchUrlB";
            }

            @Override
            public String buildBasicAutoCompleteUrl() {
                return "basicAutocompleteUrlB";
            }

            @Override
            public String buildAnswerUrl() {
                return "answerUrlB";
            }

            @Override
            public String buildAdvancedAutoCompleteUrl() {
                return "advanceAutocompleteUrlB";
            }
        };

        AuspostDomainMapperService domainMapperService = new AuspostDomainMapperService() {
            @Override
            public String getDomainNameUsingPath(String path) {
                if ("/content/siteA/page".equals(path)) return "siteA";
                if ("/content/siteB/page".equals(path)) return "siteB";
                return Constants.EMPTY;
            }
        };

        // Create registry instance
        registry = new SearchServiceRegistry();

        // Inject private 'searchServices' field
        Field searchServicesField = SearchServiceRegistry.class.getDeclaredField("searchServices");
        searchServicesField.setAccessible(true);
        searchServicesField.set(registry, List.of(siteAService, siteBService));

        // Inject private 'domainMapperService' field
        Field domainMapperField = SearchServiceRegistry.class.getDeclaredField("domainMapperService");
        domainMapperField.setAccessible(true);
        domainMapperField.set(registry, domainMapperService);
    }

    @Test
    void testGetBySiteId_Found() {
        assertEquals("siteA", registry.getBySiteId("siteA").getSiteId());
        assertEquals("siteB", registry.getBySiteId("siteB").getSiteId());
    }

    @Test
    void testGetAllSearchServices() {
        List<SearchService> services = registry.getAllSearchServices();
        assertEquals(2, services.size());
        assertTrue(services.stream().anyMatch(service -> "siteA".equals(service.getSiteId())));
        assertTrue(services.stream().anyMatch(service -> "siteB".equals(service.getSiteId())));
    }

    @Test
    void testResolveSiteId() {
        assertEquals("siteA", registry.resolveSiteId("/content/siteA/page"));
        assertEquals("siteB", registry.resolveSiteId("/content/siteB/page"));
        assertEquals(Constants.EMPTY, registry.resolveSiteId(null));
        assertEquals(Constants.EMPTY, registry.resolveSiteId(Constants.EMPTY));
        assertEquals(Constants.EMPTY, registry.resolveSiteId("/content/unknown/page"));
    }
}
package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.services.SearchService;
import com.auspost.aemaacs.program.core.services.impl.SearchServiceImpl;
import com.auspost.aemaacs.program.core.services.impl.SearchServiceRegistry;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import wiremock.com.google.common.collect.ImmutableMap;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(AemContextExtension.class)
class EcommSearchModelTest {

    private final AemContext context = new AemContext();

    @BeforeEach
    void setUp() {
        context.create().page("/content/auspost/au/en/test");
        context.load().json("/models/ecommsearch/component.json",
            "/content/auspost/au/en/test/jcr:content/root");
    }

    @Test
    void testAutocompleteUrlWhenEcommerceServiceAvailable() {
        SearchService ecommerce = context.registerInjectActivateService(
            new SearchServiceImpl(),
            ImmutableMap.<String, Object>builder()
                .put("siteId", "ecommerce")
                .put("dataStoreId", "test-datastore")
                .put("host", "https://example.test")
                .put("apiVersion", "/test-api/v1alpha/projects/")
                .put("apiVersionAutoComplete", "/website-search/v1/projects/")
                .put("projectId", "test-project")
                .put("collection", "/locations/global/collections/default_collection/engines/")
                .put("autocompleteCollection", "/locations/global/dataStores/")
                .put("completionConfig", "/completionConfig")
                .put("vertexEngineID", "test-engine")
                .put("searchEndpoint", "/servingConfigs/default_search:search")
                .put("autocompleteEndpoint", ":completeQuery")
                .put("answerEndpoint", "/servingConfigs/default_search:answer")
                .build()
        );

        SearchServiceRegistry registry = new SearchServiceRegistry() {
            @Override
            public List<SearchService> getAllSearchServices() {
                return Arrays.asList(ecommerce);
            }
        };
        context.registerService(SearchServiceRegistry.class, registry);

        context.currentResource("/content/auspost/au/en/test/jcr:content/root/container/container/ecommsearch");
        context.request().setResource(context.currentResource());
        EcommSearchModel model = context.request().adaptTo(EcommSearchModel.class);

        assertAll(
                () -> assertNotNull(model),
                () -> assertEquals(
                        "https://example.test/website-search/v1/projects/test-project/locations/global/collections/default_collection/engines/test-engine/completionConfig:completeQuery",
                        model.getAdvancedAutoCompleteUrl()
                ),
                () -> assertEquals(
                        "https://example.test/test-api/v1alpha/projects/test-project/locations/global/collections/default_collection/engines/test-engine/servingConfigs/default_search:search",
                        model.getSearchUrl()
                ),
                () -> assertEquals(
                        "https://example.test/test-api/v1alpha/projects/test-project/locations/global/collections/default_collection/engines/test-engine/servingConfigs/default_search:answer",
                        model.getAnswerUrl()
                ),
                () -> assertEquals(
                        "/content/dam/auspost/ecomm/report-guide.pdf",
                        model.getPdfUrl()
                ),
                () -> assertEquals(
                        "/content/auspost/au/en",
                        model.getHomeUrl()
                )
        );

    }

    @Test
    void testAutocompleteUrlWhenNoEcommerceService() {
        SearchServiceRegistry registry = new SearchServiceRegistry() {
            @Override
            public List<SearchService> getAllSearchServices() {
                return Arrays.asList();
            }
        };
        context.registerService(SearchServiceRegistry.class, registry);

        context.currentResource("/content/auspost/au/en/test/jcr:content/root/container/container/ecommsearch");
        context.request().setResource(context.currentResource());
        EcommSearchModel model = context.request().adaptTo(EcommSearchModel.class);

        assertAll(
                () -> assertNotNull(model),
                () -> assertEquals(Constants.EMPTY, model.getAdvancedAutoCompleteUrl()),
                () -> assertEquals(Constants.EMPTY, model.getSearchUrl()),
                () -> assertEquals(Constants.EMPTY, model.getAnswerUrl())
        );
    }

}

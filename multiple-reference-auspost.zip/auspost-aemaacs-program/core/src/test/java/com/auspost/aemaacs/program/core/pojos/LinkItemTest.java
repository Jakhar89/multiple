package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * @author Sathish Balan
 */
@ExtendWith(AemContextExtension.class)
class LinkItemTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private LinkManager linkManager;

    private LinkItem linkItem;

    @BeforeEach
    void setup() {
        createLinkItemViaInjection(true);
    }

    private void createLinkItemViaInjection(boolean buildLink) {
        Page page = ctx.create().page("/content/page");
        Map<String, Object> props = Map.of(
                "label", "Link Label",
                "linkURL", "/content/page",
                "linkTarget", "_self"
        );
        Resource linkResource = ctx.create().resource(page, "linkResource", props);
        ctx.currentResource(linkResource);
        linkItem = Objects.requireNonNull(ctx.currentResource()).adaptTo(LinkItem.class);
        if (buildLink) {
            linkManager = ctx.request().adaptTo(LinkManager.class);
            linkItem.setLink(Objects.requireNonNull(linkManager).get(linkItem.getLinkURL()).build());
        }
    }

    @Test
    void testIfLinkItemIsInitialisedAsExpectedDuringInjectionWithAProperResourceHavingAllValues() {
        assertAll(() -> {
            assertEquals("Link Label", linkItem.getLabel());
            assertEquals("/content/page", linkItem.getLinkURL());
            assertEquals("/content/page.html", linkItem.getURL());
            assertEquals("_self", linkItem.getLinkTarget());
            assertNotNull(linkItem.getLink());
            assertEquals("http://localhost:4503/content/page.html", linkItem.getExternalizedURL());
            assertEquals("/content/page.html", linkItem.getMappedURL());
        });
    }

    @Test
    void testIfLinkItemIsInitialisedAsExpectedWithConstructorInitialisationWithAProperResourceHavingAllValues() {
        LinkItem linkItem = new LinkItem("Link Label", "/content/page", "_self", linkManager);
        assertAll(() -> {
            assertEquals("Link Label", linkItem.getLabel());
            assertEquals("/content/page", linkItem.getLinkURL());
            assertEquals("/content/page.html", linkItem.getURL());
            assertEquals("_self", linkItem.getLinkTarget());
            assertNotNull(linkItem.getLink());
            assertEquals("http://localhost:4503/content/page.html", linkItem.getExternalizedURL());
            assertEquals("/content/page.html", linkItem.getMappedURL());
        });
    }

    @Test
    void testIfAllItemsAreInstantiatedAsExpectedWhenOnlySomeValuesAreInjected() {
        createLinkItemViaInjection(false);
        assertAll(() -> {
            assertNotNull(linkItem);
            assertNull(linkItem.getLink());
            assertNull(linkItem.getURL());
            assertNull(linkItem.getExternalizedURL());
            assertNull(linkItem.getMappedURL());
        });
    }
}

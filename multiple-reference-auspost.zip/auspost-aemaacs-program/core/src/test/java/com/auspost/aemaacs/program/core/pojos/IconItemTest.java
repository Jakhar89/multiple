package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * @author Sathish Balan
 */
@ExtendWith(AemContextExtension.class)
class IconItemTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private LinkManager linkManager;

    private IconItem iconItem;

    @BeforeEach
    void setup() {
        // create a page to allow proper processing of Link
        Page page = ctx.create().page("/content/page");
        // create a map to represent the resource values to then create a resource
        Map<String, Object> props = Map.of(
                "icon", "fa fa-facebook",
                "label", "Icon Label",
                "linkURL", "/content/page",
                "linkTarget", "_self"
        );
        // create a new resource and set it as current resource
        Resource linkResource = ctx.create().resource(page, "linkResource", props);
        ctx.currentResource(linkResource);
        // perform the adaptTo to prepare iconItem object for testing
        iconItem = Objects.requireNonNull(ctx.currentResource()).adaptTo(IconItem.class);
        // initialise the LinkManager from SlingHttpServletRequest and set the Link to iconItem
        linkManager = ctx.request().adaptTo(LinkManager.class);
        iconItem.setLink(Objects.requireNonNull(linkManager).get(iconItem.getLinkURL()).build());
    }

    @Test
    void testIfIconItemIsInitialisedAsExpectedDuringInjectionWithAProperResourceHavingAllValues() {
        assertAll(() -> {
            assertEquals("Icon Label", iconItem.getLabel());
            assertEquals("/content/page", iconItem.getLinkURL());
            assertEquals("/content/page.html", iconItem.getURL());
            assertEquals("_self", iconItem.getLinkTarget());
            assertNotNull(iconItem.getLink());
            assertEquals("http://localhost:4503/content/page.html", iconItem.getExternalizedURL());
            assertEquals("/content/page.html", iconItem.getMappedURL());
        });
    }

    @Test
    void testIfIconItemIsInitialisedAsExpectedWithConstructorInitialisationWithAProperResourceHavingAllValues() {
        IconItem iconItem = new IconItem("Label", "/content/page", "_self", linkManager,
                "fa", "/content/dam/collectables/ap-acknowledgement-logos.svg");
        assertAll(() -> {
            assertEquals("Label", iconItem.getLabel());
            assertEquals("/content/page", iconItem.getLinkURL());
            assertEquals("/content/page.html", iconItem.getURL());
            assertEquals("_self", iconItem.getLinkTarget());
            assertNotNull(iconItem.getLink());
            assertEquals("http://localhost:4503/content/page.html", iconItem.getExternalizedURL());
            assertEquals("/content/page.html", iconItem.getMappedURL());
            assertEquals("http://localhost:4503/content/dam/collectables/ap-acknowledgement-logos.svg",
                    iconItem.getExternalIconReference());
        });
    }

}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static junit.framework.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(AemContextExtension.class)
class GroupingContainerModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    @BeforeEach
    void setUp() {
        // Load the JSON for the component
        ctx.load().json( "/models/groupingcontainer/component.json", "/content/component");
    }

    @Test
    void testGroupingContainerModelProperties() {
        ctx.currentResource("/content/component");

        GroupingContainerModel model = ctx.request().adaptTo(GroupingContainerModel.class);
        assertAll(() -> {
            assertNotNull(model, "Model should not be null");
            // Verify properties from JSON
            assertEquals("Form Group Section", model.getHeading());
            assertEquals("This section groups multiple form fields together.", model.getDescription());
        });
    }
}

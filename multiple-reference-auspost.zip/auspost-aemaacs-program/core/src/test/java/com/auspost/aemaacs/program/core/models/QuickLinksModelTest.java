package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class QuickLinksModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private QuickLinksModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/quicklinks/component.json", "/content/page/jcr:content/quicklinks");
    }

    @Test
    void testIfAllQuickLinkItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/quicklinks");
        model = ctx.request().adaptTo(QuickLinksModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(1, model.getQuickLinks().size());
            assertEquals("Browse and Shop", model.getQuickLinks().getFirst().getLabel());
        });
    }

    @Test
    void testIfAllQuickLinkItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource =
                ctx.create().resource(page, "quicklinks", "quicklinks", "some quicklinks", "enableDataLayer", "true");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(QuickLinksModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getQuickLinks());
            assertNotNull(model.getDataLayer());
        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenQuickLinkItemsAreInstantiatedAsExpected() {
        ctx.currentResource("/content/page/jcr:content/quicklinks");
        model = ctx.request().adaptTo(QuickLinksModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(1, model.getQuickLinks().size());
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/quicklinks/datalayer.json"),
                    model.getQuickLinks().getFirst().getDataLayer());
        });
    }
}

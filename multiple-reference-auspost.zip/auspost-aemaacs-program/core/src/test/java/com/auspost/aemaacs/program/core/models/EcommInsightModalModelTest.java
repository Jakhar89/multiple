package com.auspost.aemaacs.program.core.models;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class EcommInsightModalModelTest {

  private final AemContext ctx = AppAemContext.newAemContext();

  private EcommInsightModalModel model;

  @BeforeEach
  void setUp() {
    ctx.create().page("/content/page");
    ctx
      .load()
      .json(
        "/models/ecomminsightmodal/component.json",
        "/content/page/jcr:content/ecomminsightmodal"
      );
  }

  @Test
  void testModalFieldsAreInjected() {
    ctx.currentResource("/content/page/jcr:content/ecomminsightmodal");
    model = ctx.request().adaptTo(EcommInsightModalModel.class);

    assertAll(() -> {
      assertNotNull(model);
      assertEquals("modal-001", model.getModalId());
      assertEquals("Know your shoppers", model.getModalTitle());
      assertEquals(
        "/content/dam/collectables/insight.jpg",
        model.getModalImageUrl()
      );
      assertEquals("Insight image", model.getModalImageAlt());
      assertEquals("Modal description", model.getDescription());
      assertEquals(
        "/content/dam/collectables/footer.jpg",
        model.getFooterImage()
      );
      assertEquals("Next up", model.getFooterHeader());
      assertEquals("Customer insights", model.getNextModalName());
      assertEquals("modal-002", model.getNextModalId());
    });
  }

  @Test
  void testDataLayerIsBuilt() {
    ctx.currentResource("/content/page/jcr:content/ecomminsightmodal");
    model = ctx.request().adaptTo(EcommInsightModalModel.class);

    assertAll(() -> {
      assertNotNull(model);
      assertEquals(
        AppAemContext.getExpectedDataLayerJson(
          "/models/ecomminsightmodal/datalayer.json"
        ),
        model.getDataLayer()
      );
    });
  }

  @Test
  void testDataLayerDisabledReturnsEmpty() {
    AemContext disabledCtx = AppAemContext.newAemContextWithDataLayerDisabled();
    disabledCtx.create().page("/content/page");
    disabledCtx
      .load()
      .json(
        "/models/ecomminsightmodal/component.json",
        "/content/page/jcr:content/ecomminsightmodal"
      );
    disabledCtx.currentResource("/content/page/jcr:content/ecomminsightmodal");

    EcommInsightModalModel disabledModel = disabledCtx
      .request()
      .adaptTo(EcommInsightModalModel.class);
    assertAll(() -> {
      assertNotNull(disabledModel);
      assertTrue(disabledModel.getDataLayer().isEmpty());
    });
  }

  @Test
  void testGetIdReturnsValue() {
    ctx.currentResource("/content/page/jcr:content/ecomminsightmodal");
    model = ctx.request().adaptTo(EcommInsightModalModel.class);

    assertAll(() -> {
      assertNotNull(model);
      assertNotNull(model.getId());
    });
  }

  @Test
  void testModalIdGeneratedWhenMissing() {
    ctx
      .create()
      .resource(
        "/content/page/jcr:content/ecomminsightmodal2",
        "sling:resourceType",
        "auspost-aemaacs-program/components/ecomminsightmodal",
        "id",
        "modal-auto-id",
        "modalTitle",
        "Auto Modal"
      );
    ctx.currentResource("/content/page/jcr:content/ecomminsightmodal2");
    model = ctx.request().adaptTo(EcommInsightModalModel.class);

    assertAll(() -> {
      assertNotNull(model);
      assertTrue(model.getModalId() == null || model.getModalId().isEmpty());
      assertTrue(
        model.getNextModalId() == null || model.getNextModalId().isEmpty()
      );
    });
  }
}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class BannerModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private BannerModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/banner/component.json", "/content/page/jcr:content/banner");
        ctx.load().json("/models/banner/assets.json", "/content/dam/collectables/stamp-bulletin");
    }

    @Test
    void testIfAllBannerItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/banner/banner-mock-data-with-valid-category");
        model = ctx.request().adaptTo(BannerModel.class);

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("123", model.getId());
            assertEquals("Opals(International)", model.getTitle());
            assertEquals("Description for Banner", model.getDescription());
            assertEquals("03 August 2025", model.getIssueDate());
            assertEquals(
                    "/content/page/jcr:content/banner/banner-mock-data-with-valid-category/heroImage/cq:featuredimage",
                    model.getHeroImage().getPath());
            assertEquals(
                    "/content/page/jcr:content/banner/banner-mock-data-with-valid-category/teaserImage/cq:featuredimage",
                    model.getTeaserImage().getPath());
            assertEquals(
                    "/content/page/jcr:content/banner/banner-mock-data-with-valid-category/productImage/cq:featuredimage",
                    model.getProductImage().getPath());
            assertEquals(
                    "/content/page/jcr:content/banner/banner-mock-data-with-valid-category/promoImage/cq:featuredimage",
                    model.getPromoImage().getPath());
            assertEquals(
                    "/content/page/jcr:content/banner/banner-mock-data-with-valid-category/promoFeatureImage/cq:featuredimage",
                    model.getPromoFeatureImage().getPath());
            assertNotNull(model.getHeroImage());
            assertNotNull(model.getTeaserImage());
            assertNotNull(model.getProductImage());
            assertNotNull(model.getPromoImage());
            assertNotNull(model.getPromoFeatureImage());

            assertNotNull(model.getPrimaryCta());
            assertNotNull(model.getBackToLink());
            assertEquals("Login", model.getPrimaryCta().getLabel());
            assertEquals("/content/page.html", model.getPrimaryCta().getURL());
            assertEquals("_blank", model.getPrimaryCta().getLinkTarget());
            assertEquals(EMPTY, model.getPrimaryCta().getAssetTypeAndSize());

            assertNotNull(model.getSecondaryCta());
            assertEquals("Find More", model.getSecondaryCta().getLabel());
            assertEquals("/content/dam/collectables/stamp-bulletin/stamp-bulletin-1.pdf",
                    model.getSecondaryCta().getURL());
            assertEquals("_self", model.getSecondaryCta().getLinkTarget());
            assertEquals("(PDF, 5 MB)", model.getSecondaryCta().getAssetTypeAndSize());

            assertEquals("Stamp issue", model.getPrimaryCategory().getText());
            assertEquals("red", model.getPrimaryCategory().getColour());

            assertEquals("Stamp list", model.getSecondaryCategory().getText());
            assertEquals("black", model.getSecondaryCategory().getColour());
        });
    }

    @Test
    void testBannerIfNoCategoryProvided() {
        ctx.currentResource("/content/page/jcr:content/banner/banner-mock-data-without-category");
        model = ctx.request().adaptTo(BannerModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getPrimaryCta());
            assertEquals(EMPTY, model.getPrimaryCta().getAssetTypeAndSize());
            assertNull(model.getSecondaryCta());
            assertNull(model.getPrimaryCategory());
            assertNull(model.getSecondaryCategory());
            assertNull(model.getBackToLink());
            assertNotNull(model.getDataLayer());
            assertEquals(
                    "{\"123\":{\"event\":\"site_impression\",\"eventCategory\":\"banner\",\"eventDescription\":\"opals(international)\"}}",
                    model.getDataLayer());

            assertEquals(
                    "{\"123-primary-cta-login\":{\"event\":\"site_interaction\",\"eventCategory\":\"banner||cta\",\"eventDescription\":\"opals(international)-primary-cta:login\"}}",
                    model.getPrimaryCta().getDataLayer());
        });
    }

    @Test
    void testBannerIfEmptyCategoryLabelProvided() {
        ctx.currentResource("/content/page/jcr:content/banner/banner-mock-data-with-empty-category");
        model = ctx.request().adaptTo(BannerModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getPrimaryCta());
            assertNotNull(model.getSecondaryCta());
            assertNotNull(model.getPrimaryCategory());
            assertNotNull(model.getSecondaryCategory());
            assertNotNull(model.getDataLayer());
            assertEquals(
                    "{\"123\":{\"event\":\"site_impression\",\"eventCategory\":\"banner\",\"eventDescription\":\"opals(international)\"}}",
                    model.getDataLayer());

            assertEquals(
                    "{\"123-secondary-cta-find-more\":{\"event\":\"site_interaction\",\"eventCategory\":\"banner||cta\",\"eventDescription\":\"opals(international)-secondary-cta:find-more\"}}",
                    model.getSecondaryCta().getDataLayer());
        });
    }

    @Test
    void testIfDataLayerIsPopulated() {
        ctx.currentResource("/content/page/jcr:content/banner/banner-mock-data-with-valid-category");
        model = ctx.request().adaptTo(BannerModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/banner/datalayer.json"),
                    model.getDataLayer());
            assertEquals(
                    "{\"123-primary-cta-login\":{\"event\":\"site_interaction\",\"eventCategory\":\"banner||cta\",\"eventDescription\":\"stamp-issue:stamp-list:opals(international)-primary-cta:login\"}}",
                    model.getPrimaryCta().getDataLayer());
            assertEquals(
                    "{\"123-secondary-cta-find-more\":{\"event\":\"site_interaction\",\"eventCategory\":\"banner||cta\",\"eventDescription\":\"stamp-issue:stamp-list:opals(international)-secondary-cta:find-more\"}}",
                    model.getSecondaryCta().getDataLayer());
        });
    }

    @Test
    void testGetDataWhenDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        ctx.create().page("/content/page");
        ctx.load().json("/models/banner/component.json", "/content/page/jcr:content/banner");
        ctx.currentResource("/content/page/jcr:content/banner");
        model = ctx.request().adaptTo(BannerModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
}

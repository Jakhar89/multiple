package com.auspost.aemaacs.program.core.pojos;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(AemContextExtension.class)
class FeatureCardTest {

    private final AemContext ctx = AppAemContext.newAemContext();
    private FeatureCard model;

    @Test
    void testingModelFields() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/featurecard/component.json", "/content/page/jcr:content/featurecard");
        ctx.currentResource("/content/page/jcr:content/featurecard");
        model = ctx.currentResource().adaptTo(FeatureCard.class);

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test 2", model.getSubHeading());
            assertEquals("Test 1", model.getHeading());
            assertEquals("red", model.getBackgroundColour());
            assertEquals("button label", model.getLink().getLabel());
            assertEquals("/content/test", model.getLink().getLinkURL());
            assertEquals("false", model.getImage().getValueMap().get("altValueFromDAM"));
            assertEquals("/content/dam/auspost/test.jpg", model.getImage().getValueMap().get("fileReference"));
        });
    }
}

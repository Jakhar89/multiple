package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class EcommLinkCaptureModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private EcommLinkCaptureModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/ecommlinkcapture/component.json", "/content/page/jcr:content/content");
        ctx.currentResource("/content/page/jcr:content/content/ecommlinkcapture");
        model = ctx.request().adaptTo(EcommLinkCaptureModel.class);
    }

    @Test
    void testDialogFieldsAreMappedToModel() {
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Single CTA Title", model.getCardTitle());
            assertEquals("<p>Content for the single CTA</p>\n", model.getCardDescription());
            assertNotNull(model.getSecondaryCta());
            assertEquals("Go Now", model.getSecondaryCta().getLabel());
            assertEquals("/content/go", model.getSecondaryCta().getLinkURL());
            assertEquals("_blank", model.getSecondaryCta().getLinkTarget());
            assertEquals("arrow-right-thin", model.getSecondaryCta().getIconRight());
        });
    }

    @Test
    void testHandlesMissingOptionalValues() {
        Page page = ctx.create().page("/content/page2");
        Resource resource = ctx.create().resource(page, "ecommlinkcapture_no_values",
                "sling:resourceType", "auspost-aemaacs-program/components/ecommlinkcapture",
                "cardTitle", "Just a title");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(EcommLinkCaptureModel.class);

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Just a title", model.getCardTitle());
            assertNull(model.getCardDescription());
            assertNull(model.getSecondaryCta());
        });
    }

}

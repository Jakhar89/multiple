package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.tagging.TagConstants;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.scripting.SlingBindings;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static junitx.framework.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class PageListingModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    SlingBindings bindings = new SlingBindings();

    private PageListingModel model;

    private Map<String, Object> props = new HashMap<>();

    @BeforeEach
    void setUp() {
        props = Map.of(
                "sling:resourceSuperType", "core/wcm/components/list/v4/list",
                "listFrom", "children",
                "parentPage", "/content/home",
                "disableShadowing", "true",
                "childDepth", "1");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/pagelisting", props);
        ctx.load().json("/models/pagelisting/component.json", "/content/home");
        ctx.load().json("/models/pagelisting/tags.json", TagConstants.TAG_ROOT_PATH);
        ctx.currentPage("/content/home");

        Style style = mock(Style.class);
        bindings.put(WCMBindingsConstants.NAME_CURRENT_STYLE, style);
        bindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, ctx.currentPage());
    }

    @Test
    void testIfAllPageListInstantiatedAsExpectedWhenAllValuesAreInjectedWhenNoFilterIsSelected() {
        ctx.currentResource("/content/home/jcr:content/defaultVariantWithNoFilter");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Default  variation with no filter", model.getTitle());
            assertEquals("View stamp issue", model.getPageCta());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("children", model.getListFrom());
            assertEquals("default", model.getTargetSource());
            assertEquals("No results found. Please reselect the filters", model.getNoResultsMessage());
            assertEquals("/content/home", model.getResourcePath());
            assertEquals(0, model.getFilters().size());
            assertEquals(5, model.getPageListItems().size());
            assertEquals("Page1 title from page properties", model.getPageListItems().getFirst().getLabel());
            assertEquals("/content/home/page1.html", model.getPageListItems().getFirst().getURL());
            assertEquals(EMPTY, model.getPageListItems().getFirst().getType());
            assertEquals(5, model.getFilteredResults());
            assertEquals("/content/home/page1.html", model.getPageListItems().getFirst().getPageItemUrl());
            assertEquals(
                    "{\"pagelisting-abc18760a6\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\",\"eventDescription\":\"page1-title-from-page-properties\"}}",
                    model.getPageListItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testIfAllPageListInstantiatedAsExpectedWhenAllValuesAreInjectedWhenFilterIsSelectedWithOrderByTitle() {
        ctx.currentResource("/content/home/jcr:content/bannerVariantWithFilterWithOrderByTitle");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Banner Variant With Filter", model.getTitle());
            assertEquals("View Stamp Issue", model.getPageCta());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("banner", model.getTargetSource());
            assertEquals("children", model.getListFrom());
            assertEquals("title", model.getOrderBy());
            assertEquals("No results found please retry with different filter combination",
                    model.getNoResultsMessage());
            assertEquals("/content/home", model.getResourcePath());
            assertEquals(3, model.getFilters().size());
            assertEquals(5, model.getPageListItems().size());
            assertEquals("Page5 title from banner", model.getPageListItems().getFirst().getLabel());
            assertEquals("default", model.getPageListItems().getFirst().getType());
            assertEquals("/content/home/page5.html", model.getPageListItems().getFirst().getURL());
            assertEquals(5, model.getFilteredResults());
        });
    }

    @Test
    void testIfAllPageListInstantiatedAsExpectedWhenAllValuesAreInjectedWhenFilterIsSelectedWithOrderByTitleWithOffSet() {
        ctx.requestPathInfo().setSelectorString("offset3");
        ctx.currentResource("/content/home/jcr:content/bannerVariantWithFilterWithOrderByTitleOffSet");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Banner Variant With Filter", model.getTitle());
            assertEquals("View Stamp Issue", model.getPageCta());
            assertEquals(2, model.getInitialPageLoad());
            assertEquals("banner", model.getTargetSource());
            assertEquals("children", model.getListFrom());
            assertEquals("title", model.getOrderBy());
            assertEquals("No results found please retry with different filter combination",
                    model.getNoResultsMessage());
            assertEquals("/content/home", model.getResourcePath());
            assertEquals(3, model.getFilters().size());
            assertEquals(2, model.getPageListItems().size());
            assertEquals("Page2 title from banner", model.getPageListItems().getFirst().getLabel());
            assertEquals("article-card", model.getPageListItems().getFirst().getType());
            assertEquals("/content/home/page2.html", model.getPageListItems().getFirst().getURL());
            assertEquals(5, model.getFilteredResults());
        });
    }

    @Test
    void testIfAllPageListInstantiatedAsExpectedWhenAllValuesAreInjectedWhenFilterIsSelectedWithOutSelectors() {
        ctx.currentResource("/content/home/jcr:content/bannerVariantWithFilterWithOrderByIssueDate");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(3, model.getFilters().size());
            assertEquals(5, model.getPageListItems().size());
            assertEquals("Page1 title from banner", model.getPageListItems().getFirst().getLabel());
            assertEquals("/content/home/page1.html", model.getPageListItems().getFirst().getURL());
            assertEquals("stamp-card", model.getPageListItems().getFirst().getType());
            assertEquals(5, model.getFilteredResults());
        });
    }


    @Test
    void testIfAllPageListInstantiatedAsExpectedWhenAllValuesAreInjectedWhenFilterIsSelected() {
        ctx.requestPathInfo().setSelectorString("2025.art");
        ctx.currentResource("/content/home/jcr:content/bannerVariantWithFilterWithOrderByIssueDate");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Banner Variant With Filter", model.getTitle());
            assertEquals("View Stamp Issue", model.getPageCta());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("banner", model.getTargetSource());
            assertEquals("children", model.getListFrom());
            assertEquals("issueDate", model.getOrderBy());
            assertEquals("No results found please retry with different filter combination",
                    model.getNoResultsMessage());
            assertEquals("/content/home", model.getResourcePath());
            assertEquals(3, model.getFilters().size());
            assertEquals(3, model.getPageListItems().size());
            assertEquals(3, model.getFilteredResults());
            assertEquals(
                    "{\"pagelisting-b21b5a7563\":{\"event\":\"filtered-results\",\"eventCategory\":\"2025||Art\",\"eventDescription\":\"3\"}}",
                    model.getDataLayer());

            assertEquals("Page1 title from banner", model.getPageListItems().getFirst().getLabel());
            assertEquals("/content/home/page1.html", model.getPageListItems().getFirst().getURL());
            assertEquals("stamp-card", model.getPageListItems().getFirst().getType());
            assertEquals(
                    "{\"pagelisting-b21b5a7563\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\",\"eventDescription\":\"page1-title-from-banner\"}}",
                    model.getPageListItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testIfAllPageListInstantiatedAsExpectedWhenAllValuesWithPromoVariant() {
        ctx.requestPathInfo().setSelectorString("2025.australia.dummy");
        ctx.currentResource("/content/home/jcr:content/bannerVariantWithFilterWithOrderByIssueDate");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Page5 title from banner", model.getPageListItems().getFirst().getLabel());
            assertEquals("/content/home/page5.html", model.getPageListItems().getFirst().getURL());
            assertEquals("default", model.getPageListItems().getFirst().getType());
            assertEquals(1, model.getFilteredResults());
            assertEquals(
                    "{\"pagelisting-b21b5a7563\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\",\"eventDescription\":\"page5-title-from-banner\"}}",
                    model.getPageListItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testIfAllPageListInstantiatedAsExpectedWhenAllValuesWithHeroVariant() {
        ctx.requestPathInfo().setSelectorString("2025.animal");
        ctx.currentResource("/content/home/jcr:content/bannerVariantWithFilterWithOrderByIssueDate");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Page2 title from banner", model.getPageListItems().getFirst().getLabel());
            assertEquals("/content/home/page2.html", model.getPageListItems().getFirst().getURL());
            assertEquals("article-card", model.getPageListItems().getFirst().getType());
            assertEquals(1, model.getFilteredResults());
            assertEquals(
                    "{\"pagelisting-b21b5a7563\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\",\"eventDescription\":\"page2-title-from-banner\"}}",
                    model.getPageListItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testIfDataLayerStringIsEmptyWhenDataLayerIsDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        ctx.create().resource("/apps/auspost-aemaacs-program/components/pagelist", props);
        ctx.load().json("/models/pagelisting/component.json", "/content/home");
        ctx.load().json("/models/pagelisting/tags.json", TagConstants.TAG_ROOT_PATH);
        ctx.currentPage("/content/home");
        ctx.currentResource("/content/home/jcr:content/defaultVariantWithNoFilter");
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(PageListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(0, model.getFilters().size());
            assertEquals(0, model.getPageListItems().size());
            assertEquals(0, model.getFilteredResults());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
}

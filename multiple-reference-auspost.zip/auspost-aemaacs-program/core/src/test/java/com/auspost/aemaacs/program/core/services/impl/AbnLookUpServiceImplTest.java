package com.auspost.aemaacs.program.core.services.impl;


import com.auspost.aemaacs.program.core.services.AbnLookUpService;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.models.FormAbnLookupModelTest.stubWireMockServer;
import static junitx.framework.Assert.assertEquals;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
public class AbnLookUpServiceImplTest {
    private final AemContext ctx = AppAemContext.newAemContext();

    private static WireMockServer wireMockServer;

    private static AbnLookUpService abnLookUpService;

    public static final String SEARCH_XML_RESULT = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
            "<response>      \"mainName\": {\n" +
            "          \"organisationName\": \"AUSTRALIAN POSTAL CORPORATION\",\n" +
            "          \"effectiveFrom\": \"1999-11-01\"\n" +
            "        }</response>";

    @BeforeAll
    static void setupBeforeAll() {
        wireMockServer = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        wireMockServer.start();
    }

    @BeforeEach
    void setUp() throws IOException {
        Dictionary<String, String> config = new Hashtable<>() {{
            put("host", "http://localhost:" + wireMockServer.port());
            put("endpoint", "/endpoint");
            put("authKey", "authKey123");
            put("historicalDetails", "N");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AbnLookUpServiceImpl")
                .update(config);
        abnLookUpService = ctx.registerInjectActivateService(AbnLookUpServiceImpl.class);
    }

    @Test
    void testIfExpectedResponseWhenAbnLookUpCalled() {
        stubWireMockServer(wireMockServer, "/endpoint", 200, SEARCH_XML_RESULT);
        assertEquals(SEARCH_XML_RESULT, abnLookUpService.search("12345678901"));

    }

    @Test
    void testSearchHandlesExceptionAndReturnsEmpty() throws IOException {
        Dictionary<String, String> config = new Hashtable<>() {{
            put("host", "://invalid_host");
            put("endpoint", "/endpoint");
            put("authKey", "authKey123");
            put("historicalDetails", "N");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AbnLookUpServiceImpl")
                .update(config);
        abnLookUpService = ctx.registerInjectActivateService(AbnLookUpServiceImpl.class);

        String result = abnLookUpService.search("12345678901");
        assertEquals(EMPTY, result);
    }

    @AfterAll
    static void tearDown() {
        wireMockServer.stop();
    }
}

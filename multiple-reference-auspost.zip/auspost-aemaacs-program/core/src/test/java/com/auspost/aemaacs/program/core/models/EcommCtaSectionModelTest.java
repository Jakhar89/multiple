package com.auspost.aemaacs.program.core.models;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class EcommCtaSectionModelTest {

  private final AemContext ctx = AppAemContext.newAemContext();

  private EcommCtaSectionModel model;

  @BeforeEach
  void setUp() {
    ctx.create().page("/content/page");
    ctx
      .load()
      .json(
        "/models/ecommctasection/component.json",
        "/content/page/jcr:content/content"
      );
    ctx.currentResource("/content/page/jcr:content/content/ecommctasection");
    model = ctx.request().adaptTo(EcommCtaSectionModel.class);
  }

  @Test
  void testDialogFieldsAreMappedToModel() {
    assertAll(() -> {
      assertNotNull(model);
      assertEquals("Ecomm CTA Title", model.getCardTitle());
      assertEquals(
        "<p>The <strong>Ecommerce</strong> CTA description.</p>\n",
        model.getCardDescription()
      );
      assertEquals("Helper primary text", model.getHelperTextPrimary());
      assertEquals("Helper secondary text", model.getHelperTextSecondary());
      assertNotNull(model.getPrimaryCta());
      assertEquals("Primary CTA Label", model.getPrimaryCta().getLabel());
      assertEquals("/content/primary", model.getPrimaryCta().getLinkURL());
      assertEquals("_blank", model.getPrimaryCta().getLinkTarget());
      assertEquals("download", model.getPrimaryCta().getIconLeft());
      assertNotNull(model.getSecondaryCta());
      assertEquals("Secondary CTA Label", model.getSecondaryCta().getLabel());
      assertEquals("/content/secondary", model.getSecondaryCta().getLinkURL());
      assertEquals("_self", model.getSecondaryCta().getLinkTarget());
      assertEquals("podcast", model.getSecondaryCta().getIconLeft());
      assertEquals(2, model.getMultiCta().size());
      assertEquals("Additional CTA One", model.getMultiCta().get(0).getLabel());
      assertEquals(
        "/content/additional-1",
        model.getMultiCta().get(0).getLinkURL()
      );
      assertEquals("_self", model.getMultiCta().get(0).getLinkTarget());
      assertEquals("download", model.getMultiCta().get(0).getIconLeft());
      assertEquals("Additional CTA Two", model.getMultiCta().get(1).getLabel());
      assertEquals(
        "/content/additional-2",
        model.getMultiCta().get(1).getLinkURL()
      );
      assertEquals("_blank", model.getMultiCta().get(1).getLinkTarget());
      assertEquals("podcast", model.getMultiCta().get(1).getIconLeft());
    });
  }

  @Test
  void testHandlesMissingOptionalValues() {
    Page page = ctx.create().page("/content/page2");
    Resource resource = ctx
      .create()
      .resource(
        page,
        "ecommctasection_no_values",
        "sling:resourceType",
        "auspost-aemaacs-program/components/ecommctasection",
        "cardTitle",
        "Simple CTA Title"
      );
    ctx.currentResource(resource);
    model = ctx.request().adaptTo(EcommCtaSectionModel.class);

    assertAll(() -> {
      assertNotNull(model);
      assertEquals("Simple CTA Title", model.getCardTitle());
      assertNull(model.getCardDescription());
      assertNull(model.getHelperTextPrimary());
      assertNull(model.getHelperTextSecondary());
      assertNull(model.getPrimaryCta());
      assertNull(model.getSecondaryCta());
      assertNull(model.getMultiCta());
      assertNotNull(model.getDataLayer());
    });
  }

  @Test
  void testDataLayerIsPopulated() {
    assertAll(() -> {
      assertNotNull(model);
      assertEquals(
        AppAemContext.getExpectedDataLayerJson(
          "/models/ecommctasection/datalayer.json"
        ),
        model.getDataLayer()
      );
      assertEquals(
        "{\"Ecomm-CTA-Section-ID-primary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"ecommCtaSection||cta\",\"eventDescription\":\"ecomm-cta-title:primary-cta-label\"}}",
        model.getPrimaryCta().getDataLayer()
      );
      assertEquals(
        "{\"Ecomm-CTA-Section-ID-secondary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"ecommCtaSection||cta\",\"eventDescription\":\"ecomm-cta-title:secondary-cta-label\"}}",
        model.getSecondaryCta().getDataLayer()
      );
      assertEquals(
        "{\"Ecomm-CTA-Section-ID-multi-cta-1\":{\"event\":\"site_interaction\",\"eventCategory\":\"ecommCtaSection||cta\",\"eventDescription\":\"ecomm-cta-title:additional-cta-one\"}}",
        model.getMultiCta().get(0).getDataLayer()
      );
      assertEquals(
        "{\"Ecomm-CTA-Section-ID-multi-cta-2\":{\"event\":\"site_interaction\",\"eventCategory\":\"ecommCtaSection||cta\",\"eventDescription\":\"ecomm-cta-title:additional-cta-two\"}}",
        model.getMultiCta().get(1).getDataLayer()
      );
    });
  }

  @Test
  void testDataLayerDisabledReturnsEmpty() {
    AemContext disabledCtx = AppAemContext.newAemContextWithDataLayerDisabled();
    disabledCtx.create().page("/content/page");
    disabledCtx
      .load()
      .json(
        "/models/ecommctasection/component.json",
        "/content/page/jcr:content/content"
      );
    disabledCtx.currentResource(
      "/content/page/jcr:content/content/ecommctasection"
    );
    EcommCtaSectionModel disabledModel = disabledCtx
      .request()
      .adaptTo(EcommCtaSectionModel.class);

    assertAll(() -> {
      assertNotNull(disabledModel);
      assertEquals(EMPTY, disabledModel.getDataLayer());
    });
  }

  @Test
  void testMultiCtaHandlesNullItem() throws Exception {
    Field multiCtaField = EcommCtaSectionModel.class.getDeclaredField(
      "multiCta"
    );
    multiCtaField.setAccessible(true);
    List<ButtonItem> itemsWithNull = Arrays.asList((ButtonItem) null);
    multiCtaField.set(model, itemsWithNull);

    assertAll(() -> {
      assertNotNull(model.getDataLayer());
      assertEquals(1, model.getMultiCta().size());
    });
  }

  @Test
  void testInitSkipsNullMultiCtaItem() throws Exception {
    setPrivateField(model, "multiCta", Arrays.asList((ButtonItem) null));
    invokePrivateMethod(model, "init");
  }

  @Test
  void testMultiCtaHandlesEmptyList() throws Exception {
    setPrivateField(model, "multiCta", new ArrayList<>());
    assertNotNull(model.getDataLayer());
  }

  @Test
  void testSetDataLayerForLinkHelperHandlesNulls() throws Exception {
    Method method = EcommCtaSectionModel.class.getDeclaredMethod(
      "setDataLayerForLinkHelper",
      ButtonItem.class,
      String.class,
      String.class
    );
    method.setAccessible(true);
    method.invoke(model, null, "id", "desc");
    method.invoke(model, new ButtonItem(), " ", "desc");
  }

  @Test
  void testDataLayerWhenCtasMissing() {
    Page page = ctx.create().page("/content/page3");
    Resource resource = ctx
      .create()
      .resource(
        page,
        "ecommctasection_missing_cta",
        "sling:resourceType",
        "auspost-aemaacs-program/components/ecommctasection",
        "cardTitle",
        "Simple CTA Title",
        "id",
        "cta-section-id"
      );
    ctx.currentResource(resource);
    EcommCtaSectionModel missingCtaModel = ctx
      .request()
      .adaptTo(EcommCtaSectionModel.class);

    assertAll(() -> {
      assertNotNull(missingCtaModel);
      assertEquals(
        "{\"cta-section-id\":{\"event\":\"site_impression\",\"eventCategory\":\"ecommCtaSection||view\",\"eventDescription\":\"simple-cta-title\"}}",
        missingCtaModel.getDataLayer()
      );
    });
  }

  private static void setPrivateField(
    EcommCtaSectionModel target,
    String fieldName,
    Object value
  ) throws Exception {
    Field field = EcommCtaSectionModel.class.getDeclaredField(fieldName);
    field.setAccessible(true);
    field.set(target, value);
  }

  private static void invokePrivateMethod(
    EcommCtaSectionModel target,
    String methodName
  ) throws Exception {
    Method method = EcommCtaSectionModel.class.getDeclaredMethod(methodName);
    method.setAccessible(true);
    method.invoke(target);
  }
}

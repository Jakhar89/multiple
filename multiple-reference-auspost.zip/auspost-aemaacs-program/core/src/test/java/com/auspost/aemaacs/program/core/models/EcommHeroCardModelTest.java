package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.pojos.AiSearchItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.apache.sling.api.resource.PersistenceException;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class EcommHeroCardModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private EcommHeroCardModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/ecommherocard/component.json", "/content/page/jcr:content/ecommherocard");
    }

    @Test
    void testIfAllEcommHeroCardItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/ecommherocard");
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(1, model.getCards().size());
            assertEquals("Card1 Image Alt Text", model.getCards().getFirst().getCardImageAlt());
            assertEquals("/content/dam/collectables/vERY Large JPG.jpg",
                    model.getCards().getFirst().getCardImageFileReference());
            assertEquals("modal-001", model.getCards().getFirst().getConnectedModalId());
            assertEquals("/content/collectables/au/en/test-home", model.getAiSearch().getURL());
            // aiSearch fields are specific to EcommHeroCardModel, keep these assertions
            assertNotNull(model.getAiSearch());
            assertEquals("AI Search Label", model.getAiSearch().getLabel());
            assertEquals("AI Search Title", model.getAiSearch().getTitle());
            assertEquals("Search for stamp numbers", model.getAiSearch().getPlaceholderText());
            assertEquals("AI search description", model.getAiSearch().getDescription());
            assertNotNull(model.getAiSearch().getAiImage());
            assertEquals("/content/dam/collectables/ai-search.jpg",
                    model.getAiSearch().getAiImage().getFileReference());
            assertEquals("AI Search Image", model.getAiSearch().getAiImage().getAlt());
        });
    }

    @Test
    void testIfAllEcommHeroCardItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "ecommherocard", "ecommherocard", "some ecommherocard items");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getCards());
            assertNull(model.getAiSearch());
            assertNotNull(model.getDataLayer());
        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenEcommHeroCardItemsAreInstantiatedAsExpected() {
        ctx.currentResource("/content/page/jcr:content/ecommherocard");
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(1, model.getCards().size());
            assertNotNull(model.getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/ecommherocard/datalayer.json"),
                    model.getCards().getFirst().getDataLayer());
            // Verify aiSearch data layer is built
            assertEquals(
                    "{\"id_1-ai-search\":{\"event\":\"site_interaction\",\"eventCategory\":\"ecommHeroCard||ai-search\",\"eventDescription\":\"ai-search-label\"}}",
                    model.getAiSearch().getDataLayer());
        });
    }

    @Test
    void testDataLayerReturnsEmptyWhenCardsIsNull() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "ecommherocard2", "ecommherocard", "some ecommherocard items");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertNotNull(model.getDataLayer());
    }

    @Test
    void testGetIdReturnsNonNull() {
        ctx.currentResource("/content/page/jcr:content/ecommherocard");
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertNotNull(model.getId());
    }

    @Test
    void testGetAiSearchBuildsAiSearchItemWhenConfigured() {
        ctx.currentResource("/content/page/jcr:content/ecommherocard");
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        AiSearchItem aiSearch = model.getAiSearch();
        assertNotNull(aiSearch);
        assertNotNull(aiSearch.getId());
        assertEquals("AI Search Label", aiSearch.getLabel());
        assertEquals("AI Search Title", aiSearch.getTitle());
    }

    @Test
    void testGetAiSearchReturnsAiSearchItemWhenConfigured() {
        ctx.currentResource("/content/page/jcr:content/ecommherocard");
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertNotNull(model.getAiSearch());
        assertEquals("AI Search Label", model.getAiSearch().getLabel());
        assertEquals("AI Search Title", model.getAiSearch().getTitle());
        assertEquals("Search for stamp numbers", model.getAiSearch().getPlaceholderText());
        assertEquals("AI search description", model.getAiSearch().getDescription());
        assertNotNull(model.getAiSearch().getAiImage());
    }

    @Test
    void testDataLayerIncludesAiSearchWhenAvailable() {
        ctx.currentResource("/content/page/jcr:content/ecommherocard");
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertNotNull(model.getDataLayer());
        // Verify aiSearch data layer is included
        assertNotNull(model.getAiSearch());
        assertNotNull(model.getAiSearch().getDataLayer());
    }

    @Test
    void testGetAiSearchReturnsNullWhenNotConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "ecommherocard3", "ecommherocard", "some ecommherocard items");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        AiSearchItem aiSearch = model.getAiSearch();
        assertNull(aiSearch);
    }

    @Test
    void testDataLayerWithCardsButNoMainCta() throws PersistenceException {
        ctx.load().json("/models/ecommherocard/component.json", "/content/page/jcr:content/ecommherocard_no_cta");
        ctx.currentResource("/content/page/jcr:content/ecommherocard_no_cta");
        // Remove the aiSearch (mainCta) from the loaded component
        Resource componentResource = ctx.resourceResolver()
                .getResource("/content/page/jcr:content/ecommherocard_no_cta");
        Resource aiSearchResource = componentResource.getChild("aiSearch");
        if (aiSearchResource != null) {
            ctx.resourceResolver().delete(aiSearchResource);
        }
        model = ctx.request().adaptTo(EcommHeroCardModel.class);
        assertNotNull(model.getDataLayer());
    }

    @Test
    void testGetCardsSkipsNullItems() throws Exception {
        ctx.currentResource("/content/page/jcr:content/ecommherocard");
        model = ctx.request().adaptTo(EcommHeroCardModel.class);

        List<com.auspost.aemaacs.program.core.pojos.EcommHeroCardItem> cards = new ArrayList<>();
        cards.add(null);
        setField(model, "cards", cards);

        List<com.auspost.aemaacs.program.core.pojos.EcommHeroCardItem> result = model.getCards();
        assertNotNull(result);
        assertEquals(1, result.size());
        assertNull(result.getFirst());
    }

    private static void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}

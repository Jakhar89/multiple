package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class ImageModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private ImageModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.currentPage("/content/page");
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/image/v3/image");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/image", props);
        ctx.load().json("/models/image/component.json", "/content/page/jcr:content/image");
    }


    @Test
    void testIfImageItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndCaptionTypeIsDefault() {
        ctx.currentResource("/content/page/jcr:content/image/captionDefault");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("captionDefault", model.getCaptionType());
            assertNull(model.getDownloadLabel());
            assertNull(model.getDownloadReference());
        });
    }

    @Test
    void testIfDataLayerIsPopulatedWhenDataLayerConfigIsEnabledAndCaptionTypeIsDefault() {
        ctx.currentResource("/content/page/jcr:content/image/captionDefault");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testIfDataLayerIsPopulatedWhenDataLayerConfigIsEnabledAndCaptionTypeIsDefaultWithDownloadReference() {
        ctx.currentResource("/content/page/jcr:content/image/captionDefaultWithDownloadReference");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testIfImageItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndCaptionTypeIsDownload() {
        ctx.currentResource("/content/page/jcr:content/image/captionDownload");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Asset Label", model.getDownloadLabel());
            assertEquals("captionDownload", model.getCaptionType());
            assertEquals("/content/dam/digital-id-web-terms-of-use.pdf", model.getDownloadReference());
        });
    }

    @Test
    void testIfDataLayerIsPopulatedWhenDataLayerConfigIsEnabledAndCaptionTypeIsDownload() {
        ctx.currentResource("/content/page/jcr:content/image/captionDownload");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/image/datalayer.json"), model.getDataLayer());
        });
    }

    @Test
    void testGetDataWhenDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/image/v3/image");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/image", props);
        ctx.load().json("/models/image/component.json", "/content/page/jcr:content/image");
        ctx.currentResource("/content/page/jcr:content/image/captionDefault");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testGetSizeIfImageItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndCaptionTypeIsDefault() {
        ctx.load().json("/models/image/asset.json", "/content/dam/digital-id-web-terms-of-use.pdf");
        ctx.currentResource("/content/page/jcr:content/image/captionDefault");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getSize());
        });
    }

    @Test
    void testGetSizeIfImageItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndCaptionTypeIsDownload() {
        ctx.load().json("/models/image/asset.json", "/content/dam/digital-id-web-terms-of-use.pdf");
        ctx.currentResource("/content/page/jcr:content/image/captionDownload");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("(238 KB)", model.getSize());
        });
    }

    @Test
    void testGetSizeIfImageItemsAreInstantiatedAsExpectedWhenFileReferenceIsNullAndCaptionTypeIsDownload() {
        ctx.currentResource("/content/page/jcr:content/image/captionDownload");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getSize());
        });
    }

    @Test
    void testGetSizeWhenAllValuesAreInjectedAndCaptionTypeIsDownloadAndShowPdfAttachmentSizeIsDisabled() {
        ctx.load().json("/models/image/asset.json", "/content/dam/digital-id-web-terms-of-use.pdf");
        ctx.currentResource("/content/page/jcr:content/image/captionDownloadWithDisableAttachmentSize");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getSize());
        });
    }

    @Test
    void testGetSizeIfImageItemsAreInstantiatedAsExpectedWhenDownloadAssetExistsNone() {
        ctx.load().json("/models/image/nonexistentasset.json", "/content/dam/digital-id-web-terms-of-use.pdf");
        ctx.currentResource("/content/page/jcr:content/image/captionDownload");
        model = ctx.request().adaptTo(ImageModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getSize());
        });
    }

}

package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.commons.Externalizer;
import io.wcm.testing.mock.aem.MockExternalizer;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(AemContextExtension.class)
public class SitemapLinkExternalizerImplTest {

    private SitemapLinkExternalizerImpl sitemapLinkExternalizer;

    private final AemContext ctx = AppAemContext.newAemContext();

    private Externalizer externalizer;

    @BeforeEach
    void setUp() throws IOException {
        sitemapLinkExternalizer = new SitemapLinkExternalizerImpl();

        Dictionary<String, String[]> domainMapperProps = new Hashtable<>();
        String[] domainsJson = {
                "{\"name\":\"collectables\",\"paths\":[\"/content/collectables/au/en\",\"/content/dam/collectables\"]}",
                "{\"name\":\"auspost\",\"paths\":[\"/content/auspost/au/en\",\"/content/dam/auspost\"]}"
        };
        domainMapperProps.put("domains", domainsJson);

        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AuspostDomainMapperServiceImpl")
                .update(domainMapperProps);

        Optional.ofNullable(ctx.getService(Externalizer.class)).ifPresent((externalizer -> {
            if (externalizer instanceof MockExternalizer) {
                ((MockExternalizer) externalizer).setMapping("collectables", "https://collectables.auspost.com.au");
                ((MockExternalizer) externalizer).setMapping("auspost", "https://auspost.com.au");
                ((MockExternalizer) externalizer).setMapping("publish", "http://localhost:4503");
            }
        }));

        ctx.registerInjectActivateService(AuspostDomainMapperServiceImpl.class);
        sitemapLinkExternalizer = new SitemapLinkExternalizerImpl();
        sitemapLinkExternalizer = ctx.registerInjectActivateService(SitemapLinkExternalizerImpl.class);
    }

    @Test
    void testExternalizeWithSlingHttpServletRequestWithAuspostPage() {
        String location = "/content/auspost/au/en/test";
        SlingHttpServletRequest request = ctx.request();
        assertEquals("https://auspost.com.au/content/auspost/au/en/test",
                sitemapLinkExternalizer.externalize(request, location));
    }

    @Test
    void testExternalizeWithSlingHttpServletRequestWithDummyPage() {
        String location = "/content/dummy/test";
        SlingHttpServletRequest request = ctx.request();
        assertEquals("http://localhost:4503/content/dummy/test",
                sitemapLinkExternalizer.externalize(request, location));
    }

    @Test
    void testExternalizeWithSlingHttpServletRequestWithCollectablesPage() {
        String location = "/content/collectables/au/en/test";
        SlingHttpServletRequest request = ctx.request();
        assertEquals("https://collectables.auspost.com.au/content/collectables/au/en/test",
                sitemapLinkExternalizer.externalize(request, location));
    }


    @Test
    void testExternalizeWithSlingHttpServletRequestWithAuspostAsset() {
        String location = "/content/dam/auspost/test";
        SlingHttpServletRequest request = ctx.request();
        assertEquals("https://auspost.com.au/content/dam/auspost/test",
                sitemapLinkExternalizer.externalize(request, location));
    }

    @Test
    void testExternalizeWithSlingHttpServletRequestWithCollectablesAsset() {
        String location = "/content/dam/collectables/test";
        SlingHttpServletRequest request = ctx.request();
        assertEquals("https://collectables.auspost.com.au/content/dam/collectables/test",
                sitemapLinkExternalizer.externalize(request, location));
    }

    @Test
    void testExternalizeWithResourceWithAuspostPage() {
        String path = "/content/auspost/au/en/resource";
        ctx.create().resource(path);
        Resource resource = ctx.resourceResolver().getResource(path);
        Assertions.assertNotNull(resource);
        String result = sitemapLinkExternalizer.externalize(resource);
        assertEquals("https://auspost.com.au/content/auspost/au/en/resource", result);
    }

    @Test
    void testExternalizeWithResourceWithCollectables() {
        String path = "/content/collectables/au/en/resource";
        ctx.create().resource(path);
        Resource resource = ctx.resourceResolver().getResource(path);
        Assertions.assertNotNull(resource);
        String result = sitemapLinkExternalizer.externalize(resource);
        assertEquals("https://collectables.auspost.com.au/content/collectables/au/en/resource", result);
    }

    @Test
    void testExternalizeWithResourceResolverWithAuspost(AemContext context) {
        String location = "/content/auspost/au/en/page1";
        String result = sitemapLinkExternalizer.externalize(context.resourceResolver(), location);
        assertEquals("https://auspost.com.au/content/auspost/au/en/page1", result);
    }

    @Test
    void testExternalizeWithResourceResolverWithCollectables(AemContext context) {
        String location = "/content/collectables/au/en/page1";
        String result = sitemapLinkExternalizer.externalize(context.resourceResolver(), location);
        assertEquals("https://collectables.auspost.com.au/content/collectables/au/en/page1", result);
    }

}

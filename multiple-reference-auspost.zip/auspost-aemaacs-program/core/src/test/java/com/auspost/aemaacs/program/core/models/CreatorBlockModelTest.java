package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class CreatorBlockModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private CreatorBlockModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/creatorblock/component.json", "/content/page/jcr:content/root");
        ctx.contentPolicyMapping("auspost-aemaacs-program/components/creatorblock",
                "facebookShareUrlPrefix", "https://www.facebook.com/sharer/sharer.php?u=",
                "linkedInShareUrlPrefix", "https://www.linkedin.com/feed/?shareActive=true&amp;shareUrl=",
                "xShareUrlPrefix", "https://twitter.com/intent/tweet?text=");
        model = ctx.request().adaptTo(CreatorBlockModel.class);
    }

    @Test
    void testIfAllCreatorBlockItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/root/creator-block-with-valid-image");
        model = ctx.request().adaptTo(CreatorBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Lorem ipsum", model.getAuthorName());
            assertEquals("Author", model.getAuthorTitle());
            assertEquals("123", model.getId());
            assertEquals("Share this article", model.getSocialShareTitle());
            assertEquals("Author Description", model.getAuthorDescription());
            assertNotNull(model.getAuthorImage());
            assertTrue(model.getAuthorImage().isResourceType(Constants.RT_IMAGE));
            assertEquals("https://www.facebook.com/sharer/sharer.php?u=http://localhost:4503/content/page.html",
                    model.getFacebookLink().getURL());
            assertEquals("https://twitter.com/intent/tweet?text=http://localhost:4503/content/page.html",
                    model.getXLink().getURL());
            assertEquals(
                    "https://www.linkedin.com/feed/?shareActive=true&amp;shareUrl=http://localhost:4503/content/page.html",
                    model.getLinkedInLink().getURL());
            assertEquals("/content/page/jcr:content/root/creator-block-with-valid-image/cq:featuredimage",
                    model.getAuthorImage().getPath());
        });
    }

    @Test
    void testIfGetAuthorImageIsNullWhenImageIsDeemedInvalid() {
        ctx.currentResource("/content/page/jcr:content/root/creator-block-with-invalid-image");
        model = ctx.request().adaptTo(CreatorBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getAuthorImage());
        });
    }
}

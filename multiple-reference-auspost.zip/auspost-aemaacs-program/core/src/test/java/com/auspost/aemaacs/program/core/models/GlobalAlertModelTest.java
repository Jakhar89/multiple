package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.wcm.style.ComponentStyleInfo;
import com.adobe.cq.wcm.style.ContentPolicyStyleInfo;
import com.adobe.cq.wcm.style.StyleInfo;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Collections;
import java.util.List;
import java.util.function.Function;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@ExtendWith(AemContextExtension.class)
class GlobalAlertModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private GlobalAlertModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/globalalert/component.json", "/content/page/jcr:content/globalalert");
        // Register adapter manually: Resource -> ComponentStyleInfo
        registerStyleInfoAdapter("information");
    }

    private void registerStyleInfoAdapter(String cssClass) {
        ctx.registerAdapter(Resource.class, ComponentStyleInfo.class,
                (Function<Resource, ComponentStyleInfo>) resource -> new ComponentStyleInfo() {
                    @Override
                    public @Nullable ContentPolicyStyleInfo getContentPolicyStyleInfo() {
                        return null;
                    }

                    @Override
                    public @NotNull List<StyleInfo> getAppliedStyles() {
                        return Collections.emptyList();
                    }

                    @Override
                    public @Nullable String getAppliedCssClasses() {
                        return cssClass;
                    }

                    @Override
                    public @Nullable String getAppliedHtmlElement() {
                        return null;
                    }
                });
    }

    @Test
    void testIfGlobalAlertModelInstantiatedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/globalalert/globalalertallproperties");
        model = ctx.request().adaptTo(GlobalAlertModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("globalalert-345355", model.getId());
            assertEquals("Global alert message text", model.getAlertMessage());
            String dataLayerJson = model.getDataLayer();
            assertNotNull(dataLayerJson);
            assertTrue(dataLayerJson.contains("information"));
        });
    }

    @Test
    void testIfGlobalAlertModelInstantiatedWhenNoValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/globalalert/globalalertwithnoproperties");
        model = ctx.request().adaptTo(GlobalAlertModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("globalalert-ee683b739d", model.getId());
            assertNull(model.getAlertMessage());
        });
    }

    @Test
    void testIfGlobalAlertModelAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndEnableDataLayerIsFalse() {
        ctx.currentResource("/content/page/jcr:content/globalalert/globalalertdisabledatalayer");
        model = ctx.request().adaptTo(GlobalAlertModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals("Global alert message text", model.getAlertMessage());
        });
    }

    @Test
    void testIfGlobalAlertModelAsExpectedWhenAllValuesAreInjectedAndEnableDataLayerIsTrue() {
        ctx.currentResource("/content/page/jcr:content/globalalert/globalalertallproperties");
        model = ctx.request().adaptTo(GlobalAlertModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Global alert message text", model.getAlertMessage());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/globalalert/datalayer.json"),
                    model.getDataLayer());
        });
    }

    @Test
    void testIfTabItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndEnableDataLayerIsTrueButDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();

        ctx.load().json("/models/globalalert/component.json", "/content/page/jcr:content/globalalert");
        ctx.currentResource("/content/page/jcr:content/globalalert/globalalertallproperties");
        model = ctx.request().adaptTo(GlobalAlertModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }

    @Test
    void testAppliedCssAndLabel() {
        ComponentStyleInfo styleInfo = mock(ComponentStyleInfo.class);
        StyleInfo style = mock(StyleInfo.class);
        when(style.getLabel()).thenReturn("Red Bar");
        when(style.getCssClasses()).thenReturn("alert--red");
        when(styleInfo.getAppliedCssClasses()).thenReturn("alert--red");
        when(styleInfo.getAppliedStyles()).thenReturn(Collections.singletonList(style));
    }
}

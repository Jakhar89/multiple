package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.IOException;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.testcontext.AppAemContext.newAemContextWithDataLayerDisabled;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class FooterModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private FooterModel model;

    @BeforeEach
    void setUp() {
        // create a page (page is needed for Link processing) while loading the component config via the json stub
        ctx.create().page("/content/page");
        ctx.load().json("/models/footer/component.json", "/content/page/jcr:content/footer");
        ctx.currentResource("/content/page/jcr:content/footer");
        model = ctx.request().adaptTo(FooterModel.class);
    }

    @Test
    void testIfAllFooterItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        assertAll(() -> {
            assertEquals("http://localhost:4503/content/dam/collectables/auspostlogo.png",
                    model.getDesktopLogo().getExternalIconReference());
            assertEquals("http://localhost:4503/content/dam/collectables/auspostlogo.png",
                    model.getTabletLogo().getExternalIconReference());
            assertEquals("http://localhost:4503/content/dam/collectables/auspostlogo.png",
                    model.getMobileLogo().getExternalIconReference());
            assertEquals("/content/page.html", model.getLogoLink().getURL());
            assertEquals("Logo alt", model.getLogoAlt());
            assertEquals("/content/page.html", model.getPrimaryLinks().getFirst().getParentLink().getURL());
            assertEquals("/content/page.html", model.getPrimaryLinks().getFirst().getChildLinks().getFirst().getURL());
            assertEquals("/content/page.html", model.getPromoCards().getFirst().getPromoLink().getURL());
            assertEquals("/content/page.html", model.getSecondaryLinks().getFirst().getURL());
            assertEquals("facebook", model.getSocialLinks().getFirst().getIcon());
            assertEquals("http://localhost:4503/content/dam/collectables/ap-acknowledgement-logos.svg",
                    model.getFootnoteLogo().getExternalIconReference());
            assertEquals("some footnote", model.getFootnote());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/footer/datalayer/footer.json"),
                    model.getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/footer/datalayer/promocard.json"),
                    model.getPromoCards().getFirst().
                            getPromoLink().getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/footer/datalayer/parentlink.json"),
                    model.getPrimaryLinks().getFirst().
                            getParentLink().getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/footer/datalayer/childlink.json"),
                    model.getPrimaryLinks().getFirst().
                            getChildLinks().getFirst().getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/footer/datalayer/secondarylink.json"),
                    model.getSecondaryLinks().get(1).
                            getDataLayer());
        });
    }

    @Test
    void testIfAllFooterItemsAreInstantiatedAsExpectedWhenOnlySomeValuesAreInjected() {
        // create a page and resource locally to mimic a specific scenario of the component for testing
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "footer", "footnote", "some footnote", "enableDataLayer",
                "true");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(FooterModel.class);
        // do the assertions
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getDesktopLogo());
            assertNull(model.getMobileLogo());
            assertNull(model.getTabletLogo());
            assertNull(model.getLogoLink());
            assertNull(model.getPrimaryLinks());
            assertNull(model.getSecondaryLinks());
            assertNull(model.getSecondaryLinks());
            assertNull(model.getSocialLinks());
            assertNull(model.getPromoCards());
            assertNull(model.getFootnoteLogo());
            assertEquals("{\"-3f42c26416\":{\"event\":\"site_interaction\",\"eventCategory\":\"footer||view\"," +
                            "\"eventDescription\":\"\"}}",
                    model.getDataLayer());
            assertEquals("some footnote", model.getFootnote());
        });
    }

    @Test
    void testIfDataLayerIsNotPopulatedWhenDataLayerConfigIsDisabledWhenOnlySomeValuesAreInjected() throws IOException {
        // create a new context to mimic the disabled state of data layer
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        // create a page and resource locally to mimic a specific scenario of the component for testing
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "footer", "footnote", "some footnote");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(FooterModel.class);
        assertEquals(EMPTY, Objects.requireNonNull(model).getDataLayer());
    }

    @Test
    void testIfDataLayerIsNotPopulatedWhenDataLayerConfigIsDisabledWhenAllValuesAreInjected() {
        AemContext ctx = newAemContextWithDataLayerDisabled();
        ctx.load().json("/models/footer/component.json", "/content/page/jcr:content/footer");
        ctx.currentResource("/content/page/jcr:content/footer");
        model = ctx.request().adaptTo(FooterModel.class);
        assertEquals(EMPTY, Objects.requireNonNull(model).getDataLayer());
    }

}

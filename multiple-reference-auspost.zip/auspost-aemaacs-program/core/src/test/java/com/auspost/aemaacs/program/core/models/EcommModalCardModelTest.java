package com.auspost.aemaacs.program.core.models;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.auspost.aemaacs.program.core.pojos.EcommModalCardGraphItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class EcommModalCardModelTest {

  private final AemContext ctx = AppAemContext.newAemContext();

  private EcommModalCardModel model;

  @BeforeEach
  void setUp() {
    ctx.create().page("/content/page");
    ctx
      .load()
      .json(
        "/models/ecommmodalcard/component.json",
        "/content/page/jcr:content/content"
      );
    ctx.currentResource("/content/page/jcr:content/content/ecommmodalcard");
    model = ctx.request().adaptTo(EcommModalCardModel.class);
  }

  @Test
  void testModalCardFieldsAreInjected() {
    assertAll(() -> {
      assertNotNull(model);
      assertEquals("Modal title", model.getTitle());
      assertEquals("<p>Modal description</p>", model.getDescription());
      assertEquals("graph", model.getMediaType());
      assertEquals("bar", model.getGraphType());
      assertEquals("left", model.getMediaAlignment());
      assertEquals("default", model.getVariant());
      assertEquals(82.6d, model.getMaxValue());
      assertNotNull(model.getCardImage());
      assertEquals(
        "/content/dam/collectables/modal-card.jpg",
        model.getCardImage().getValueMap().get("fileReference")
      );
      assertEquals(
        "Modal card image",
        model.getCardImage().getValueMap().get("alt")
      );

      List<EcommModalCardGraphItem> items = model.getItems();
      assertEquals(2, items.size());
      assertEquals("$", items.getFirst().getPrefix());
      assertEquals("B", items.getFirst().getSuffix());
      assertEquals(82.6d, items.getFirst().getValue());
      assertEquals("2025", items.getFirst().getLabel());
    });
  }

  @Test
  void testBuildBarWidthsReturnsWhenItemsNull() throws Exception {
    EcommModalCardModel plainModel = new EcommModalCardModel();
    setField(plainModel, "maxValue", 10d);
    setField(plainModel, "items", null);

    invokeBuildBarWidths(plainModel);
  }

  @Test
  void testBuildBarWidthsReturnsWhenMaxValueNull() throws Exception {
    EcommModalCardGraphItem item = new EcommModalCardGraphItem();
    setField(item, "value", 10d);

    EcommModalCardModel plainModel = new EcommModalCardModel();
    setField(plainModel, "maxValue", null);
    setField(plainModel, "items", List.of(item));

    invokeBuildBarWidths(plainModel);
    assertNull(item.getBarWidth());
  }

  @Test
  void testBuildBarWidthsReturnsWhenMaxValueZero() throws Exception {
    EcommModalCardGraphItem item = new EcommModalCardGraphItem();
    setField(item, "value", 10d);

    EcommModalCardModel plainModel = new EcommModalCardModel();
    setField(plainModel, "maxValue", 0d);
    setField(plainModel, "items", List.of(item));

    invokeBuildBarWidths(plainModel);
    assertNull(item.getBarWidth());
  }

  @Test
  void testBuildBarWidthsSkipsNullItemsAndNullValues() throws Exception {
    EcommModalCardGraphItem nullValueItem = new EcommModalCardGraphItem();
    setField(nullValueItem, "value", null);

    EcommModalCardGraphItem valuedItem = new EcommModalCardGraphItem();
    setField(valuedItem, "value", 10d);

    EcommModalCardModel plainModel = new EcommModalCardModel();
    setField(plainModel, "maxValue", 20d);
    setField(
      plainModel,
      "items",
      Arrays.asList(null, nullValueItem, valuedItem)
    );

    invokeBuildBarWidths(plainModel);
    assertNull(nullValueItem.getBarWidth());
    assertEquals(50, valuedItem.getBarWidth());
  }

  private static void invokeBuildBarWidths(EcommModalCardModel model)
    throws Exception {
    Method method = EcommModalCardModel.class.getDeclaredMethod(
      "buildBarWidths"
    );
    method.setAccessible(true);
    method.invoke(model);
  }

  private static void setField(Object target, String fieldName, Object value)
    throws Exception {
    Field field = target.getClass().getDeclaredField(fieldName);
    field.setAccessible(true);
    field.set(target, value);
  }
}

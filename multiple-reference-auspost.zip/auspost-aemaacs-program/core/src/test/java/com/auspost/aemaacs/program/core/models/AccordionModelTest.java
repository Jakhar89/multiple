package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.scripting.SlingBindings;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class AccordionModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private AccordionModel model;

    @BeforeEach
    void setUp() {
        Map<String, Object>
                props = Map.of("sling:resourceSuperType", "core/wcm/components/accordion/v1/accordion");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/accordion", props);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/text");
        ctx.load().json("/models/accordion/component.json", "/content/home/jcr:content/accordion");
        ctx.currentResource("/content/home/jcr:content/accordion");

        // Mock style and register in SlingBindings
        Style style = mock(Style.class);
        SlingBindings bindings = new SlingBindings();
        bindings.put(WCMBindingsConstants.NAME_CURRENT_STYLE, style);
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(AccordionModel.class);
    }

    @Test
    void testAccordionWhenDataLayerDisabled() {
        try (var mocked = mockStatic(DataLayerUtils.class)) {
            mocked.when(() -> DataLayerUtils.isDataLayerEnabled(ctx.currentResource())).thenReturn(false);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals(1, model.getAccordionItems().size());
            assertNull(model.getAccordionItems().getFirst().getDataLayer());
        }
    }

    @Test
    void testAccordionWhenDataLayerEnabled() {
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals(1, model.getAccordionItems().size());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/accordion/datalayer.json"),
                    model.getAccordionItems().getFirst().getDataLayer());
        });
    }
}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedConstruction;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.when;

/**
 * @author Sathish Balan
 */
@ExtendWith(AemContextExtension.class)
class CurrencyConverterModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private CurrencyConverterModel model;

    @BeforeEach
    void setUp() throws IOException {
        // create stubs and load the json representation of the component
        ctx.create().page("/content/page");
        ctx.load().json("/models/currencyconverter/component.json", "/content/page/jcr:content/currencyconverter");
        ctx.currentResource("/content/page/jcr:content/currencyconverter");
        // inject an OSGi config to mimic a real one during runtime
        ConfigurationAdmin configAdmin = ctx.getService(ConfigurationAdmin.class);
        Dictionary<String, Object> props = new Hashtable<>() {{
            put("authKey", "some random authKey");
            put("apiUrl", "some random apiUrl");
        }};
        Objects.requireNonNull(configAdmin).getConfiguration(CurrencyConverterModel.PID_CONFIG).update(props);
        // instantiate the model
        model = ctx.request().adaptTo(CurrencyConverterModel.class);
    }

    @Test
    void testIfAllCurrencyConverterItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        assertAll(() -> {
            assertEquals("some random apiUrl", model.getApiUrl());
            assertEquals("some random authKey", model.getAuthKey());
            assertEquals("Please enter an amount less than $30,000.00", model.getCcAlertMessage());
            assertEquals("Amount", model.getCcLabelAmount());
            assertEquals("A to Z Index", model.getCcLabelAtoZindex());
            assertEquals("Available product", model.getCcLabelAvailableProduct());
            assertEquals("Currency converter", model.getCcLabelCurrencyConverter());
            assertEquals("Destination Currency", model.getCcLabelDestinationCurrency());
            assertEquals("How to buy", model.getCcLabelHowToBuy());
            assertEquals("Popular currencies", model.getCcLabelPopularCurrencies());
            assertEquals("Rate", model.getCcLabelRate());
            assertEquals("1 AUD buys", model.getCcLabelRateInAud());
            assertEquals("Currency converter", model.getCurrencyCodeHeading());
            assertEquals("Random currency code sub heading", model.getCurrencyCodeSubHeading());
            assertEquals("/content/auspost/au/en/footer-test2", model.getSubmissionAction());
            assertEquals("What would you like to convert?", model.getCcWidgetBarTitle());
            assertEquals("Go", model.getCcWidgetButtonTitle());
            assertEquals("Convert $", model.getCcWidgetBarLabel());
            assertEquals("1 AUD", model.getCcWidgetBarPlaceholderText());
            assertEquals("To", model.getCcLabelToCurrency());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/currencyconverter/datalayer.json"),
                    model.getData());
        });
    }

    @Test
    void testIfDataLayerStringIsEmptyWhenDataLayerIsDisabled() throws IOException {
        // create a new context to mimic the disabled state of data layer
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        // create a page and resource locally to mimic a specific scenario of the component for testing
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "currencyconverter", "Go", "ccWidgetButtonTitle");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(CurrencyConverterModel.class);
        // do the assertion
        assertEquals(EMPTY, Objects.requireNonNull(model).getData());
    }

    @Test
    void testIfDataLayerStringIsEmptyWhenAJsonProcessingExceptionOccurs() {
        // mock the ObjectMapper construction to mimic the exception on method call
        try (MockedConstruction<ObjectMapper> mc = mockConstruction(ObjectMapper.class, (mock, context) -> {
            doThrow(JsonProcessingException.class).when(mock).writeValueAsString(any());
        })) {
            assertEquals(EMPTY, model.getData());
        }
    }

    @Test
    void testIfEmptyValuesAreReturnedFromConfigWhenTheProvidedConfigKeyIsUnavailable() throws IOException {
        // inject an OSGi config to mimic a real one without apiUrl during runtime
        ConfigurationAdmin configAdmin = ctx.getService(ConfigurationAdmin.class);
        Dictionary<String, Object> props = new Hashtable<>() {{
            put("authKey", "some random authKey");
        }};
        Objects.requireNonNull(configAdmin).getConfiguration(CurrencyConverterModel.PID_CONFIG).update(props);
        // do the assertion
        assertEquals(EMPTY, model.getApiUrl());
    }

    @Test
    void testIfEmptyValueIsReturnedForApiUrlWhenAnIOExceptionOccurs() throws IOException {
        // create a mock ConfigurationAdmin to mimic an IOException scenario
        ConfigurationAdmin mockCa = mock(ConfigurationAdmin.class);
        when(mockCa.getConfiguration(CurrencyConverterModel.PID_CONFIG)).thenThrow(IOException.class);
        // register the mocked ConfigurationAdmin with a pretty high service ranking
        ctx.registerService(ConfigurationAdmin.class, mockCa, org.osgi.framework.Constants.SERVICE_RANKING, 1000);
        // instantiate the model again to start fresh
        model = ctx.request().adaptTo(CurrencyConverterModel.class);
        // do the assertion
        assertEquals(EMPTY, Objects.requireNonNull(model).getApiUrl());
        // replacing previous stubbing to prevent AemContextExtension tearDown failure
        when(mockCa.getConfiguration(anyString())).thenReturn(mock(Configuration.class));
        // registering the new stub with an ever higher ranking to ensure successful tearDown of AemContext
        ctx.registerService(ConfigurationAdmin.class, mockCa, org.osgi.framework.Constants.SERVICE_RANKING, 2000);
    }

    @Test
    void testIfEmptyValueIsReturnedForAuthKeyWhenAnIOExceptionOccurs() throws IOException {
        // create a mock ConfigurationAdmin to mimic an IOException scenario
        ConfigurationAdmin mockCa = mock(ConfigurationAdmin.class);
        when(mockCa.getConfiguration(CurrencyConverterModel.PID_CONFIG)).thenThrow(IOException.class);
        // register the mocked ConfigurationAdmin with a pretty high service ranking
        ctx.registerService(ConfigurationAdmin.class, mockCa, org.osgi.framework.Constants.SERVICE_RANKING, 1000);
        // instantiate the model again to start fresh
        model = ctx.request().adaptTo(CurrencyConverterModel.class);
        // do the assertion
        assertEquals(EMPTY, Objects.requireNonNull(model).getAuthKey());
        // replacing previous stubbing to prevent AemContextExtension tearDown failure
        when(mockCa.getConfiguration(anyString())).thenReturn(mock(Configuration.class));
        // registering the new stub with an ever higher ranking to ensure successful tearDown of AemContext
        ctx.registerService(ConfigurationAdmin.class, mockCa, org.osgi.framework.Constants.SERVICE_RANKING, 2000);
    }
}

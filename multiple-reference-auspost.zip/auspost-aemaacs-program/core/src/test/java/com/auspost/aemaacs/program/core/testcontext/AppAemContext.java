/*
 *  Copyright 2021 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.auspost.aemaacs.program.core.testcontext;

import com.day.cq.commons.jcr.JcrConstants;
import com.fasterxml.jackson.databind.json.JsonMapper;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextBuilder;
import io.wcm.testing.mock.aem.junit5.AemContextCallback;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.resource.filter.ResourceFilterStream;
import org.apache.sling.resource.filter.impl.ResourcePredicateImpl;
import org.apache.sling.testing.mock.sling.ResourceResolverType;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.function.Function;

import static com.adobe.cq.wcm.core.components.testing.mock.ContextPlugins.CORE_COMPONENTS;
import static org.apache.sling.testing.mock.caconfig.ContextPlugins.CACONFIG;

/**
 * Sets up {@link AemContext} for unit tests in this application.
 */
public final class AppAemContext {


    private final static String DATA_LAYER_CONFIG_PATH =
            "/conf/global/sling:configs/com.adobe.cq.wcm.core.components.internal.DataLayerConfig";

    /**
     * Custom set up rules required in all unit tests.
     */
    private static final AemContextCallback SETUP_CALLBACK = ctx -> {
        // custom project initialization code for every unit test
        // enable data layer to test getData methods on most components
        ctx.create().resource(DATA_LAYER_CONFIG_PATH, new HashMap<>() {{
            put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
            put("enabled", true);
        }});
        // register adapter for Resource -> ResourceFilterStream
        ctx.registerAdapter(
                Resource.class,
                ResourceFilterStream.class,
                (Function<Resource, ResourceFilterStream>) r -> new ResourceFilterStream(r, new ResourcePredicateImpl())
        );
    };

    /**
     * Custom set up rules required in all unit tests.
     */
    private static final AemContextCallback SETUP_CALLBACK_WITH_DATA_LAYER_DISABLED = ctx -> {
        // custom project initialization code for every unit test
        // enable data layer to test getData methods on most components
        ctx.create().resource(DATA_LAYER_CONFIG_PATH, new HashMap<>() {{
            put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
            put("enabled", false);
        }});
    };

    private AppAemContext() {
        // static methods only
    }

    /**
     * @return {@link AemContext}
     */
    public static AemContext newAemContext() {
        return newAemContextBuilder().build();
    }

    /**
     * @return {@link AemContext}
     */
    public static AemContext newAemContextWithDataLayerDisabled() {
        return newAemContextBuilder(ResourceResolverType.RESOURCERESOLVER_MOCK, SETUP_CALLBACK_WITH_DATA_LAYER_DISABLED)
                .build();
    }


    /**
     * @return {@link AemContextBuilder}
     */
    public static AemContextBuilder newAemContextBuilder() {
        return newAemContextBuilder(ResourceResolverType.RESOURCERESOLVER_MOCK);
    }

    /**
     * @return {@link AemContextBuilder}
     */
    public static AemContextBuilder newAemContextBuilder(ResourceResolverType resourceResolverType) {
        return new AemContextBuilder()
                .plugin(CACONFIG)
                .plugin(CORE_COMPONENTS)
                .afterSetUp(SETUP_CALLBACK);
    }

    /**
     * @return {@link AemContextBuilder}
     */
    public static AemContextBuilder newAemContextBuilder
    (ResourceResolverType resourceResolverType, AemContextCallback aemContextCallback) {
        return new AemContextBuilder()
                .plugin(CACONFIG)
                .plugin(CORE_COMPONENTS)
                .afterSetUp(aemContextCallback);
    }

    /**
     * Retrieves the expected Data Layer JSON for a given component.
     *
     * @param path the resource path of the Data Layer JSON.
     * @return The JSON string for the specified component.
     * @throws IOException If an error occurs while reading the resource stream.
     */
    public static String getExpectedDataLayerJson(String path) throws IOException {
        try (InputStream is = AppAemContext.class.getResourceAsStream(path)) {
            return new JsonMapper().readTree(is).toString();
        }
    }

}

package com.auspost.aemaacs.program.core.servlets;

import com.adobe.granite.ui.components.ds.DataSource;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import lombok.extern.slf4j.Slf4j;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@Slf4j
@ExtendWith({AemContextExtension.class})
class ContentFragmentDataSourceServletTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    ContentFragmentDataSourceServlet servlet;

    ResourceResolverFactory resolverFactory;

    ResourceResolver resourceResolver;


    @BeforeEach
    void setUp() {
        resolverFactory =
                Mockito.mock(ResourceResolverFactory.class);
        resourceResolver =
                Mockito.mock(ResourceResolver.class);
        ctx.registerService(ResourceResolverFactory.class, resolverFactory);
        servlet = ctx.registerInjectActivateService(new ContentFragmentDataSourceServlet());
    }


    @Test
    void testContentFragmentReturnsValidDatasource() {
        Map<String, Object> selectProps = new HashMap<>();
        selectProps.put("sling:resourceType", "granite/ui/components/foundation/form/select");
        selectProps.put("contentFragmentPath", "/content/dam/content-fragments/forms/sf-form-fields-fragment");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select", selectProps);

        Map<String, Object> datasourceProps = Map.of(" sling:resourceType", "auspost-aemaacs-program/components/datasource/dropdownfieldslist");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select/datasource", datasourceProps);
        ctx.currentResource("/apps/auspost-aemaacs-program/components/forms/text/select");

        ctx.load().json("/servlets/salesforcefields.json", "/content/dam/content-fragments/forms/sf-form-fields-fragment");

        servlet.doGet(ctx.request(), ctx.response());
        DataSource dataSource = (DataSource) ctx.request().getAttribute(DataSource.class.getName());

        assertAll(() -> {
            assertNotNull(dataSource);
            assertTrue(dataSource.iterator().hasNext());
            for (Iterator<Resource> it = dataSource.iterator(); it.hasNext(); ) {
                Resource res = it.next();
                ValueMap vm = res.getValueMap();
                if ("FirstName".equals(vm.get("text", String.class)) &&
                        "FirstName".equals(vm.get("value", String.class))) {
                    assertTrue(true, "Expected key-value pair found in DataSource");
                    break;
                }
            }
         });
    }


    @Test
    void testContentFragmentDatasourceWithNullCFPath() {
        Map<String, Object> selectProps = new HashMap<>();
        selectProps.put("sling:resourceType", "granite/ui/components/foundation/form/select");
        selectProps.put("contentFragmentPath", null);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select", selectProps);

        Map<String, Object> datasourceProps = Map.of(" sling:resourceType", "auspost-aemaacs-program/components/datasource/dropdownfieldslist");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select/datasource", datasourceProps);
        ctx.currentResource("/apps/auspost-aemaacs-program/components/forms/text/select");

        ctx.load().json("/servlets/salesforcefields.json", "/content/dam/content-fragments/forms/sf-form-fields-fragment");

        servlet.doGet(ctx.request(), ctx.response());
        DataSource dataSource = (DataSource) ctx.request().getAttribute(DataSource.class.getName());
        assertNull(dataSource);
    }

    @Test
    void testContentFragmentDatasourceWithNonExistentCFResource() {
        Map<String, Object> selectProps = new HashMap<>();
        selectProps.put("sling:resourceType", "granite/ui/components/foundation/form/select");
        selectProps.put("contentFragmentPath", "/apps/auspost-aemaacs-program/components/forms/text/select/test");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select", selectProps);

        Map<String, Object> datasourceProps = Map.of(" sling:resourceType", "auspost-aemaacs-program/components/datasource/dropdownfieldslist");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select/datasource", datasourceProps);
        ctx.currentResource("/apps/auspost-aemaacs-program/components/forms/text/select");

        ctx.load().json("/servlets/salesforcefields.json", "/content/dam/content-fragments/forms/sf-form-fields-fragment");

        servlet.doGet(ctx.request(), ctx.response());
        DataSource dataSource = (DataSource) ctx.request().getAttribute(DataSource.class.getName());
            assertNull(dataSource);

    }

    @Test
    void testContentFragmentDatasourceWithNonExistentCFModel() {
        Map<String, Object> selectProps = new HashMap<>();
        selectProps.put("sling:resourceType", "granite/ui/components/foundation/form/select");
        selectProps.put("contentFragmentPath", "/apps/auspost-aemaacs-program/components/forms/text/select");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select", selectProps);

        Map<String, Object> datasourceProps = Map.of(" sling:resourceType", "auspost-aemaacs-program/components/datasource/dropdownfieldslist");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select/datasource", datasourceProps);
        ctx.currentResource("/apps/auspost-aemaacs-program/components/forms/text/select");

        ctx.load().json("/servlets/salesforcefields.json", "/content/dam/content-fragments/forms/sf-form-fields-fragment");

        servlet.doGet(ctx.request(), ctx.response());
        DataSource dataSource = (DataSource) ctx.request().getAttribute(DataSource.class.getName());
        assertNull(dataSource);

    }


    @Test
    void testContentFragmentDatasourceWithEmptyCFData() {
        Map<String, Object> selectProps = new HashMap<>();
        selectProps.put("sling:resourceType", "granite/ui/components/foundation/form/select");
        selectProps.put("contentFragmentPath", "/content/dam/content-fragments/forms/sf-form-fields-fragment");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select", selectProps);

        Map<String, Object> datasourceProps = Map.of(" sling:resourceType", "auspost-aemaacs-program/components/datasource/dropdownfieldslist");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/forms/text/select/datasource", datasourceProps);
        ctx.currentResource("/apps/auspost-aemaacs-program/components/forms/text/select");

        ctx.load().json("/servlets/salesforcefieldsemptydata.json", "/content/dam/content-fragments/forms/sf-form-fields-fragment");

        servlet.doGet(ctx.request(), ctx.response());
        DataSource dataSource = (DataSource) ctx.request().getAttribute(DataSource.class.getName());
        assertAll(() -> {
            assertNotNull(dataSource);
            assertFalse(dataSource.iterator().hasNext());
        });
    }
}

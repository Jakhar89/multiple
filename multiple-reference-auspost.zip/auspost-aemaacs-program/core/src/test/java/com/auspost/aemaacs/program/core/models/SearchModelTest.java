package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.services.SearchService;
import com.auspost.aemaacs.program.core.services.impl.AuspostDomainMapperServiceImpl;
import com.auspost.aemaacs.program.core.services.impl.SearchServiceImpl;
import com.auspost.aemaacs.program.core.services.impl.SearchServiceRegistry;
import com.auspost.aemaacs.program.core.utils.CommonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import wiremock.com.google.common.collect.ImmutableMap;

import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mockStatic;

@ExtendWith(AemContextExtension.class)
class SearchModelTest {

    private final AemContext context = new AemContext();

    @BeforeEach
    void setUp() {
        context.create().page("/content/auspost/au/en");
        context.create().page("/content/collectables/au/en");

        context.load().json("/models/search/component.json",
                "/content/auspost/au/en/jcr:content/root");

        context.registerInjectActivateService(
                new AuspostDomainMapperServiceImpl(),
                ImmutableMap.of(
                        "domains", new String[]{
                                "{\"name\":\"auspost\",\"paths\":[\"/content/auspost\"]}",
                                "{\"name\":\"collectables\",\"paths\":[\"/content/collectables\"]}"
                        }
                )
        );

        Map<String, SearchService> servicesMap = new HashMap<>();

        SearchService auspostService = context.registerInjectActivateService(
                new SearchServiceImpl(),
                ImmutableMap.<String, Object>builder()
                        .put("siteId", new String[]{"auspost"})
                        .put("projectId", "1059627761126")
                        .put("dataStoreId", "auspost-vtx-seo_1743636714358")
                        .put("host", "https://digitalapi2-ptest.npe.auspost.com.au")
                        .put("apiVersion", "/website-search/v1beta/projects/")
                        .put("apiVersionAutoComplete", "/website-search/v1/projects/")
                        .put("collection", "/locations/global/collections/default_collection/engines/")
                        .put("autocompleteCollection", "/locations/global/dataStores/")
                        .put("completionConfig", "/completionConfig")
                        .put("vertexEngineID", "vertex-ai_1744093322600")
                        .put("searchEndpoint", "/servingConfigs/default_search:search")
                        .put("autocompleteEndpoint", ":completeQuery")
                        .put("answerEndpoint", "/servingConfigs/default_search:answer")
                        .build()
        );
        servicesMap.put("auspost", auspostService);

        SearchService collectablesService = context.registerInjectActivateService(
                new SearchServiceImpl(),
                ImmutableMap.<String, Object>builder()
                        .put("siteId", new String[]{"collectables"})
                        .put("projectId", "1059627761126")
                        .put("dataStoreId", "collectables_1751334621778")
                        .put("host", "https://digitalapi2-ptest.npe.auspost.com.au")
                        .put("apiVersion", "/website-search/v1beta/projects/")
                        .put("apiVersionAutoComplete", "/website-search/v1/projects/")
                        .put("collection", "/locations/global/collections/default_collection/engines/")
                        .put("autocompleteCollection", "/locations/global/dataStores/")
                        .put("completionConfig", "/completionConfig")
                        .put("vertexEngineID", "auspost-collectables_1753855879141")
                        .put("searchEndpoint", "/servingConfigs/default_search:search")
                        .put("autocompleteEndpoint", ":completeQuery")
                        .put("answerEndpoint", "/servingConfigs/default_search:answer")
                        .build()
        );
        servicesMap.put("collectables", collectablesService);

        SearchServiceRegistry fakeRegistry = new SearchServiceRegistry() {
            @Override
            public String resolveSiteId(String resourcePath) {
                if (resourcePath.startsWith("/content/auspost")) return "auspost";
                if (resourcePath.startsWith("/content/collectables")) return "collectables";
                return null;
            }

            @Override
            public SearchService getBySiteId(String siteId) {
                return servicesMap.get(siteId);
            }
        };

        context.registerService(SearchServiceRegistry.class, fakeRegistry);
    }

    @Test
    void testServiceSelectedCorrectlyFromResourcePath() {
        context.currentResource("/content/auspost/au/en/jcr:content/root/search-valid");
        context.request().setResource(context.currentResource());
        SearchModel model = context.request().adaptTo(SearchModel.class);

        assertAll(
                () -> assertNotNull(model),
                () -> assertEquals("Search Title", model.getSearchTitle()),
                () -> assertEquals("Something went wrong", model.getNoResult()),
                () -> assertEquals("Search Button", model.getSearchButtonLabel()),
                () -> assertEquals("Search here", model.getSearchPlaceHolder()),
                () -> assertNotNull(model.getService()),
                () -> assertEquals("auspost", model.getService().getSiteId()),
                () -> assertNotNull(model.getId())
        );
    }

    @Test
    void testSearchModelAuspost() {
        context.currentResource("/content/auspost/au/en/jcr:content/root/search-valid");
        context.request().setResource(context.currentResource());
        SearchModel model = context.request().adaptTo(SearchModel.class);
        assertAll(
                () -> assertNotNull(model),
                () -> assertNotNull(model.getService()),
                () -> assertEquals("auspost", model.getService().getSiteId()),
                () -> assertEquals("https://digitalapi2-ptest.npe.auspost.com.au/website-search/v1beta/projects/1059627761126/locations/global/collections/default_collection/engines/vertex-ai_1744093322600/servingConfigs/default_search:search", model.getSearchUrl()),
                () -> assertEquals("https://digitalapi2-ptest.npe.auspost.com.au/website-search/v1/projects/1059627761126/locations/global/dataStores/auspost-vtx-seo_1743636714358:completeQuery", model.getBasicAutoCompleteUrl()),
                () -> assertEquals("https://digitalapi2-ptest.npe.auspost.com.au/website-search/v1beta/projects/1059627761126/locations/global/collections/default_collection/engines/vertex-ai_1744093322600/servingConfigs/default_search:answer", model.getAnswerUrl()),
                () -> assertEquals("https://digitalapi2-ptest.npe.auspost.com.au/website-search/v1/projects/1059627761126/locations/global/collections/default_collection/engines/vertex-ai_1744093322600/completionConfig:completeQuery", model.getAdvancedAutoCompleteUrl())
        );
    }

    @Test
    void testNullRequestReturnsNoService() {
        context.create().resource("/content/test");
        context.currentResource("/content/test");
        SearchModel model = context.request().adaptTo(SearchModel.class);
        assertAll(
                () -> assertNotNull(model),
                () -> assertNull(model.getService()),
                () -> assertEquals(Constants.EMPTY, model.getSearchUrl()),
                () -> assertEquals(Constants.EMPTY, model.getBasicAutoCompleteUrl()),
                () -> assertEquals(Constants.EMPTY, model.getAnswerUrl()),
                () -> assertEquals(Constants.EMPTY, model.getAdvancedAutoCompleteUrl())
        );
    }

    @Test
    void testSearchResultJsonWithAllFields() {
        context.currentResource("/content/auspost/au/en/jcr:content/root/search-valid");
        context.request().setResource(context.currentResource());

        SearchModel model = context.request().adaptTo(SearchModel.class);

        String json = model.getSearchResultJson();

        assertAll(
                () -> assertNotNull(json),
                () -> assertTrue(json.contains("\"label\":\"Search Title\"")),
                () -> assertTrue(json.contains("\"buttonText\":\"Search Button\"")),
                () -> assertTrue(json.contains("\"placeholder\":\"Search here\""))
        );
    }

    @Test
    void testSearchResultJsonReturnsEmptyWhenNoFieldsPresent() {
        context.create().resource(
                "/content/auspost/au/en/jcr:content/root/search-empty",
                "sling:resourceType", "search"
        );

        context.currentResource("/content/auspost/au/en/jcr:content/root/search-empty");
        context.request().setResource(context.currentResource());
        SearchModel model = context.request().adaptTo(SearchModel.class);

        assertEquals(Constants.EMPTY, model.getSearchResultJson());
    }

    @Test
    void testSearchResultJsonReturnsEmptyOnJsonException() {
        context.currentResource("/content/auspost/au/en/jcr:content/root/search-valid");
        context.request().setResource(context.currentResource());

        try (MockedStatic<CommonUtils> mocked = mockStatic(CommonUtils.class)) {
            mocked.when(() -> CommonUtils.addToMapIfNotBlank(anyMap(), anyString(), any()))
                    .thenCallRealMethod();

            mocked.when(() -> CommonUtils.writeJson(anyMap()))
                    .thenThrow(new JsonProcessingException("error") {});

            SearchModel model = context.request().adaptTo(SearchModel.class);

            assertEquals(Constants.EMPTY, model.getSearchResultJson());
        }
    }
}


package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.utils.CommonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(AemContextExtension.class)
class EcommSuggestedSearchModelTest {

    private final AemContext context = new AemContext();

    @BeforeEach
    void setUp() {
        context.create().page("/content/auspost/au/en/test");
        context.load().json("/models/ecommsearch/component.json",
            "/content/auspost/au/en/test/jcr:content/root");
    }

    @Test
    void testSuggestedSearchJsonIncludesLabelOnlyEntries() throws Exception {
        context.currentResource("/content/auspost/au/en/test/jcr:content/root/container/container/ecommsearch");
        context.request().setResource(context.currentResource());
        EcommSuggestedSearchModel model = context.request().adaptTo(EcommSuggestedSearchModel.class);

        assertNotNull(model);
        JsonNode suggestedSearch = new ObjectMapper().readTree(model.getSuggestedSearchJson());
        assertEquals("Suggested Search", suggestedSearch.get(Constants.TITLE).asText());
        JsonNode items = suggestedSearch.get("items");
        assertEquals(2, items.size());

        boolean foundWithLink = false;
        boolean foundLabelOnly = false;
        for (JsonNode item : items) {
            String label = item.get("label").asText();
            if ("Keyword With Link".equals(label)) {
                assertEquals("/content/auspost/au/en/personal", item.get("href").asText());
                assertEquals("_blank", item.get("target").asText());
                foundWithLink = true;
            } else if ("Keyword Only".equals(label)) {
                assertFalse(item.has("href"));
                assertFalse(item.has("target"));
                foundLabelOnly = true;
            }
        }

        assertTrue(foundWithLink);
        assertTrue(foundLabelOnly);
    }

    @Test
    void testSuggestedSearchJsonWithoutPopularSearchReturnsEmpty() {
        Resource resource = context.create().resource(
            "/content/auspost/au/en/test/jcr:content/root/container/container/ecommsearch-missing",
            "sling:resourceType", "auspost-aemaacs-program/components/ecommsearch"
        );
        context.currentResource(resource);
        context.request().setResource(resource);

        EcommSuggestedSearchModel model = context.request().adaptTo(EcommSuggestedSearchModel.class);
        assertNotNull(model);
        assertEquals(Constants.EMPTY, model.getSuggestedSearchJson());
    }

    @Test
    void testSuggestedSearchJsonReturnsEmptyWhenNoValidItems() {
        Resource resource = context.create().resource(
            "/content/auspost/au/en/test/jcr:content/root/container/container/ecommsearch-no-items",
            "sling:resourceType", "auspost-aemaacs-program/components/ecommsearch"
        );
        Resource popularSearch = context.create().resource(
            resource.getPath() + "/popularsearch",
            "jcr:primaryType", "nt:unstructured"
        );
        context.create().resource(popularSearch.getPath() + "/item-0", "label", "");
        context.create().resource(popularSearch.getPath() + "/item-1");

        context.currentResource(resource);
        context.request().setResource(resource);

        EcommSuggestedSearchModel model = context.request().adaptTo(EcommSuggestedSearchModel.class);
        assertNotNull(model);
        assertEquals(Constants.EMPTY, model.getSuggestedSearchJson());
    }

    @Test
    void testSuggestedSearchJsonWithNullResourceReturnsEmpty() {
        context.request().setResource(null);
        EcommSuggestedSearchModel model = context.request().adaptTo(EcommSuggestedSearchModel.class);

        assertNotNull(model);
        assertEquals(Constants.EMPTY, model.getSuggestedSearchJson());
    }

    @Test
    void testSuggestedSearchJsonReturnsEmptyWhenJsonProcessingFails() {
        context.currentResource("/content/auspost/au/en/test/jcr:content/root/container/container/ecommsearch");
        context.request().setResource(context.currentResource());

        try (MockedStatic<CommonUtils> mocked = Mockito.mockStatic(
            CommonUtils.class,
            Mockito.withSettings().defaultAnswer(Mockito.CALLS_REAL_METHODS)
        )) {
            mocked.when(() -> CommonUtils.writeJson(Mockito.any()))
                .thenThrow(new JsonProcessingException("serialization failed") {
                });

            EcommSuggestedSearchModel model = context.request().adaptTo(EcommSuggestedSearchModel.class);
            assertNotNull(model);
            assertEquals(Constants.EMPTY, model.getSuggestedSearchJson());
            mocked.verify(() -> CommonUtils.writeJson(Mockito.any()), Mockito.times(1));
        }
    }
}

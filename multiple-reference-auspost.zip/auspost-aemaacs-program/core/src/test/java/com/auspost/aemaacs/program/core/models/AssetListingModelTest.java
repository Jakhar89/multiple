package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.tagging.TagConstants;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import junit.framework.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static junit.framework.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class AssetListingModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private AssetListingModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/assetlisting/component.json", "/content/page/jcr:content/assetlisting");
        ctx.load().json("/models/assetlisting/tags.json", TagConstants.TAG_ROOT_PATH);
        ctx.load().json("/models/assetlisting/assets.json", "/content/dam/collectables/stamp-bulletin");
    }

    @Test
    void testIfAllAssetListingWhenCompletePropertiesAreInjectedWithOutSelectors() {
        ctx.currentResource("/content/page/jcr:content/assetlisting/withValidProperties");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test with Filter", model.getTitle());
            assertEquals("/content/dam/collectables/stamp-bulletin", model.getParentFolder());
            assertEquals("<p>No results found based on your filter selection.</p>", model.getNoResultsMessage());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("Download Now", model.getCtaLabel());
            assertEquals("/content/page", model.getResourcePath());
            assertEquals(9, model.getAssetResourceList().size());
            assertTrue(model.getAssetResourceList().getFirst().endsWith("jcr:content/metadata"));
            assertEquals(2, model.getFilters().size());
            assertEquals(6, model.getAssetListItems().size());
            assertEquals("(PDF, 5 MB)", model.getAssetListItems().getFirst().getAssetTypeAndSize());
            assertEquals(6, model.getFilteredResults());
            Assert.assertEquals(
                    "{\"assetlisting-f2466bddf5\":{\"event\":\"filtered-results\",\"eventCategory\":\"\",\"eventDescription\":\"6\"}}",
                    model.getDataLayer());
            Assert.assertEquals(
                    "{\"assetlisting-f2466bddf5\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\"," +
                            "\"eventDescription\":\"2025-mar-stamp-bulletin\"}}",
                    model.getAssetListItems().getFirst().getDataLayer());
        });
    }


    @Test
    void testIfAllAssetListingWhenCompletePropertiesAreInjectedWithOutSelectorsAndNoValidDefaultImage() {
        ctx.currentResource("/content/page/jcr:content/assetlisting/withOutValidDefaultImage");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test with Filter", model.getTitle());
            assertEquals("/content/dam/collectables/stamp-bulletin", model.getParentFolder());
            assertEquals("<p>No results found based on your filter selection.</p>", model.getNoResultsMessage());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("/content/page", model.getResourcePath());
            assertEquals("Download Now", model.getCtaLabel());
            assertEquals(9, model.getAssetResourceList().size());
            assertTrue(model.getAssetResourceList().getFirst().endsWith("jcr:content/metadata"));
            assertEquals(1, model.getFilters().size());
            assertEquals(6, model.getAssetListItems().size());
            assertEquals("9", model.getTotalNoOfAssets());
            assertEquals("(PDF, 5 MB)", model.getAssetListItems().getFirst().getAssetTypeAndSize());
            assertEquals("/content/dam/collectables/stamp-bulletin/2025/2025-stamp-bulletin-2.pdf",
                    model.getAssetListItems().getFirst().getAssetItemUrl());
            assertEquals(6, model.getFilteredResults());
            Assert.assertEquals(
                    "{\"assetlisting-8e33005c55\":{\"event\":\"filtered-results\",\"eventCategory\":\"\",\"eventDescription\":\"6\"}}",
                    model.getDataLayer());
            Assert.assertEquals(
                    "{\"assetlisting-8e33005c55\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\"," +
                            "\"eventDescription\":\"2025-mar-stamp-bulletin\"}}",
                    model.getAssetListItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testIfAllAssetListingWhenCompletePropertiesAreInjectedWithSelectors() {
        ctx.requestPathInfo().setSelectorString("2025");
        ctx.currentResource("/content/page/jcr:content/assetlisting/withValidProperties");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test with Filter", model.getTitle());
            assertEquals("/content/dam/collectables/stamp-bulletin", model.getParentFolder());
            assertEquals("<p>No results found based on your filter selection.</p>", model.getNoResultsMessage());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("/content/page", model.getResourcePath());
            assertEquals("Download Now", model.getCtaLabel());
            assertEquals(9, model.getAssetResourceList().size());
            assertTrue(model.getAssetResourceList().getFirst().endsWith("jcr:content/metadata"));
            assertEquals(2, model.getFilters().size());
            assertEquals(2, model.getAssetListItems().size());
            assertEquals("(PDF, 5 MB)", model.getAssetListItems().getFirst().getAssetTypeAndSize());
            assertEquals(2, model.getFilteredResults());
            Assert.assertEquals(
                    "{\"assetlisting-f2466bddf5\":{\"event\":\"filtered-results\",\"eventCategory\":\"2025\",\"eventDescription\":\"2\"}}",
                    model.getDataLayer());
            Assert.assertEquals(
                    "{\"assetlisting-f2466bddf5\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\"," +
                            "\"eventDescription\":\"2025-mar-stamp-bulletin\"}}",
                    model.getAssetListItems().getFirst().getDataLayer());

        });
    }

    @Test
    void testIfAllAssetListingWhenCompletePropertiesAreInjectedWithSelectorsOffSet() {
        ctx.requestPathInfo().setSelectorString("offset5");
        ctx.currentResource("/content/page/jcr:content/assetlisting/withValidPropertiesOffset");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test with Filter", model.getTitle());
            assertEquals("/content/dam/collectables/stamp-bulletin", model.getParentFolder());
            assertEquals("<p>No results found based on your filter selection.</p>", model.getNoResultsMessage());
            assertEquals(2, model.getInitialPageLoad());
            assertEquals("/content/page", model.getResourcePath());
            assertEquals("Download Now", model.getCtaLabel());
            assertEquals(9, model.getAssetResourceList().size());
            assertTrue(model.getAssetResourceList().getFirst().endsWith("jcr:content/metadata"));
            assertEquals(2, model.getFilters().size());
            assertEquals(1, model.getAssetListItems().size());
            assertEquals("(PDF, 5 MB)", model.getAssetListItems().getFirst().getAssetTypeAndSize());
            assertEquals(6, model.getFilteredResults());
            Assert.assertEquals(
                    "{\"assetlisting-15773b2a6e\":{\"event\":\"filtered-results\",\"eventCategory\":\"\",\"eventDescription\":\"1\"}}",
                    model.getDataLayer());
            Assert.assertEquals(
                    "{\"assetlisting-15773b2a6e\":{\"event\":\"site_interaction\",\"eventCategory\":\"list||cta\"," +
                            "\"eventDescription\":\"stamp-bulletin\"}}",
                    model.getAssetListItems().getFirst().getDataLayer());

        });
    }

    @Test
    void testIfAllAssetListingWhenCompletePropertiesAreInjectedWithSelectorsWithNoMonthTagSelected() {
        ctx.requestPathInfo().setSelectorString("2024");
        ctx.currentResource("/content/page/jcr:content/assetlisting/withValidProperties");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(9, model.getAssetResourceList().size());
            assertEquals(2, model.getFilters().size());
            assertEquals(4, model.getAssetListItems().size());
            assertEquals("(PDF, 0 bytes)", model.getAssetListItems().getFirst().getAssetTypeAndSize());
            assertEquals(4, model.getFilteredResults());
        });
    }

    @Test
    void testIfAllAssetListingWhenNoFiltersSelected() {
        ctx.currentResource("/content/page/jcr:content/assetlisting/withOutFilters");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test with Filter", model.getTitle());
            assertEquals("/content/dam/collectables/stamp-bulletin", model.getParentFolder());
            assertEquals("<p>No results found based on your filter selection.</p>", model.getNoResultsMessage());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("Download Now", model.getCtaLabel());
            assertEquals("/content/page", model.getResourcePath());
            assertEquals(0, model.getAssetResourceList().size());
            assertEquals(0, model.getFilters().size());
            assertEquals(0, model.getAssetListItems().size());
            assertEquals(0, model.getFilteredResults());
            Assert.assertEquals(
                    "{\"assetlisting-9d4818ddb4\":{\"event\":\"filtered-results\",\"eventCategory\":\"\",\"eventDescription\":\"0\"}}",
                    model.getDataLayer());
        });
    }

    @Test
    void testIfAllAssetListingWhenIncompletePropertiesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/assetlisting/withMissingProperties");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test with Filter", model.getTitle());
            assertNull(model.getParentFolder());
            assertEquals("<p>No results found based on your filter selection.</p>", model.getNoResultsMessage());
            assertEquals(20, model.getInitialPageLoad());
            assertEquals("/content/page", model.getResourcePath());
            assertEquals("Download Now", model.getCtaLabel());
            assertEquals(0, model.getAssetResourceList().size());
            assertEquals(0, model.getFilters().size());
            assertEquals(0, model.getAssetListItems().size());
            assertEquals(0, model.getFilteredResults());
            Assert.assertEquals(
                    "{\"assetlisting-7e7beb9805\":{\"event\":\"filtered-results\",\"eventCategory\":\"\",\"eventDescription\":\"0\"}}",
                    model.getDataLayer());
        });
    }

    @Test
    void testIfDataLayerStringIsEmptyWhenDataLayerIsDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        ctx.create().page("/content/page");
        ctx.load().json("/models/assetlisting/component.json", "/content/page/jcr:content/assetlisting");
        ctx.load().json("/models/assetlisting/tags.json", TagConstants.TAG_ROOT_PATH);
        ctx.load().json("/models/assetlisting/assets.json", "/content/dam/collectables/stamp-bulletin");
        ctx.currentResource("/content/page/jcr:content/assetlisting/withValidProperties");
        model = ctx.request().adaptTo(AssetListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            Assert.assertEquals(EMPTY, model.getDataLayer());
        });
    }
}

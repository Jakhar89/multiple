package com.auspost.aemaacs.program.core.models;


import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(AemContextExtension.class)
public class FormInputOptionsTest {
    private final AemContext ctx = AppAemContext.newAemContext();
    private FormInputOptions model;

    @BeforeEach
    void setUp() {
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/form/options/v2/options");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/form/options", props);
        ctx.load().json("/models/formOptions/component.json", "/content/page/jcr:content/options");
    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpected() {
        ctx.currentResource("/content/page/jcr:content/options/option1");
        model = ctx.request().adaptTo(FormInputOptions.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Select the test checkbox", model.getTitle());
            assertEquals("select-the-test-checkbox-_-testCheckbox", model.getName());
            assertEquals("Help Message For Checkbox", model.getHelpMessage());
            assertEquals("true", model.getRequired());
            assertEquals("This field is required.", model.getRequiredMessage());
        });
    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpectedWithoutTitle() {
        ctx.currentResource("/content/page/jcr:content/options/option2");
        model = ctx.request().adaptTo(FormInputOptions.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("no_title-_-testCheckbox", model.getName());
            assertEquals("Help Message For Checkbox", model.getHelpMessage());
            assertEquals("true", model.getRequired());
            assertEquals("This field is required.", model.getRequiredMessage());
        });
    }
}

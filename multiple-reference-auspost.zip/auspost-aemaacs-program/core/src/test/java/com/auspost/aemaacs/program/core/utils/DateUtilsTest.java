package com.auspost.aemaacs.program.core.utils;

import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.auspost.aemaacs.program.core.constants.Constants.DATE_FORMAT;
import static junitx.framework.ComparableAssert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

@ExtendWith(AemContextExtension.class)
class DateUtilsTest {

    @Test
    void testIfEmptyDateReturnedWhenNullDateIsPassed() {
        Assertions.assertTrue(DateUtils.getFormattedDate(null, DATE_FORMAT).isEmpty());
    }

    @Test
    void testIfNonEmptyDateReturnedWhenDatePassedInRightFormat() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = formatter.parse("2025-08-27");
        Assertions.assertEquals("27 August 2025", DateUtils.getFormattedDate(date, DATE_FORMAT));
    }

    @Test
    void testParseMonth() {
        assertAll(() -> {
            assertEquals(1, DateUtils.parseMonth("january"));
            assertEquals(2, DateUtils.parseMonth("february"));
            assertEquals(3, DateUtils.parseMonth("march"));
            assertEquals(4, DateUtils.parseMonth("april"));
            assertEquals(5, DateUtils.parseMonth("may"));
            assertEquals(6, DateUtils.parseMonth("june"));
            assertEquals(7, DateUtils.parseMonth("july"));
            assertEquals(8, DateUtils.parseMonth("august"));
            assertEquals(9, DateUtils.parseMonth("september"));
            assertEquals(10, DateUtils.parseMonth("october"));
            assertEquals(11, DateUtils.parseMonth("november"));
            assertEquals(12, DateUtils.parseMonth("december"));
            assertEquals(0, DateUtils.parseMonth("randomText"));
        });
    }
}

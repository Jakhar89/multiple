package com.auspost.aemaacs.program.core.utils;

import com.auspost.aemaacs.program.core.pojos.LinkItem;
import com.auspost.aemaacs.program.core.pojos.PanelContainerItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.json.JsonMapper;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;

import java.util.HashMap;
import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.PN_ENABLE_DATA_LAYER;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_IMPRESSION;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mockConstruction;

@ExtendWith(AemContextExtension.class)
class DataLayerUtilsTest {
    private final AemContext ctx = AppAemContext.newAemContext();

    @Test
    void testCreateEventMap() {
        Map<String, Object> map = DataLayerUtils.createEventMap("click", "header", "desc");
        assertEquals("click", map.get("event"));
        assertEquals("header", map.get("eventCategory"));
        assertEquals("desc", map.get("eventDescription"));
    }

    @Test
    void testSetDataLayerForLink() {
        LinkItem item = new LinkItem();
        DataLayerUtils.setDataLayerForLink(item, "id1", "event1", "cat1", "desc1");
        assertNotNull(item.getDataLayer());
        assertTrue(item.getDataLayer().contains("id1"));
        assertTrue(item.getDataLayer().contains("event1"));
    }

    @Test
    void testIsDataLayerGlobalDisabled() {
        Resource resource = ctx.create().resource("/content/test", "enableDataLayer", false);
        ctx.currentResource(resource);
        try (var mocked = Mockito.mockStatic(com.adobe.cq.wcm.core.components.util.ComponentUtils.class)) {
            mocked.when(() -> com.adobe.cq.wcm.core.components.util.ComponentUtils.isDataLayerEnabled(resource))
                    .thenReturn(false);
            assertFalse(DataLayerUtils.isDataLayerEnabled(resource));
        }
    }

    @Test
    void testIsDataLayerGlobalEnabled() {
        Resource resource = ctx.create().resource("/content/test");
        ctx.currentResource(resource);
        try (var mocked = Mockito.mockStatic(com.adobe.cq.wcm.core.components.util.ComponentUtils.class)) {
            mocked.when(() -> com.adobe.cq.wcm.core.components.util.ComponentUtils.isDataLayerEnabled(resource))
                    .thenReturn(true);
            ctx.request().setAttribute(PN_ENABLE_DATA_LAYER, true);
            assertTrue(DataLayerUtils.isDataLayerEnabled(resource));
        }
    }

    @Test
    void testIsDataLayerGlobalEnabledIsNull() {
        Resource resource = ctx.create().resource("/content/test");
        try (var mocked = Mockito.mockStatic(com.adobe.cq.wcm.core.components.util.ComponentUtils.class)) {
            mocked.when(() -> com.adobe.cq.wcm.core.components.util.ComponentUtils.isDataLayerEnabled(resource))
                    .thenReturn(true);
            assertTrue(DataLayerUtils.isDataLayerEnabled(resource));
        }
    }

    @Test
    void testIsDataLayerLocalDisabled() {
        Resource resource = ctx.create().resource("/content/test2", "enableDataLayer", false);
        try (var mocked = Mockito.mockStatic(com.adobe.cq.wcm.core.components.util.ComponentUtils.class)) {
            mocked.when(() -> com.adobe.cq.wcm.core.components.util.ComponentUtils.isDataLayerEnabled(resource))
                    .thenReturn(true);
            assertFalse(DataLayerUtils.isDataLayerEnabled(resource));
        }
    }

    @Test
    void testIsDataLayerLocalEnabled() {
        Resource resource = ctx.create().resource("/content/test3", "enableDataLayer", true);
        ctx.currentResource(resource);
        try (var mocked = Mockito.mockStatic(com.adobe.cq.wcm.core.components.util.ComponentUtils.class)) {
            mocked.when(() -> com.adobe.cq.wcm.core.components.util.ComponentUtils.isDataLayerEnabled(resource))
                    .thenReturn(true);
            assertTrue(DataLayerUtils.isDataLayerEnabled(resource));
        }
    }

    @Test
    void testMapToJsonWhenJsonProcessingException() {
        try (MockedConstruction<JsonMapper> mocked = mockConstruction(JsonMapper.class, (mock, context) -> {
            Mockito.when(mock.writeValueAsString(Mockito.anyMap()))
                    .thenThrow(new JsonProcessingException("error") {
                    });
        })) {
            Map<String, Object> map = new HashMap<>();
            map.put("key", new Object());
            String result = DataLayerUtils.mapToJson("testId", map);
            assertNotNull(result);
        }
    }

    @Test
    void testGetFormattedDataLayerDescription() {
        String input = "Banner Title Example";
        String expected = "banner-title-example";
        String result = DataLayerUtils.getFormattedDataLayerDescription(input);
        assertEquals(expected, result);

        // Test with multiple spaces and mixed case
        input = "CTA Button  Click";
        expected = "cta-button--click";
        result = DataLayerUtils.getFormattedDataLayerDescription(input);
        assertEquals(expected, result);

        // Test with no spaces
        input = "NoSpaces";
        expected = "nospaces";
        result = DataLayerUtils.getFormattedDataLayerDescription(input);
        assertEquals(expected, result);

        // Test with empty string
        input = EMPTY;
        expected = EMPTY;
        result = DataLayerUtils.getFormattedDataLayerDescription(input);
        assertEquals(expected, result);

        // Test with null
        expected = EMPTY;
        result = DataLayerUtils.getFormattedDataLayerDescription(null);
        assertEquals(expected, result);
    }

    @Test
    void testSetDataLayerForPanelItemEnabled() {
        Resource resource = ctx.create().resource("/content/panel");
        PanelContainerItem item = new PanelContainerItem("panel1", "Panel Title", "Panel Name", resource);
        try (var mocked = Mockito.mockStatic(com.adobe.cq.wcm.core.components.util.ComponentUtils.class)) {
            mocked.when(() -> com.adobe.cq.wcm.core.components.util.ComponentUtils.isDataLayerEnabled(resource))
                    .thenReturn(true);
            DataLayerUtils.setDataLayerForPanelItem(item, SITE_IMPRESSION, "panelComponent", "event description");

            assertNotNull(item.getDataLayer());
            assertTrue(item.getDataLayer().contains("panel1"));
            assertTrue(item.getDataLayer().contains(SITE_IMPRESSION));
            assertTrue(item.getDataLayer().contains("panelComponent"));
            assertTrue(item.getDataLayer().contains("event description"));
        }
    }

}

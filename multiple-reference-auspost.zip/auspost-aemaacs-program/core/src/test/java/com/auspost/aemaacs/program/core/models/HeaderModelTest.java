package com.auspost.aemaacs.program.core.models;

import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.constants.Constants;
import com.auspost.aemaacs.program.core.pojos.HeaderNavigationItem;
import com.auspost.aemaacs.program.core.pojos.LinkItem;
import com.auspost.aemaacs.program.core.utils.CommonUtils;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.msm.api.LiveRelationshipManager;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import junit.framework.Assert;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.testcontext.AppAemContext.getExpectedDataLayerJson;
import static com.auspost.aemaacs.program.core.testcontext.AppAemContext.newAemContext;
import static com.auspost.aemaacs.program.core.testcontext.AppAemContext.newAemContextWithDataLayerDisabled;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;


@ExtendWith(AemContextExtension.class)
class HeaderModelTest {

    private final AemContext ctx = newAemContext();

    private final LiveRelationshipManager liveRelationshipManager = mock(LiveRelationshipManager.class);

    private HeaderModel model;
    private LinkManager linkManager;

    @BeforeEach
    void setUp() {
        Map<String, Object> props = Map.of(
                "sling:resourceSuperType", "core/wcm/components/navigation/v2/navigation",
                "navigationRoot", "/content/page",
                "structureDepth", "3",
                "structureStart", "1",
                "collectAllPages", "false");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/header", props);
        ctx.load().json("/models/header/component.json", "/content/page");
        ctx.currentResource("/content/page/jcr:content/root/header");
        linkManager = ctx.request().adaptTo(LinkManager.class);
        ctx.registerService(LiveRelationshipManager.class, liveRelationshipManager);
        model = ctx.request().adaptTo(HeaderModel.class);
    }

    @Test
    void testIfHeaderLogoLinksAreBuiltAsExpected() {
        assertAll(() -> {
            assertNotNull(model.getHeaderLogoAlt());
            assertEquals("Test alt text", model.getHeaderLogoAlt());
            assertNotNull(model.getHeaderLogoLink());
            assertEquals("/content/test", model.getHeaderLogoLink().getLinkURL());
        });
    }

    @Test
    void testIfAllHeaderLogosAreBuiltAsExpected() {
        assertAll(() -> {
            assertNotNull(model.getHeaderDesktopLogo());
            assertEquals("/content/dam/collectables/auspostlogo.png", model.getHeaderDesktopLogo().getIconReference());
            assertNotNull(model.getHeaderTabletLogo());
            assertEquals("/content/dam/collectables/auspostlogo.png", model.getHeaderTabletLogo().getIconReference());
            assertNotNull(model.getHeaderMobileLogo());
            assertEquals("/content/dam/collectables/auspostlogo.png", model.getHeaderMobileLogo().getIconReference());
        });
    }

    @Test
    void testIfSearchIsBuiltAsExpectedWhenItIsConfigured() {
        assertAll(() -> {
            LinkItem search = model.getSearch();
            assertNotNull(search);
            assertEquals("Search", search.getLabel());
            assertEquals("#", search.getLinkURL());
        });
    }

    @Test
    void testIfPromoLinksAreBuiltAsExpectedWhenConfigured() {
        assertAll(() -> {
            assertNotNull(model.getPromoLinks());
            assertEquals(3, model.getPromoLinks().size());
            assertEquals("#", model.getPromoLinks().getFirst().getParentLink().getLinkURL());
            assertEquals("#", model.getPromoLinks().getFirst().getChildLinks().getFirst().getLinkURL());
            assertEquals("#", model.getPromoLinks().getFirst().getFeatureCard().getLink().getLinkURL());
        });
    }

    @Test
    void testIfSecondaryLinksAreBuildAsExpectedWhenConfigured() {
        assertAll(() -> {
            assertEquals(1, model.getHeaderSecondaryLinks().size());
            assertEquals("Support", model.getHeaderSecondaryLinks().getFirst().getLabel());
        });
    }

    @Test
    void testIfAuthenticationIsBuiltAsExpectedWhenConfigured() {
        assertAll(() -> {
            assertEquals("Login", model.getLoginOrSignup().getLabel());
            assertEquals(1, model.getLoginOptions().size());
            assertEquals("My Post", model.getLoginOptions().getFirst().getLabel());
        });
    }

    @Test
    void testIfPopularSearchAreBuildAsExpectedWhenConfigured() {
        assertAll(() -> {
            assertEquals(2, model.getPopularsearch().size());
            assertEquals("Jellyfish", model.getPopularsearch().getFirst().getLabel());
            assertEquals("/content/collectables/au/en/test-homepage-template",
                    model.getPopularsearch().getFirst().getLinkURL());

            String json = model.getPopularSearchJson();
            assertTrue(json.contains("\"title\":\"POPULAR SEARCHES\""));
            assertTrue(json.contains("\"label\":\"Jellyfish\""));
            assertTrue(json.contains("\"href\":\"/content/collectables/au/en/test-homepage-template\""));
            assertTrue(json.contains("\"label\":\"Underwater wonders\""));
        });
    }

    @Test
    void testIfNavigationIsBuiltAsExpectedWhenConfigured() {
        assertAll(() -> {
            List<HeaderNavigationItem> navItems = model.getNavigationLinkItem();
            assertEquals("About Us",
                    navItems.getFirst().getParent().getLabel());
            assertEquals("Child 2",
                    navItems.getFirst().getChildren().get(1).getParent().getLabel());
            assertEquals("Grand Child 1",
                    navItems.getFirst().getChildren().get(1).getChildren().getFirst().getParent().getLabel());
        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenEnabled() {
        assertAll(() -> {
            String headerDataLayer = model.getDataLayer();
            String promoParentDataLayer = model.getPromoLinks().getFirst().getParentLink().getDataLayer();
            String promoChildDataLayer = model.getPromoLinks().getFirst().getChildLinks().getFirst().getDataLayer();
            String secondaryDataLayer = model.getHeaderSecondaryLinks().getFirst().getDataLayer();
            String navParentDataLayer = model.getNavigationLinkItem().getFirst().getParent().getDataLayer();
            String navChildDataLayer =
                    model.getNavigationLinkItem().getFirst().getChildren().getFirst().getParent().getDataLayer();
            assertEquals(getExpectedDataLayerJson("/models/header/datalayer/header.json"), headerDataLayer);
            assertEquals(getExpectedDataLayerJson("/models/header/datalayer/promoparent.json"), promoParentDataLayer);
            assertEquals(getExpectedDataLayerJson("/models/header/datalayer/promochild.json"), promoChildDataLayer);
            assertEquals(getExpectedDataLayerJson("/models/header/datalayer/secondary.json"), secondaryDataLayer);
            assertEquals(getExpectedDataLayerJson("/models/header/datalayer/navparent.json"), navParentDataLayer);
            assertEquals(getExpectedDataLayerJson("/models/header/datalayer/navchild.json"), navChildDataLayer);
        });
    }

    @Test
    void testIfAllHeaderItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "header", "header", "some header", "enableDataLayer", "true");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(HeaderModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getHeaderDesktopLogo());
            assertNull(model.getHeaderMobileLogo());
            assertNull(model.getHeaderTabletLogo());
            assertNull(model.getHeaderLogoLink());
            assertTrue(model.getPromoLinks().isEmpty());
            assertNull(model.getSearch());
            assertNull(model.getHeaderSecondaryLinks());
            assertNull(model.getLoginOrSignup());
            assertNotNull(model.getDataLayer());
        });
    }

    @Test
    void testIfDataLayerIsNotPopulatedWhenDataLayerConfigIsDisabled() {
        AemContext ctx = newAemContextWithDataLayerDisabled();
        ctx.load().json("/models/header/component.json", "/content/page");
        ctx.currentResource("/content/page/jcr:content/root/header");
        model = ctx.request().adaptTo(HeaderModel.class);
        assertEquals(EMPTY, Objects.requireNonNull(model).getDataLayer());
    }

    @Test
    void testNavigationIsBuiltAsExpectedWithConstructorDefaultsActiveToFalse() {
        LinkItem mockLink = new LinkItem("About Us", "/content/page/about-us", "", linkManager);
        List<HeaderNavigationItem> children = new ArrayList<>();
        HeaderNavigationItem item = new HeaderNavigationItem(mockLink, children, false);
        assertNotNull(item);
        assertEquals(mockLink, item.getParent());
        assertEquals(children, item.getChildren());
        assertFalse(item.isActive());
    }

    @Test
    void testPopularSearchJsonWhenEmpty() throws JsonProcessingException {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-empty");
        model = ctx.request().adaptTo(HeaderModel.class);
        assertNotNull(model);
        assertEquals(EMPTY, model.getPopularSearchJson());
    }

    @Test
    void testPopularSearchJsonWhenNull() {
        ctx.currentResource(
                ctx.create().resource("/content/page/jcr:content/root/header-null")
        );
        model = ctx.request().adaptTo(HeaderModel.class);
        assertEquals(EMPTY, model.getPopularSearchJson());
    }

    @Test
    void testPopularSearchJsonWhenInvalidItems() throws JsonProcessingException {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-invalid");
        model = ctx.request().adaptTo(HeaderModel.class);
        assertNotNull(model);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode json = mapper.readTree(model.getPopularSearchJson());
        assertEquals(0, json.get("items").size());
    }

    @Test
    void testPopularSearchJsonWhenPopularSearchIsNull() throws JsonProcessingException {
        ctx.currentResource(
                ctx.create().resource(
                        "/content/page/jcr:content/root/header-null",
                        "enableDataLayer", "true"
                )
        );
        model = ctx.request().adaptTo(HeaderModel.class);
        assertNotNull(model);
        assertEquals(EMPTY, model.getPopularSearchJson());
    }

    @Test
    void testPopularSearchJsonWhenEmptyList() {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-empty");
        model = ctx.request().adaptTo(HeaderModel.class);
        assertNotNull(model);
        assertEquals(EMPTY, model.getPopularSearchJson());
        assertEquals(EMPTY, model.getSearchJson());
    }
    @Test
    void testPopularSearchResourceWhenEmptyList() {
        ctx.currentResource("/content/page/jcr:content/root/header-some-values");
        model = ctx.request().adaptTo(HeaderModel.class);
        assertNotNull(model);
        assertEquals(EMPTY, model.getSearchJson());
    }

    @Test
    void testSearchResultJsonReturnsEmptyOnJsonException() {
        try (MockedStatic<CommonUtils> mocked = mockStatic(CommonUtils.class)) {
            mocked.when(() -> CommonUtils.addToMapIfNotBlank(anyMap(), anyString(), any()))
                    .thenCallRealMethod();
            mocked.when(() -> CommonUtils.writeJson(anyMap()))
                    .thenThrow(new JsonProcessingException("error") {});
            model = ctx.request().adaptTo(HeaderModel.class);
            Assert.assertEquals(Constants.EMPTY, model.getPopularSearchJson());
            Assert.assertEquals(Constants.EMPTY, model.getSearchJson());
        }
    }


    @Test
    void testIfPopularSearchFieldsBuildAsExpectedWhenConfigured() {
        String json = model.getSearchJson();
        assertAll(
                () -> assertNotNull(json),
                () -> assertFalse(json.isBlank()),

                () -> assertTrue(json.contains("\"label\":\"Search\"")),
                () -> assertTrue(json.contains("\"buttonText\":\"Search Button\"")),
                () -> assertTrue(json.contains("\"placeholder\":\"Search in site\"")),
                () -> assertTrue(json.contains("redirectUrl"))
        );
    }

    @Test
    void testGetSearchJson_SomePropertiesMissing() throws Exception {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-invalid");
        model = ctx.request().adaptTo(HeaderModel.class);

        ObjectMapper mapper = new ObjectMapper();
        JsonNode json = mapper.readTree(model.getSearchJson());

        assertEquals("Search", json.get("label").asText());
        assertEquals(1, json.size());
    }

    @Test
    void testGetSearchJson_AllPropertiesEmpty() {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-empty");
        model = ctx.request().adaptTo(HeaderModel.class);
        assertNotNull(model);
        String json = model.getSearchJson();
        assertEquals(EMPTY, json);
    }

    @Test
    void testGetSearchJson_AllPropertiesBlank() {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-null");
        model = ctx.request().adaptTo(HeaderModel.class);
        assertNotNull(model);
        String json = model.getSearchJson();
        assertEquals(EMPTY, json);
    }

    @Test
    void testGetSearchJson_ButtonOnly() {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-button-only");
        model = ctx.request().adaptTo(HeaderModel.class);

        String json = model.getSearchJson();
        assertEquals("{\"buttonText\":\"Search Button\"}", json);
    }

    @Test
    void testGetSearchJson_PlaceholderOnly() {
        ctx.currentResource("/content/page/jcr:content/root/popularsearch-placeholder-only");
        model = ctx.request().adaptTo(HeaderModel.class);

        String json = model.getSearchJson();
        assertEquals("{\"placeholder\":\"Search in site\"}", json);
    }

    @Test
    void testGetSearchCachingWithoutGetter() {
        LinkItem firstCall = model.getSearch();
        assertNotNull(firstCall);
        LinkItem secondCall = model.getSearch();
        assertSame(firstCall, secondCall, "getSearch() should return the cached LinkItem");
    }
}

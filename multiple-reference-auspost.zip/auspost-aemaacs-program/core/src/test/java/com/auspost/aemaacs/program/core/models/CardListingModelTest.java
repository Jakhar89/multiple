package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class CardListingModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private CardListingModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/cardlisting/component.json", "/content/page/jcr:content/cardlisting");
    }

    @Test
    void testIfAllCardListingItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/cardlisting");
        model = ctx.request().adaptTo(CardListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(1, model.getCards().size());
            assertEquals("Card Listing Heading", model.getHeading());
            assertEquals("Card1 Image Alt Text", model.getCards().getFirst().getCardImage().getValueMap().get("alt"));
            assertEquals("/content/collectables/au/en/test-home", model.getMainCta().getURL());
        });
    }

    @Test
    void testIfAllCardListingItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "cardlisting", "cardlisting", "some cardlisting items");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(CardListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getCards());
            assertNull(model.getMainCta());
            assertNotNull(model.getDataLayer());
        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenCardListingItemsAreInstantiatedAsExpected() {
        ctx.currentResource("/content/page/jcr:content/cardlisting");
        model = ctx.request().adaptTo(CardListingModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(1, model.getCards().size());
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals("/content/collectables/au/en/home-page", model.getCards().getFirst().getCardUrl());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/cardlisting/datalayer.json"),
                    model.getCards().getFirst().getDataLayer());
            assertEquals(
                    "{\"id_1-main-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"cardListing||main-cta\",\"eventDescription\":\"main-cta-label\"}}",
                    model.getMainCta().getDataLayer());
        });
    }
}

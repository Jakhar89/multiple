package com.auspost.aemaacs.program.core.pojos;

import com.adobe.cq.wcm.core.components.commons.link.LinkManager;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.SITE_INTERACTION;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class ButtonItemTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private ButtonItem buttonItem;

    private Resource buttonResource;

    @BeforeEach
    void setup() {
        // Create a page to allow proper processing of resources
        Page page = ctx.create().page("/content/page");
        // Create a map to represent the resource values
        Map<String, Object> props = Map.of(
                "label", "Link Label",
                "linkURL", "/content/page",
                "linkTarget", "_self",
                "iconLeft", "icon-left",
                "iconRight", "icon-right"
        );
        // create a new resource and set it as current resource
        buttonResource = ctx.create().resource(page, "buttonResource", props);
        ctx.currentResource(buttonResource);
        // perform the adaptTo to prepare LinkItem object for testing
        buttonItem = Objects.requireNonNull(ctx.currentResource()).adaptTo(ButtonItem.class);
        // initialise the LinkManager from SlingHttpServletRequest and set the Link to LinkItem
        LinkManager linkManager = ctx.request().adaptTo(LinkManager.class);
        buttonItem.setLink(Objects.requireNonNull(linkManager).get(buttonItem.getLinkURL()).build());
        DataLayerUtils.setDataLayerForLink(buttonItem, "primary-cta-123", SITE_INTERACTION, "callout||cta", "info" +
                ":primary-cta-label");
    }

    @Test
    void testResourceCreationWithExpectedProperties() {
        assertNotNull(buttonResource, "Resource should not be null");
        assertEquals("Link Label", buttonResource.getValueMap().get("label"));
        assertEquals("/content/page", buttonResource.getValueMap().get("linkURL"));
        assertEquals("_self", buttonResource.getValueMap().get("linkTarget"));
        assertEquals("icon-left", buttonItem.getIconLeft());
        assertEquals("icon-right", buttonItem.getIconRight());
    }

    @Test
    void testButtonItemAssetSizeWhenDamAssetSizeWithExtensionEnabled() {
        Page page = ctx.create().page("/content/page");
        Map<String, Object> props = Map.of(
                "label", "Link Label",
                "linkURL", "/content/dam/digital-id-web-terms-of-use.pdf",
                "linkTarget", "_self",
                "iconLeft", "icon-left",
                "iconRight", "icon-right",
                "assetTypeAndSize", "true"
        );
        buttonResource = ctx.create().resource(page, "buttonResource", props);
        ctx.currentResource(buttonResource);
        buttonItem = Objects.requireNonNull(ctx.currentResource()).adaptTo(ButtonItem.class);
        LinkManager linkManager = ctx.request().adaptTo(LinkManager.class);
        buttonItem.setLink(Objects.requireNonNull(linkManager).get(buttonItem.getLinkURL()).build());
        ctx.load().json("/models/buttonItem/asset.json", "/content/dam/digital-id-web-terms-of-use.pdf");
        assertEquals("(PDF, 238 KB)", buttonItem.getAssetTypeAndSize());
    }

    @Test
    void testButtonItemAssetSizeWhenDamAssetSizeWithExtensionEnabledWithInvalidUrl() {
        Page page = ctx.create().page("/content/page");
        Map<String, Object> props = Map.of(
                "label", "Link Label",
                "linkTarget", "_self",
                "iconLeft", "icon-left",
                "iconRight", "icon-right",
                "assetTypeAndSize", "true"
        );
        buttonResource = ctx.create().resource(page, "buttonResource", props);
        ctx.currentResource(buttonResource);
        buttonItem = Objects.requireNonNull(ctx.currentResource()).adaptTo(ButtonItem.class);
        LinkManager linkManager = ctx.request().adaptTo(LinkManager.class);
        buttonItem.setLink(Objects.requireNonNull(linkManager).get(buttonItem.getLinkURL()).build());
        ctx.load().json("/models/buttonItem/asset.json", "/content/dam/digital-id-web-terms-of-use.pdf");
        assertEquals(EMPTY, buttonItem.getAssetTypeAndSize());
    }

    @Test
    void testButtonItemAssetSizeWhenDamAssetSizeWithExtensionDisabled() {
        Page page = ctx.create().page("/content/page");
        Map<String, Object> props = Map.of(
                "label", "Link Label",
                "linkURL", "/content/dam/digital-id-web-terms-of-use.pdf",
                "linkTarget", "_self",
                "iconLeft", "icon-left",
                "iconRight", "icon-right",
                "assetTypeAndSize", "false"
        );
        buttonResource = ctx.create().resource(page, "buttonResource", props);
        ctx.currentResource(buttonResource);
        buttonItem = Objects.requireNonNull(ctx.currentResource()).adaptTo(ButtonItem.class);
        LinkManager linkManager = ctx.request().adaptTo(LinkManager.class);
        buttonItem.setLink(Objects.requireNonNull(linkManager).get(buttonItem.getLinkURL()).build());
        ctx.load().json("/models/buttonItem/asset.json", "/content/dam/digital-id-web-terms-of-use.pdf");
        assertEquals(EMPTY, buttonItem.getAssetTypeAndSize());
    }


    @Test
    void testIfDataLayerIsPopulatedWhenDataLayerConfigIsEnabled() throws IOException {
        assertNotNull(buttonItem.getDataLayer());
        assertEquals("{\"primary-cta-123\":{\"event\":\"site_interaction\",\"eventCategory\":\"callout||cta\"," +
                "\"eventDescription\":\"info:primary-cta-label\"}}", buttonItem.getDataLayer());
    }

    @Test
    void testResourcePath() {
        assertEquals("/content/page/jcr:content/buttonResource", buttonResource.getPath(),
                "Resource path should match expected value");
    }

}

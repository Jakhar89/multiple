package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.services.AbnLookUpService;
import com.auspost.aemaacs.program.core.services.impl.AbnLookUpServiceImpl;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static junitx.framework.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
public class FormAbnLookupModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private FormAbnLookupModel model;

    private static WireMockServer wireMockServer;

    private static AbnLookUpService abnLookUpService;

    @BeforeAll
    static void setupBeforeAll() {
        wireMockServer = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        wireMockServer.start();
    }

    @BeforeEach
    void setUp() throws IOException {
        Dictionary<String, String> config = new Hashtable<>() {{
            put("host", "http://localhost:" + wireMockServer.port());
            put("endpoint", "/endpoint");
            put("authKey", "authKey123");
            put("historicalDetails", "N");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AbnLookUpServiceImpl")
                .update(config);
        ctx.create().page("/content/page");
        ctx.load().json("/models/formabnlookup/component.json", "/content/page/jcr:content/content");
        stubWireMockServer(wireMockServer, "/endpoint", 200, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<ABRPayloadSearchResults><response>sample response</response></ABRPayloadSearchResults>");

    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpected() {
        ctx.registerInjectActivateService(new AbnLookUpServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/abnLookup");
        model = ctx.request().adaptTo(FormAbnLookupModel.class);
        ctx.request().setQueryString("abn=123456789");

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("AbnLookup Title", model.getTitle());
            assertNotNull(model.getId());
            assertEquals("Hint text message", model.getHintText());
            assertEquals("Please enter an ABN", model.getRequiredMessage());
            assertEquals("/content/page/_jcr_content/content/abnLookup.model.json", model.getResourcePath());
            assertEquals("{\"response\":\"sample response\"}", model.getAbnDetails().toString());
        });
    }


    @Test
    void testAllComponentsValuesAreInjectingAsExpectedWithoutAbnParameter() {
        ctx.registerInjectActivateService(new AbnLookUpServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/abnLookup");
        model = ctx.request().adaptTo(FormAbnLookupModel.class);
        stubWireMockServer(wireMockServer, "/endpoint", 400, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<ABRPayloadSearchResults><response>No search text specified</response></ABRPayloadSearchResults>");

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("AbnLookup Title", model.getTitle());
            assertNotNull(model.getId());
            assertEquals("Hint text message", model.getHintText());
            assertEquals("Please enter an ABN", model.getRequiredMessage());
            assertEquals("/content/page/_jcr_content/content/abnLookup.model.json", model.getResourcePath());
            assertEquals("{\"response\":\"No search text specified\"}", model.getAbnDetails().toString());
        });
    }

    @Test
    void testGetAbnDetailsHandlesIOException() {
        ctx.registerInjectActivateService(new AbnLookUpServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/abnLookup");
        model = ctx.request().adaptTo(FormAbnLookupModel.class);
        ctx.request().setQueryString("abn=123456789");

        stubWireMockServer(wireMockServer, "/endpoint", 500, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<ABRPayloadSearchResults><response>Internal server error</response></ABRPayloadSearchResults>");
        assertEquals("{\"response\":\"Internal server error\"}", model.getAbnDetails().toString());
    }

    @Test
    void testGetAbnDetailsURIException() throws IOException {
        Dictionary<String, String> config = new Hashtable<>() {{
            put("host", "://invalid_host");
            put("endpoint", "/endpoint");
            put("authKey", "authKey123");
            put("historicalDetails", "N");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AbnLookUpServiceImpl")
                .update(config);
        ctx.registerInjectActivateService(AbnLookUpServiceImpl.class);
        model = ctx.request().adaptTo(FormAbnLookupModel.class);
        ctx.request().setQueryString("abn=123456789");

        assertEquals("{\"error\":\"Service Error\"}", model.getAbnDetails().toString());
    }

    @AfterAll
    static void tearDown() {
        wireMockServer.stop();
    }


    public static void stubWireMockServer(WireMockServer wireMockServer, String url, int status, String body) {
        wireMockServer.stubFor(post(urlEqualTo(url))
                .willReturn(aResponse()
                        .withStatus(status)
                        .withHeader("Content-Type", "application/json")
                        .withBody(body)));
    }
}

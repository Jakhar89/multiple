package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.pojos.BannerTile;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.IOException;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.testcontext.AppAemContext.getExpectedDataLayerJson;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;


@ExtendWith(AemContextExtension.class)
class HomePageBannerModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private HomePageBannerModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/homepagebanner/component.json", "/content/page/jcr:content/homepagebanner");
        ctx.load().json("/models/banner/assets.json", "/content/dam/collectables/stamp-bulletin");
    }

    @Test
    void testTile1Values() {
        ctx.currentResource("/content/page/jcr:content/homepagebanner/homepagebanner1");
        model = ctx.request().adaptTo(HomePageBannerModel.class);
        assertAll(() -> {
            assertNotNull(model);
            BannerTile tile1 = model.getHeroTile();
            assertNotNull(tile1);
            assertEquals("Tile 1 Title", tile1.getTileTitle());
            assertEquals("Tile 1 Desc", tile1.getTileDescription());
            assertEquals("Promo", tile1.getTileCategory().getText());
            assertNotNull(model.getPrimaryCta());
            assertEquals("Shop Now", model.getPrimaryCta().getLabel());
            assertEquals("/content/homepage/shop", model.getPrimaryCta().getLinkURL());
            assertEquals(EMPTY, model.getPrimaryCta().getAssetTypeAndSize());
            assertEquals("(PDF, 5 MB)", model.getSecondaryCta().getAssetTypeAndSize());
            BannerTile tile2 = model.getSideTopTile();
            assertNotNull(tile2);
            assertEquals("Tile 2 Title", tile2.getTileTitle());
            assertNotNull(tile2.getTileLink());
            BannerTile tile3 = model.getSideBottomTile();
            assertNotNull(tile3.getTileLink());
            assertNotNull(tile3);
        });
    }

    @Test
    void testSecondaryTilesAreNull() {
        // Create page without any secondary tiles
        ctx.create().page("/content/page2");
        ctx.currentResource("/content/page2");
        model = ctx.request().adaptTo(HomePageBannerModel.class);

        // Both secondary tiles should be null
        assertNull(model.getSideTopTile(), "Secondary Tile 1 should be null");
        assertNull(model.getSideBottomTile(), "Secondary Tile 2 should be null");
    }

    @Test
    void testIfDataLayerIsPopulatedWhenDataLayerConfigIsEnabled() throws IOException {
        ctx.currentResource("/content/page/jcr:content/homepagebanner/homepagebanner1");
        model = ctx.request().adaptTo(HomePageBannerModel.class);
        assertNotNull(model);
        String dataLayerJson = model.getDataLayer();
        assertNotNull(model.getSideTopTile());
        assertNotNull(model.getSideBottomTile());
        assertNotNull(model.getSideTopTile().getTileLink());
        assertNotNull(model.getSideBottomTile().getTileLink());
        assertEquals("https://example.com/tile2", model.getSideBottomTile().getTileUrl());
        String expectedBannerJson = getExpectedDataLayerJson("/models/homepagebanner/datalayer.json");
        assertEquals(expectedBannerJson, dataLayerJson);
        assertEquals(
                "{\"homepagebanner-162f1969ce-primary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"homePageBanner||cta\",\"eventDescription\":\"tile-1-title:shop-now\"}}",
                model.getPrimaryCta().getDataLayer());
        assertEquals(
                "{\"homepagebanner-162f1969ce-secondary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"homePageBanner||cta\",\"eventDescription\":\"tile-1-title:secondary-tile-1\"}}",
                model.getSecondaryCta().getDataLayer());
        assertEquals(
                "{\"homepagebanner-162f1969ce-secondaryTile1-link\":{\"event\":\"site_interaction\",\"eventCategory\":\"homePageBanner||tile1||cta\",\"eventDescription\":\"tile-2-title\"}}",
                model.getSideTopTile().getTileLink().getDataLayer());
    }

    @Test
    void testGetDataWhenDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        ctx.create().page("/content/page");
        ctx.load().json("/models/homepagebanner/component.json", "/content/page/jcr:content/homepagebanner");
        ctx.currentResource("/content/page/jcr:content/homepagebanner");
        model = ctx.request().adaptTo(HomePageBannerModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
}

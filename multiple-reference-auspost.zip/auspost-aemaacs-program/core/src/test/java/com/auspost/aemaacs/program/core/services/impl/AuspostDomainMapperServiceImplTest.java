package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.services.AuspostDomainMapperService;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static junit.framework.Assert.assertEquals;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class AuspostDomainMapperServiceImplTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private AuspostDomainMapperService auspostDomainMapperService;

    @BeforeEach
    void setUp() throws IOException {

        Dictionary<String, String[]> props = new Hashtable<>();
        String[] domainsJson = {
                "{\"name\":\"collectables\",\"paths\":[\"/content/collectables/au/en\",\"/content/dam/collectables\"]}",
                "{\"name\":\"auspost\",\"paths\":[\"/content/auspost/au/en\",\"/content/dam/auspost\"]}"
        };

        props.put("domains", domainsJson);

        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AuspostDomainMapperServiceImpl")
                .update(props);
        auspostDomainMapperService = ctx.registerInjectActivateService(AuspostDomainMapperServiceImpl.class);
    }

    @Test
    void testExternalize_CollectablesPageMapping() {
        assertEquals("collectables",
                auspostDomainMapperService.getDomainNameUsingPath("/content/collectables/au/en/page1.html"));
    }

    @Test
    void testExternalize_CollectablesDamMapping() {
        assertEquals("collectables",
                auspostDomainMapperService.getDomainNameUsingPath("/content/dam/collectables/image.jpg"));
    }

    @Test
    void testExternalize_AuspostPageMapping() {
        assertEquals("auspost",
                auspostDomainMapperService.getDomainNameUsingPath("/content/auspost/au/en/page2.html"));
    }

    @Test
    void testExternalize_AuspostDamMapping() {
        assertEquals("auspost",
                auspostDomainMapperService.getDomainNameUsingPath("/content/dam/auspost/image2.jpg"));
    }

    @Test
    void testExternalize_NoMatch() {
        assertEquals("publish",
                auspostDomainMapperService.getDomainNameUsingPath("/content/other/path"));
    }
}

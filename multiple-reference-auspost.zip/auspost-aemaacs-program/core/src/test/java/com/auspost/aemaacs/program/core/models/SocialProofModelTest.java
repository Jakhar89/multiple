package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;


@ExtendWith(AemContextExtension.class)
class SocialProofModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private SocialProofModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/socialproof/component.json", "/content/page/jcr:content/socialproof");
    }

    @Test
    void testIfAllSocialProofItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/socialproof/socialproof-all");
        model = ctx.request().adaptTo(SocialProofModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Mr. Abc", model.getAuthorName());
            assertEquals("Testing Lead", model.getAuthorTitle());
            assertEquals("review", model.getType());
            assertNotNull(model.getTitle());
            assertNotNull(model.getSocialProofImage());
            assertNotNull(model.getDate());
            ButtonItem cta = model.getSocialProofCta();
            assertNotNull(cta);
            assertEquals("View all Stamps", cta.getLabel());
            assertEquals("Test logo alt text", model.getSocialProofLogoAlt());
            assertEquals("http://localhost:4503/content/dam/collectables/ap-acknowledgement-logos.svg",
                    model.getSocialProofLogo().getExternalIconReference());

        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenSocialProofItemAreInstantiatedAsExpected() {
        ctx.currentResource("/content/page/jcr:content/socialproof/socialproof-all");
        model = ctx.request().adaptTo(SocialProofModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals("arrow-right-thin", model.getSocialProofCta().getIconRight());
            assertEquals("View all Stamps", model.getSocialProofCta().getLabel());
            assertEquals("/content/auspost/au/en/test-page", model.getSocialProofCta().getURL());
            assertEquals("_blank", model.getSocialProofCta().getLinkTarget());
            assertEquals(
                    "{\"socialproof-bae2fefbd2cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"socialproof||view\",\"eventDescription\":\"view-all-stamps\"}}",
                    model.getSocialProofCta().getDataLayer());
        });
    }

    @Test
    void testIfAllSocialProofItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        ctx.currentResource("/content/page/jcr:content/socialproof/socialproof-null-cta");
        model = ctx.request().adaptTo(SocialProofModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getSocialProofCta());
            assertNotNull(model.getDataLayer());
        });
    }

    @Test
    void testGetDataWhenDataLayerDisabled() {
        AemContext ctx = AppAemContext.newAemContextWithDataLayerDisabled();
        ctx.create().page("/content/page");
        ctx.load().json("/models/socialproof/component.json", "/content/page/jcr:content/socialproof/socialproof-all");
        ctx.currentResource("/content/page/jcr:content/socialproof/socialproof-all");
        model = ctx.request().adaptTo(SocialProofModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(EMPTY, model.getDataLayer());
        });
    }
}

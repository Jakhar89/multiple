package com.auspost.aemaacs.program.core.models;


import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.foundation.forms.FormStructureHelperFactory;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(AemContextExtension.class)
public class FormInputTextTest {
    private final AemContext ctx = AppAemContext.newAemContext();
    private FormInputText model;


    @BeforeEach
    void setUp() {
        ctx.registerService(FormStructureHelperFactory.class, resource -> null);
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/form/text/v2/text");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/form/text", props);
        ctx.load().json("/models/formtext/component.json", "/content/page/jcr:content/text");
        ctx.registerService(FormStructureHelperFactory.class, resource -> null);
    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpected() {
        ctx.currentResource("/content/page/jcr:content/text/text1");
        model = ctx.request().adaptTo(FormInputText.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("10", model.getCharLimit());
            assertEquals("2", model.getMinCharLimit());
            assertEquals("false", model.getSpellCheck());
            assertEquals("first_name-_-FirstName", model.getName());
        });
    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpectedWithOutTitle() {
        ctx.currentResource("/content/page/jcr:content/text/text2");
        model = ctx.request().adaptTo(FormInputText.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("10", model.getCharLimit());
            assertEquals("2", model.getMinCharLimit());
            assertEquals("true", model.getSpellCheck());
            assertEquals("text_input_field-_-LastName", model.getName());
        });
    }
}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;
import java.util.Objects;

@ExtendWith(AemContextExtension.class)
class BreadcrumbModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private BreadcrumbModel model;

    @BeforeEach
    void setup() {
        // create a stub for the component with reference to the core super type
        Map<String, Object> props = Map.of("sling:resourceSuperType", "core/wcm/components/breadcrumb/v3/breadcrumb");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/breadcrumb", props);
        // load the stub for pages in a tree
        ctx.load().json("/models/breadcrumb/component.json", "/content/home");
    }

    @Test
    void testIfBreadcrumbItemsAreReturnedAsExpectedForAValidContentTree() {
        // set current resource to the breadcrumb on test
        ctx.currentResource("/content/home/l1/l2/l3/jcr:content/root/container/breadcrumb");
        model = ctx.request().adaptTo(BreadcrumbModel.class);
        Assertions.assertEquals(3, Objects.requireNonNull(model).getItems().size());
    }

    @Test
    void testIfNonNegativeParentIndexIsReturnedWhenMoreThanThreePagesAreInTheContentTree() {
        // set current resource to the breadcrumb on test
        ctx.currentResource("/content/home/l1/l2/l3/jcr:content/root/container/breadcrumb");
        model = ctx.request().adaptTo(BreadcrumbModel.class);
        Assertions.assertEquals(1, Objects.requireNonNull(model).getParentIndex());
    }

    @Test
    void testIfANegativeParentIndexIsReturnedAsExpectedWhenLessThanThreePagesAreInTheContentTree() {
        // set current resource to the breadcrumb on test
        ctx.currentResource("/content/home/l1/jcr:content/root/container/breadcrumb");
        model = ctx.request().adaptTo(BreadcrumbModel.class);
        Assertions.assertEquals(-1, Objects.requireNonNull(model).getParentIndex());
    }

}

package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.auspost.aemaacs.program.core.utils.DataLayerUtils;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.auspost.aemaacs.program.core.constants.Constants.TITLE;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mockStatic;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class CarouselModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private CarouselModel model;

    @BeforeEach
    void setUp() {
        Map<String, Object>
                props = Map.of("sling:resourceSuperType", "core/wcm/components/carousel/v1/carousel");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/carousel", props);
        ctx.create().resource("/apps/auspost-aemaacs-program/components/banner");
        ctx.load().json("/models/carousel/component.json", "/content/home/jcr:content/carousel");
    }

    @Test
    void testCarouselWhenDataLayerEnabledWithTitle() {
        ctx.currentResource("/content/home/jcr:content/carousel/withTitle");
        model = ctx.request().adaptTo(CarouselModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals("Stamp Issues", model.getTitle());
            assertEquals(1, model.getCarouselItems().size());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/carousel/datalayer.json"),
                    model.getCarouselItems().getFirst().getDataLayer());
            assertEquals("arrow-right", model.getCta().getIconRight());
            assertEquals("View all Stamps", model.getCta().getLabel());
            assertEquals("/content/auspost/au/en/test-page", model.getCta().getURL());
            assertEquals("_blank", model.getCta().getLinkTarget());
            assertEquals(
                    "{\"carousel-ee1f73e829-item-7d2c0d0876\":{\"event\":\"site_impression\",\"eventCategory\":\"carousel||view\",\"eventDescription\":\"opals(international):1\"}}",
                    model.getCarouselItems().getFirst().getDataLayer());
            assertEquals(
                    "{\"carousel-ee1f73e829-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"carousel||cta\",\"eventDescription\":\"stamp-issues:view-all-stamps\"}}",
                    model.getCta().getDataLayer());
            assertEquals("Opals(international)",
                    model.getCarouselItems().getFirst().getResource().getValueMap().get(TITLE, String.class));
        });
    }


    @Test
    void testCarouselWhenDataLayerEnabledWithOutTitle() {
        ctx.currentResource("/content/home/jcr:content/carousel/withOutTitle");
        model = ctx.request().adaptTo(CarouselModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals("Stamp Issues", model.getTitle());
            assertEquals(1, model.getCarouselItems().size());
            assertEquals(
                    "{\"carousel-e986c6e1df-item-6bd5b347da\":{\"event\":\"site_impression\",\"eventCategory\":\"carousel||view\",\"eventDescription\":\"banner1:1\"}}",
                    model.getCarouselItems().getFirst().getDataLayer());
            assertEquals("arrow-right", model.getCta().getIconRight());
            assertEquals("View all Stamps", model.getCta().getLabel());
            assertEquals("/content/auspost/au/en/test-page", model.getCta().getURL());
            assertEquals("_blank", model.getCta().getLinkTarget());
            assertEquals(
                    "{\"carousel-e986c6e1df-item-6bd5b347da\":{\"event\":\"site_impression\",\"eventCategory\":\"carousel||view\",\"eventDescription\":\"banner1:1\"}}",
                    model.getCarouselItems().getFirst().getDataLayer());
        });
    }

    @Test
    void testCarouselWhenDataLayerDisabled() {
        ctx.currentResource("/content/home/jcr:content/carousel/withOutTitle");
        model = ctx.request().adaptTo(CarouselModel.class);
        try (var mocked = mockStatic(DataLayerUtils.class)) {
            mocked.when(() -> DataLayerUtils.isDataLayerEnabled(ctx.currentResource())).thenReturn(false);
            assertEquals(EMPTY, model.getDataLayer());
            assertEquals("Stamp Issues", model.getTitle());
            assertEquals(1, model.getCarouselItems().size());
            assertEquals("arrow-right", model.getCta().getIconRight());
            assertEquals("View all Stamps", model.getCta().getLabel());
            assertEquals("/content/auspost/au/en/test-page", model.getCta().getURL());
            assertEquals("_blank", model.getCta().getLinkTarget());
            assertNull(model.getCarouselItems().getFirst().getDataLayer());
            assertNull(model.getCta().getDataLayer());
        }
    }
}

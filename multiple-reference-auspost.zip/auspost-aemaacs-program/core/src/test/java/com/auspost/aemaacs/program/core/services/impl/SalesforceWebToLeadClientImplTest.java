package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.services.SalesforceWebToLeadClient;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * @author Sathish Balan
 */
@ExtendWith(AemContextExtension.class)
class SalesforceWebToLeadClientImplTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private WireMockServer mockAPI;

    private SalesforceWebToLeadClient client;

    @BeforeEach
    void setUp() throws IOException {
        mockAPI = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        mockAPI.start();
        Dictionary<String, String> props = new Hashtable<>() {{
            put("host", "http://localhost:" + mockAPI.port());
            put("authEndpoint", "/salesforce/v2/auth");
            put("leadEndpoint", "/salesforce/v2/lead");
            put("campaignEndpoint", "/salesforce/v2/campaign");
            put("clientId", "randomwrongclientid");
            put("clientSecret", "randomwrongclientsecret");
            put("username", "random_un");
            put("password", "random_pd");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.SalesforceWebToLeadClientImpl")
                .update(props);
        client = ctx.registerInjectActivateService(SalesforceWebToLeadClientImpl.class);
    }

    @AfterEach
    void tearDown() {
        mockAPI.stop();
    }

    @Test
    void testIfSubmitSucceedsAsExpectedWhenAuthTokenIsFetchedAndTypeIsLead() throws IOException, InterruptedException {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("success"))
        );
        // stub form submission data
        String data = """
                {
                  "firstName": "John",
                  "lastName": "Doe",
                  "email": "john.doe@email.com",
                  "phone": "123-456-7890",
                  "address": {
                    "street": "123 Main St",
                    "city": "Melbourne",
                    "state": "VIC",
                    "postalCode": "3000"
                  }
                }
                """;
        // assert
        assertTrue(client.submit(data, "lead").contains("success"));
    }

    @Test
    void testIfSubmitSucceedsAsExpectedWhenAuthTokenIsFetchedAndTypeIsCampaign() throws IOException,
            InterruptedException {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for campaign submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(201).withBody("success"))
        );
        // stub form submission data
        String data = """
                {
                  "firstName": "John",
                  "lastName": "Doe",
                  "email": "john.doe@email.com",
                  "phone": "123-456-7890",
                  "address": {
                    "street": "123 Main St",
                    "city": "Melbourne",
                    "state": "VIC",
                    "postalCode": "3000"
                  }
                }
                """;
        // assert
        assertTrue(client.submit(data, "campaign").contains("success"));
    }

    @Test
    void testIfSubmitFailsAsExpectedWhenAuthTokenIsInvalidAndTypeIsLead() throws IOException, InterruptedException {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(403).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/lead"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(500).withBody("failed"))
        );
        // stub form submission data
        String data = """
                {
                  "firstName": "John",
                  "lastName": "Doe",
                  "email": "john.doe@email.com",
                  "phone": "123-456-7890",
                  "address": {
                    "street": "123 Main St",
                    "city": "Melbourne",
                    "state": "VIC",
                    "postalCode": "3000"
                  }
                }
                """;
        // assert
        assertTrue(client.submit(data, "lead").isBlank());
    }

    @Test
    void testIfSubmitFailsAsExpectedWhenAuthTokenIsInvalidAndTypeIsCampaign() throws IOException, InterruptedException {
        // stub API response for auth token retrieval
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/auth"))
                .withHeader("Content-Type", equalTo("application/x-www-form-urlencoded"))
                .willReturn(aResponse().withStatus(403).withHeader("Set-Cookie", "somerandomauthtoken"))
        );
        // stub API response for lead submission
        mockAPI.stubFor(post(urlEqualTo("/salesforce/v2/campaign"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withHeader("Cookie", equalTo("somerandomauthtoken"))
                .willReturn(aResponse().withStatus(500).withBody("failed"))
        );
        // stub form submission data
        String data = """
                {
                  "firstName": "John",
                  "lastName": "Doe",
                  "email": "john.doe@email.com",
                  "phone": "123-456-7890",
                  "address": {
                    "street": "123 Main St",
                    "city": "Melbourne",
                    "state": "VIC",
                    "postalCode": "3000"
                  }
                }
                """;
        // assert
        assertTrue(client.submit(data, "campaign").isBlank());
    }

}

package com.auspost.aemaacs.program.core.pojos;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(AemContextExtension.class)
class CardItemTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private CardItem model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/carditems/component.json", "/content/page/jcr:content/root");
    }

    @Test
    void testCardItemsInjectedSuccessfully() {
        ctx.currentResource("/content/page/jcr:content/root/cardItemsTest");
        model = ctx.currentResource().adaptTo(CardItem.class);

        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getCardImage());
            assertEquals("Card Item Title", model.getCardTitle());
            assertEquals("Category Label", model.getCardCategory().getText());
            assertEquals("grey", model.getCardCategory().getColour());
            assertEquals("rounded-edge", model.getCardImageStyle());
            assertTrue(model.getEnableLightBox());
            assertEquals("Light Box Image Caption", model.getLightboxImageCaption());
            assertNotNull(model.getCardDescription());
            assertEquals("03 August 2025", model.getIssueDate());
        });

    }

    @Test
    void testWhenValuesAresNotSet() {
        ctx.create().asset("/content/dam/wknd-shared/en/activities/camping/camp-summer-night.jpg", 1600, 900,
                "image/jpeg", "dc:title", "My Test Image Title");
        ctx.currentResource("/content/page/jcr:content/root/cardItemsImageNotSet");
        model = ctx.currentResource().adaptTo(CardItem.class);

        assertAll(() -> {
            assertNotNull(model);
            assertFalse(model.getEnableLightBox());
            assertNotNull(model.getCardImage());
            assertEquals("My Test Image Title", model.getLightboxImageCaption());
        });
    }

    @Test
    void testWhenLightBoxCaptionNotSetAndDamAssetTitleNotSet() {
        ctx.create().asset("/content/dam/wknd-shared/en/activities/camping/camp-summer-night.jpg", 1600, 900,
                "image/jpeg");
        ctx.currentResource("/content/page/jcr:content/root/LightboxImageCaptionNotSetAndDamAssetTitleNotPresent");
        model = ctx.currentResource().adaptTo(CardItem.class);

        assertAll(() -> {
            assertNotNull(model);
            assertFalse(model.getEnableLightBox());
            assertNotNull(model.getCardImage());
            assertNull(model.getLightboxImageCaption());
        });
    }
}

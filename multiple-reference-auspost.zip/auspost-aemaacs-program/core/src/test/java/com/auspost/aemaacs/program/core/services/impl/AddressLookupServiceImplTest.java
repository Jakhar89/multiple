package com.auspost.aemaacs.program.core.services.impl;

import com.auspost.aemaacs.program.core.services.AddressLookupService;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.http.Fault;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.http.impl.client.CloseableHttpClient;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static junit.framework.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
public class AddressLookupServiceImplTest {
    private final AemContext ctx = AppAemContext.newAemContext();

    private static WireMockServer wireMockServer;

    private static AddressLookupService addressLookupService;

    public static final String GET_DOMESTIC_ADDRESS_SUGGESTIONS_BODY = """
            {
                "total": 2,
                "entries": [
                    {
                        "address": "23 Maywood Crescent, CALAMVALE QLD 4116",
                        "moniker": "aWQ9MjMgTWF5d29vZCBDcmVzY2VudCwgQ0FMQU1WQUxFICBRTEQgNDExNiwgQXVzdHJhbGlhfmFsdF9rZXk9NjI4OTM0NjJ-ZGF0YXNldD1BVVNfUEFGfmZvcm1hdGlkPTc2MkFVUy1FT0FVU0hBVHBCd0FBQUFBSUFnRUFBQUFBbUVGWmdBQUFBQUFBQURJekFBRC4uMlFBQUFBQS4uLi4ud0FBQUFBQUFBQUFBQUFBQUFBQUFESXpJRzFoZVhkdmIyUUFBQUFBQUEtLX5xbD0xMH5nZW89MA"
                    },
                    {
                        "address": "23 Maywood Drive, EPPING VIC 3076",
                        "moniker": "aWQ9MjMgTWF5d29vZCBEcml2ZSwgRVBQSU5HICBWSUMgMzA3NiwgQXVzdHJhbGlhfmFsdF9rZXk9Njk1MTkwODF-ZGF0YXNldD1BVVNfUEFGfmZvcm1hdGlkPTc2MkFVUy1TT0FVU0hBVHBCd0FBQUFBSUFnRUFBQUFCTGM3VXdBQUFBQUFBQURJekFBRC4uMlFBQUFBQS4uLi4ud0FBQUFBQUFBQUFBQUFBQUFBQUFESXpJRzFoZVhkdmIyUUFBQUFBQUEtLX5xbD0xMH5nZW89MA"
                    }
                ]
            }
            """;
    private static final String GET_DOMESTIC_SUBURB_SUGGESTIONS_BODY = """
            {
                "more_results_available": false,
                "confidence": "No matches",
                "suggestions": [
                    {
                        "locality": {
                            "region": {
                                "name": "Victoria",
                                "code": "VIC"
                        },
                        "town": {
                            "name": "Wyndham Vale"
                        }
                    },
                    "postal_code": {
                        "full_name": "3024"
                    },
                    "postal_code_key": "aWQ9MzAyNCwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzAyNA",
                    "locality_key": "aWQ9V3luZGhhbSBWYWxlLCBWaWN0b3JpYSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1sb2NhbGl0eX5sb2NhbGl0eT1XeW5kaGFtIFZhbGUsIFZpY3RvcmlhfnBvc3RhbF9jb2RlPQ"
                }
                ]
            }""";

    private static final String GET_DOMESTIC_POSTCODE_SUGGESTIONS_BODY = """
            {
                    "more_results_available": false,
                    "confidence": "No matches",
                    "suggestions": [
                        {
                            "locality": {
                                "region": {
                                    "name": "Victoria",
                                    "code": "VIC"
                                },
                                "town": {
                                    "name": "Manor Lakes"
                                }
                            },
                            "postal_code": {
                                "full_name": "3024"
                            },
                            "postal_code_key": "aWQ9MzAyNCwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzAyNA",
                            "locality_key": "aWQ9TWFub3IgTGFrZXMsIFZpY3RvcmlhLCBBdXN0cmFsaWF-YWx0X2tleT1-ZGF0YXNldD1BVVNfUEFGfmZvcm1hdF9rZXk9QVVTJGF1LWFkZHJlc3MtYmV0YSQkJCQkfnBvcz0xfmdha190eXBlPWxvY2FsaXR5fmxvY2FsaXR5PU1hbm9yIExha2VzLCBWaWN0b3JpYX5wb3N0YWxfY29kZT0"
                        }
                    ]
                }
            """;

    @BeforeAll
    static void setupBeforeAll() {
        wireMockServer = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        wireMockServer.start();
    }

    @BeforeEach
    void setUp() throws IOException {
        Dictionary<String, String> config = new Hashtable<>() {{
            put("apiHost", "http://localhost:" + wireMockServer.port() + "/api");
            put("tokenHost", "http://localhost:" + wireMockServer.port() + "/token");
            put("clientID", "clientId123");
            put("clientSecret", "clientSecret123");
            put("audience", "audience");
            put("addressSuggestionEndpoint", "/address");
            put("postcodeOrSuburbSuggestionEndpoint", "/lookup");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AddressLookupServiceImpl")
                .update(config);
        addressLookupService = ctx.registerInjectActivateService(AddressLookupServiceImpl.class);
    }

    @Test
    void testIfExpectedResponseWhenDomesticAddressSuggestionCalledAndWithResponse() {

        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"mocked_token\"}")));

        wireMockServer.stubFor(get(urlPathEqualTo("/api/address")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody(GET_DOMESTIC_ADDRESS_SUGGESTIONS_BODY)));

        assertEquals(GET_DOMESTIC_ADDRESS_SUGGESTIONS_BODY,
                addressLookupService.getDomesticAddressSuggestion("23 Maywood Road"));
    }

    @Test
    void testIfExpectedResponseWhenDomesticAddressSuggestionCalledAndAddressApiRespondsIOException() {
        wireMockServer.stubFor(get(urlPathEqualTo("/api/address"))
                .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));

        String result = addressLookupService.getDomesticAddressSuggestion("test");
        assertEquals(EMPTY, result);
    }

    @Test
    void testIfExpectedResponseWhenDomesticAddressSuggestionCalledAndAddressApiRespondsUrlSyntaxException()
            throws NoSuchFieldException, IllegalAccessException {
        Field apiHostField = AddressLookupServiceImpl.class.getDeclaredField("apiHost");
        apiHostField.setAccessible(true);
        apiHostField.set(addressLookupService, "http://invalid_host^"); // Invalid character to cause URISyntaxException

        String result = addressLookupService.getDomesticAddressSuggestion("test");
        assertEquals(EMPTY, result);
    }

    @Test
    void testIfExpectedResponseWhenDomesticAddressSuggestionCalledAndApiBearerTokenRespondsIOException() {
        wireMockServer.stubFor(post(urlEqualTo("/token"))
                .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));

        wireMockServer.stubFor(get(urlPathEqualTo("/api/address"))
                .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));

        assertEquals(EMPTY, addressLookupService.getDomesticAddressSuggestion("23 Maywood Road"));

    }

    @Test
    void testGetApiBearerTokenReturnsEmptyOnTokenEndpointError() {
        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(500).withHeader("Content-Type", "application/json")
                        .withBody("{\"error\":\"Internal Server Error\"}")));

        assertTrue(addressLookupService.getDomesticAddressSuggestion("23 Maywood Road")
                .contains("404 Not Found"));
    }


    @Test
    void testIfExpectedResponseWhenGetDomesticPostCodeOrSuburbSuggestionCalledAndWithResponse() {
        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"mocked_token\"}")));

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody(GET_DOMESTIC_SUBURB_SUGGESTIONS_BODY)));

        assertEquals(GET_DOMESTIC_SUBURB_SUGGESTIONS_BODY,
                addressLookupService.getDomesticSuburbSuggestion("3024"));
    }

    @Test
    void testIfExpectedResponseWhenDomesticPostCodeSuggestionCalledAndWithResponse() {
        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"mocked_token\"}")));

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody(GET_DOMESTIC_POSTCODE_SUGGESTIONS_BODY)));

        assertEquals(GET_DOMESTIC_POSTCODE_SUGGESTIONS_BODY,
                addressLookupService.getDomesticPostCodeSuggestion("Manor Lakes"));
    }

    @Test
    void testIfExpectedResponseWhenDomesticSuburbSuggestionCalledAndAddressApiRespondsUrlSyntaxException()
            throws NoSuchFieldException, IllegalAccessException {
        Field apiHostField = AddressLookupServiceImpl.class.getDeclaredField("apiHost");
        apiHostField.setAccessible(true);
        apiHostField.set(addressLookupService,
                "https://invalid_host^"); // Invalid character to cause URISyntaxException

        String result = addressLookupService.getDomesticSuburbSuggestion("3024");
        assertEquals(EMPTY, result);
    }

    @Test
    void testIfExpectedResponseWhenDomesticSuburbSuggestionCalledAndAddressApiRespondsIOException() {
        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup"))
                .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));

        String result = addressLookupService.getDomesticSuburbSuggestion("3024");
        assertEquals(EMPTY, result);
    }

    @Test
    void testIfExpectedResponseWhenDomesticSuburbSuggestionCalledAndApiBearerTokenRespondsIOException() {
        wireMockServer.stubFor(post(urlEqualTo("/token"))
                .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup"))
                .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));

        assertEquals(EMPTY, addressLookupService.getDomesticSuburbSuggestion("3024"));
    }

    @Test
    void testIfExpectedResponseWhenDomesticSuburbSuggestionCalledAndRespondsIOException() {
        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"mocked_token\"}")));

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup"))
                .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));

        assertEquals(EMPTY, addressLookupService.getDomesticSuburbSuggestion("3024"));
    }

    @Test
    void testDomesticASuburbSuggestionReturnsApiResponseStringOnNonSuccessStatus() {
        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"mocked_token \r \n\"}")));

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup"))
                .willReturn(aResponse().withStatus(404).withHeader("Content-Type", "application/json")
                        .withBody("{\"error\":\"Not Found\"}")));

        assertTrue(addressLookupService.getDomesticSuburbSuggestion("3024")
                .contains("404 Not Found"));
    }

    @Test
    void testDeactivateClosesHttpClient() throws Exception {
        // Ensure httpClient is not null before deactivation
        Field httpClientField = AddressLookupServiceImpl.class.getDeclaredField("httpClient");
        httpClientField.setAccessible(true);
        Object httpClientBefore = httpClientField.get(addressLookupService);
        assertNotNull(httpClientBefore);

        // Before calling deactivation, httpClient should  not be null
        Method deactivateMethod = AddressLookupServiceImpl.class.getDeclaredMethod("deactivate");
        deactivateMethod.setAccessible(true);
        deactivateMethod.invoke(addressLookupService);

        // After calling deactivation, httpClient should be null
        Object httpClientAfter = httpClientField.get(addressLookupService);
        assertNull(httpClientAfter);

        // Try to use the service after httpClient is closed
        Exception exception = assertThrows(Exception.class, () -> {
            addressLookupService.getDomesticAddressSuggestion("test");
        });

        assertTrue(exception instanceof NullPointerException
                || exception.getCause() instanceof NullPointerException
                || exception.getCause() instanceof IllegalStateException);
    }

    @Test
    void testDeactivateHandlesIOExceptionOnClose() throws Exception {
        AddressLookupServiceImpl service = new AddressLookupServiceImpl();

        // Create mock that throws IOException on close
        CloseableHttpClient mockHttpClient = mock(CloseableHttpClient.class);
        doThrow(new IOException("Mock IO error")).when(mockHttpClient).close();

        // Inject mock into httpClient field
        Field httpClientField = AddressLookupServiceImpl.class.getDeclaredField("httpClient");
        httpClientField.setAccessible(true);
        httpClientField.set(service, mockHttpClient);

        // Call deactivate via reflection
        Method deactivateMethod = AddressLookupServiceImpl.class.getDeclaredMethod("deactivate");
        deactivateMethod.setAccessible(true);
        deactivateMethod.invoke(service);
    }

    @AfterAll
    static void tearDown() {
        wireMockServer.stop();
    }

}

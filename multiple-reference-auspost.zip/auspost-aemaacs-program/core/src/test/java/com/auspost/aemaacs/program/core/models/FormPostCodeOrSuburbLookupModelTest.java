package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.services.AddressLookupService;
import com.auspost.aemaacs.program.core.services.impl.AddressLookupServiceImpl;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static junitx.framework.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
public class FormPostCodeOrSuburbLookupModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private FormPostCodeOrSuburbLookupModel model;

    private static WireMockServer wireMockServer;

    private AddressLookupService addressLookupService;

    private final ObjectMapper MAPPER = new ObjectMapper();

    private static final String GET_DOMESTIC_SUBURB_SUGGESTIONS_BODY = "{\n" +
            "  \"postCodeOrSuburbSuggestionList\": {\n" +
            "    \"more_results_available\": false,\n" +
            "    \"confidence\": \"No matches\",\n" +
            "    \"suggestions\": [\n" +
            "      {\n" +
            "        \"locality\": {\n" +
            "          \"region\": {\n" +
            "            \"name\": \"Victoria\",\n" +
            "            \"code\": \"VIC\"\n" +
            "          },\n" +
            "          \"town\": {\n" +
            "            \"name\": \"Wyndham Vale\"\n" +
            "          }\n" +
            "        },\n" +
            "        \"postal_code\": {\n" +
            "          \"full_name\": \"3024\"\n" +
            "        },\n" +
            "        \"postal_code_key\": \"aWQ9MzAyNCwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzAyNA\",\n" +
            "        \"locality_key\": \"aWQ9V3luZGhhbSBWYWxlLCBWaWN0b3JpYSwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1sb2NhbGl0eX5sb2NhbGl0eT1XeW5kaGFtIFZhbGUsIFZpY3RvcmlhfnBvc3RhbF9jb2RlPQ\"\n" +
            "      }\n" +
            "    ]\n" +
            "  }\n" +
            "}";


    private static final String GET_DOMESTIC_POSTCODE_SUGGESTIONS_BODY = "{\n" +
            "    \"postCodeOrSuburbSuggestionList\": {\n" +
            "        \"more_results_available\": false,\n" +
            "        \"confidence\": \"No matches\",\n" +
            "        \"suggestions\": [\n" +
            "            {\n" +
            "                \"locality\": {\n" +
            "                    \"region\": {\n" +
            "                        \"name\": \"Victoria\",\n" +
            "                        \"code\": \"VIC\"\n" +
            "                    },\n" +
            "                    \"town\": {\n" +
            "                        \"name\": \"Manor Lakes\"\n" +
            "                    }\n" +
            "                },\n" +
            "                \"postal_code\": {\n" +
            "                    \"full_name\": \"3024\"\n" +
            "                },\n" +
            "                \"postal_code_key\": \"aWQ9MzAyNCwgQXVzdHJhbGlhfmFsdF9rZXk9fmRhdGFzZXQ9QVVTX1BBRn5mb3JtYXRfa2V5PUFVUyRhdS1hZGRyZXNzLWJldGEkJCQkJH5wb3M9MX5nYWtfdHlwZT1wb3N0YWxfY29kZX5sb2NhbGl0eT1-cG9zdGFsX2NvZGU9MzAyNA\",\n" +
            "                \"locality_key\": \"aWQ9TWFub3IgTGFrZXMsIFZpY3RvcmlhLCBBdXN0cmFsaWF-YWx0X2tleT1-ZGF0YXNldD1BVVNfUEFGfmZvcm1hdF9rZXk9QVVTJGF1LWFkZHJlc3MtYmV0YSQkJCQkfnBvcz0xfmdha190eXBlPWxvY2FsaXR5fmxvY2FsaXR5PU1hbm9yIExha2VzLCBWaWN0b3JpYX5wb3N0YWxfY29kZT0\"\n" +
            "            }\n" +
            "        ]\n" +
            "    }\n" +
            "}";

    @BeforeAll
    static void setupBeforeAll() {
        wireMockServer = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        wireMockServer.start();
    }

    @BeforeEach
    void setUp() throws IOException {
        Dictionary<String, String> config = new Hashtable<>() {{
            put("apiHost", "http://localhost:" + wireMockServer.port() + "/api");
            put("tokenHost", "http://localhost:" + wireMockServer.port() + "/token");
            put("clientID", "clientId123");
            put("clientSecret", "clientSecret123");
            put("audience", "audience");
            put("addressSuggestionEndpoint", "/address");
            put("postcodeOrSuburbSuggestionEndpoint", "/lookup");
        }};
        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AddressLookupServiceImpl")
                .update(config);
        ctx.create().page("/content/page");
        ctx.load().json("/models/formpostcodeorsuburblookup/component.json", "/content/page/jcr:content/content");

        wireMockServer.stubFor(post(urlEqualTo("/token")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"mocked_token\"}")));

    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpected() {
        ctx.registerInjectActivateService(new AddressLookupServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/postcodeorsuburblookup");
        model = ctx.request().adaptTo(FormPostCodeOrSuburbLookupModel.class);
        ctx.request().setQueryString("postcode=3024");

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody(GET_DOMESTIC_SUBURB_SUGGESTIONS_BODY)));

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("PostCode or SuburbLookup Title", model.getTitle());
            assertEquals("Test Required Message", model.getRequiredMessage());
            assertNotNull(model.getId());
            assertEquals("Help text message", model.getHelpMessage());
            assertEquals("/content/page/_jcr_content/content/postcodeorsuburblookup.model.json",
                    model.getResourcePath());
            assertEquals(MAPPER.readTree(GET_DOMESTIC_SUBURB_SUGGESTIONS_BODY),
                    MAPPER.readTree(model.getPostCodeOrSuburbSuggestionList().toString()));
        });
    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpectedForPostCodeSearch() {
        ctx.registerInjectActivateService(new AddressLookupServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/postcodeorsuburblookup");
        model = ctx.request().adaptTo(FormPostCodeOrSuburbLookupModel.class);
        ctx.request().setQueryString("suburb=Manor Lakes");

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody(GET_DOMESTIC_POSTCODE_SUGGESTIONS_BODY)));

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("PostCode or SuburbLookup Title", model.getTitle());
            assertNotNull(model.getId());
            assertEquals("Help text message", model.getHelpMessage());
            assertEquals("/content/page/_jcr_content/content/postcodeorsuburblookup.model.json",
                    model.getResourcePath());
            assertEquals(MAPPER.readTree(GET_DOMESTIC_POSTCODE_SUGGESTIONS_BODY),
                    MAPPER.readTree(model.getPostCodeOrSuburbSuggestionList().toString()));
        });
    }


    @Test
    void testAllComponentsValuesAreInjectingAsExpectedWithoutSearchText() {
        ctx.registerInjectActivateService(new AddressLookupServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/postcodeorsuburblookup");
        model = ctx.request().adaptTo(FormPostCodeOrSuburbLookupModel.class);

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("PostCode or SuburbLookup Title", model.getTitle());
            assertEquals("Test Required Message", model.getRequiredMessage());
            assertNotNull(model.getId());
            assertEquals("Help text message", model.getHelpMessage());
            assertEquals("/content/page/_jcr_content/content/postcodeorsuburblookup.model.json",
                    model.getResourcePath());
            assertEquals("{\"error\":\"No search parameters provided, provide suburb or postcode\"}",
                    model.getPostCodeOrSuburbSuggestionList().toString());
        });
    }

    @Test
    void testGetSuburbSuggestionListHandlesJsonProcessingException() {
        ctx.registerInjectActivateService(new AddressLookupServiceImpl());
        ctx.currentResource("/content/page/jcr:content/content/postcodeorsuburblookup");
        model = ctx.request().adaptTo(FormPostCodeOrSuburbLookupModel.class);
        ctx.request().setQueryString("postcode=3024");

        wireMockServer.stubFor(post(urlPathEqualTo("/api/lookup")).willReturn(
                aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{")));

        Assertions.assertEquals("{\"error\":\"Service Error\"}", model.getPostCodeOrSuburbSuggestionList().toString());
    }


    @AfterAll
    static void tearDown() {
        wireMockServer.stop();
    }

}

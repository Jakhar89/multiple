package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.scripting.SlingBindings;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
public class IpgModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private final SlingBindings bindings = new SlingBindings();

    private IpgModel model;

    @BeforeEach
    void setUp() {
        Map<String, Object>
                props = Map.of("sling:resourceSuperType", "core/wcm/components/list/v4/list");
        ctx.create().resource("/apps/auspost-aemaacs-program/components/ipg", props);
        ctx.load().json("/models/ipg/component.json", "/content/home");
        ctx.currentPage("/content/home");

        Style style = mock(Style.class);
        bindings.put(WCMBindingsConstants.NAME_CURRENT_STYLE, style);
        bindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, ctx.currentPage());
    }

    @Test
    void testIpgWithPopularAndAllCountriesConfigured() {
        ctx.currentResource("/content/home/jcr:content/ipgVariant1");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(IpgModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("/content/home/_jcr_content/ipgVariant1.model.json", model.getResourcePath());
            assertEquals("Title", model.getTitle());
            assertEquals("Error Text Message", model.getErrorText());
            assertEquals(3, model.getPopularDestinations().size());
            assertEquals(3, model.getAllCountries().size());
        });
    }

    @Test
    void testIpgWithOutPopularCountriesConfigured() {
        ctx.currentResource("/content/home/jcr:content/ipgVariant2");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(IpgModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(0, model.getPopularDestinations().size());
            assertEquals(3, model.getAllCountries().size());
        });
    }

    @Test
    void testIpgWithNoCountryPagesAndNoPopularDestinationsPresent() {
        ctx.currentResource("/content/home/jcr:content/ipgVariant3");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(IpgModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(0, model.getPopularDestinations().size());
            assertEquals(0, model.getAllCountries().size());
        });
    }

    @Test
    void testIpgWithInvalidListObjectWithValidPopulatDestinationsConfigured() {
        ctx.currentResource("/content/home/jcr:content/ipgVariant4");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(IpgModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(3, model.getPopularDestinations().size());
            assertEquals(0, model.getAllCountries().size());
        });
    }

    @Test
    void testIpgWithOutPopularCountriesNull() {
        ctx.currentResource("/content/home/jcr:content/ipgVariant5");
        bindings.put(WCMBindingsConstants.NAME_PROPERTIES, Objects.requireNonNull(ctx.currentResource()).getValueMap());
        ctx.request().setAttribute(SlingBindings.class.getName(), bindings);
        model = ctx.request().adaptTo(IpgModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(0, model.getPopularDestinations().size());
            assertEquals(3, model.getAllCountries().size());
        });
    }


}

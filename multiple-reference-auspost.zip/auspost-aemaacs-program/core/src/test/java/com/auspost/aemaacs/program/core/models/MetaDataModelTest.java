package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.services.impl.AuspostDomainMapperServiceImpl;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.commons.Externalizer;
import com.day.cq.tagging.TagConstants;
import io.wcm.testing.mock.aem.MockExternalizer;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.osgi.service.cm.ConfigurationAdmin;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Objects;
import java.util.Optional;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(AemContextExtension.class)
class MetaDataModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private MetaDataModel model;

    @BeforeEach
    void setUp() throws IOException {
        Dictionary<String, String[]> domainMapperProps = new Hashtable<>();
        String[] domainsJson = {
                "{\"name\":\"collectables\",\"paths\":[\"/content/collectables/au/en\",\"/content/dam/collectables\"]}",
                "{\"name\":\"auspost\",\"paths\":[\"/content/auspost/au/en\",\"/content/dam/auspost\"]}"
        };
        domainMapperProps.put("domains", domainsJson);

        ConfigurationAdmin configurationAdmin = ctx.getService(ConfigurationAdmin.class);
        Objects.requireNonNull(configurationAdmin)
                .getConfiguration("com.auspost.aemaacs.program.core.services.impl.AuspostDomainMapperServiceImpl")
                .update(domainMapperProps);

        Optional.ofNullable(ctx.getService(Externalizer.class)).ifPresent((externalizer -> {
            if (externalizer instanceof MockExternalizer) {
                ((MockExternalizer) externalizer).setMapping("collectables", "https://collectables.auspost.com.au");
                ((MockExternalizer) externalizer).setMapping("auspost", "https://auspost.com.au");
                ((MockExternalizer) externalizer).setMapping("publish", "http://localhost:4503");
            }
        }));
        ctx.registerInjectActivateService(AuspostDomainMapperServiceImpl.class);
    }

    @Test
    void testIfAllMetaDataItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndGetImagePathFromBannerForCollectables() {
        ctx.load().json("/models/metadata/component.json", "/content/collectables/au/en");
        ctx.currentResource("/content/collectables/au/en/page1");
        model = ctx.request().adaptTo(MetaDataModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test Page 1", model.getOgTitle());
            assertEquals("Test description for Page 1", model.getOgDescription());
            assertEquals("https://collectables.auspost.com.au/content/dam/collectables/imagePathFromBanner.jpg",
                    model.getOgImagePath());
            assertEquals("https://collectables.auspost.com.au/content/collectables/au/en/page1.html", model.getOgUrl());
        });
    }

    @Test
    void testIfAllMetaDataItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedForAuspost() {
        ctx.load().json("/models/metadata/component.json", "/content/auspost/au/en");
        ctx.currentResource("/content/auspost/au/en/page4");
        model = ctx.request().adaptTo(MetaDataModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test Page 4", model.getOgTitle());
            assertEquals("Test description for Page 4", model.getOgDescription());
            assertEquals("https://auspost.com.au/content/dam/auspost/pageContentImage.jpg",
                    model.getOgImagePath());
            assertEquals("https://auspost.com.au/content/auspost/au/en/page4.html", model.getOgUrl());
        });
    }

    @Test
    void testIfAllMetaDataItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedForLocal() {
        ctx.load().json("/models/metadata/component.json", "/content/dummy");
        ctx.currentResource("/content/dummy/page5");
        model = ctx.request().adaptTo(MetaDataModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test Page 5", model.getOgTitle());
            assertEquals("Test description for Page 5", model.getOgDescription());
            assertEquals("http://localhost:4503/content/dam/dummy/pageContentImage.jpg",
                    model.getOgImagePath());
            assertEquals("http://localhost:4503/content/dummy/page5.html", model.getOgUrl());
        });
    }

    @Test
    void testIfAllMetaDataItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndGetImagePathFromPageProperty() {
        ctx.load().json("/models/metadata/component.json", "/content/collectables/au/en");
        ctx.currentResource("/content/collectables/au/en/page2");
        model = ctx.request().adaptTo(MetaDataModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test Page 2", model.getOgTitle());
            assertEquals("Test description for Page 2", model.getOgDescription());
            assertEquals(
                    "https://collectables.auspost.com.au/content/dam/collectables/pagePropertyImage.jpg",
                    model.getOgImagePath());
            assertEquals("https://collectables.auspost.com.au/content/collectables/au/en/page2.html", model.getOgUrl());
        });
    }

    @Test
    void testIfAllMetaDataItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndGetImagePathFromPageContent() {
        ctx.load().json("/models/metadata/component.json", "/content/collectables/au/en");
        ctx.currentResource("/content/collectables/au/en/page3");
        model = ctx.request().adaptTo(MetaDataModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Test Page 3", model.getOgTitle());
            assertEquals("Test description for Page 3", model.getOgDescription());
            assertEquals("https://collectables.auspost.com.au/content/dam/collectables/pageContentImage.jpg",
                    model.getOgImagePath());
            assertEquals("https://collectables.auspost.com.au/content/collectables/au/en/page3.html", model.getOgUrl());
        });
    }

    @Test
    void testIfTagsArePopulated() {
        ctx.load().json("/models/metadata/component.json", "/content/collectables/au/en");
        ctx.currentResource("/content/collectables/au/en/page1");
        ctx.load().json("/models/metadata/tags.json", TagConstants.TAG_ROOT_PATH);
        model = ctx.request().adaptTo(MetaDataModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("product:concession-post,booklet-collection | year:2025,2024 | theme:animal,art",
                    model.getTags());
        });
    }

    @Test
    void testIfTagsNoArePopulated() {
        ctx.load().json("/models/metadata/component.json", "/content/auspost/au/en");
        ctx.currentResource("/content/auspost/au/en/page2");
        ctx.load().json("/models/metadata/tags.json", TagConstants.TAG_ROOT_PATH);
        model = ctx.request().adaptTo(MetaDataModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getTags());
        });
    }
}

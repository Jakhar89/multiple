package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(AemContextExtension.class)
class PromoCardModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private PromoCardModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/promocard/component.json", "/content/page/jcr:content/content");
        ctx.load().json("/models/banner/assets.json", "/content/dam/collectables/stamp-bulletin");
        ctx.currentResource("/content/page/jcr:content/content/promocard");
        model = ctx.request().adaptTo(PromoCardModel.class);
    }

    @Test
    void testAllComponentsValuesAreInjectingAsExpected() {
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("Promo Card Title", model.getCardItem().getCardTitle());
            assertEquals("Promo-Card-ID", model.getId());
            assertTrue(model.getCardItem().getEnableLightBox());
            assertEquals("04 August 2025", model.getCardDate());
            assertEquals("Label", model.getCardItem().getCardCategory().getText());
            assertEquals("promocard--category-grey", model.getCardItem().getCardCategory().getColour());
            assertEquals("rounded-edge", model.getCardItem().getCardImageStyle());
            assertNotNull(model.getCardItem().getCardImage());
            assertNotNull(model.getCardItem().getCardDescription());
            assertNotNull(model.getCardItem().getCardImage());

            // Primary CTAs config
            assertEquals("Primary CTA Text", model.getPrimaryCta().getLabel());
            assertEquals("/content/dam/abcd", model.getPrimaryCta().getLinkURL());
            assertEquals("_blank", model.getPrimaryCta().getLinkTarget());
            assertEquals("arrow-right-thin.svg", model.getPrimaryCta().getIconRight());
            assertEquals(EMPTY, model.getPrimaryCta().getAssetTypeAndSize());

            // secondary CTAs config
            assertEquals("Cta Secondary Label", model.getSecondaryCta().getLabel());
            assertEquals("/content/dam/collectables/stamp-bulletin/stamp-bulletin-1.pdf",
                    model.getSecondaryCta().getLinkURL());
            assertEquals("_self", model.getSecondaryCta().getLinkTarget());
            assertEquals("(PDF, 5 MB)", model.getSecondaryCta().getAssetTypeAndSize());
        });
    }

    @Test
    void testIfDataLayerIsPopulatedWhenDataLayerConfigIsEnabled() {
        assertAll(() -> {
            assertNotNull(model);
            assertNotNull(model.getDataLayer());
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/promocard/datalayer.json"),
                    model.getDataLayer());
            assertEquals(
                    "{\"Promo-Card-ID-primary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"promoCard||cta\",\"eventDescription\":\"promo-card-title:primary-cta-text\"}}",
                    model.getPrimaryCta().getDataLayer());
            assertEquals(
                    "{\"Promo-Card-ID-secondary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"promoCard||cta\",\"eventDescription\":\"promo-card-title:cta-secondary-label\"}}",
                    model.getSecondaryCta().getDataLayer());
        });
    }

    @Test
    void testGetDataWhenDataLayerDisabled() {
        AemContext dataLayerDisabled = AppAemContext.newAemContextWithDataLayerDisabled();
        dataLayerDisabled.create().page("/content/page");
        dataLayerDisabled.load().json("/models/promocard/component.json", "/content/page/jcr:content/content");
        dataLayerDisabled.currentResource("/content/page/jcr:content/content/promocard_dataLayerDisabled");
        PromoCardModel promoCardModel = dataLayerDisabled.request().adaptTo(PromoCardModel.class);
        assertAll(() -> {
            assertNotNull(promoCardModel);
            assertNotNull(promoCardModel.getDataLayer());
            assertEquals(StringUtils.EMPTY, promoCardModel.getDataLayer());
        });
    }

    @Test
    void testIfAllPromoCardItemsAreInstantiatedAsExpectedWhenOnlySomeValuesAreInjected() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "promocard", "cardTitle", "Promo Card Title");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(PromoCardModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getPrimaryCta());
            assertNull(model.getSecondaryCta());
            assertEquals("Promo Card Title", model.getCardItem().getCardTitle());
        });
    }
}

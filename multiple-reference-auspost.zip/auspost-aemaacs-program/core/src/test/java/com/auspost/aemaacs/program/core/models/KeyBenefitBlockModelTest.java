package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.pojos.ButtonItem;
import com.auspost.aemaacs.program.core.pojos.IconItem;
import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import junit.framework.Assert;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.List;

import static com.auspost.aemaacs.program.core.constants.Constants.EMPTY;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(AemContextExtension.class)
class KeyBenefitBlockModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private KeyBenefitBlockModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/keybenefitblock/component.json", "/content/page/jcr:content/keyBenefitBlock");
    }

    @Test
    void testIfAllKeyBenefitBlockItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/keyBenefitBlock");
        model = ctx.request().adaptTo(KeyBenefitBlockModel.class);

        assertAll(() -> {
            assertNotNull(model);
            assertEquals("123", model.getId());
            assertEquals("Key Benefit Title", model.getTitle());
            assertEquals("Key Benefit Description", model.getDescription());

            assertNotNull(model.getKeyBenefitImage());
            assertEquals(
                    "/content/page/jcr:content/keyBenefitBlock/cq:featuredimage",
                    model.getKeyBenefitImage().getPath());

            List<ButtonItem> ctas = model.getCta();
            Assert.assertNotNull(ctas);
            Assert.assertEquals(1, ctas.size());
            ButtonItem primaryCta = ctas.get(0);

            assertEquals("Primary CTA Label", primaryCta.getLabel());
            assertEquals("/content/collectables/au/en/test/key", primaryCta.getLinkURL());
            assertEquals("_self", primaryCta.getLinkTarget());
            assertEquals("primaryCta", primaryCta.getButtonType());
            assertEquals("arrow-right-thin", primaryCta.getIconRight());

            List<IconItem> bullets = model.getBulletList();
            Assert.assertNotNull(bullets);
            Assert.assertEquals(1, bullets.size());

            IconItem bullet = bullets.get(0);
            assertEquals("green", bullet.getIconTheme());
            assertEquals("Bullet 1 Description", bullet.getIconDescription());
            assertEquals("phone", bullet.getIcon());
        });
    }

    @Test
    void testIfAllKeyBenefitBlockItemsAreBuiltAsExpectedWhenOnlySomeValuesAreConfigured() {
        Page page = ctx.create().page("/content/page");
        Resource resource = ctx.create().resource(page, "keybenefitblocks", "keybenefitblocks", "some keybenefitblocks items");
        ctx.currentResource(resource);
        model = ctx.request().adaptTo(KeyBenefitBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertNull(model.getTitle());
        });
    }

    @Test
    void testIfDataLayerIsBuiltAsExpectedWhenKeyBenefitBlockItemsAreInstantiatedAsExpected() {
        ctx.currentResource("/content/page/jcr:content/keyBenefitBlock");
        model = ctx.request().adaptTo(KeyBenefitBlockModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals(EMPTY, model.getDataLayer());
            List<ButtonItem> ctas = model.getCta();
            Assert.assertNotNull(ctas);
            Assert.assertEquals(1, ctas.size());
            ButtonItem primaryCta = ctas.get(0);
            assertEquals(AppAemContext.getExpectedDataLayerJson("/models/keybenefitblock/datalayer.json"),
                    primaryCta.getDataLayer());
            assertEquals(
                    "{\"123-primary-cta-label-primary-cta\":{\"event\":\"site_interaction\",\"eventCategory\":\"keybenefit||cta\",\"eventDescription\":\"primary-cta-label\"}}",
                    primaryCta.getDataLayer());
        });
    }
}

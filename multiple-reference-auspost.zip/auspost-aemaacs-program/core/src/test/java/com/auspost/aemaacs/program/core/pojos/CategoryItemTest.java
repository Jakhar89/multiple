package com.auspost.aemaacs.program.core.pojos;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * @author Seeni Rajan
 */
class CategoryItemTest {

    @Test
    void testTagItemConstructorAndGetters() {
        CategoryItem tagItem = new CategoryItem("red", "Urgent");
        assertEquals("red", tagItem.getColour());
        assertEquals("Urgent", tagItem.getText());
    }

    @Test
    void testTagItemWithNullValues() {
        CategoryItem tagItem = new CategoryItem(null, null);
        assertNull(tagItem.getColour());
        assertNull(tagItem.getText());
    }
}

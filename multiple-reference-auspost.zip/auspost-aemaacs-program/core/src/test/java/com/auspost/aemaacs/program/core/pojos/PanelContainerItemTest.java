package com.auspost.aemaacs.program.core.pojos;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * @author Seeni Rajan
 */
class PanelContainerItemTest {

    @Test
    void testConstructorAndGetters() {
        Resource mockResource = Mockito.mock(Resource.class);
        PanelContainerItem item = new PanelContainerItem("id1", "Title", "Name", mockResource);

        assertEquals("id1", item.getId());
        assertEquals("Title", item.getTitle());
        assertEquals("Name", item.getName());
        assertEquals(mockResource, item.getResource());
        assertNull(item.getDataLayer());
    }

    @Test
    void testSetters() {
        PanelContainerItem item = new PanelContainerItem(null, null, null, null);
        Resource mockResource = Mockito.mock(Resource.class);

        item.setId("id2");
        item.setTitle("New Title");
        item.setName("New Name");
        item.setResource(mockResource);
        item.setDataLayer("dataLayerValue");

        assertEquals("id2", item.getId());
        assertEquals("New Title", item.getTitle());
        assertEquals("New Name", item.getName());
        assertEquals(mockResource, item.getResource());
        assertEquals("dataLayerValue", item.getDataLayer());
    }

}

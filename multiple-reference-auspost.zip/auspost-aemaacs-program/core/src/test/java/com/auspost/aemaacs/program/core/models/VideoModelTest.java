package com.auspost.aemaacs.program.core.models;

import com.auspost.aemaacs.program.core.testcontext.AppAemContext;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * @author Seeni Rajan
 */
@ExtendWith(AemContextExtension.class)
class VideoModelTest {

    private final AemContext ctx = AppAemContext.newAemContext();

    private VideoModel model;

    @BeforeEach
    void setUp() {
        ctx.create().page("/content/page");
        ctx.load().json("/models/video/component.json", "/content/page/jcr:content/video");
    }

    @Test
    void testIfAllVideoItemsAreInstantiatedAsExpectedWhenAllValuesAreInjected() {
        ctx.currentResource("/content/page/jcr:content/video/withId");
        model = ctx.request().adaptTo(VideoModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("vudoo", model.getVideoType());
            assertEquals("13764241248", model.getVideoId());
            assertEquals("video_Id", model.getId());
            assertEquals("test transcript", model.getTranscript());
        });
    }

    @Test
    void testIfAllVideoItemsAreInstantiatedAsExpectedWhenAllValuesAreInjectedAndVideoIdIsNull() {
        ctx.currentResource("/content/page/jcr:content/video/withoutId");
        model = ctx.request().adaptTo(VideoModel.class);
        assertAll(() -> {
            assertNotNull(model);
            assertEquals("video-5a712249eb", model.getId());
        });
    }
}

(function($) {
    "use strict";

    var dialogContentSelector = ".cmp-download__editor";
    var titleCheckboxSelector = 'coral-checkbox[name="./titleFromAsset"]';
    var titleTextfieldSelector = 'input[name="./jcr:title"]';

    var CheckboxTextfieldTuple = window.CQ.CoreComponents.CheckboxTextfieldTuple.v1;
    var titleTuple;
    var fileReference;
    var $cqFileUpload;
    var $cqFileUploadEdit;

    $(document).on("dialog-loaded", function(e) {
        var $dialog = e.dialog;
        var $dialogContent = $dialog.find(dialogContentSelector);
        var dialogContent = $dialogContent.length > 0 ? $dialogContent[0] : undefined;

        if (dialogContent) {
            init($dialog, dialogContent);
        }
    });

    // Initialize fields
    function init($dialog, dialogContent) {
        // Only title tuple now
        titleTuple = new CheckboxTextfieldTuple(dialogContent, titleCheckboxSelector, titleTextfieldSelector, false);

        $cqFileUpload     = $dialog.find(".cq-FileUpload");
        $cqFileUploadEdit = $dialog.find(".cq-FileUpload-edit");

        if ($cqFileUpload) {
            $cqFileUpload.on("assetselected", function(e) {
                fileReference = e.path;
                retrieveDAMInfo(fileReference).then(function() {
                    titleTuple.reinitCheckbox();
                });
            });

            $cqFileUpload.on("click", "[coral-fileupload-clear]", function() {
                titleTuple.reset();
            });
        }

        if ($cqFileUploadEdit) {
            fileReference = $cqFileUploadEdit.data("cqFileuploadFilereference");
            if (fileReference === "") {
                fileReference = undefined;
            }
            if (fileReference) {
                retrieveDAMInfo(fileReference);
            }
        }
    }

    $(window).on("focus", function() {
        if (fileReference) {
            retrieveDAMInfo(fileReference);
        }
    });

    function retrieveDAMInfo(fileReference) {
        return $.ajax({
            url: fileReference + "/_jcr_content/metadata.json"
        }).done(function(data) {
            if (data && titleTuple) {
                var title = data["dc:title"];
                titleTuple.seedTextValue(title);
                titleTuple.update();
            }
        });
    }
})(jQuery);
